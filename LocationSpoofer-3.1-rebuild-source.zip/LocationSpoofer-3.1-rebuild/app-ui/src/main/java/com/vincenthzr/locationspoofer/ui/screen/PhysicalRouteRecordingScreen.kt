package com.vincenthzr.locationspoofer.ui.screen

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.vincenthzr.locationspoofer.data.recording.PhysicalRouteCommand
import com.vincenthzr.locationspoofer.data.recording.PhysicalRouteIssue
import com.vincenthzr.locationspoofer.data.recording.PhysicalRoutePhase
import com.vincenthzr.locationspoofer.data.recording.PhysicalRouteRecorder
import com.vincenthzr.locationspoofer.ui.R
import kotlinx.coroutines.launch
import org.koin.compose.koinInject
import java.util.Locale

/**
 * 物理路线录制界面（本项目的 UI 实现）。
 * 采集由 :service 的前台服务完成；本页只负责下发命令与展示/保存草稿。
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PhysicalRouteRecordingScreen(onClose: () -> Unit) {
    val recorder = koinInject<PhysicalRouteRecorder>()
    val state by recorder.state.collectAsState()
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    var name by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    var showDiscardConfirm by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) recorder.request(PhysicalRouteCommand.START)
        else message = context.getString(R.string.physical_route_issue_permission)
    }

    fun startRecording() {
        val granted = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION,
        ) == PackageManager.PERMISSION_GRANTED
        if (granted) recorder.request(PhysicalRouteCommand.START)
        else permissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.physical_route_title)) },
                navigationIcon = {
                    IconButton(onClick = onClose) {
                        Icon(Icons.Filled.Close, contentDescription = null)
                    }
                },
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Text(
                        text = when (state.phase) {
                            PhysicalRoutePhase.IDLE -> stringResource(R.string.physical_route_start)
                            PhysicalRoutePhase.RECORDING -> stringResource(R.string.physical_route_finish)
                            PhysicalRoutePhase.PAUSED -> stringResource(R.string.physical_route_pause)
                            PhysicalRoutePhase.FINISHED -> stringResource(R.string.physical_route_save)
                        },
                        style = MaterialTheme.typography.titleMedium,
                    )
                    Text(stringResource(R.string.physical_route_distance, formatDistance(state.distanceM)))
                    Text(stringResource(R.string.physical_route_duration, formatDuration(state.durationMillis)))
                    Text(stringResource(R.string.physical_route_points, state.points.size))
                    state.accuracyM?.let {
                        Text(String.format(Locale.US, "±%.1f m", it), style = MaterialTheme.typography.bodySmall)
                    }
                    issueText(state.issue)?.let {
                        Text(
                            text = it,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                    message?.let {
                        Text(it, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            when (state.phase) {
                PhysicalRoutePhase.IDLE -> {
                    Button(
                        onClick = { startRecording() },
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text(stringResource(R.string.physical_route_start))
                    }
                }

                PhysicalRoutePhase.RECORDING -> {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(
                            onClick = { recorder.request(PhysicalRouteCommand.PAUSE) },
                            modifier = Modifier.weight(1f),
                        ) {
                            Text(stringResource(R.string.physical_route_pause))
                        }
                        Button(
                            onClick = { recorder.request(PhysicalRouteCommand.FINISH) },
                            modifier = Modifier.weight(1f),
                        ) {
                            Text(stringResource(R.string.physical_route_finish))
                        }
                    }
                }

                PhysicalRoutePhase.PAUSED -> {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = { recorder.request(PhysicalRouteCommand.RESUME) },
                            modifier = Modifier.weight(1f),
                        ) {
                            Text(stringResource(R.string.physical_route_resume))
                        }
                        OutlinedButton(
                            onClick = { showDiscardConfirm = true },
                            modifier = Modifier.weight(1f),
                        ) {
                            Text(stringResource(R.string.physical_route_discard))
                        }
                    }
                    OutlinedButton(
                        onClick = { recorder.request(PhysicalRouteCommand.FINISH) },
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text(stringResource(R.string.physical_route_finish))
                    }
                }

                PhysicalRoutePhase.FINISHED -> {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text(stringResource(R.string.physical_route_name_hint)) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = {
                                scope.launch {
                                    val ok = recorder.save(name)
                                    message = context.getString(
                                        if (ok) R.string.physical_route_saved else R.string.physical_route_save_failed
                                    )
                                    if (ok) name = ""
                                }
                            },
                            enabled = name.isNotBlank() && !state.saving,
                            modifier = Modifier.weight(1f),
                        ) {
                            Text(stringResource(R.string.physical_route_save))
                        }
                        OutlinedButton(
                            onClick = { showDiscardConfirm = true },
                            modifier = Modifier.weight(1f),
                        ) {
                            Text(stringResource(R.string.physical_route_discard))
                        }
                    }
                }
            }
        }
    }

    if (showDiscardConfirm) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showDiscardConfirm = false },
            title = { Text(stringResource(R.string.physical_route_discard)) },
            text = { Text(stringResource(R.string.physical_route_discard_confirm)) },
            confirmButton = {
                androidx.compose.material3.TextButton(
                    onClick = {
                        showDiscardConfirm = false
                        scope.launch {
                            val ok = recorder.discard()
                            message = if (ok) {
                                context.getString(R.string.physical_route_discarded)
                            } else {
                                context.getString(R.string.physical_route_save_failed)
                            }
                        }
                    }
                ) {
                    Text(
                        stringResource(R.string.delete),
                        color = MaterialTheme.colorScheme.error
                    )
                }
            },
            dismissButton = {
                androidx.compose.material3.TextButton(
                    onClick = { showDiscardConfirm = false }
                ) {
                    Text(stringResource(R.string.cancel))
                }
            }
        )
    }
}

@Composable
private fun issueText(issue: PhysicalRouteIssue): String? = when (issue) {
    PhysicalRouteIssue.NONE -> null
    PhysicalRouteIssue.WAITING -> stringResource(R.string.physical_route_issue_waiting)
    PhysicalRouteIssue.GPS_OFF -> stringResource(R.string.physical_route_issue_gps_off)
    PhysicalRouteIssue.SIMULATION_ACTIVE -> stringResource(R.string.physical_route_issue_simulation)
    PhysicalRouteIssue.PERMISSION -> stringResource(R.string.physical_route_issue_permission)
    PhysicalRouteIssue.STORAGE -> stringResource(R.string.physical_route_save_failed)
    PhysicalRouteIssue.INTERRUPTED -> stringResource(R.string.physical_route_draft_restored)
    PhysicalRouteIssue.MOCK_LOCATION,
    PhysicalRouteIssue.POOR_ACCURACY,
    PhysicalRouteIssue.STALE,
    PhysicalRouteIssue.JUMP,
    PhysicalRouteIssue.GAP,
    PhysicalRouteIssue.LIMIT -> stringResource(R.string.physical_route_issue_waiting)

    else -> null
}

private fun formatDistance(meters: Double): String =
    if (meters >= 1000.0) String.format(Locale.US, "%.2f km", meters / 1000.0)
    else String.format(Locale.US, "%.1f m", meters)

private fun formatDuration(millis: Long): String {
    val totalSeconds = (millis / 1000).coerceAtLeast(0)
    val hours = totalSeconds / 3600
    val minutes = (totalSeconds % 3600) / 60
    val seconds = totalSeconds % 60
    return if (hours > 0) {
        String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
    } else {
        String.format(Locale.US, "%02d:%02d", minutes, seconds)
    }
}
