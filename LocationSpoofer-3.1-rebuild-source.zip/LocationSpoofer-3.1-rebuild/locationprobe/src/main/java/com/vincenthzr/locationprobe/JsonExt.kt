package com.vincenthzr.locationprobe

import android.os.Bundle
import org.json.JSONArray
import org.json.JSONObject

internal fun truncate(value: String?, maxChars: Int = 4000): String {
    if (value == null) return ""
    return if (value.length <= maxChars) value else value.substring(0, maxChars) + "...[truncated ${value.length - maxChars}]"
}

internal fun String?.nullIfBlank(): String? = if (this.isNullOrBlank()) null else this

internal fun Bundle?.toJsonObject(maxEntries: Int = 64): JSONObject {
    val out = JSONObject()
    if (this == null) return out
    var count = 0
    for (key in keySet()) {
        if (count++ >= maxEntries) {
            out.put("_truncated", true)
            break
        }
        val value = try { get(key) } catch (_: Throwable) { null }
        out.put(key, valueToJson(value))
    }
    return out
}

private fun valueToJson(value: Any?): Any {
    return when (value) {
        null -> JSONObject.NULL
        is String -> truncate(value, 2000)
        is Boolean, is Number -> value
        is FloatArray -> JSONArray(value.toList())
        is DoubleArray -> JSONArray(value.toList())
        is IntArray -> JSONArray(value.toList())
        is LongArray -> JSONArray(value.toList())
        is BooleanArray -> JSONArray(value.toList())
        is Array<*> -> JSONArray(value.map { valueToJson(it) })
        is Bundle -> value.toJsonObject(16)
        else -> truncate(value.toString(), 1000)
    }
}

internal fun JSONArray.addObject(block: JSONObject.() -> Unit): JSONArray {
    put(JSONObject().apply(block))
    return this
}

internal fun JSONObject.putAny(key: String, value: Any?) {
    when (value) {
        null -> put(key, JSONObject.NULL)
        is String -> put(key, truncate(value, 8000))
        is Boolean, is Number -> put(key, value)
        is JSONObject, is JSONArray -> put(key, value)
        else -> put(key, truncate(value.toString(), 4000))
    }
}
