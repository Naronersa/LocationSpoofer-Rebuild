#!/system/bin/sh
# Location Probe - read-only root collector.
# Usage:
#   su -c 'sh /sdcard/Android/data/com.vincenthzr.locationprobe/files/probe/root_probe.sh \
#          /sdcard/Android/data/com.vincenthzr.locationprobe/files/probe/root_probe.txt'
# The app reads root_probe.txt on the next collection and embeds it into system.rootScriptOutput.
# Sections are ordered small/high-value first so a display truncation still keeps them.

PKG=com.vincenthzr.locationprobe
OUT="${1:-/sdcard/Android/data/$PKG/files/probe/root_probe.txt}"
mkdir -p "$(dirname "$OUT")" 2>/dev/null

exec > "$OUT" 2>&1

echo "root_probe_start=$(date '+%Y-%m-%dT%H:%M:%S%z')"
echo "root_probe_uid=$(id)"
echo "root_probe_selinux=$(getenforce 2>&1)"
echo "root_probe_uname=$(uname -a 2>&1)"

echo "### id"
id

echo "### getenforce"
getenforce 2>&1

echo "### getprop_location_mock_root"
getprop | grep -iE 'gps|gnss|location|mock|debuggable|secure|build.type|build.tags|magisk|kernel|zygisk|lsposed|selinux' 2>&1

echo "### settings_location_mock"
settings list secure 2>/dev/null | grep -iE 'location|mock'
settings list global 2>/dev/null | grep -iE 'location|mock|adb_enabled|development_settings_enabled'

echo "### root_paths"
ls -ld /system/bin/su /system/xbin/su /sbin/su /system/sbin/su /vendor/bin/su /data/adb/ksu /data/adb/magisk /data/adb/modules /data/adb/lspd 2>&1

echo "### mount_filtered"
mount 2>&1 | grep -iE 'magisk|zygisk|shamiko|riru|overlay|data'

echo "### self_maps"
cat /proc/self/maps 2>&1 | grep -iE 'xposed|magisk|zygisk|shamiko|riru|shadowhook|location_accel|lspd'

echo "### system_server_pid"
pidof system_server 2>&1
SS_PID=$(pidof system_server 2>/dev/null | awk '{print $1}')
if [ -n "$SS_PID" ]; then
  echo "### system_server_maps"
  cat /proc/$SS_PID/maps 2>&1 | grep -iE 'xposed|magisk|zygisk|shamiko|riru|shadowhook|location_accel|lspd'
  echo "### system_server_status"
  cat /proc/$SS_PID/status 2>&1 | grep -E 'Name|TracerPid|Seccomp|NoNewPrivs|CapEff'
fi

echo "### service_list_filtered"
service list 2>&1 | grep -iE 'location|gnss|sensor|wifi|telephony|bluetooth|connectivity'

echo "### ip_addr"
ip addr 2>&1

echo "### ip_route"
ip route 2>&1

echo "### ip_neigh"
ip neigh 2>&1

echo "### proc_net_arp"
cat /proc/net/arp 2>&1

echo "### proc_net_route"
cat /proc/net/route 2>&1

echo "### settings_secure_xml"
grep -iE 'mock_location|location_mode|location_providers_allowed|allow_mock_location|adb_enabled|development_settings_enabled' /data/system/users/0/settings_secure.xml /data/system/users/0/settings_global.xml 2>&1

echo "### appops_xml_mock"
grep -iE -C 2 'mock_location' /data/system/appops.xml 2>&1 | head -500

echo "### location_data_files"
ls -la /data/system/location /data/misc/location 2>&1

echo "### dumpsys_appops_mock"
dumpsys appops 2>&1 | grep -iE -C 2 'MOCK_LOCATION|mock_location' | head -1000

echo "### dumpsys_package_probe"
dumpsys package "$PKG" 2>&1

echo "### packages_with_mock_op"
dumpsys package 2>&1 | grep -iE -B 3 -A 3 'mock_location' | head -500

echo "### dumpsys_location"
dumpsys location 2>&1

echo "### cmd_location_help"
cmd location help 2>&1

echo "### dumpsys_sensorservice"
dumpsys sensorservice 2>&1

echo "### dumpsys_wifi_filtered"
dumpsys wifi 2>&1 | grep -iE 'SSID|BSSID|RSSI|frequency|linkSpeed|mWifiInfo|mScanResult|mNetworkInfo|mLinkProperties|mDhcpInfo|Gateway|DNS|ARP' | head -1000

echo "### dumpsys_telephony_filtered"
dumpsys telephony.registry 2>&1 | grep -iE 'CellInfo|SignalStrength|mServiceState|mDataConnectionState|mNetworkType|mOperator|mCellIdentity|mRegistered|mRoaming|mNrState' | head -1000

echo "### dumpsys_bluetooth_filtered"
dumpsys bluetooth_manager 2>&1 | grep -iE 'BleScan|ScanResult|mScanResults|mConnectedDevices|mBluetoothAddress|mDevice|mRssi|mLeScan' | head -1000

echo "### gnss_hal_dumpsys"
dumpsys android.hardware.gnss.IGnss/default 2>&1 | head -300

echo "### gnss_hal_lshal"
lshal 2>&1 | grep -iE 'gnss|location' | head -200

echo "### gnss_devices"
ls -l /dev 2>&1 | grep -iE 'gnss|gps|location'

echo "### gnss_sysfs"
find /sys -maxdepth 5 \( -iname '*gnss*' -o -iname '*gps*' \) 2>/dev/null | head -200

echo "### gnss_dmesg"
dmesg 2>&1 | grep -iE 'gnss|gps|location' | tail -200

echo "root_probe_end=$(date '+%Y-%m-%dT%H:%M:%S%z')"
