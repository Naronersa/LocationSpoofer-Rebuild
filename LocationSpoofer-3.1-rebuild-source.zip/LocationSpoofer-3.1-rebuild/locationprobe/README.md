# Location Probe

独立定位数据验证工具，包名 `com.vincenthzr.locationprobe`，不依赖 LocationSpoofer，也不参与 `:app` 打包。

## 用途

在**自己的设备**上采集“定位相关”和“可用于识别虚拟定位”的数据，输出一份本地 JSON，供分析/调试使用。APK **没有 INTERNET 权限**，不会上传任何数据。

## 采集层次

### 框架层（无需 Root，权限允许时）

- **Location**：全部 provider、enabled 状态、lastKnown、连续位置事件、`isMock`/`isFromMockProvider`、时间/elapsedRealtime 偏差、accuracy/altitude/speed/bearing、`Location.extras`。
- **GNSS**：硬件年份/型号、`GnssCapabilities`、天线信息、`GnssStatus` 卫星（SVID/星座/C/N0/仰角/方位/usedInFix/almanac/ephemeris）、`GnssMeasurementsEvent` 原始测量与 clock、`GnssNavigationMessage` 计数/样本、NMEA 语句。
- **传感器**：系统全部传感器元数据；加速度/陀螺/磁场/旋转矢量/重力/线性加速度/气压/计步/方向等事件的计数、轴 min/max/mean/variance/range、首尾样本、accuracy 分布。用于检查“位置在动但传感器静止”等矛盾。
- **WiFi**：开关/扫描状态、连接信息、DHCP、扫描结果（SSID/BSSID/RSSI/频率/能力/时间戳/标准）。
- **基站**：数据/语音网络类型、运营商、漫游、信号强度、全部 `CellInfo`（含 identity/signalStrength 的 toString）。
- **蓝牙**：适配器状态、已配对设备、BLE 扫描结果（地址/名称/RSSI/PHY/广播字节）。
- **网络**：活动网络、Transport、LinkProperties、路由、DNS、NetworkInfo。
- **设置/AppOps**：`mock_location`、`allow_mock_location`、location_mode、location_providers_allowed、开发者选项、ADB、时间设置；本应用 `android:mock_location` AppOps。
- **设备/Build**：指纹、tags/type、debuggable/testOnly、target/minSdk、Root/注入相关构建属性线索。

### 系统层（Root；未授权时自动降级并记录错误）

固定只读命令，不接收外部输入：

- `dumpsys location`、`cmd location help`
- `dumpsys sensorservice`
- `dumpsys wifi`（过滤 SSID/BSSID/RSSI/扫描/连接/DHCP）
- `dumpsys telephony.registry`（过滤 CellInfo/SignalStrength/网络状态）
- `dumpsys bluetooth_manager`（过滤 BLE/连接设备）
- `dumpsys appops`（过滤 `mock_location`）
- `dumpsys package <probe>`、`service list`（过滤 location/gnss/sensor/wifi/telephony/bt）
- `getprop`（过滤 gps/gnss/location/mock/debuggable/tags/magisk/zygisk/lsposed/selinux）
- `ip addr/route/neigh`、`/proc/net/arp`、`/proc/net/route`
- `id`、`getenforce`、`uname -a`、root 路径检查、mount 过滤
- `/proc/self/maps` 与 `system_server` maps（Xposed/Magisk/Zygisk/Shamiko/Riru/ShadowHook/location_accel/lspd）
- `/proc/<system_server>/status`（TracerPid/Seccomp/NoNewPrivs/CapEff）
- `settings_secure.xml`/`settings_global.xml` 中与 mock/location/ADB/开发者选项相关的行
- `appops.xml` 中 `mock_location` 上下文
- `/data/system/location`、`/data/misc/location` 文件列表

## 输出与观察信号

完成后自动写入：

```text
/sdcard/Android/data/com.vincenthzr.locationprobe/files/probe/location_probe_<timestamp>.json
```

JSON 包含 `probe`、`device`、`permissions`、`settings`、`appOps`、`location`、`gnss`、`sensors`、`wifi`、`cell`、`bluetooth`、`network`、`system`、`analysis`。

`analysis.signals` 是**保守提示**，不是定罪；包括：

- `isMock`/`isFromMockProvider`、mock provider 名称、extras 中的 mock 字段；
- GPS 位置存在但无卫星/无 usedInFix、无 raw measurements/NMEA、NMEA fix quality=0；
- AppOps/secure settings/appops.xml 的 mock_location 允许记录；
- 位置在动但加速度计/陀螺仪几乎静止、气压不变但海拔变化、计步不增长、罗盘与 bearing 不一致；
- Root/build debuggable、进程 maps 中的 Xposed/Magisk/Zygisk/ShadowHook/本工程注入库。

这些信号可能因设备/权限/室内环境产生误报，需结合原始数据判断。

## 构建与安装

```bash
JAVA_HOME="$HOME/.jdks/jdk-21.0.12.1+1" \
  "$HOME/.gradle-local/gradle-9.6.1/bin/gradle" \
  :locationprobe:assembleDebug --console=plain
```

APK：`locationprobe/build/outputs/apk/debug/locationprobe-debug.apk`（debug 签名，独立包名，可直接安装；SHA-256 见交付目录 `LocationProbe/README.md`）。

```bash
adb install -r locationprobe-debug.apk
# 可选：授予运行时权限后再自动开始
adb shell am start -n com.vincenthzr.locationprobe/.MainActivity \
  --ez auto_start true --el duration_ms 10000
```

默认采集时长 **60 秒**，界面可在 30/60/120/300 秒之间切换；`--el duration_ms` 可覆盖。

采集会自动执行 `su -c id`：

- 已授予 KernelSU/Magisk root 时（本机已授予 Location Probe），**默认直接从系统层采集**：
  `dumpsys location/sensorservice/wifi/telephony/bluetooth/appops`、`getprop`、`ip`、
  `/proc`、`/sys`、settings/appops XML、进程 maps 等；
- 如果 `su` 返回 `EACCES/Permission denied`（未授权或管理器/驱动不匹配时），点
  **“生成 Root 采集脚本”**，在 Termux/ADB root shell 执行界面显示的：
  ```sh
  su -c 'sh /sdcard/Android/data/com.vincenthzr.locationprobe/files/probe/root_probe.sh \
         /sdcard/Android/data/com.vincenthzr.locationprobe/files/probe/root_probe.txt'
  ```
  然后再点一次“开始采集”。App 会把 `root_probe.txt`（最多约 1.2MB）嵌入
  `system.rootScriptOutput`。
- 即使没有 root，框架层数据仍会完整采集，并在 `system.rootAvailable=false` /
  `suCheck.error` 中记录原因。

## 交叉判定（本次新增）

除原始数据外，`analysis.metrics` 会给出本次采集窗口内的：

- 位置位移、持续时间、由位移/时间反算的速度、Location.speed、海拔变化、accuracy 取值数；
- 加速度计/陀螺仪/气压的范围、计步器增量；
- 末次卫星数、usedInFix、最大 C/N0、raw measurements/NMEA 计数；
- WiFi BSSID 集合大小、CellInfo identity 集合大小。

`analysis.signals` 会检查例如：

- 位置移动但 `Location.speed` 为 0 或与位移速度明显不符；
- 位置移动但加速度计/陀螺仪几乎静止、计步不增长、气压不随海拔变化；
- 设备在运动但位置几乎不位移；
- GPS 位置存在但卫星数为 0/无 usedInFix、无 raw measurements、NMEA GGA fix quality=0；
- 移动 >200m 但 WiFi BSSID 集合几乎不变、>500m 但基站 identity 集合不变；
- `isMock`/mock extras、AppOps mock_location、注入库/进程 maps 等环境证据。

这些是**启发式信号**，不是定罪；例如室内 GPS 无 fix、缓存位置、权限不足都会造成类似数据。

## 注意

- 导出的 JSON 含 WiFi BSSID、基站 ID、蓝牙地址、位置历史等敏感数据，只保存在本机；不要公开上传。
- 没有 `INTERNET` 权限；没有写系统设置、注入、修改定位的行为，全部命令为只读诊断。
- “系统最底层”指 Root 可见的系统服务/`proc`/`sysfs`/设置数据库，不包含 GNSS 芯片寄存器或厂商 HAL 私有 IOCTL。
- 部分机型不开放 raw GNSS/NMEA；`gnss` 中的缺失不代表一定是虚拟定位。
