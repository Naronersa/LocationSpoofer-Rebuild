package com.vincenthzr.locationspoofer.service

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.location.LocationManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel

class SpoofingService : Service() {

    private lateinit var locationManager: LocationManager
    private var wakeLock: PowerManager.WakeLock? = null
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    companion object {
        const val ACTION_START = "ACTION_START"
        const val ACTION_STOP = "ACTION_STOP"
        const val EXTRA_LAT = "EXTRA_LAT"
        const val EXTRA_LNG = "EXTRA_LNG"
        private const val NOTIFICATION_ID = 1001
        private const val CHANNEL_ID = "SpoofingServiceChannel"

        var isRunning = false
            private set
    }

    override fun onCreate() {
        super.onCreate()
        locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        createNotificationChannel()
    }

    private var lastLat = 0.0
    private var lastLng = 0.0
    private var hasLastPosition = false

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                lastLat = intent.getDoubleExtra(EXTRA_LAT, 0.0)
                lastLng = intent.getDoubleExtra(EXTRA_LNG, 0.0)
                hasLastPosition = true
                if (!startForegroundSafely(lastLat, lastLng, startId)) {
                    return START_NOT_STICKY
                }
            }

            ACTION_STOP -> stopSpoofing()

            // 系统以 START_STICKY 重启服务时 intent 为 null；必须重新
            // startForeground，否则会触发 "did not then call startForeground"。
            null -> {
                if (!hasLastPosition ||
                    !startForegroundSafely(lastLat, lastLng, startId)
                ) {
                    isRunning = false
                    stopSelf(startId)
                    return START_NOT_STICKY
                }
            }
        }
        return START_STICKY
    }

    @SuppressLint("WakelockTimeout")
    private fun startForegroundSafely(lat: Double, lng: Double, startId: Int): Boolean {
        acquireWakeLock()

        val launchIntent = packageManager.getLaunchIntentForPackage(packageName) ?: Intent()
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            launchIntent.apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.spoofing_service_title))
            .setContentText(
                getString(
                    R.string.spoofing_service_content,
                    String.format(java.util.Locale.US, "%.6f", lat),
                    String.format(java.util.Locale.US, "%.6f", lng)
                )
            )
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .build()

        val foregroundOk = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
            true
        } catch (e: Throwable) {
            android.util.Log.e("LocationSpoofer", "startForeground failed", e)
            false
        }
        if (!foregroundOk) {
            // 不能把失败当成运行中：立即停止，避免系统 5 秒后以
            // RemoteServiceException 杀进程。
            isRunning = false
            stopSelf(startId)
            return false
        }
        isRunning = true
        return true
    }

    private fun acquireWakeLock() {
        try {
            if (wakeLock == null) {
                val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
                wakeLock = powerManager.newWakeLock(
                    PowerManager.PARTIAL_WAKE_LOCK,
                    "LocationSpoofer:BackgroundSpoofingWakeLock"
                ).apply {
                    setReferenceCounted(false)
                }
            }
            if (wakeLock?.isHeld == false) {
                wakeLock?.acquire(24 * 60 * 60 * 1000L) // 保持 24 小时唤醒，防止后台系统冻结
            }
        } catch (e: Throwable) {
            e.printStackTrace()
        }
    }

    private fun releaseWakeLock() {
        try {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
            }
        } catch (_: Throwable) {
        }
        wakeLock = null
    }

    private fun stopSpoofing() {
        isRunning = false
        releaseWakeLock()
        cleanupLegacyTestProviders()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun cleanupLegacyTestProviders() {
        val providers =
            mutableListOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            providers.add(LocationManager.FUSED_PROVIDER)
        }
        for (provider in providers) {
            try {
                locationManager.setTestProviderEnabled(provider, false)
            } catch (_: Throwable) {
            }
            try {
                locationManager.removeTestProvider(provider)
            } catch (_: Throwable) {
            }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.spoofing_service_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.spoofing_bg_notification_title)
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        // 用户在多任务卡片划掉 Activity 时，如果正在模拟，继续在后台保持运行
        if (isRunning) {
            acquireWakeLock()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        releaseWakeLock()
        serviceScope.cancel()
        cleanupLegacyTestProviders()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
