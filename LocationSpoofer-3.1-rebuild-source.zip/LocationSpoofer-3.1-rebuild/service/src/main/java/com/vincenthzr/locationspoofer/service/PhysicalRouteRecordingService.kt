package com.vincenthzr.locationspoofer.service

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.vincenthzr.locationspoofer.data.recording.PhysicalRouteCommand
import com.vincenthzr.locationspoofer.data.recording.PhysicalRouteFix
import com.vincenthzr.locationspoofer.data.recording.PhysicalRouteIssue
import com.vincenthzr.locationspoofer.data.recording.PhysicalRouteRecorder
import com.vincenthzr.locationspoofer.service.R
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.koin.android.ext.android.inject

/**
 * 物理路线录制前台服务：以 1s 间隔采集真实 GPS 定位并交给 [PhysicalRouteRecorder]。
 * 命令通过 Intent action（PhysicalRouteCommand 名称）传入，通知栏提供暂停/完成操作。
 */
class PhysicalRouteRecordingService : Service(), LocationListener {

    private val recorder: PhysicalRouteRecorder by inject()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val owner = Any()

    private var latestStartId = 0
    private var listening = false
    private var loop: Job? = null
    private var sessionId: String? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var wakeRenewedAt = 0L

    private val locationManager: LocationManager
        get() = getSystemService(LocationManager::class.java)

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(
                CHANNEL,
                getString(R.string.physical_route_channel),
                NotificationManager.IMPORTANCE_LOW,
            )
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        latestStartId = startId
        val command = PhysicalRouteCommand.entries.firstOrNull { it.name == intent?.action }
        if (command == null) {
            stopSelf(startId)
            return START_NOT_STICKY
        }

        if (command == PhysicalRouteCommand.START || command == PhysicalRouteCommand.RESUME) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    startForeground(ID, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
                } else {
                    startForeground(ID, notification())
                }
            } catch (e: Exception) {
                scope.launch { recorder.pause(PhysicalRouteIssue.PERMISSION) }
                close(startId)
                return START_NOT_STICKY
            }
        }

        scope.launch {
            try {
                when (command) {
                    PhysicalRouteCommand.START,
                    PhysicalRouteCommand.RESUME -> {
                        // 已在录制且属于本服务会话：忽略重复 START/RESUME（上游同样直接返回）
                        val current = recorder.state.value
                        if (current.recording && sessionId == current.id) return@launch
                        if (!recorder.begin(
                                resumeExisting = command == PhysicalRouteCommand.RESUME,
                                owner = owner,
                            )
                        ) {
                            close(startId)
                            return@launch
                        }
                        sessionId = recorder.state.value.id
                        if (ContextCompat.checkSelfPermission(
                                this@PhysicalRouteRecordingService,
                                Manifest.permission.ACCESS_FINE_LOCATION,
                            ) != PackageManager.PERMISSION_GRANTED
                        ) {
                            recorder.pause(PhysicalRouteIssue.PERMISSION)
                            close(startId)
                            return@launch
                        }
                        listen()
                        updateNotification()
                    }

                    PhysicalRouteCommand.PAUSE -> {
                        recorder.pause()
                        close(startId)
                    }

                    PhysicalRouteCommand.FINISH -> {
                        recorder.finish()
                        close(startId)
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                recorder.pause(PhysicalRouteIssue.PERMISSION)
                close(startId)
            }
        }
        return START_NOT_STICKY
    }

    private suspend fun listen() {
        if (!listening) {
            locationManager.requestLocationUpdates(
                LocationManager.GPS_PROVIDER,
                1000L,
                0f,
                this,
                Looper.getMainLooper(),
            )
            listening = true
            val lock = getSystemService(PowerManager::class.java)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "$packageName:physical-route")
            lock.setReferenceCounted(false)
            lock.acquire(60_000L)
            wakeLock = lock
            wakeRenewedAt = SystemClock.elapsedRealtime()
        }
        recorder.signal(
            if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                PhysicalRouteIssue.WAITING
            } else {
                PhysicalRouteIssue.GPS_OFF
            }
        )
        startLoop()
    }

    private fun startLoop() {
        loop?.cancel()
        loop = scope.launch {
            while (isActive) {
                delay(1000L)
                if (!recorder.state.value.recording) break
                recorder.tick()
                updateNotification()
                val now = SystemClock.elapsedRealtime()
                val lock = wakeLock
                if (lock != null && now - wakeRenewedAt >= 50_000L) {
                    if (lock.isHeld) lock.release()
                    lock.acquire(60_000L)
                    wakeRenewedAt = now
                }
            }
        }
    }

    private fun stopListening() {
        if (listening) {
            try {
                locationManager.removeUpdates(this)
            } catch (_: Throwable) {
            }
        }
        listening = false
        loop?.cancel()
        loop = null
        val lock = wakeLock
        if (lock != null && lock.isHeld) lock.release()
        wakeLock = null
    }

    private fun close(startId: Int) {
        if (startId != latestStartId) return
        stopListening()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelfResult(startId)
    }

    private fun notification(): Notification {
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName) ?: Intent()
        val contentIntent = PendingIntent.getActivity(
            this,
            ID,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val state = recorder.state.value
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle(getString(R.string.physical_route_notification))
            .setContentText(
                getString(
                    R.string.physical_route_notification_content,
                    state.distanceM.toInt(),
                    state.points.size,
                )
            )
            .setContentIntent(contentIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(0, getString(R.string.physical_route_pause), actionIntent(PhysicalRouteCommand.PAUSE, 4211))
            .addAction(0, getString(R.string.physical_route_finish), actionIntent(PhysicalRouteCommand.FINISH, 4212))
            .build()
    }

    private fun actionIntent(command: PhysicalRouteCommand, requestCode: Int): PendingIntent {
        val intent = Intent(this, PhysicalRouteRecordingService::class.java).setAction(command.name)
        return PendingIntent.getService(
            this,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    private fun updateNotification() {
        if (!recorder.state.value.recording) return
        getSystemService(NotificationManager::class.java).notify(ID, notification())
    }

    override fun onLocationChanged(location: Location) {
        if (!location.hasAccuracy()) return
        val mock = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            location.isMock
        } else {
            @Suppress("DEPRECATION")
            location.isFromMockProvider
        }
        scope.launch {
            recorder.sample(
                PhysicalRouteFix(
                    lat = location.latitude,
                    lng = location.longitude,
                    accuracyM = location.accuracy,
                    elapsedNanos = location.elapsedRealtimeNanos,
                    mock = mock,
                )
            )
        }
    }

    override fun onProviderDisabled(provider: String) {
        scope.launch { recorder.signal(PhysicalRouteIssue.GPS_OFF) }
    }

    override fun onProviderEnabled(provider: String) {
        scope.launch { recorder.signal(PhysicalRouteIssue.WAITING) }
    }

    override fun onDestroy() {
        stopListening()
        scope.cancel()
        recorder.serviceLost(sessionId, owner)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val CHANNEL = "physical-route-recording"
        const val ID = 4210
    }
}
