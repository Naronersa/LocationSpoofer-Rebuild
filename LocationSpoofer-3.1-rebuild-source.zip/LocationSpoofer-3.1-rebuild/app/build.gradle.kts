@file:Suppress("DEPRECATION")

import java.util.Properties
import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.jetbrains.kotlin.android)
    alias(libs.plugins.jetbrains.kotlin.compose)
}

android {
    namespace = "com.vincenthzr.locationspoofer"
    compileSdk = 37

    fun getLocalConfig(key: String): String? {
        val localYml = file("../local.yml")
        if (localYml.exists()) {
            val line = localYml.readLines().find { it.startsWith("$key:") }
            if (line != null) {
                return line.substringAfter(":").trim().removeSurrounding("\"")
                    .removeSurrounding("'")
            }
        }
        return null
    }

    // 默认不注入任何地图 Key：不读 local.yml、不读 Key 环境变量。
    // 只有显式传入 -PinjectMapKeys=true 时才允许从 local.yml/环境变量注入；
    // 本地发布物默认保持空 Key，避免误发布含 Key 的 APK。
    val injectMapKeys = providers.gradleProperty("injectMapKeys")
        .orNull?.toBoolean() ?: false

    val googleMapsApiKey = if (injectMapKeys) {
        System.getenv("GOOGLE_MAPS_API_KEY")
            ?: getLocalConfig("GOOGLE_MAPS_API_KEY") ?: ""
    } else ""

    // 地图 Key 默认留空；显式 opt-in 时才从环境变量或未跟踪的 local.yml 读取。
    val amapApiKey = if (injectMapKeys) {
        System.getenv("AMAP_API_KEY") ?: getLocalConfig("AMAP_API_KEY") ?: ""
    } else ""
    val baiduApiKey = if (injectMapKeys) {
        System.getenv("BAIDU_API_KEY") ?: getLocalConfig("BAIDU_API_KEY") ?: ""
    } else ""

    defaultConfig {
        applicationId = "com.vincenthzr.locationspoofer"
        testInstrumentationRunner = "com.vincenthzr.locationspoofer.SystemFilesInstrumentation"
        minSdk = 26
        targetSdk = 37
        versionCode = providers.gradleProperty("APP_VERSION_CODE").get().toInt()
        versionName = providers.gradleProperty("APP_VERSION_NAME").get()

        vectorDrawables {
            useSupportLibrary = true
        }

        manifestPlaceholders["googleMapsApiKey"] = googleMapsApiKey
        manifestPlaceholders["amapApiKey"] = amapApiKey
        manifestPlaceholders["baiduApiKey"] = baiduApiKey

        splits {
            abi {
                isEnable = true
                reset()
                // 仅支持 arm64：global native 传感器层与上游 global 一致只做 64 位
                include("arm64-v8a")
                isUniversalApk = false
            }
        }
    }

    // 只保留全局方案：Hook system_server 等系统进程，对全设备生效。
    // app / app-ui / core-data / xposed 四个模块声明相同的 flavor，保证变体对齐。
    flavorDimensions += "scheme"
    productFlavors {
        create("global") {
            dimension = "scheme"
            buildConfigField("boolean", "GLOBAL_SCHEME", "true")
        }
    }

    // CI 用环境变量（见 .github/workflows/release.yml），本地用仓库根目录的 keystore.properties（已被 gitignore）
    val keystoreProps = Properties().apply {
        val f = rootProject.file("keystore.properties")
        if (f.exists()) f.inputStream().use { load(it) }
    }
    fun signingValue(env: String, prop: String): String? =
        System.getenv(env)?.takeIf { it.isNotBlank() } ?: keystoreProps.getProperty(prop)?.takeIf { it.isNotBlank() }

    val keystorePath = signingValue("KEYSTORE_FILE_PATH", "storeFile")
    // 相对路径按仓库根目录解析（keystore.properties 也放在根目录）；
    // CI 传绝对路径时 rootProject.file() 同样可用。
    val keystoreFile = keystorePath?.let { rootProject.file(it) }
    val hasReleaseKeystore = keystoreFile != null && keystoreFile.exists()

    signingConfigs {
        create("release") {
            if (hasReleaseKeystore) {
                storeFile = keystoreFile
                storePassword = signingValue("KEYSTORE_PASSWORD", "storePassword")
                keyAlias = signingValue("KEY_ALIAS", "keyAlias")
                keyPassword = signingValue("KEY_PASSWORD", "keyPassword")
            }
            // v3 为以后的密钥轮换（lineage）预留；API 26–27 设备仍按 v2 校验，所以 v2 保持开启
            enableV2Signing = true
            enableV3Signing = true
        }
    }

    // release 与上游签名域不同：统一使用 .rebuild 包名，才能与上游 3.0.0 共存。
    // 默认空 Key；只有显式 -PinjectMapKeys=true 时才读取 .rebuild 专用 Key。
    val rebuildAmapApiKey = if (injectMapKeys) {
        System.getenv("COMPARE_AMAP_API_KEY")
            ?: getLocalConfig("COMPARE_AMAP_API_KEY") ?: amapApiKey
    } else ""

    buildTypes {
        debug {
            // 没配置发布密钥时回退到 debug 签名，保证新克隆仓库的人也能直接编译调试
            signingConfig = signingConfigs.getByName(if (hasReleaseKeystore) "release" else "debug")
            buildConfigField("String", "GOOGLE_MAPS_API_KEY", "\"$googleMapsApiKey\"")
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            // 与上游 3.0.0 共存：release 也使用 .rebuild 包名
            applicationIdSuffix = ".rebuild"
            manifestPlaceholders["amapApiKey"] = rebuildAmapApiKey
            // 未配置发布密钥时回退到 debug 签名，保证 fork 后也能直接出 release 包
            signingConfig = signingConfigs.getByName(if (hasReleaseKeystore) "release" else "debug")
            buildConfigField("String", "GOOGLE_MAPS_API_KEY", "\"$googleMapsApiKey\"")
        }
        // 对比调试专用：与上游 3.0.0(同包名)共存，applicationId 加 .rebuild 后缀。
        // 构建命令：:app:assembleGlobalCompare；AMap Key 与包名绑定，
        // 需要为 com.vincenthzr.locationspoofer.rebuild 单独登记，或提供 COMPARE_AMAP_API_KEY。
        create("compare") {
            initWith(getByName("release"))
            // 本机对比包关闭 R8/资源压缩：避免 6GB 机器上的 R8 OOM，调试构建更快
            isMinifyEnabled = false
            isShrinkResources = false
            applicationIdSuffix = ".rebuild"
            versionNameSuffix = "-compare"
            matchingFallbacks += listOf("release")
            manifestPlaceholders["amapApiKey"] = rebuildAmapApiKey
            buildConfigField("String", "GOOGLE_MAPS_API_KEY", "\"$googleMapsApiKey\"")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
        freeCompilerArgs.addAll(
            "-Xskip-metadata-version-check"
        )
    }
}

dependencies {
    implementation(project(":core-geo"))
    implementation(project(":core-data"))
    implementation(project(":service"))
    implementation(project(":app-ui"))
    // 纯打包依赖：:app 不直接调用 :xposed 的代码，只是需要把它的产物
    // （LocationHooker 及 META-INF/xposed/* 资源）一起打进最终 APK，供 LSPosed 扫描加载。
    implementation(project(":xposed"))

    implementation(libs.xposed.service)
    implementation(libs.koin.androidx.compose)
    implementation(libs.amap.map)
    implementation(libs.amap.search)
    implementation(libs.baidu.map)
    implementation(libs.google.places)
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.ui)
    implementation(libs.androidx.ui.graphics)
    implementation(libs.androidx.ui.tooling.preview)
    implementation(libs.androidx.material3)
    implementation(libs.androidx.material.icons.extended)

    implementation(libs.miuix.ui)
    implementation(libs.miuix.blur)

    debugImplementation(libs.androidx.ui.tooling)
    androidTestImplementation(libs.room.runtime)
    androidTestImplementation(libs.room.ktx)
}
