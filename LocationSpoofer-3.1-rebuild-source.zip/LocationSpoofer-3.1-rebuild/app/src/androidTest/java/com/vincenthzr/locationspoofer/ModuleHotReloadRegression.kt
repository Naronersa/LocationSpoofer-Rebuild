package com.vincenthzr.locationspoofer

import com.vincenthzr.locationspoofer.utils.ConfigKeys

import android.app.Instrumentation
import android.os.Bundle
import com.vincenthzr.locationspoofer.utils.FrameworkConfigChannel
import com.vincenthzr.locationspoofer.utils.XposedModuleStatus
import com.vincenthzr.locationspoofer.utils.RootManager
import com.vincenthzr.locationspoofer.vendor.HookStatusFiles
import io.github.libxposed.service.HotReloadResult
import io.github.libxposed.service.XposedService
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.json.JSONObject
import java.util.UUID

private suspend fun moduleService(): XposedService {
    repeat(150) {
        XposedModuleStatus.mService?.let { return it }
        delay(100)
    }
    error("Framework service unavailable")
}

/** Module-local diagnostics; does not start or stop a simulation. */
internal fun Instrumentation.verifyModuleRuntime(): Bundle {
    val output = Bundle()
    try {
        val service = runBlocking { moduleService() }
        output.putString("framework", "${service.frameworkName} ${service.frameworkVersion} API ${service.apiVersion}")
        output.putString("scope", service.scope.sorted().joinToString())
        if (service.apiVersion >= 102) {
            output.putString("targets", service.runningTargets.joinToString { target ->
                "${target.processName}:pid=${target.pid},state=${target.state},version=${target.loadedVersionCode}"
            })
        }
        val text = service.getRemotePreferences(FrameworkConfigChannel.GROUP)
            .getString(FrameworkConfigChannel.SNAPSHOT_KEY, null)
        if (text != null) {
            val envelope = JSONObject(text)
            val payload = envelope.optString(ConfigKeys.PAYLOAD)
            output.putString("configuration", "published=${envelope.optLong(ConfigKeys.PUBLISHED_AT)},inline=${payload.isNotEmpty()},active=${if (payload.isNotEmpty()) JSONObject(payload).optBoolean(ConfigKeys.ACTIVE) else "remote-file"}")
        }
        output.putString("result", "PASS")
    } catch (error: Throwable) {
        output.putString("result", "FAIL: ${error.stackTraceToString()}")
    }
    return output
}

/** Exercises actual API 102 generation replacement, preserving scope and simulation payload. */
internal fun Instrumentation.verifyModuleHotReload(): Bundle {
    val output = Bundle()
    try {
        runBlocking {
            val service = moduleService()
            check(BuildConfig.GLOBAL_SCHEME && service.apiVersion >= 102)
            val scope = service.scope.sorted()
            val targets = service.runningTargets
            val pids = targets.associate { it.processName to it.pid }
            check(pids.keys == setOf("system", "com.android.phone", "com.android.bluetooth")) {
                "Unexpected targets: $pids"
            }
            val preferences = service.getRemotePreferences(FrameworkConfigChannel.GROUP)
            val original = JSONObject(requireNotNull(preferences.getString(FrameworkConfigChannel.SNAPSHOT_KEY, null)))
            // This regression only republishes the inactive existing payload, never starts a simulation.
            check(original.optString(ConfigKeys.FILE).isEmpty() && !JSONObject(original.getString(ConfigKeys.PAYLOAD)).optBoolean(ConfigKeys.ACTIVE))
            val root = RootManager()
            fun reports(): Map<String, JSONObject> = HookStatusFiles.PATHS.mapValues { (_, paths) ->
                val command = paths.joinToString(" || ") { "cat '/proc/1/root$it' 2>/dev/null" }
                JSONObject(root.executeCommand(command))
            }
            fun hookCounts(report: JSONObject): Map<String, Int> = buildMap {
                val components = report.getJSONArray(ConfigKeys.COMPONENTS)
                repeat(components.length()) { index ->
                    val component = components.getJSONObject(index)
                    if (component.optBoolean(ConfigKeys.FOUND)) {
                        val methods = component.getJSONObject(ConfigKeys.METHODS)
                        methods.keys().forEach { name -> put("${component.getString(ConfigKeys.NAME)}.$name", methods.getInt(name)) }
                    }
                }
            }
            var baseline = reports()
            repeat(2) { cycle ->
                for (target in service.runningTargets) {
                    val completion = CompletableDeferred<HotReloadResult>()
                    service.hotReloadModule(target, null) { _, result -> completion.complete(result) }
                    val result = withTimeout(30_000) { completion.await() }
                    check(result.status() == HotReloadResult.Status.SUCCEEDED) {
                        "${target.processName}: ${result.status()} ${result.message()}"
                    }
                }
                val newSnapshot = JSONObject(original.toString()).apply {
                    put(ConfigKeys.ID, UUID.randomUUID().toString())
                    put(ConfigKeys.PUBLISHED_AT, System.currentTimeMillis())
                }
                check(preferences.edit().putString(FrameworkConfigChannel.SNAPSHOT_KEY, newSnapshot.toString()).commit())
                val timestamp = newSnapshot.getLong(ConfigKeys.PUBLISHED_AT)
                var after: Map<String, JSONObject>? = null
                withTimeout(20_000) {
                    while (after == null) {
                        delay(500)
                        val current = reports()
                        if (current.all { (process, report) ->
                                report.optString(ConfigKeys.GENERATION).isNotBlank() &&
                                    report.optString(ConfigKeys.GENERATION) != baseline.getValue(process).optString(ConfigKeys.GENERATION) &&
                                    report.optJSONObject(ConfigKeys.CONFIG)?.optLong(ConfigKeys.MODIFIED) == timestamp
                            }) after = current
                    }
                }
                val verified = requireNotNull(after)
                verified.forEach { (process, report) ->
                    val target = when (process) {
                        "SYSTEM_SERVER" -> "system"
                        "PHONE" -> "com.android.phone"
                        else -> "com.android.bluetooth"
                    }
                    check(report.getInt(ConfigKeys.PID) == pids.getValue(target)) { "$process restarted" }
                    check(report.getString(ConfigKeys.LOAD_KIND) == "hot-reload")
                    check(report.getJSONArray(ConfigKeys.ERRORS).length() == 0) { "$process: ${report.getJSONArray(ConfigKeys.ERRORS)}" }
                    val counts = hookCounts(report)
                    check(counts.isNotEmpty() && hookCounts(baseline.getValue(process)).all { (method, count) ->
                        counts.getOrDefault(method, 0) >= count
                    }) { "$process lost hooks" }
                }
                check(service.scope.sorted() == scope)
                check(service.runningTargets.associate { it.processName to it.pid } == pids)
                output.putString("cycle_${cycle + 1}", "All three generations replaced; hooks intact; latest configuration received; PIDs unchanged")
                baseline = verified
            }
            output.putString("pids", pids.toString())
            output.putString("scope", scope.joinToString())
        }
        output.putString("result", "PASS")
    } catch (error: Throwable) {
        output.putString("result", "FAIL: ${error.stackTraceToString()}")
    }
    return output
}
