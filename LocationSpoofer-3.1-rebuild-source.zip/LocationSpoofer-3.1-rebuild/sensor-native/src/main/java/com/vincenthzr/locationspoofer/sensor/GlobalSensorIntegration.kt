package com.vincenthzr.locationspoofer.sensor

import com.vincenthzr.locationspoofer.utils.ConfigKeys

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorManager
import android.os.Build
import android.os.UserHandle
import android.os.UserManager
import android.util.Log
import com.vincenthzr.locationspoofer.utils.MotionGoldenVectors
import com.vincenthzr.locationspoofer.utils.MotionRealism
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs

/**
 * global 系统级传感器层入口（运行在 system_server）。
 *
 * 由 LocationHooker 通过反射调用：
 *  - [install]：加载 ShadowHook / location_accel，应用最近一次配置；
 *  - [onConfig]：每次框架配置快照更新时下发速度、步频、句柄、真实度、步态模板与气压配置。
 *
 * 目标选择（有意与上游 SystemSensorPolicy 不同）：
 *  - `system_hook_global_mode=true`：枚举普通应用的 UID，默认只扫描主用户 0，
 *    默认排除 GMS/GSF/Play Store、系统应用、SystemUI/Phone/BT 与自身；
 *    不再使用 native 的 `allApps` UID 段匹配。
 *    `sensor_hook_all_users=true` 时才枚举所有 profile（包括双开用户 999），
 *    也可以用 `sensor_hook_user_ids` 精确指定用户。
 *  - 否则只解析 `system_hook_packages` 白名单（user 0）。
 *
 * 句柄优先取配置覆盖；未配置时从系统 SensorManager 的默认传感器自动读取，
 * 失败才退回本 ROM 默认值 3/5/0x37。
 *
 * 安装/卸载/更新会通过 PackageManager 广播使目标缓存失效并重新扫描，
 * 不再依赖 60 秒缓存过期。
 */
object GlobalSensorIntegration {

    private const val TAG = "SysSensor"
    private const val DEFAULT_STEP_DETECTOR_HANDLE = 3
    private const val DEFAULT_STEP_COUNTER_HANDLE = 5
    private const val DEFAULT_ACCELEROMETER_HANDLE = 0x37
    private const val RESOLVE_RETRY_MS = 500L
    private const val RESOLVE_RETRY_COUNT = 120
    private const val GLOBAL_TARGET_CACHE_MS = 60_000L

    // 与 SystemHookUtils 的基础豁免对齐，并补充 Play Store / GSF / 自身 compare 包
    private val DEFAULT_EXCLUDED_PACKAGES = setOf(
        "com.vincenthzr.locationspoofer",
        "com.vincenthzr.locationspoofer.rebuild",
        "android",
        "system_server",
        "system",
        "com.android.systemui",
        "com.android.phone",
        "com.android.server.telecom",
        "com.google.android.gms",
        "com.google.android.gsf",
        "com.android.vending",
        "com.qualcomm.location",
        "com.qualcomm.atfwd",
        "com.android.ons",
        "com.android.location.fused",
    )
    private val DEFAULT_EXCLUDED_PREFIXES = listOf(
        "com.google.android.gms.",
        "com.google.android.gsf.",
    )

    @Volatile private var loaded = false
    @Volatile private var nativeLoadFailed = false
    @Volatile private var nativeFailureReason = ""
    @Volatile private var realismParityChecked = false
    @Volatile private var initialized = false
    @Volatile private var nativeInitAttempts = 0
    @Volatile private var nativeInitRetryThread: Thread? = null
    @Volatile private var pendingJson: String = ""
    @Volatile private var lastKey: String? = null
    @Volatile private var retryGeneration = 0
    @Volatile private var lastResolutionLog = 0L
    @Volatile private var globalCache: GlobalTargetCache? = null
    @Volatile private var autoHandles: SensorHandles? = null
    @Volatile private var packageReceiver: BroadcastReceiver? = null
    @Volatile private var refreshScheduled = false
    @Volatile private var profileApplied = false

    @JvmStatic
    fun install() {
        ensureLoaded()
        if (!loaded) return
        if (pendingJson.isBlank()) {
            // 给框架配置接收器一点时间，让 ROM 描述符/目标配置先于 Hook 安装到达
            Thread({
                try {
                    for (i in 1..10) {
                        Thread.sleep(200)
                        if (pendingJson.isNotBlank()) break
                    }
                } catch (_: InterruptedException) {
                    return@Thread
                }
                synchronized(this) { applyLocked(pendingJson, allowRetry = true) }
            }, "SysSensorConfigWait").start()
            return
        }
        synchronized(this) { applyLocked(pendingJson, allowRetry = true) }
    }

    @JvmStatic
    fun onConfig(json: String) {
        pendingJson = json
        ensureLoaded()
        if (!loaded) return
        synchronized(this) { applyLocked(json, allowRetry = true) }
    }

    /**
     * system_server 的 1 Hz worker 调用：下发真北方位、WMM 磁偏角和精度。
     * native 侧负责按传感器类型换算为磁北（TYPE_HEADING 保持真北）。
     */
    @JvmStatic
    fun onCompassHeading(
        trueHeadingDeg: Double,
        declinationDeg: Double,
        accuracyDeg: Double,
        horizontalUt: Double,
        verticalUt: Double,
        enabled: Boolean
    ) {
        if (!loaded || !initialized) return
        runCatching {
            SystemAccelNative.nativeSetCompassHeading(
                trueHeadingDeg,
                declinationDeg,
                accuracyDeg,
                horizontalUt,
                verticalUt,
                enabled
            )
        }
    }

    /**
     * 用 Kotlin 的 SmoothNoise 作为基准，检查 native 移植是否仍产生相同结果。
     * 只在首次加载后执行一次；结果写入日志，不影响传感器主流程。
     */
    private fun verifyRealismParity() {
        if (realismParityChecked) return
        realismParityChecked = true
        runCatching {
            val seed = 0x5EED5EEDL
            val minPeriod = 20.0
            val maxPeriod = 600.0
            val t = 42.0
            val noise = MotionRealism.SmoothNoise(seed, minPeriod, maxPeriod)
            val expected = doubleArrayOf(noise.value(t), noise.integral(t))
            val actual = SystemAccelNative.nativeNoiseProbe(seed, minPeriod, maxPeriod, t)
            val matches = actual.size == expected.size && expected.indices.all { i ->
                abs(actual[i] - expected[i]) <= 1e-9 * (1.0 + abs(expected[i]))
            }
            if (matches) {
                Log.i(TAG, "realism parity: ok")
            } else {
                Log.e(
                    TAG,
                    "realism parity: mismatch expected=${expected.contentToString()} " +
                        "actual=${actual.contentToString()}"
                )
            }

            val motion = SystemAccelNative.nativeMotionProbe(
                MotionGoldenVectors.STEPS_FLOAT,
                MotionGoldenVectors.SPEED_MPS,
                MotionGoldenVectors.CADENCE_SPM,
                MotionGoldenVectors.TRUE_HEADING_DEG,
                MotionGoldenVectors.DECLINATION_DEG,
                MotionGoldenVectors.YAW_RATE_RAD,
                MotionGoldenVectors.REALISM_LEVEL,
                MotionGoldenVectors.SEED,
                MotionGoldenVectors.TIME_SEC,
            )
            val expectedMotion = MotionGoldenVectors.ATTITUDE + MotionGoldenVectors.GYRO
            val motionMatches = motion.size == expectedMotion.size &&
                expectedMotion.indices.all { i ->
                    // 姿态是 double，角速度经过 native float 输出。
                    val tolerance = if (i < MotionGoldenVectors.ATTITUDE.size) 1e-9 else 1e-4
                    abs(motion[i] - expectedMotion[i]) <=
                        tolerance * (1.0 + abs(expectedMotion[i]))
                }
            if (motionMatches) {
                Log.i(TAG, "motion parity: ok")
            } else {
                Log.e(
                    TAG,
                    "motion parity: mismatch expected=${expectedMotion.contentToString()} " +
                        "actual=${motion.contentToString()}"
                )
            }

            val pressure = SystemAccelNative.nativePressureProbe(
                MotionGoldenVectors.PRESSURE_ALTITUDE_M,
                MotionGoldenVectors.PRESSURE_SEA_LEVEL_HPA,
                MotionGoldenVectors.PRESSURE_TIME_SEC,
            )
            val pressureMatches = abs(pressure - MotionGoldenVectors.PRESSURE_HPA) <=
                1e-9 * (1.0 + abs(MotionGoldenVectors.PRESSURE_HPA))
            if (pressureMatches) {
                Log.i(TAG, "pressure parity: ok")
            } else {
                Log.e(
                    TAG,
                    "pressure parity: mismatch expected=${MotionGoldenVectors.PRESSURE_HPA} " +
                        "actual=$pressure"
                )
            }
        }.onFailure { Log.e(TAG, "realism parity: probe failed", it) }
    }

    private fun ensureLoaded() {
        if (loaded || nativeLoadFailed) return
        synchronized(this) {
            if (loaded || nativeLoadFailed) return

            // 只打包了 arm64-v8a 的 native 库；在 x86_64 等 ABI 上直接降级为 Java-only，
            // 不反复调用 System.loadLibrary 刷日志。
            val abis = Build.SUPPORTED_ABIS
            if (abis.none { it == "arm64-v8a" }) {
                nativeLoadFailed = true
                nativeFailureReason = "unsupported ABI: ${abis.joinToString()}"
                Log.w(TAG, "native unavailable ($nativeFailureReason); Java-only mode")
                return
            }

            try {
                // ShadowHook 的 JNI_OnLoad 需要这个 Java 类在模块 classloader 中可见
                Class.forName("com.bytedance.shadowhook.ShadowHook", true, javaClass.classLoader)
                System.loadLibrary("shadowhook")
                System.loadLibrary("location_accel")
                loaded = true
                Log.i(TAG, "native libraries loaded")
                verifyRealismParity()
            } catch (t: Throwable) {
                // 加载失败是进程级事实，缓存失败状态，避免每次 onConfig 都重试并重复刷日志。
                nativeLoadFailed = true
                nativeFailureReason = "${t.javaClass.simpleName}: ${t.message}"
                Log.e(TAG, "load native library failed (cached; no retry): $nativeFailureReason", t)
            }
        }
    }

    /**
     * @return true 表示目标 UID 已解析并已下发；false 表示仍在等待 PMS。
     */
    private fun applyLocked(json: String, allowRetry: Boolean): Boolean {
        val cfg = runCatching {
            if (json.isBlank()) JSONObject() else JSONObject(json)
        }.getOrElse {
            Log.w(TAG, "invalid config json: ${it.message}")
            JSONObject()
        }

        val ctx = systemContext()
        if (ctx != null) registerPackageListener(ctx)

        val activeConfig = cfg.optBoolean(ConfigKeys.ACTIVE, false)
        val speed = cfg.optDouble(ConfigKeys.SPEED_M_S, 0.0).coerceIn(0.0, 30.0)
        val stepEnabled = cfg.optBoolean(ConfigKeys.ENABLE_STEP_SIMULATION, true)
        val accelEnabled = cfg.optBoolean(ConfigKeys.ENABLE_ACCEL_SIMULATION, true)
        val compassEnabled = activeConfig &&
            cfg.optBoolean(ConfigKeys.ENABLE_COMPASS_SIMULATION, true)
        val motionSimulate = activeConfig && speed > 0.05 &&
            (stepEnabled || accelEnabled)
        // compass 可以在静止/仅 compass 的配置下工作；步数/加速度仍只由 motionSimulate 控制。
        val simulate = motionSimulate || compassEnabled

        val globalMode = cfg.optBoolean(ConfigKeys.SYSTEM_HOOK_GLOBAL_MODE, false)
        val whitelist = cfg.optJSONArray(ConfigKeys.SYSTEM_HOOK_PACKAGES) ?: JSONArray()
        val resolution = if (globalMode) {
            resolveGlobalTargetUids(cfg, ctx)
        } else {
            resolvePackageUids(whitelist)
        }
        if (!resolution.resolved) {
            val now = System.currentTimeMillis()
            if (now - lastResolutionLog > 5000L) {
                lastResolutionLog = now
                Log.w(
                    TAG,
                    "target uids unresolved global=$globalMode " +
                        "packages=${resolution.total} matched=${resolution.matched}; " +
                        "retry=$allowRetry"
                )
            }
            // 即使 UID 解析失败，停止请求也必须到达 native；否则之前
            // 已配置的 UID 会继续收到步数/加速度/指南针注入。
            if (!activeConfig && initialized) {
                runCatching {
                    SystemAccelNative.nativeConfigure(
                        IntArray(0), false, 0.0, 0, -1, -1, -1,
                        0, 0, false, false, false, ""
                    )
                }
                runCatching {
                    SystemAccelNative.nativeSetCompassHeading(
                        0.0, 0.0, 0.0, Double.NaN, Double.NaN, false
                    )
                }
                lastKey = ""
            }
            if (allowRetry) scheduleTargetResolution(json)
            return false
        }

        val targetUids = resolution.uids
        val cadence = if (cfg.optBoolean(ConfigKeys.IS_AUTO_CADENCE, true)) {
            0
        } else {
            cfg.optInt(ConfigKeys.STEP_CADENCE_SPM, 165).coerceIn(60, 240)
        }
        val realism = cfg.optInt(ConfigKeys.REALISM_LEVEL, 0).coerceIn(0, 3)
        val fluctuation = cfg.optInt(ConfigKeys.SPEED_FLUCTUATION_PCT, 0).coerceIn(0, 100)
        val handles = resolveSensorHandles(cfg, ctx)
        val gait = cfg.optString(ConfigKeys.GAIT_TEMPLATE, "")

        val altitude = cfg.optDouble(ConfigKeys.ALTITUDE, 25.0)
        val altitudeVariation = if (cfg.has(ConfigKeys.ALTITUDE_VARIATION_M)) {
            cfg.optDouble(ConfigKeys.ALTITUDE_VARIATION_M, 0.0).coerceIn(0.0, 100.0)
        } else {
            altitudeAmplitudeForLevel(realism)
        }
        val barometer = cfg.optBoolean(ConfigKeys.BAROMETER_FLUCTUATION, false)
        val seaLevelHpa = cfg.optDouble(ConfigKeys.BAROMETER_SEA_LEVEL_HPA, 1013.25)
            .coerceIn(800.0, 1100.0)
        val startTimestamp = cfg.optLong(ConfigKeys.START_TIMESTAMP, 0L)
        val latitude = cfg.optDouble(ConfigKeys.LAT, 0.0)
        val longitude = cfg.optDouble(ConfigKeys.LNG, 0.0)
        val altitudeDrift = altitudeAmplitudeForLevel(realism)

        // 只比较传感器相关字段，避免位置/地址等高频配置变化反复打乱步态时钟
        val key = buildString {
            append(targetUids.joinToString(","))
            append('|').append(globalMode)
            append('|').append(simulate)
            append('|').append(speed)
            append('|').append(cadence)
            append('|').append(handles.stepDetector)
            append('|').append(handles.stepCounter)
            append('|').append(handles.accelerometer)
            append('|').append(realism)
            append('|').append(fluctuation)
            append('|').append(stepEnabled)
            append('|').append(accelEnabled)
            append('|').append(compassEnabled)
            append('|').append(altitude)
            append('|').append(altitudeVariation)
            append('|').append(barometer)
            append('|').append(startTimestamp)
            append('|').append(latitude)
            append('|').append(longitude)
            append('|').append(altitudeDrift)
            append('|').append(seaLevelHpa)
            append('|').append(gait.hashCode())
        }
        if (key == lastKey) return true

        try {
            if (!initialized && !profileApplied) {
                profileApplied = true
                val svcOffset = cfg.optInt(ConfigKeys.SENSOR_NATIVE_SVC_OFFSET, 0)
                val ctorOffset = cfg.optInt(ConfigKeys.SENSOR_NATIVE_CTOR_OFFSET, 0)
                val pltOffset = cfg.optInt(ConfigKeys.SENSOR_NATIVE_PLT_OFFSET, 0)
                val bitTubeOffset = cfg.optInt(ConfigKeys.SENSOR_NATIVE_BIT_TUBE_OFFSET, 0)
                val bitTubeFdOffset = cfg.optInt(ConfigKeys.SENSOR_NATIVE_BIT_TUBE_FD_OFFSET, 0)
                val uidOffset = cfg.optInt(ConfigKeys.SENSOR_NATIVE_UID_OFFSET, 0)
                val force = cfg.optBoolean(ConfigKeys.SENSOR_NATIVE_PROFILE_FORCE, false)
                if (svcOffset > 0 || ctorOffset > 0 || pltOffset > 0 ||
                    bitTubeOffset > 0 || bitTubeFdOffset > 0 || uidOffset > 0
                ) {
                    val profileOk = runCatching {
                        SystemAccelNative.nativeSetProfile(
                            svcOffset, ctorOffset, pltOffset,
                            bitTubeOffset, bitTubeFdOffset, uidOffset, force
                        )
                    }.getOrDefault(false)
                    Log.i(
                        TAG,
                        "native profile applied=$profileOk " +
                            "svc=0x${svcOffset.toString(16)} " +
                            "ctor=0x${ctorOffset.toString(16)} " +
                            "plt=0x${pltOffset.toString(16)} " +
                            "tube=$bitTubeOffset fd=$bitTubeFdOffset " +
                            "uid=0x${uidOffset.toString(16)} force=$force"
                    )
                }
                val eventStride = cfg.optInt(ConfigKeys.SENSOR_NATIVE_EVENT_STRIDE, 0)
                if (eventStride > 0) {
                    val layoutOk = runCatching {
                        SystemAccelNative.nativeSetEventLayout(eventStride)
                    }.getOrDefault(false)
                    Log.i(TAG, "native event stride applied=$layoutOk stride=$eventStride")
                }
            }
            // 始终使用显式 UID 列表；global 模式不再交给 native 的 allApps 段匹配
            if (!initialized) {
                initialized = SystemAccelNative.nativeInit(targetUids, false)
                nativeInitAttempts++
                Log.i(
                    TAG,
                    "nativeInit=$initialized targets=${targetUids.size} allApps=false " +
                        "attempt=$nativeInitAttempts"
                )
                if (!initialized) {
                    // 初始化失败不能继续 configure 并缓存 lastKey，否则同一份
                    // 配置永远不会再触发 nativeInit，UI 却仍显示传感器模拟已开。
                    if (allowRetry && nativeInitAttempts < 3) scheduleNativeInitRetry(json)
                    return false
                }
            }
            val ok = SystemAccelNative.nativeConfigure(
                targetUids,
                false,
                speed,
                cadence,
                handles.stepDetector,
                handles.stepCounter,
                handles.accelerometer,
                realism,
                fluctuation,
                simulate,
                motionSimulate && stepEnabled,
                motionSimulate && accelEnabled,
                gait
            )
            val clockOk = runCatching {
                SystemAccelNative.nativeSetClockStart(startTimestamp)
            }.getOrDefault(false)
            val pressureOk = runCatching {
                SystemAccelNative.nativeConfigurePressure(
                    altitude,
                    altitudeVariation,
                    latitude,
                    longitude,
                    altitudeDrift,
                    seaLevelHpa,
                    barometer && motionSimulate
                )
            }.getOrDefault(false)
            if (!compassEnabled) {
                runCatching {
                    SystemAccelNative.nativeSetCompassHeading(
                        0.0, 0.0, 0.0, Double.NaN, Double.NaN, false
                    )
                }
            }
            lastKey = key
            Log.i(
                TAG,
                "configure ok=$ok clockOk=$clockOk pressureOk=$pressureOk " +
                    "active=$activeConfig simulate=$simulate motionSim=$motionSimulate " +
                    "compass=$compassEnabled global=$globalMode " +
                    "targets=${targetUids.size} " +
                    "excludedSystem=${resolution.excludedSystem} " +
                    "excludedDenied=${resolution.excludedDenied} " +
                    "speed=$speed cadence=$cadence handles=" +
                    "${handles.stepDetector}/${handles.stepCounter}/" +
                    "0x${handles.accelerometer.toString(16)} realism=$realism " +
                    "start=$startTimestamp lat=$latitude lng=$longitude " +
                    "altitude=$altitude altVar=$altitudeVariation drift=$altitudeDrift " +
                    "barometer=$barometer " +
                    "gaitLen=${gait.length} status=${SystemAccelNative.nativeStatus()}"
            )
        } catch (t: Throwable) {
            Log.e(TAG, "native configure failed", t)
        }
        return true
    }

    private fun scheduleTargetResolution(json: String) {
        val generation = ++retryGeneration
        Thread({
            for (attempt in 1..RESOLVE_RETRY_COUNT) {
                Thread.sleep(RESOLVE_RETRY_MS)
                if (generation != retryGeneration || json != pendingJson) return@Thread
                if (!loaded) return@Thread
                val done = synchronized(this) {
                    applyLocked(json, allowRetry = false)
                }
                if (done) {
                    Log.i(TAG, "target uids resolved after $attempt retries")
                    return@Thread
                }
            }
            Log.w(TAG, "target uid resolution timed out")
        }, "SysSensorTargets").start()
    }

    /** nativeInit 失败后最多重试 3 次；常见原因是 libsensorservice 尚未加载。 */
    private fun scheduleNativeInitRetry(json: String) {
        if (nativeInitRetryThread?.isAlive == true) return
        nativeInitRetryThread = Thread({
            try {
                Thread.sleep(2_000L)
            } catch (_: InterruptedException) {
                return@Thread
            }
            if (!initialized && json == pendingJson) {
                Log.i(TAG, "retrying nativeInit after failure")
                onConfig(json)
            }
        }, "SysSensorInitRetry").also { it.start() }
    }

    // ---------------------------------------------------------------- target scan

    private data class GlobalTargetCache(
        val key: String,
        val at: Long,
        val resolution: TargetResolution,
    )

    private data class TargetResolution(
        val uids: IntArray,
        val matched: Int,
        val total: Int,
        val resolved: Boolean,
        val selected: Int = matched,
        val excludedSystem: Int = 0,
        val excludedDenied: Int = 0,
    )

    private data class AppEntry(
        val pkg: String,
        val uid: Int,
        val systemApp: Boolean,
        val enabled: Boolean,
        val userId: Int,
    )

    /**
     * global 模式：枚举所有用户的普通应用，默认排除系统应用与 GMS 等服务。
     * 60 秒缓存只是兜底；PackageManager 广播会立即失效缓存。
     */
    private fun resolveGlobalTargetUids(cfg: JSONObject, ctx: Context?): TargetResolution {
        val includeSystem = cfg.optBoolean(ConfigKeys.SENSOR_HOOK_INCLUDE_SYSTEM_APPS, false)
        val extraExcludes = stringSet(cfg.optJSONArray(ConfigKeys.SENSOR_HOOK_EXCLUDE_PACKAGES))
        val extraIncludes = stringSet(cfg.optJSONArray(ConfigKeys.SENSOR_HOOK_INCLUDE_PACKAGES)) +
            stringSet(cfg.optJSONArray(ConfigKeys.SYSTEM_HOOK_PACKAGES))
        val pm = ctx?.packageManager
            ?: return TargetResolution(IntArray(0), 0, 0, resolved = false)
        val userIds = resolveUserIds(ctx, cfg)
        val cacheKey = buildString {
            append(userIds.joinToString(","))
            append('|').append(includeSystem)
            append('|').append(extraExcludes.sorted().joinToString(","))
            append('|').append(extraIncludes.sorted().joinToString(","))
        }
        val now = System.currentTimeMillis()
        globalCache?.let { cache ->
            if (cache.key == cacheKey && now - cache.at < GLOBAL_TARGET_CACHE_MS) {
                return cache.resolution
            }
        }

        val entries = ArrayList<AppEntry>()
        for (userId in userIds) {
            val packages = installedPackagesForUser(pm, userId) ?: continue
            for (info in packages) {
                val ai = info.applicationInfo ?: continue
                val pkg = info.packageName ?: continue
                entries.add(
                    AppEntry(
                        pkg = pkg,
                        uid = ai.uid,
                        systemApp = isSystemApp(ai),
                        enabled = ai.enabled,
                        userId = userId,
                    )
                )
            }
        }
        if (entries.isEmpty()) {
            return TargetResolution(IntArray(0), 0, 0, resolved = false)
        }

        val excludedUids = HashSet<Int>()
        for (entry in entries) {
            if (isDeniedName(entry.pkg, extraExcludes)) excludedUids.add(entry.uid)
        }

        val uids = LinkedHashSet<Int>()
        var selected = 0
        var excludedSystem = 0
        var excludedDenied = 0
        for (entry in entries) {
            if (!entry.enabled) continue
            val appId = entry.uid % 100000
            if (entry.uid < 10000 || appId < 10000 || appId >= 20000) continue

            val explicitlyIncluded = extraIncludes.contains(entry.pkg)
            val denied = !explicitlyIncluded && (
                excludedUids.contains(entry.uid) ||
                    extraExcludes.contains(entry.pkg) ||
                    isDefaultExcludedName(entry.pkg)
                )
            if (denied) {
                excludedDenied++
                continue
            }
            if (entry.systemApp && !includeSystem && !explicitlyIncluded) {
                excludedSystem++
                continue
            }
            if (uids.add(entry.uid)) selected++
        }

        val sortedUids = uids.toIntArray().also { it.sort() }
        val resolution = TargetResolution(
            uids = sortedUids,
            matched = selected,
            total = entries.size,
            resolved = true,
            selected = selected,
            excludedSystem = excludedSystem,
            excludedDenied = excludedDenied,
        )
        globalCache = GlobalTargetCache(cacheKey, now, resolution)
        val gmsUid = resolvePackageUid("com.google.android.gms", 0)
        val gmsExcluded = gmsUid <= 0 || !uids.contains(gmsUid)
        Log.i(
            TAG,
            "global target scan users=${userIds.joinToString(",")} packages=${entries.size} " +
                "selected=$selected excludedSystem=$excludedSystem " +
                "excludedDenied=$excludedDenied includeSystem=$includeSystem " +
                "gmsUid=$gmsUid gmsExcluded=$gmsExcluded " +
                "uids=${sortedUids.joinToString(",")}"
        )
        return resolution
    }

    private fun resolveUserIds(ctx: Context, cfg: JSONObject): List<Int> {
        // 显式用户列表优先；支持 0、999、10 等 profile。
        val configured = cfg.optJSONArray(ConfigKeys.SENSOR_HOOK_USER_IDS)
        if (configured != null && configured.length() > 0) {
            val ids = (0 until configured.length())
                .mapNotNull { index ->
                    configured.optInt(index, -1).takeIf { it >= 0 }
                }
                .distinct()
            if (ids.isNotEmpty()) return ids
        }
        // 默认只作用于主用户，避免意外命中 HyperOS 的 user 999 / 双开空间。
        if (!cfg.optBoolean(ConfigKeys.SENSOR_HOOK_ALL_USERS, false)) return listOf(0)
        val um = runCatching {
            ctx.getSystemService(Context.USER_SERVICE) as? UserManager
        }.getOrNull()
        val profiles = runCatching {
            um?.javaClass?.getMethod("getUserProfiles")?.invoke(um)
        }.getOrNull() as? List<*>
        val ids = profiles.orEmpty()
            .filterIsInstance<UserHandle>()
            .mapNotNull { userHandleId(it) }
            .distinct()
        return if (ids.isNotEmpty()) ids else listOf(0)
    }

    private fun userHandleId(handle: UserHandle): Int? {
        return runCatching {
            val method = handle.javaClass.getMethod("getIdentifier")
            method.invoke(handle) as? Int
        }.getOrNull()
    }

    private fun installedPackagesForUser(
        pm: PackageManager,
        userId: Int
    ): List<PackageInfo>? {
        if (userId == 0) {
            return runCatching { pm.getInstalledPackages(0) }.getOrNull()
        }
        return runCatching {
            val method = pm.javaClass.getMethod(
                "getInstalledPackagesAsUser",
                Int::class.javaPrimitiveType,
                Int::class.javaPrimitiveType
            )
            @Suppress("UNCHECKED_CAST")
            method.invoke(pm, 0, userId) as? List<PackageInfo>
        }.getOrNull()
    }

    private fun isSystemApp(ai: ApplicationInfo): Boolean =
        (ai.flags and (ApplicationInfo.FLAG_SYSTEM or
            ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) != 0

    private fun isDefaultExcludedName(pkg: String): Boolean {
        if (DEFAULT_EXCLUDED_PACKAGES.contains(pkg)) return true
        return DEFAULT_EXCLUDED_PREFIXES.any { pkg.startsWith(it) }
    }

    private fun isDeniedName(pkg: String, extraExcludes: Set<String>): Boolean =
        extraExcludes.contains(pkg) || isDefaultExcludedName(pkg)

    private fun stringSet(array: JSONArray?): Set<String> {
        if (array == null) return emptySet()
        val out = LinkedHashSet<String>()
        for (i in 0 until array.length()) {
            val pkg = array.optString(i, "").substringBefore(":").trim()
            if (pkg.isNotEmpty()) out.add(pkg)
        }
        return out
    }

    // ---------------------------------------------------------------- handles

    private data class SensorHandles(
        val stepDetector: Int,
        val stepCounter: Int,
        val accelerometer: Int,
    )

    private fun resolveSensorHandles(cfg: JSONObject, ctx: Context?): SensorHandles {
        val auto = autoHandles ?: scanDefaultSensorHandles(ctx)?.also { autoHandles = it }
        return SensorHandles(
            stepDetector = cfg.optInt(
                ConfigKeys.SENSOR_STEP_DETECTOR_HANDLE,
                auto?.stepDetector ?: DEFAULT_STEP_DETECTOR_HANDLE
            ),
            stepCounter = cfg.optInt(
                ConfigKeys.SENSOR_STEP_COUNTER_HANDLE,
                auto?.stepCounter ?: DEFAULT_STEP_COUNTER_HANDLE
            ),
            accelerometer = cfg.optInt(
                ConfigKeys.SENSOR_ACCELEROMETER_HANDLE,
                auto?.accelerometer ?: DEFAULT_ACCELEROMETER_HANDLE
            ),
        )
    }

    private fun scanDefaultSensorHandles(ctx: Context?): SensorHandles? {
        val sensorManager = runCatching {
            ctx?.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
        }.getOrNull() ?: return null
        fun handleOf(type: Int): Int? {
            val sensor = runCatching { sensorManager.getDefaultSensor(type) }.getOrNull()
                ?: return null
            return sensorHandle(sensor)
        }
        val stepDetector = handleOf(Sensor.TYPE_STEP_DETECTOR) ?: -1
        val stepCounter = handleOf(Sensor.TYPE_STEP_COUNTER) ?: -1
        val accelerometer = handleOf(Sensor.TYPE_ACCELEROMETER) ?: -1
        if (stepDetector < 0 && stepCounter < 0 && accelerometer < 0) return null
        Log.i(
            TAG,
            "auto sensor handles detector=$stepDetector counter=$stepCounter " +
                "accelerometer=0x${accelerometer.toString(16)}"
        )
        return SensorHandles(stepDetector, stepCounter, accelerometer)
    }

    private fun sensorHandle(sensor: Sensor): Int? {
        var clazz: Class<*>? = sensor.javaClass
        while (clazz != null) {
            val value = runCatching {
                val method = clazz!!.getDeclaredMethod("getHandle")
                method.isAccessible = true
                method.invoke(sensor) as? Int
            }.getOrNull()
            if (value != null) return value
            clazz = clazz.superclass
        }
        return null
    }

    private fun altitudeAmplitudeForLevel(level: Int): Double = when (level) {
        1 -> 1.5
        2 -> 3.0
        3 -> 5.0
        else -> 0.0
    }

    // ---------------------------------------------------------------- package changes

    private fun registerPackageListener(ctx: Context) {
        if (packageReceiver != null) return
        synchronized(this) {
            if (packageReceiver != null) return
            val filter = IntentFilter().apply {
                addAction(Intent.ACTION_PACKAGE_ADDED)
                addAction(Intent.ACTION_PACKAGE_REMOVED)
                addAction(Intent.ACTION_PACKAGE_REPLACED)
                addDataScheme("package")
            }
            val receiver = object : BroadcastReceiver() {
                override fun onReceive(context: Context?, intent: Intent?) {
                    globalCache = null
                    scheduleGlobalRefresh()
                }
            }
            if (runCatching { ctx.registerReceiver(receiver, filter) }.isSuccess) {
                packageReceiver = receiver
                Log.i(TAG, "package change listener registered")
            }
        }
    }

    private fun scheduleGlobalRefresh() {
        synchronized(this) {
            if (refreshScheduled) return
            refreshScheduled = true
        }
        Thread({
            try {
                Thread.sleep(500)
            } catch (_: InterruptedException) {
                return@Thread
            }
            synchronized(this) { refreshScheduled = false }
            if (loaded) {
                synchronized(this) { applyLocked(pendingJson, allowRetry = true) }
            }
        }, "SysSensorPackages").start()
    }

    // ---------------------------------------------------------------- uid resolution

    private fun resolvePackageUids(array: JSONArray): TargetResolution {
        val packages = ArrayList<String>()
        for (i in 0 until array.length()) {
            val pkg = array.optString(i, "").substringBefore(":").trim()
            if (pkg.isNotEmpty()) packages.add(pkg)
        }
        val uids = LinkedHashSet<Int>()
        var matched = 0
        for (pkg in packages) {
            val uid = resolvePackageUid(pkg, 0)
            if (uid > 0) {
                uids.add(uid)
                matched++
            }
        }
        return TargetResolution(
            uids = uids.toIntArray(),
            matched = matched,
            total = packages.size,
            // 白名单里某个包被卸载/暂时不可见时，不应该让其余包也停止
            // 注入；只要解析到至少一个 UID 就继续，缺失的包由下次
            // PackageManager 变化/配置更新再补。
            resolved = packages.isEmpty() || matched > 0,
        )
    }

    /**
     * 双路径解析：系统 Context 的 PackageManager（user 0），失败后退回
     * AppGlobals 的 IPackageManager（可指定 userId）。
     */
    private fun resolvePackageUid(pkg: String, userId: Int): Int {
        if (userId == 0) {
            systemPackageManager()?.let { pm ->
                val uid = runCatching { pm.getPackageUid(pkg, 0) }.getOrDefault(-1)
                if (uid > 0) return uid
            }
        }
        return try {
            val appGlobals = Class.forName("android.app.AppGlobals")
            val ipm = appGlobals.getMethod("getPackageManager").invoke(null) ?: return -1
            val method = ipm.javaClass.getMethod(
                "getPackageUid",
                String::class.java,
                Long::class.javaPrimitiveType,
                Int::class.javaPrimitiveType
            )
            (method.invoke(ipm, pkg, 0L, userId) as? Int) ?: -1
        } catch (_: Throwable) {
            -1
        }
    }

    private fun systemContext(): Context? {
        return try {
            val at = Class.forName("android.app.ActivityThread")
            val current = at.getMethod("currentActivityThread").invoke(null)
            at.getMethod("getSystemContext").invoke(current) as? Context
        } catch (_: Throwable) {
            null
        }
    }

    private fun systemPackageManager(): PackageManager? = systemContext()?.packageManager
}
