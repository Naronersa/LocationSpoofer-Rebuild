import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    alias(libs.plugins.android.library)
    alias(libs.plugins.jetbrains.kotlin.android)
}

android {
    namespace = "com.vincenthzr.locationspoofer.sensor"
    compileSdk = 37
    ndkVersion = "27.2.12479018"

    defaultConfig {
        minSdk = 26
        // release 构建保留反射入口与 JNI 方法名
        consumerProguardFiles("consumer-rules.pro")

        // 与上游 global native 一致：仅 arm64。
        ndk {
            abiFilters += listOf("arm64-v8a")
        }
        externalNativeBuild {
            cmake {
                cppFlags += listOf("-std=c++17", "-fno-exceptions", "-fno-rtti")
            }
        }
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

dependencies {
    // 运行时用 Kotlin 的 MotionRealism 生成同一组噪声基准，校验 native 移植是否漂移
    implementation(project(":core-geo"))
    // ShadowHook 的 Java 类与 libshadowhook.so（Apache-2.0）；JNI_OnLoad 需要注册其 Java 类
    implementation("com.bytedance.android:shadowhook:2.0.1")
}
