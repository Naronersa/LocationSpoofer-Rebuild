package com.vincenthzr.sensorprobe

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

/**
 * 自测页面：注册计步/加速度传感器并显示实时值。
 * 验证工具 Hook 生效时，本 App（按 UID 匹配）会看到被改写的步数。
 */
class MainActivity : Activity(), SensorEventListener {

    private lateinit var sensorManager: SensorManager
    private lateinit var output: TextView

    private var stepCounter = -1f
    private var stepDetector = -1f
    private var accel = "-"
    private var pressure = -1f
    private var orientation = "-"
    private var magnetic = "-"
    private var magneticAzimuth = -1f
    private var rotation = "-"
    private var rotationAzimuth = -1f
    private var gameRotationAzimuth = -1f
    private var geomagneticAzimuth = -1f
    private var heading = "-"
    private var gyroscope = "-"
    private var lastLogAt = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        output = TextView(this).apply {
            textSize = 16f
            gravity = Gravity.START
            setPadding(48, 48, 48, 48)
        }
        setContentView(
            LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                addView(output)
            }
        )

        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        if (checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.ACTIVITY_RECOGNITION), 1)
        }
        render("uid=${android.os.Process.myUid()}")
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        registerSensors()
    }

    override fun onResume() {
        super.onResume()
        registerSensors()
    }

    override fun onPause() {
        sensorManager.unregisterListener(this)
        super.onPause()
    }

    private fun registerSensors() {
        sensorManager.unregisterListener(this)
        val types = mutableListOf(
            Sensor.TYPE_STEP_COUNTER,
            Sensor.TYPE_STEP_DETECTOR,
            Sensor.TYPE_ACCELEROMETER,
            Sensor.TYPE_PRESSURE,
            Sensor.TYPE_GYROSCOPE,
            Sensor.TYPE_GYROSCOPE_UNCALIBRATED,
            Sensor.TYPE_MAGNETIC_FIELD,
            Sensor.TYPE_ORIENTATION,
            Sensor.TYPE_ROTATION_VECTOR,
            Sensor.TYPE_MAGNETIC_FIELD_UNCALIBRATED,
            Sensor.TYPE_GAME_ROTATION_VECTOR,
            Sensor.TYPE_GEOMAGNETIC_ROTATION_VECTOR
        )
        if (Build.VERSION.SDK_INT >= 33) {
            // TYPE_HEADING (API 33+) 使用真北。
            types.add(42)
        }
        for (type in types) {
            val sensor = sensorManager.getDefaultSensor(type)
            if (sensor == null) {
                Log.w(TAG, "sensor type=$type not available")
                continue
            }
            sensorManager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_NORMAL)
            Log.i(TAG, "registered type=$type name=${sensor.name}")
        }
        render("uid=${android.os.Process.myUid()} (listening)")
    }

    override fun onSensorChanged(event: SensorEvent) {
        when (event.sensor.type) {
            Sensor.TYPE_STEP_COUNTER -> stepCounter = event.values.firstOrNull() ?: -1f
            Sensor.TYPE_STEP_DETECTOR -> stepDetector = event.values.firstOrNull() ?: -1f
            Sensor.TYPE_ACCELEROMETER -> accel = event.values.take(3).joinToString(",") { "%.2f".format(it) }
            Sensor.TYPE_PRESSURE -> pressure = event.values.firstOrNull() ?: -1f
            Sensor.TYPE_GYROSCOPE, Sensor.TYPE_GYROSCOPE_UNCALIBRATED -> {
                gyroscope = event.values.take(3).joinToString(",") { "%.3f".format(it) }
            }
            Sensor.TYPE_ORIENTATION -> orientation =
                event.values.take(3).joinToString(",") { "%.1f".format(it) }
            Sensor.TYPE_MAGNETIC_FIELD, Sensor.TYPE_MAGNETIC_FIELD_UNCALIBRATED -> {
                magnetic = event.values.take(3).joinToString(",") { "%.1f".format(it) }
                magneticAzimuth = fieldAzimuth(event.values)
            }
            Sensor.TYPE_ROTATION_VECTOR -> {
                rotation = event.values.take(4).joinToString(",") { "%.3f".format(it) }
                rotationAzimuth = quaternionAzimuth(event.values)
            }
            Sensor.TYPE_GAME_ROTATION_VECTOR -> {
                gameRotationAzimuth = quaternionAzimuth(event.values)
            }
            Sensor.TYPE_GEOMAGNETIC_ROTATION_VECTOR -> {
                geomagneticAzimuth = quaternionAzimuth(event.values)
            }
            42 -> {
                // TYPE_HEADING (API 33+): true-north heading, accuracy degrees.
                heading = event.values.take(2).joinToString(",") { "%.1f".format(it) }
            }
        }
        val now = android.os.SystemClock.elapsedRealtime()
        if (now - lastLogAt >= 250L) {
            lastLogAt = now
            Log.i(
                TAG,
                "onSensorChanged type=${event.sensor.type} values=${event.values.joinToString(",")}"
            )
        }
        render(
            "uid=${android.os.Process.myUid()}\n" +
                "step_counter=$stepCounter\n" +
                "step_detector=$stepDetector\n" +
                "accel=$accel\n" +
                "pressure=$pressure\n" +
                "gyro=$gyroscope\n" +
                "orientation=$orientation\n" +
                "magnetic=$magnetic\n" +
                "magnetic_azimuth=$magneticAzimuth\n" +
                "rotation=$rotation\n" +
                "rotation_azimuth=$rotationAzimuth\n" +
                "game_azimuth=$gameRotationAzimuth\n" +
                "geomagnetic_azimuth=$geomagneticAzimuth\n" +
                "heading=$heading"
        )
    }

    private fun fieldAzimuth(values: FloatArray): Float {
        if (values.size < 2) return -1f
        val degrees = Math.toDegrees(
            kotlin.math.atan2(-values[0].toDouble(), values[1].toDouble())
        )
        return ((degrees + 360.0) % 360.0).toFloat()
    }

    private fun quaternionAzimuth(values: FloatArray): Float {
        if (values.size < 4) return -1f
        return try {
            val matrix = FloatArray(9)
            SensorManager.getRotationMatrixFromVector(matrix, values.copyOf(4))
            val orientation = FloatArray(3)
            SensorManager.getOrientation(matrix, orientation)
            val degrees = Math.toDegrees(orientation[0].toDouble())
            ((degrees + 360.0) % 360.0).toFloat()
        } catch (_: Throwable) {
            -1f
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    private fun render(prefix: String) {
        output.text = "$prefix\n\n" +
            "如果 Hook 生效：step_counter 应按 cadence 持续增长；\n" +
            "step_detector 在运动/静止时由验证工具置 1。\n" +
            "指南针：heading 使用真北；orientation/magnetic/rotation 使用磁北。\n" +
            "查看日志：adb logcat -s SensorProbe"
    }

    private companion object {
        const val TAG = "SensorProbe"
    }
}
