import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    alias(libs.plugins.android.library)
    alias(libs.plugins.jetbrains.kotlin.android)
    alias(libs.plugins.ksp)
    alias(libs.plugins.jetbrains.kotlin.serialization)
}

android {
    namespace = "com.vincenthzr.locationspoofer.data"
    compileSdk = 37

    defaultConfig {
        minSdk = 26
    }

    // 与 app/build.gradle.kts 中的 scheme 维度保持一致
    flavorDimensions += "scheme"
    productFlavors {
        create("global") {
            dimension = "scheme"
            buildConfigField("boolean", "GLOBAL_SCHEME", "true")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    buildFeatures {
        buildConfig = true
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
        freeCompilerArgs.addAll(
            "-opt-in=kotlinx.serialization.InternalSerializationApi"
        )
    }
}

ksp {
    // Room schema 是数据库升级的唯一契约；没有 schema 就无法做迁移测试。
    arg("room.schemaLocation", "$projectDir/schemas")
}

dependencies {
    implementation(project(":core-geo"))

    implementation(libs.xposed.service)
    implementation(libs.koin.android)
    implementation(libs.kotlinx.serialization.json)
    implementation(libs.okhttp)
    implementation(libs.androidx.core.ktx)

    implementation(libs.room.runtime)
    implementation(libs.room.ktx)
    ksp(libs.room.compiler)

    testImplementation(libs.junit)
    testImplementation(libs.org.json)
}
