package com.vincenthzr.locationspoofer.utils

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SystemFileCommandsTest {

    @Test
    fun `legacy cleanup only targets the current package`() {
        val command = SystemFileCommands.removeLegacyConfigs(
            "com.vincenthzr.locationspoofer.rebuild"
        )

        assertTrue(
            command.contains(
                "/data/data/com.vincenthzr.locationspoofer.rebuild/files/locationspoofer_config.json"
            )
        )
        assertFalse(
            "本项目不得删除其他包的数据",
            command.contains("/data/data/com.vincenthzr.locationspoofer/files/")
        )
    }

    @Test(expected = IllegalArgumentException::class)
    fun `legacy cleanup rejects a shell-unsafe package name`() {
        SystemFileCommands.removeLegacyConfigs("com.foo;rm -rf /")
    }
}
