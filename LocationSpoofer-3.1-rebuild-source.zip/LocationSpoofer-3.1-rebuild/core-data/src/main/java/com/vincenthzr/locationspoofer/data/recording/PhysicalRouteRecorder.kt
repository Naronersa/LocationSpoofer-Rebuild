package com.vincenthzr.locationspoofer.data.recording

import com.vincenthzr.locationspoofer.utils.ConfigKeys

import android.os.SystemClock
import com.vincenthzr.locationspoofer.data.db.SavedRouteDao
import com.vincenthzr.locationspoofer.data.db.SavedRouteEntity
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * 物理路线录制状态机。行为对齐上游 3.0.19：
 * - 采样过滤、跳点/间隙/精度判断由 [PhysicalRouteTrack] 完成；
 * - 每 5 秒把草稿原子写入磁盘，进程被杀后可在下次启动时恢复（PAUSED/INTERRUPTED）；
 * - 完成（FINISHED）后由 UI 调用 [save] 落库为普通路线，或 [discard] 丢弃。
 */
class PhysicalRouteRecorder(
    private val storage: PhysicalRouteDraftStorage,
    private val dao: SavedRouteDao,
    private val sendCommand: (PhysicalRouteCommand) -> Unit,
    private val simulationActive: () -> Boolean,
    private val millis: () -> Long = { SystemClock.elapsedRealtime() },
    private val nanos: () -> Long = { SystemClock.elapsedRealtimeNanos() },
    private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate),
) {

    private val mutex = Mutex()
    private val _state = MutableStateFlow(PhysicalRouteRecordingState())
    val state: StateFlow<PhysicalRouteRecordingState> = _state.asStateFlow()

    private var track = PhysicalRouteTrack()
    private var elapsedBeforeSegment = 0L
    private var segmentStarted: Long? = null
    private var segmentStartedNanos = 0L
    private var lastGoodFixAt = 0L
    private var lastCheckpoint = 0L
    private var serviceOwner: Any? = null

    init {
        scope.launch {
            mutex.withLock {
                try {
                    val draft = withContext(Dispatchers.IO) { storage.load() }
                    if (draft != null) {
                        track = PhysicalRouteTrack(draft.pointsWgs84)
                        elapsedBeforeSegment = draft.durationMillis
                        _state.value = PhysicalRouteRecordingState(
                            ready = true,
                            id = draft.id,
                            phase = if (draft.finished) PhysicalRoutePhase.FINISHED else PhysicalRoutePhase.PAUSED,
                            points = track.businessPoints(),
                            distanceM = track.distanceM,
                            durationMillis = draft.durationMillis,
                            accuracyM = null,
                            issue = if (draft.finished) PhysicalRouteIssue.NONE else PhysicalRouteIssue.INTERRUPTED,
                            saving = false,
                        )
                    } else {
                        _state.value = PhysicalRouteRecordingState(ready = true)
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    _state.value = PhysicalRouteRecordingState(ready = true, issue = PhysicalRouteIssue.STORAGE)
                }
            }
        }
    }

    /**
     * 开始（或恢复）录制。
     * @param resumeExisting true = 从 PAUSED 草稿继续；false = 全新录制（要求没有草稿）。
     * @param owner 服务实例标识，用于区分“当前服务退出”与过期回调。
     */
    suspend fun begin(resumeExisting: Boolean, owner: Any?): Boolean = mutex.withLock {
        val current = _state.value
        if (!current.ready || current.saving || current.issue == PhysicalRouteIssue.STORAGE) {
            return@withLock false
        }
        if (simulationActive()) {
            _state.value = current.copy(issue = PhysicalRouteIssue.SIMULATION_ACTIVE)
            return@withLock false
        }
        if (resumeExisting && current.phase != PhysicalRoutePhase.PAUSED) return@withLock false
        if (!resumeExisting && current.hasDraft) return@withLock false

        if (!resumeExisting) {
            track = PhysicalRouteTrack()
            elapsedBeforeSegment = 0L
        }
        track.resume()

        val now = millis()
        segmentStarted = now
        segmentStartedNanos = nanos()
        lastGoodFixAt = millis()
        serviceOwner = owner

        _state.value = current.copy(
            id = if (resumeExisting) current.id else UUID.randomUUID().toString(),
            phase = PhysicalRoutePhase.RECORDING,
            points = track.businessPoints(),
            distanceM = track.distanceM,
            durationMillis = elapsedBeforeSegment,
            issue = PhysicalRouteIssue.WAITING,
            saving = false,
        )
        checkpointLocked()
        true
    }

    suspend fun pause(issue: PhysicalRouteIssue = PhysicalRouteIssue.NONE) {
        mutex.withLock { pauseLocked(issue) }
    }

    suspend fun finish() = mutex.withLock {
        val current = _state.value
        if (current.hasDraft && !current.saving) {
            elapsedBeforeSegment = elapsed()
            segmentStarted = null
            _state.value = current.copy(
                phase = PhysicalRoutePhase.FINISHED,
                durationMillis = elapsedBeforeSegment,
            )
            checkpointLocked()
        }
    }

    /** 丢弃草稿并复位。录制中或保存中不允许丢弃。 */
    suspend fun discard(): Boolean = mutex.withLock {
        val current = _state.value
        if (current.recording || current.saving) return@withLock false
        try {
            withContext(Dispatchers.IO) { storage.clear() }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            _state.value = current.copy(issue = PhysicalRouteIssue.STORAGE)
            return@withLock false
        }
        resetToIdle()
        true
    }

    /** 把当前草稿保存为普通路线；成功返回 true。 */
    suspend fun save(name: String): Boolean = mutex.withLock {
        val current = _state.value
        val points = track.businessPoints()
        val trimmed = name.trim()
        if (current.recording || current.saving || current.id == null ||
            points.size < 2 || trimmed.isEmpty() || name.length > 100
        ) {
            return@withLock false
        }
        val sessionId = current.id ?: return@withLock false
        _state.value = current.copy(saving = true)
        try {
            withContext(Dispatchers.IO) {
                val array = JSONArray()
                for (point in points) {
                    array.put(JSONObject().put(ConfigKeys.LAT, point.lat).put(ConfigKeys.LNG, point.lng).put(ConfigKeys.WAIT_SEC, 0))
                }
                // 与上游一致：草稿 id 作为 syncId；已存在时幂等跳过，避免重复保存
                if (dao.findBySyncId(sessionId) == null) {
                    dao.insertSavedRoute(
                        SavedRouteEntity(
                            name = trimmed,
                            pointsJson = array.toString(),
                            timestamp = System.currentTimeMillis(),
                            syncId = sessionId,
                            recorded = true,
                            coordinateSystem = "WGS84",
                        )
                    )
                }
                storage.clear()
            }
            resetToIdle()
            true
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            _state.value = _state.value.copy(issue = PhysicalRouteIssue.STORAGE, saving = false)
            false
        }
    }

    /** 处理一条真实定位采样。 */
    suspend fun sample(fix: PhysicalRouteFix) = mutex.withLock {
        val current = _state.value
        if (!current.recording) return@withLock
        if (simulationActive()) {
            pauseLocked(PhysicalRouteIssue.SIMULATION_ACTIVE)
            return@withLock
        }
        if (fix.elapsedNanos < segmentStartedNanos) {
            _state.value = current.copy(issue = PhysicalRouteIssue.STALE)
            return@withLock
        }
        when (val issue = track.append(fix, nanos())) {
            PhysicalRouteIssue.GAP, PhysicalRouteIssue.LIMIT -> pauseLocked(issue)
            else -> {
                if (issue == PhysicalRouteIssue.NONE) lastGoodFixAt = millis()
                _state.value = _state.value.copy(
                    points = track.businessPoints(),
                    distanceM = track.distanceM,
                    durationMillis = elapsed(),
                    accuracyM = if (issue == PhysicalRouteIssue.NONE) fix.accuracyM else _state.value.accuracyM,
                    issue = issue,
                )
                if (millis() - lastCheckpoint >= CHECKPOINT_INTERVAL_MS) checkpointLocked()
            }
        }
    }

    /** 服务侧每秒驱动一次：刷新时长、失联提示与周期性检查点。 */
    suspend fun tick() = mutex.withLock {
        val current = _state.value
        if (!current.recording) return@withLock
        if (simulationActive()) {
            pauseLocked(PhysicalRouteIssue.SIMULATION_ACTIVE)
            return@withLock
        }
        val issue = if (current.issue != PhysicalRouteIssue.NONE ||
            millis() - lastGoodFixAt <= WAITING_AFTER_MS
        ) {
            current.issue
        } else {
            PhysicalRouteIssue.WAITING
        }
        _state.value = current.copy(durationMillis = elapsed(), issue = issue)
        if (millis() - lastCheckpoint >= CHECKPOINT_INTERVAL_MS) checkpointLocked()
    }

    /** GPS 开关等即时状态变化：录制中（或权限错误）时反映到 issue。 */
    suspend fun signal(issue: PhysicalRouteIssue) = mutex.withLock {
        if (_state.value.recording || issue == PhysicalRouteIssue.PERMISSION) {
            _state.value = _state.value.copy(issue = issue)
        }
    }

    /** 服务被系统回收时的兜底：会话与 owner 都匹配时才自动暂停为 INTERRUPTED（与上游一致）。 */
    fun serviceLost(sessionId: String?, owner: Any?) {
        if (sessionId == null || owner == null) return
        scope.launch {
            mutex.withLock {
                if (_state.value.id != sessionId || serviceOwner !== owner) return@withLock
                if (_state.value.recording) pauseLocked(PhysicalRouteIssue.INTERRUPTED)
            }
        }
    }

    /** 通过控制器把命令发给服务；失败时标记 PERMISSION。 */
    fun request(command: PhysicalRouteCommand) {
        try {
            sendCommand(command)
        } catch (e: Exception) {
            _state.value = _state.value.copy(issue = PhysicalRouteIssue.PERMISSION)
        }
    }

    /** 模拟开始等互斥操作：录制中直接拒绝。 */
    suspend fun <T> withSimulationStart(block: suspend () -> T): T = mutex.withLock {
        if (_state.value.recording) throw IllegalStateException("physical_route_recording_active")
        block()
    }

    private suspend fun pauseLocked(issue: PhysicalRouteIssue) {
        if (!_state.value.recording) return
        elapsedBeforeSegment = elapsed()
        segmentStarted = null
        _state.value = _state.value.copy(
            phase = PhysicalRoutePhase.PAUSED,
            durationMillis = elapsedBeforeSegment,
            issue = issue,
            saving = false,
        )
        checkpointLocked()
    }

    private suspend fun checkpointLocked(): Boolean {
        val current = _state.value
        val id = current.id ?: return true
        return try {
            val draft = PhysicalRouteDraft(
                id = id,
                pointsWgs84 = track.points(),
                durationMillis = elapsed(),
                finished = current.phase == PhysicalRoutePhase.FINISHED,
            )
            withContext(Dispatchers.IO) { storage.save(draft) }
            lastCheckpoint = millis()
            true
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            elapsedBeforeSegment = elapsed()
            segmentStarted = null
            _state.value = _state.value.copy(
                phase = PhysicalRoutePhase.PAUSED,
                durationMillis = elapsedBeforeSegment,
                issue = PhysicalRouteIssue.STORAGE,
                saving = false,
            )
            false
        }
    }

    private fun resetToIdle() {
        track = PhysicalRouteTrack()
        segmentStarted = null
        elapsedBeforeSegment = 0L
        _state.value = PhysicalRouteRecordingState(ready = true)
    }

    private fun elapsed(): Long {
        val running = segmentStarted?.let { millis() - it } ?: 0L
        return (elapsedBeforeSegment + running).coerceIn(0L, PhysicalRouteDraft.MAX_DURATION_MILLIS)
    }

    companion object {
        private const val CHECKPOINT_INTERVAL_MS = 5_000L
        private const val WAITING_AFTER_MS = 10_000L
    }
}
