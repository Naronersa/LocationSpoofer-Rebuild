package com.vincenthzr.locationspoofer.data.recording

import com.vincenthzr.locationspoofer.data.model.RoutePoint
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * 物理路线轨迹：对定位采样做质量过滤、跳点/间隙判断与距离累计。
 * 行为与上游 3.0.19 的 PhysicalRouteTrack 一致（阈值见常量）。
 */
class PhysicalRouteTrack(initialPoints: List<RoutePoint> = emptyList()) {

    private val recorded = ArrayList(initialPoints)
    private var mapped: List<RoutePoint> = ArrayList(initialPoints)
    private var lastFixNanos: Long? = null

    var distanceM: Double = 0.0
        private set

    init {
        for (index in 1 until recorded.size) {
            distanceM += distance(recorded[index - 1], recorded[index])
        }
    }

    fun append(fix: PhysicalRouteFix, nowNanos: Long): PhysicalRouteIssue {
        if (fix.mock) return PhysicalRouteIssue.MOCK_LOCATION

        val lat = fix.lat
        val lng = fix.lng
        val accuracy = fix.accuracyM
        if (lat !in -90.0..90.0 || lng !in -180.0..180.0) return PhysicalRouteIssue.POOR_ACCURACY
        if (accuracy.isNaN() || accuracy <= 0f || accuracy > 35f) return PhysicalRouteIssue.POOR_ACCURACY

        if (fix.elapsedNanos <= 0L || fix.elapsedNanos > nowNanos ||
            nowNanos - fix.elapsedNanos > 10_000_000_000L
        ) {
            return PhysicalRouteIssue.STALE
        }

        val point = RoutePoint(lat, lng)
        val last = recorded.lastOrNull()
        val distance = if (last != null) distance(last, point) else 0.0
        val previousNanos = lastFixNanos

        // 距上一点超过 30m 且停顿超过 15s：视为录制中断留下的间隙
        if (last != null && distance > 30.0 &&
            (previousNanos == null || fix.elapsedNanos - previousNanos > 15_000_000_000L)
        ) {
            return PhysicalRouteIssue.GAP
        }
        // 超出“30m 或 80m/s”的瞬移
        if (previousNanos != null &&
            distance > max(30.0, (fix.elapsedNanos - previousNanos) / 1.0E9 * 80.0)
        ) {
            return PhysicalRouteIssue.JUMP
        }

        lastFixNanos = fix.elapsedNanos

        // 位移小于精度抖动阈值：不落点
        if (last != null && distance < max(3.0, min(accuracy.toDouble(), 10.0) * 0.5)) {
            return PhysicalRouteIssue.NONE
        }
        if (recorded.size >= MAX_POINTS) return PhysicalRouteIssue.LIMIT

        recorded.add(point)
        mapped = mapped + point
        distanceM += distance
        return PhysicalRouteIssue.NONE
    }

    fun businessPoints(): List<RoutePoint> = mapped

    fun points(): List<RoutePoint> = recorded.toList()

    fun resume() {
        lastFixNanos = null
    }

    companion object {
        const val MAX_POINTS = 10_000
        private const val MAX_ACCURACY_M = 35.0
        private const val MAX_FIX_AGE_NANOS = 10_000_000_000L
        private const val GAP_DISTANCE_M = 30.0
        private const val GAP_PAUSE_NANOS = 15_000_000_000L
        private const val MAX_SPEED_M_PER_S = 80.0
        private const val EARTH_DIAMETER_M = 1.2742E7

        /** Haversine 距离（米），与上游实现一致。 */
        fun distance(a: RoutePoint, b: RoutePoint): Double {
            val dLat = Math.toRadians(b.lat - a.lat)
            val dLng = Math.toRadians(b.lng - a.lng)
            val sinLat = sin(dLat / 2.0).pow(2)
            val sinLng = sin(dLng / 2.0).pow(2)
            val h = sinLng * cos(Math.toRadians(b.lat)) * cos(Math.toRadians(a.lat)) + sinLat
            return asin(sqrt(h.coerceIn(0.0, 1.0))) * EARTH_DIAMETER_M
        }
    }
}
