package com.vincenthzr.locationspoofer.data.recording

import android.content.Context

/** 将录制命令转发给 PhysicalRouteRecordingService（实现位于 :service 模块）。 */
interface PhysicalRouteServiceController {
    fun send(context: Context, command: PhysicalRouteCommand)
}
