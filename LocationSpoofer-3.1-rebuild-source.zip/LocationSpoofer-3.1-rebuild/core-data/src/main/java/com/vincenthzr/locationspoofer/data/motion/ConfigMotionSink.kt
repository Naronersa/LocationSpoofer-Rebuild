package com.vincenthzr.locationspoofer.data.motion

import com.vincenthzr.locationspoofer.utils.ConfigKeys

import com.vincenthzr.locationspoofer.data.model.RoutePoint
import com.vincenthzr.locationspoofer.data.repository.LocationRepository
import com.vincenthzr.locationspoofer.data.state.SpoofingState
import com.vincenthzr.locationspoofer.utils.ConfigManager
import org.json.JSONArray
import org.json.JSONObject

/** [MotionController] 的生产实现：只改配置里的运动字段，路线保存到"已保存路线" */
class ConfigMotionSink(
    private val locationRepository: LocationRepository,
    private val configManager: ConfigManager
) : MotionController.MotionSink {

    /** 非路线模式，Xposed 端在两次写入之间按方向和速度推算位置（见 RouteEngine 的 JOYSTICK 分支） */
    override suspend fun writeManual(lat: Double, lng: Double, bearing: Float, speedMs: Double, timestamp: Long) {
        locationRepository.patchConfig { json ->
            configManager.putPosition(json, lat, lng)
            json.put(ConfigKeys.IS_ROUTE_MODE, false)
            json.put(ConfigKeys.SIM_MODE, "JOYSTICK")
            json.put(ConfigKeys.SIM_BEARING, bearing.toDouble())
            json.put(ConfigKeys.SPEED_M_S, speedMs)
            json.put(ConfigKeys.START_TIMESTAMP, timestamp)
            json.put(ConfigKeys.ROUTE_LATERAL_DEVIATION, SpoofingState.routeLateralDeviation)
            json.put(ConfigKeys.ROUTE_LATERAL_SEED, SpoofingState.routeLateralSeed)
        }
    }

    override suspend fun writeStatic(lat: Double, lng: Double, timestamp: Long) {
        locationRepository.patchConfig { json ->
            configManager.putPosition(json, lat, lng)
            json.put(ConfigKeys.IS_ROUTE_MODE, false)
            json.put(ConfigKeys.SIM_MODE, "STILL")
            json.put(ConfigKeys.SIM_BEARING, 0.0)
            json.put(ConfigKeys.SPEED_M_S, 0.0)
            json.put(ConfigKeys.START_TIMESTAMP, timestamp)
            json.put(ConfigKeys.ROUTE_POINTS, JSONArray())
            json.put(ConfigKeys.STOP_AT_DESTINATION, false)
            json.put(ConfigKeys.ROUTE_DISTANCE_OFFSET, 0.0)
            json.put(ConfigKeys.ROUTE_LATERAL_DEVIATION, SpoofingState.routeLateralDeviation)
            json.put(ConfigKeys.ROUTE_LATERAL_SEED, SpoofingState.routeLateralSeed)
        }
    }

    override suspend fun writeRoute(
        lat: Double,
        lng: Double,
        bearing: Float,
        preset: MotionController.SpeedPreset,
        points: List<RoutePoint>,
        startTimestamp: Long,
        distanceOffset: Double,
        stopAtDestination: Boolean
    ) {
        val routeArray = JSONArray().apply { points.forEach { put(JSONObject().put(ConfigKeys.LAT, it.lat).put(ConfigKeys.LNG, it.lng)) } }
        locationRepository.patchConfig { json ->
            configManager.putPosition(json, lat, lng)
            json.put(ConfigKeys.IS_ROUTE_MODE, true)
            json.put(ConfigKeys.ROUTE_POINTS, routeArray)
            json.put(ConfigKeys.SIM_MODE, preset.name)
            json.put(ConfigKeys.SIM_BEARING, bearing.toDouble())
            json.put(ConfigKeys.SPEED_M_S, preset.speedMs)
            json.put(ConfigKeys.START_TIMESTAMP, startTimestamp)
            json.put(ConfigKeys.ROUTE_DISTANCE_OFFSET, distanceOffset)
            json.put(ConfigKeys.STOP_AT_DESTINATION, stopAtDestination)
            json.put(ConfigKeys.ROUTE_LATERAL_DEVIATION, SpoofingState.routeLateralDeviation)
            json.put(ConfigKeys.ROUTE_LATERAL_SEED, SpoofingState.routeLateralSeed)
        }
    }

    override suspend fun saveRoute(name: String, points: List<RoutePoint>) {
        locationRepository.insertSavedRoute(name, points)
    }
}
