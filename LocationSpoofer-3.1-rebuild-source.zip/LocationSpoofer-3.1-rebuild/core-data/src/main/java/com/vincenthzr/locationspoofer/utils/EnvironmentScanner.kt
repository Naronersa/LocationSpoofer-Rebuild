package com.vincenthzr.locationspoofer.utils

import android.annotation.SuppressLint
import android.content.Context
import android.net.wifi.WifiManager
import android.telephony.CellInfo
import android.telephony.CellInfoCdma
import android.telephony.CellInfoGsm
import android.telephony.CellInfoLte
import android.telephony.CellInfoNr
import android.telephony.CellInfoWcdma
import android.telephony.TelephonyManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.launch
import kotlin.coroutines.resume

@android.annotation.SuppressLint("MissingPermission", "NewApi")
class EnvironmentScanner(private val context: Context) {

    @SuppressLint("MissingPermission")
    suspend fun scanWifi(): String = withContext(Dispatchers.IO) {
        val wifiManager =
            context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val connectivityManager =
            context.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
        val resultObj = JSONObject()
        try {
            var isWifiConnected = false
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                val networks = connectivityManager.allNetworks
                for (network in networks) {
                    val caps = connectivityManager.getNetworkCapabilities(network)
                    if (caps != null && caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI)) {
                        // 确保这个 Wi-Fi 网络具备基础的连接能力
                        if (caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET) ||
                            caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_VALIDATED)
                        ) {
                            isWifiConnected = true
                            break
                        }
                    }
                }
            } else {
                val activeNetwork = connectivityManager.activeNetworkInfo
                isWifiConnected =
                    activeNetwork != null && activeNetwork.type == android.net.ConnectivityManager.TYPE_WIFI && activeNetwork.isConnected
            }

            resultObj.put(ConfigKeys.IS_CONNECTED, isWifiConnected)

            val connectionInfo = wifiManager.connectionInfo
            val connectedBssid = if (isWifiConnected) connectionInfo?.bssid else null
            try {
                wifiManager.startScan()
            } catch (e: Throwable) {
            }
            val results = wifiManager.scanResults ?: emptyList()

            // 1. 优先提取当前正在连接的 Wi-Fi 信息
            if (isWifiConnected && connectedBssid != null && connectedBssid != "02:00:00:00:00:00") {
                val connObj = JSONObject()
                connObj.put(ConfigKeys.BSSID, connectedBssid)
                val rawSsid = connectionInfo.ssid
                var cleanSsid =
                    if (rawSsid != null && rawSsid.startsWith("\"") && rawSsid.endsWith("\"")) {
                        rawSsid.substring(1, rawSsid.length - 1)
                    } else {
                        rawSsid ?: ""
                    }

                val match = results.find { it.BSSID == connectedBssid }
                // 如果是 unknown ssid 或为空，尝试从扫描结果中恢复真实 SSID
                if (cleanSsid == "<unknown ssid>" || cleanSsid.isEmpty()) {
                    if (match != null && !match.SSID.isNullOrEmpty()) {
                        cleanSsid = match.SSID
                    }
                }

                connObj.put(ConfigKeys.SSID, if (cleanSsid == "<unknown ssid>") "" else cleanSsid)
                connObj.put(ConfigKeys.VENDOR, MacVendorHelper.getVendor(connectedBssid))
                connObj.put(ConfigKeys.LEVEL, connectionInfo.rssi)
                connObj.put(ConfigKeys.FREQUENCY, connectionInfo.frequency)
                connObj.put(ConfigKeys.CHANNEL, MacVendorHelper.frequencyToChannel(connectionInfo.frequency))
                connObj.put(ConfigKeys.CAPABILITIES, match?.capabilities ?: "[WPA2-PSK-CCMP][ESS]")
                try {
                    connObj.put(ConfigKeys.MAC_ADDRESS, connectionInfo.macAddress)
                } catch (e: Throwable) {
                }
                try {
                    connObj.put(ConfigKeys.LINK_SPEED, connectionInfo.linkSpeed)
                } catch (e: Throwable) {
                }
                try {
                    connObj.put(ConfigKeys.NETWORK_ID, connectionInfo.networkId)
                } catch (e: Throwable) {
                }
                if (android.os.Build.VERSION.SDK_INT >= 30) {
                    try {
                        connObj.put(ConfigKeys.WIFI_STANDARD, connectionInfo.wifiStandard)
                    } catch (e: Throwable) {
                    }
                }
                resultObj.put(ConfigKeys.CONNECTED_WIFI, connObj)
            } else {
                resultObj.put(ConfigKeys.CONNECTED_WIFI, JSONObject.NULL)
            }

            // 2. 提取周围扫描到的其他 Wi-Fi（去重，不包含当前已连接的）
            val nearbyArray = JSONArray()
            val seenBssids = mutableSetOf<String>()
            if (isWifiConnected && connectedBssid != null) {
                seenBssids.add(connectedBssid)
            }
            results.forEach { scanResult ->
                val bssid = scanResult.BSSID
                if (bssid != null && !seenBssids.contains(bssid)) {
                    seenBssids.add(bssid)
                    val obj = JSONObject()
                    obj.put(ConfigKeys.BSSID, bssid)
                    obj.put(ConfigKeys.SSID, scanResult.SSID ?: "")
                    obj.put(ConfigKeys.VENDOR, MacVendorHelper.getVendor(bssid))
                    obj.put(ConfigKeys.LEVEL, scanResult.level)
                    obj.put(ConfigKeys.CAPABILITIES, scanResult.capabilities ?: "")
                    obj.put(ConfigKeys.FREQUENCY, scanResult.frequency)
                    obj.put(ConfigKeys.CHANNEL, MacVendorHelper.frequencyToChannel(scanResult.frequency))
                    nearbyArray.put(obj)
                }
            }
            resultObj.put(ConfigKeys.NEARBY_WIFI, nearbyArray)
        } catch (e: Exception) {
            e.printStackTrace()
            resultObj.put(ConfigKeys.IS_CONNECTED, false)
            resultObj.put(ConfigKeys.CONNECTED_WIFI, JSONObject.NULL)
            resultObj.put(ConfigKeys.NEARBY_WIFI, JSONArray())
        }
        resultObj.toString()
    }

    @SuppressLint("MissingPermission")
    suspend fun scanCell(): String = withContext(Dispatchers.IO) {
        // 之前这里连了 Wi-Fi 就直接跳过基站扫描，但 Wi-Fi 和基站是同一个物理位置的两个
        // 独立维度，并不互斥，跳过只会导致最常见的采集场景（家里/公司都连着 Wi-Fi）
        // 永远采不到基站数据，纯属早期写错，去掉这个限制。
        val telephonyManager =
            context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        val jsonArray = JSONArray()
        try {
            val allCellInfo =
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                    try {
                        kotlinx.coroutines.withTimeoutOrNull(3000L) {
                            suspendCancellableCoroutine { continuation ->
                                telephonyManager.requestCellInfoUpdate(
                                    context.mainExecutor,
                                    object : android.telephony.TelephonyManager.CellInfoCallback() {
                                        override fun onCellInfo(cellInfo: MutableList<CellInfo>) {
                                            if (continuation.isActive) continuation.resume(cellInfo)
                                        }

                                        override fun onError(errorCode: Int, detail: Throwable?) {
                                            if (continuation.isActive) continuation.resume(
                                                telephonyManager.allCellInfo ?: emptyList()
                                            )
                                        }
                                    }
                                )
                            }
                        } ?: (telephonyManager.allCellInfo ?: emptyList())
                    } catch (e: Exception) {
                        telephonyManager.allCellInfo ?: emptyList()
                    }
                } else {
                    telephonyManager.allCellInfo ?: emptyList()
                }

            if (allCellInfo.isEmpty()) {
                val cellLoc = try {
                    telephonyManager.cellLocation
                } catch (e: Exception) {
                    null
                }
                if (cellLoc is android.telephony.gsm.GsmCellLocation) {
                    val obj = JSONObject()
                    obj.put(ConfigKeys.IS_REGISTERED, true)
                    obj.put(ConfigKeys.TYPE, "GSM")
                    obj.put(ConfigKeys.LAC, cellLoc.lac)
                    obj.put(ConfigKeys.CID, cellLoc.cid)
                    obj.put(ConfigKeys.PSC, cellLoc.psc)
                    obj.put(ConfigKeys.DBM, -85) // 虚拟一个信号值
                    obj.put(ConfigKeys.MCC, 460)
                    obj.put(ConfigKeys.MNC, 0)
                    jsonArray.put(obj)
                } else if (cellLoc is android.telephony.cdma.CdmaCellLocation) {
                    val obj = JSONObject()
                    obj.put(ConfigKeys.IS_REGISTERED, true)
                    obj.put(ConfigKeys.TYPE, "CDMA")
                    obj.put(ConfigKeys.NETWORK_ID, cellLoc.networkId)
                    obj.put(ConfigKeys.SYSTEM_ID, cellLoc.systemId)
                    obj.put(ConfigKeys.BASESTATION_ID, cellLoc.baseStationId)
                    obj.put(ConfigKeys.DBM, -85)
                    jsonArray.put(obj)
                }
            }

            allCellInfo.forEach { cellInfo ->
                val obj = JSONObject()
                obj.put(ConfigKeys.IS_REGISTERED, cellInfo.isRegistered)

                when (cellInfo) {
                    is CellInfoLte -> {
                        obj.put(ConfigKeys.TYPE, "LTE")
                        val id = cellInfo.cellIdentity
                        obj.put(ConfigKeys.MCC, id.mccString?.toIntOrNull() ?: 460)
                        obj.put(ConfigKeys.MNC, id.mncString?.toIntOrNull() ?: 0)
                        obj.put(ConfigKeys.TAC, id.tac)
                        obj.put(ConfigKeys.CI, id.ci)
                        obj.put(ConfigKeys.PCI, id.pci)
                        val signal = cellInfo.cellSignalStrength
                        obj.put(ConfigKeys.DBM, signal.dbm)
                    }

                    is CellInfoGsm -> {
                        obj.put(ConfigKeys.TYPE, "GSM")
                        val id = cellInfo.cellIdentity
                        obj.put(ConfigKeys.MCC, id.mccString?.toIntOrNull() ?: 460)
                        obj.put(ConfigKeys.MNC, id.mncString?.toIntOrNull() ?: 0)
                        obj.put(ConfigKeys.LAC, id.lac)
                        obj.put(ConfigKeys.CID, id.cid)
                        val signal = cellInfo.cellSignalStrength
                        obj.put(ConfigKeys.DBM, signal.dbm)
                    }

                    is CellInfoWcdma -> {
                        obj.put(ConfigKeys.TYPE, "WCDMA")
                        val id = cellInfo.cellIdentity
                        obj.put(ConfigKeys.MCC, id.mccString?.toIntOrNull() ?: 460)
                        obj.put(ConfigKeys.MNC, id.mncString?.toIntOrNull() ?: 0)
                        obj.put(ConfigKeys.LAC, id.lac)
                        obj.put(ConfigKeys.CID, id.cid)
                        obj.put(ConfigKeys.PSC, id.psc)
                        val signal = cellInfo.cellSignalStrength
                        obj.put(ConfigKeys.DBM, signal.dbm)
                    }

                    is CellInfoNr -> {
                        obj.put(ConfigKeys.TYPE, "NR")
                        val id = cellInfo.cellIdentity as? android.telephony.CellIdentityNr
                        obj.put(ConfigKeys.MCC, id?.mccString?.toIntOrNull() ?: 460)
                        obj.put(ConfigKeys.MNC, id?.mncString?.toIntOrNull() ?: 0)
                        obj.put(ConfigKeys.TAC, id?.tac ?: Int.MAX_VALUE)
                        obj.put(ConfigKeys.NCI, id?.nci ?: Long.MAX_VALUE)
                        obj.put(ConfigKeys.PCI, id?.pci ?: Int.MAX_VALUE)
                        val signal =
                            cellInfo.cellSignalStrength as? android.telephony.CellSignalStrengthNr
                        obj.put(ConfigKeys.DBM, signal?.dbm ?: 0)
                    }

                    is CellInfoCdma -> {
                        obj.put(ConfigKeys.TYPE, "CDMA")
                        val id = cellInfo.cellIdentity
                        obj.put(ConfigKeys.NETWORK_ID, id.networkId)
                        obj.put(ConfigKeys.SYSTEM_ID, id.systemId)
                        obj.put(ConfigKeys.BASESTATION_ID, id.basestationId)
                        val signal = cellInfo.cellSignalStrength
                        obj.put(ConfigKeys.DBM, signal.dbm)
                    }
                }
                jsonArray.put(obj)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        jsonArray.toString()
    }

    @SuppressLint("MissingPermission")
    suspend fun scanBluetooth(): String = withContext(Dispatchers.IO) {
        val bluetoothManager =
            context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        val adapter = bluetoothManager?.adapter
        val scanner = adapter?.bluetoothLeScanner

        val jsonArray = JSONArray()
        if (scanner == null || !adapter.isEnabled) {
            return@withContext jsonArray.toString()
        }

        try {
            suspendCancellableCoroutine<Unit> { cont ->
                // ScanCallback 在主线程追加，2 秒定时器在 IO 协程读取；
                // 用同步列表并在遍历前复制，避免 ConcurrentModificationException。
                val resultsList = java.util.Collections.synchronizedList(
                    ArrayList<ScanResult>()
                )
                val callback = object : ScanCallback() {
                    override fun onScanResult(callbackType: Int, result: ScanResult?) {
                        if (result != null) {
                            resultsList.add(result)
                        }
                    }

                    override fun onBatchScanResults(results: MutableList<ScanResult>?) {
                        if (results != null) {
                            resultsList.addAll(results)
                        }
                    }

                    override fun onScanFailed(errorCode: Int) {
                    }
                }

                // 开始扫描
                scanner.startScan(callback)

                // 2 秒后停止扫描；绑定到外层挂起协程的 context，避免脱离生命周期成为孤儿协程
                kotlinx.coroutines.CoroutineScope(cont.context).launch {
                    delay(2000)
                    try {
                        scanner.stopScan(callback)
                    } catch (e: Exception) {
                    }

                    // 去重并转换为 JSON。先复制快照，避免与仍在到达的 callback 并发。
                    val snapshot = synchronized(resultsList) { resultsList.toList() }
                    val deduped = snapshot.distinctBy { it.device.address }
                    deduped.forEach { res ->
                        val obj = JSONObject()
                        obj.put(ConfigKeys.ADDRESS, res.device.address)
                        obj.put(ConfigKeys.NAME, res.device.name ?: "")
                        obj.put(ConfigKeys.RSSI, res.rssi)

                        // 如果可用，解析扫描记录的字节
                        val recordBytes = res.scanRecord?.bytes
                        if (recordBytes != null) {
                            val hexString = recordBytes.joinToString("") { "%02X".format(it) }
                            obj.put(ConfigKeys.SCAN_RECORD_HEX, hexString)
                        }
                        jsonArray.put(obj)
                    }
                    if (cont.isActive) {
                        cont.resume(Unit)
                    }
                }

                cont.invokeOnCancellation {
                    try {
                        scanner.stopScan(callback)
                    } catch (e: Exception) {
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        jsonArray.toString()
    }
}
