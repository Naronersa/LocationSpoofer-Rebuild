package com.vincenthzr.locationspoofer.data.model

data class SavedRoute(
    val name: String,
    val points: List<RoutePoint>,
    /** 上游 3.0.17 起使用唯一标识删除，避免同名路线误删。 */
    val syncId: String = ""
)
