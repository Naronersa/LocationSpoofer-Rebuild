package com.vincenthzr.locationspoofer.data.repository

import com.vincenthzr.locationspoofer.utils.ConfigKeys

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationManager
import android.os.Build
import com.vincenthzr.locationspoofer.data.db.SavedRouteDao
import com.vincenthzr.locationspoofer.data.db.SavedRouteEntity
import com.vincenthzr.locationspoofer.data.model.RootSetupTestResult
import com.vincenthzr.locationspoofer.data.model.RootSolution
import com.vincenthzr.locationspoofer.data.model.RoutePoint
import com.vincenthzr.locationspoofer.data.state.SpoofingState
import com.vincenthzr.locationspoofer.utils.ConfigManager
import com.vincenthzr.locationspoofer.utils.LSPosedManager
import com.vincenthzr.locationspoofer.utils.RootManager
import com.vincenthzr.locationspoofer.utils.SettingsManager
import org.json.JSONArray
import org.json.JSONObject

/** 进程重启后仍存活的路线会话快照，用于恢复 UI/MotionController 而不是把它改成 STILL。 */
data class RouteRecovery(
    val points: List<RoutePoint>,
    val simMode: String,
    val speedMs: Double,
    val startTimestamp: Long,
    val distanceOffset: Double,
    val stopAtDestination: Boolean,
    val currentLat: Double,
    val currentLng: Double,
    val realismLevel: Int,
    val speedFluctuationPct: Int
)

class LocationRepository(
    private val configManager: ConfigManager,
    private val rootManager: RootManager,
    private val lsposedManager: LSPosedManager,
    private val settingsManager: SettingsManager,
    private val savedRouteDao: SavedRouteDao,
    private val spoofingServiceController: SpoofingServiceController
) {
    /** 用户在设置里选择的 root 方案；解析失败（脏数据/尚未设置）时退回 AUTO */
    private fun currentRootSolution(): RootSolution =
        try {
            RootSolution.valueOf(settingsManager.rootSolution)
        } catch (e: Exception) {
            RootSolution.AUTO
        }

    suspend fun checkRootAccess(packageName: String): Boolean =
        rootManager.checkRootAccess(packageName, currentRootSolution())

    /** 检测 Root 权限与框架配置通道是否正常，返回完整诊断结果供设置页"测试"按钮展示 */
    suspend fun testRootSetup(): RootSetupTestResult = rootManager.testRootSetup(currentRootSolution())

    /** 强制停止目标 App，让它们下次启动时加载当前模块并订阅框架配置 */
    suspend fun forceStopApps(packages: List<String>) = rootManager.forceStopApps(packages)

    /**
     * 设备重启 / App 更新后的统一自愈入口：恢复 Root 后台运行权限，
     * 并在模拟定位此前处于开启状态时重新调用 startSpoofing() 发布完整配置。
     * 供 BootCompletedReceiver 和 MainViewModel.initialize() 共同复用，
     * 避免这段逻辑两处各写一份。
     */
    suspend fun recoverAfterBoot(context: Context): Boolean {
        val hasRoot = rootManager.checkRootAccess(context.packageName, currentRootSolution())

        if (settingsManager.isSpoofingActive) {
            // 路线模拟由框架按 START_TIMESTAMP + ROUTE_POINTS 独立推进；App 进程
            // 重启时如果还发布一份 STILL 快照，会把正在跑的路线冻结在旧点位。
            val route = activeRouteRecovery()
            if (route != null) {
                if (route.currentLat != 0.0 || route.currentLng != 0.0) {
                    try {
                        spoofingServiceController.startForeground(
                            context, route.currentLat, route.currentLng
                        )
                    } catch (t: Throwable) {
                        android.util.Log.e("LocationSpoofer", "recover route foreground failed", t)
                        settingsManager.isSpoofingActive = false
                    }
                }
                return hasRoot
            }

            val lastLat = settingsManager.lastSpoofedLat.toDoubleOrNull() ?: 0.0
            val lastLng = settingsManager.lastSpoofedLng.toDoubleOrNull() ?: 0.0
            if (lastLat != 0.0 && lastLng != 0.0) {
                val started = startSpoofing(
                    context, lastLat, lastLng,
                    "STILL", 0f, System.currentTimeMillis(),
                    emptyList(), false,
                    mockWifi = settingsManager.mockWifi,
                    mockCell = settingsManager.mockCell,
                    mockBluetooth = settingsManager.mockBluetooth,
                    enableJitter = settingsManager.enableJitter
                )
                if (!started) settingsManager.isSpoofingActive = false
            }
        } else if (spoofingServiceController.isRunning) {
            stopSpoofing(context)
        }

        return hasRoot
    }

    /** 当前框架快照里仍在运行的路线；没有 active 路线时返回 null。 */
    fun activeRouteRecovery(): RouteRecovery? {
        val json = configManager.currentSnapshot() ?: return null
        if (!json.optBoolean(ConfigKeys.ACTIVE, false) ||
            !json.optBoolean(ConfigKeys.IS_ROUTE_MODE, false)
        ) return null
        val arr = json.optJSONArray(ConfigKeys.ROUTE_POINTS) ?: return null
        if (arr.length() < 2) return null
        val points = ArrayList<RoutePoint>(arr.length())
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            points.add(RoutePoint(obj.optDouble(ConfigKeys.LAT), obj.optDouble(ConfigKeys.LNG)))
        }
        if (points.size < 2) return null
        return RouteRecovery(
            points = points,
            simMode = json.optString(ConfigKeys.SIM_MODE, "WALKING"),
            speedMs = json.optDouble(ConfigKeys.SPEED_M_S, 1.4),
            startTimestamp = json.optLong(ConfigKeys.START_TIMESTAMP, 0L),
            distanceOffset = json.optDouble(ConfigKeys.ROUTE_DISTANCE_OFFSET, 0.0),
            stopAtDestination = json.optBoolean(ConfigKeys.STOP_AT_DESTINATION, false),
            currentLat = json.optDouble(ConfigKeys.LAT, 0.0),
            currentLng = json.optDouble(ConfigKeys.LNG, 0.0),
            realismLevel = json.optInt(ConfigKeys.REALISM_LEVEL, 0).coerceIn(0, 3),
            speedFluctuationPct = json.optInt(ConfigKeys.SPEED_FLUCTUATION_PCT, 0).coerceIn(0, 100)
        )
    }

    fun isModuleActive(): Boolean = lsposedManager.isModuleActive()

    /** 前台模拟服务是否真的起来了；异步失败时 UI 用它回滚 active 状态。 */
    val isSpoofingServiceRunning: Boolean
        get() = spoofingServiceController.isRunning

    suspend fun startSpoofing(
        context: Context,
        lat: Double,
        lng: Double,
        simMode: String,
        simBearing: Float,
        startTime: Long,
        routePoints: List<RoutePoint>,
        isRouteMode: Boolean,
        wifiJson: String = "[]",
        cellJson: String = "[]",
        bluetoothJson: String = "[]",
        mockWifi: Boolean = true,
        mockCell: Boolean = true,
        mockBluetooth: Boolean = true,
        enableJitter: Boolean = true,
        speedMs: Double = 0.0,
        stopAtDestination: Boolean = false,
        enableStepSimulation: Boolean = true,
        stepCadenceSpm: Int = 165,
        isAutoCadence: Boolean = true
    ): Boolean {
        if (context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            android.util.Log.e("LocationSpoofer", "startSpoofing refused: ACCESS_FINE_LOCATION not granted")
            return false
        }
        SpoofingState.isActive = true
        SpoofingState.latitude = lat
        SpoofingState.longitude = lng
        SpoofingState.startTimestamp = startTime
        SpoofingState.realismLevel = settingsManager.realismLevel
        SpoofingState.speedFluctuationPct = settingsManager.speedFluctuationPct
        SpoofingState.routeLateralDeviation = settingsManager.routeLateralDeviation
        // 每次会话固定一个 seed，保证同一路线重放的横向偏移可复现。
        SpoofingState.routeLateralSeed =
            if (SpoofingState.routeLateralDeviation) startTime else 0L
        SpoofingState.routeDistanceOffset = 0.0
        SpoofingState.simMode = simMode
        SpoofingState.simBearing = simBearing
        SpoofingState.wifiJson = wifiJson
        SpoofingState.cellJson = cellJson
        SpoofingState.bluetoothJson = bluetoothJson
        SpoofingState.routeJson = routePointsToJson(routePoints)
        SpoofingState.isRouteMode = isRouteMode
        SpoofingState.enableJitter = enableJitter

        // 与 stopSpoofing() 里的 revokeMockLocation() 对称：上一次停止模拟时会把
        // android:mock_location 重置为 default（用于避免被系统安全中心一直记录为"模拟中"），
        // 如果这里不重新授予，第二次开始模拟时该 AppOps 就会一直停留在 default，
        // 导致"模拟一次后关闭再开就再也无法模拟"。
        rootManager.grantMockLocation(context.packageName)

        val alt = settingsManager.altitude.toDoubleOrNull() ?: 0.0
        val satCount = settingsManager.satelliteCount.toIntOrNull() ?: 20
        configManager.saveConfig(
            lat,
            lng,
            true,
            simMode,
            simBearing,
            startTime,
            routePoints,
            isRouteMode,
            SpoofingState.wifiJson,
            SpoofingState.cellJson,
            SpoofingState.bluetoothJson,
            mockWifi,
            mockCell,
            mockBluetooth,
            enableJitter,
            alt,
            satCount,
            speedMs,
            stopAtDestination,
            enableStepSimulation,
            stepCadenceSpm,
            isAutoCadence
        )

        return try {
            spoofingServiceController.startForeground(context, lat, lng)
            true
        } catch (t: Throwable) {
            // 前台服务被系统拒绝时，刚写入的 active=true 必须回滚，
            // 否则模块会在没有服务/通知的情况下继续伪造位置。
            android.util.Log.e("LocationSpoofer", "startForegroundService failed", t)
            runCatching { configManager.saveConfig(0.0, 0.0, false) }
            runCatching { rootManager.revokeMockLocation(context.packageName) }
            SpoofingState.isActive = false
            false
        }
    }

    suspend fun stopSpoofing(context: Context) {
        SpoofingState.isActive = false
        SpoofingState.latitude = 0.0
        SpoofingState.longitude = 0.0
        SpoofingState.wifiJson = "[]"
        SpoofingState.cellJson = "[]"
        SpoofingState.bluetoothJson = "[]"
        SpoofingState.routeJson = "[]"
        SpoofingState.isRouteMode = false
        // 停止时只关闭 active 并清空运动字段，保留 altitude、卫星数、
        // mock 开关、步频等设置；旧的 saveConfig(0,0,false) 会把它们全部
        // 重置为默认值，还会触发一次 (0,0) 逆地理编码。
        val patched = configManager.patchConfig { json ->
            json.put(ConfigKeys.ACTIVE, false)
            json.put(ConfigKeys.SIM_MODE, "STILL")
            json.put(ConfigKeys.SIM_BEARING, 0.0)
            json.put(ConfigKeys.SPEED_M_S, 0.0)
            json.put(ConfigKeys.IS_ROUTE_MODE, false)
            json.put(ConfigKeys.ROUTE_POINTS, JSONArray())
            json.put(ConfigKeys.STOP_AT_DESTINATION, false)
            json.put(ConfigKeys.ROUTE_DISTANCE_OFFSET, 0.0)
            json.put(ConfigKeys.ROUTE_LATERAL_DEVIATION, false)
            json.put(ConfigKeys.ROUTE_LATERAL_SEED, 0L)
        }
        if (!patched) configManager.saveConfig(0.0, 0.0, false)

        // 1. 同步在当前进程清理所有可能残留的 TestProvider
        val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
        if (lm != null) {
            try {
                lm.setTestProviderEnabled(LocationManager.GPS_PROVIDER, false)
            } catch (e: Throwable) {
            }
            try {
                lm.removeTestProvider(LocationManager.GPS_PROVIDER)
            } catch (e: Throwable) {
            }
            try {
                lm.setTestProviderEnabled(LocationManager.NETWORK_PROVIDER, false)
            } catch (e: Throwable) {
            }
            try {
                lm.removeTestProvider(LocationManager.NETWORK_PROVIDER)
            } catch (e: Throwable) {
            }
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    lm.setTestProviderEnabled(LocationManager.FUSED_PROVIDER, false)
                    lm.removeTestProvider(LocationManager.FUSED_PROVIDER)
                }
            } catch (e: Throwable) {
            }
        }

        // 2. 停止前台模拟服务
        spoofingServiceController.stop(context)

        // 3. 彻底重置系统的 mock_location 状态，防止被澎湃OS/系统安全中心记录为模拟中
        rootManager.revokeMockLocation(context.packageName)
    }

    val isFloatingJoystickShowing: Boolean get() = spoofingServiceController.isFloatingJoystickShowing

    fun setFloatingJoystickVisible(context: Context, visible: Boolean) =
        spoofingServiceController.setFloatingJoystickVisible(context, visible)

    /** 只改配置里的部分字段，见 [ConfigManager.patchConfig] */
    suspend fun patchConfig(mutate: (JSONObject) -> Unit): Boolean = configManager.patchConfig(mutate)

    /** 系统进程读取的配置写入失败事件，界面据此提示用户 */
    val configWriteFailures get() = configManager.writeFailures

    /** 路线 / 摇杆移动过程中刷新周边 Wi-Fi、基站、蓝牙数据，不改动位置和运动状态 */
    suspend fun updateEnvironment(wifiJson: String, cellJson: String, bluetoothJson: String) {
        SpoofingState.wifiJson = wifiJson
        SpoofingState.cellJson = cellJson
        SpoofingState.bluetoothJson = bluetoothJson
        configManager.patchConfig { configManager.putEnvironment(it, wifiJson, cellJson, bluetoothJson) }
    }

    suspend fun updateConfig(
        lat: Double,
        lng: Double,
        simMode: String,
        simBearing: Float,
        startTime: Long,
        routePoints: List<RoutePoint>,
        isRouteMode: Boolean,
        wifiJson: String = SpoofingState.wifiJson,
        cellJson: String = SpoofingState.cellJson,
        bluetoothJson: String = SpoofingState.bluetoothJson,
        mockWifi: Boolean = true,
        mockCell: Boolean = true,
        mockBluetooth: Boolean = true,
        enableJitter: Boolean = true,
        speedMs: Double = 0.0,
        stopAtDestination: Boolean = false,
        enableStepSimulation: Boolean = true,
        stepCadenceSpm: Int = 165,
        isAutoCadence: Boolean = true
    ) {
        SpoofingState.latitude = lat
        SpoofingState.longitude = lng
        SpoofingState.startTimestamp = startTime
        SpoofingState.simMode = simMode
        SpoofingState.simBearing = simBearing
        SpoofingState.routeJson = routePointsToJson(routePoints)
        SpoofingState.isRouteMode = isRouteMode
        SpoofingState.wifiJson = wifiJson
        SpoofingState.cellJson = cellJson
        SpoofingState.bluetoothJson = bluetoothJson
        SpoofingState.enableJitter = enableJitter
        val alt = settingsManager.altitude.toDoubleOrNull() ?: 0.0
        val satCount = settingsManager.satelliteCount.toIntOrNull() ?: 20
        configManager.saveConfig(
            lat,
            lng,
            true,
            simMode,
            simBearing,
            startTime,
            routePoints,
            isRouteMode,
            SpoofingState.wifiJson,
            SpoofingState.cellJson,
            SpoofingState.bluetoothJson,
            mockWifi,
            mockCell,
            mockBluetooth,
            enableJitter,
            alt,
            satCount,
            speedMs,
            stopAtDestination,
            enableStepSimulation,
            stepCadenceSpm,
            isAutoCadence
        )
    }

    suspend fun updateWifiJson(wifiJson: String) {
        SpoofingState.wifiJson = wifiJson
        // 同步写入配置文件,确保Xposed端能读取到WiFi数据
        configManager.saveConfig(
            SpoofingState.latitude,
            SpoofingState.longitude,
            SpoofingState.isActive,
            SpoofingState.simMode,
            SpoofingState.simBearing,
            startTimestamp = SpoofingState.startTimestamp,
            wifiJson = wifiJson,
            cellJson = SpoofingState.cellJson,
            bluetoothJson = SpoofingState.bluetoothJson,
            altitude = settingsManager.altitude.toDoubleOrNull() ?: 0.0,
            satelliteCount = settingsManager.satelliteCount.toIntOrNull() ?: 20
        )
    }

    private fun routePointsToJson(points: List<RoutePoint>): String {
        val arr = JSONArray()
        points.forEach { p ->
            arr.put(JSONObject().apply {
                put(ConfigKeys.LAT, p.lat)
                put(ConfigKeys.LNG, p.lng)
            })
        }
        return arr.toString()
    }

    fun getSavedRoutes(): kotlinx.coroutines.flow.Flow<List<SavedRouteEntity>> {
        return savedRouteDao.getAllSavedRoutes()
    }

    suspend fun getAllSavedRoutesList(): List<SavedRouteEntity> {
        return savedRouteDao.getAllSavedRoutesList()
    }

    suspend fun insertSavedRoute(name: String, points: List<RoutePoint>) {
        val pointsJson = routePointsToJson(points)
        savedRouteDao.insertSavedRoute(
            SavedRouteEntity(
                name = name,
                pointsJson = pointsJson,
                // 规划/模拟保存的路线来自地图或 MotionController，坐标已是 GCJ-02。
                // 实体录制路线由 PhysicalRouteRecorder 单独以 WGS84 写入。
                coordinateSystem = "GCJ02"
            )
        )
    }

    suspend fun insertSavedRouteEntity(route: SavedRouteEntity) {
        savedRouteDao.insertSavedRoute(route)
    }

    suspend fun deleteSavedRoute(route: SavedRouteEntity) {
        savedRouteDao.deleteSavedRoute(route)
    }

    suspend fun deleteSavedRouteBySyncId(syncId: String) {
        savedRouteDao.deleteBySyncId(syncId)
    }

    suspend fun findSavedRouteBySyncId(syncId: String): SavedRouteEntity? {
        return savedRouteDao.findBySyncId(syncId)
    }
}
