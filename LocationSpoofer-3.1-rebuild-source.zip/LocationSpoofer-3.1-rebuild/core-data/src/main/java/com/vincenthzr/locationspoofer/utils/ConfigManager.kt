package com.vincenthzr.locationspoofer.utils

import android.content.Context
import android.location.Geocoder
import com.vincenthzr.locationspoofer.data.model.RoutePoint
import com.vincenthzr.locationspoofer.data.state.SpoofingState
import com.vincenthzr.locationspoofer.utils.CoordinateUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import android.os.ParcelFileDescriptor
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

class ConfigManager(private val context: Context, private val rootManager: RootManager) {

    // system_hook_packages 是独立于每次模拟会话的常驻勾选项（在"系统级模拟应用"页面里配置），
    // 不随 lat/lng/active 这类瞬时状态一起在调用方逐层透传，这里每次发布时直接读取最新值即可。
    private val settingsManager = SettingsManager(context)

    private var lastGeocodedLat = -999.0
    private var lastGeocodedLng = -999.0
    private var cachedProvince = ""
    private var cachedCity = ""
    private var cachedDistrict = ""
    private var cachedStreet = ""
    private var cachedStreetNum = ""
    private var cachedAddressText = ""
    private var cachedCountry = ""
    private var cachedPoiName = ""

    suspend fun saveConfig(
        lat: Double,
        lng: Double,
        active: Boolean,
        simMode: String = "STILL",
        simBearing: Float = 0f,
        startTimestamp: Long = System.currentTimeMillis(),
        routePoints: List<RoutePoint> = emptyList(),
        isRouteMode: Boolean = false,
        wifiJson: String = "[]",
        cellJson: String = "[]",
        bluetoothJson: String = "[]",
        mockWifi: Boolean = true,
        mockCell: Boolean = true,
        mockBluetooth: Boolean = true,
        enableJitter: Boolean = true,
        altitude: Double = 0.0,
        satelliteCount: Int = 20,
        speedMs: Double = 0.0,
        stopAtDestination: Boolean = false,
        enableStepSimulation: Boolean = true,
        stepCadenceSpm: Int = 165,
        isAutoCadence: Boolean = true
    ): Boolean = withContext(Dispatchers.IO) {
        val routeArray = JSONArray()
        routePoints.forEach { p ->
            val obj = JSONObject()
            obj.put(ConfigKeys.LAT, p.lat)
            obj.put(ConfigKeys.LNG, p.lng)
            routeArray.put(obj)
        }


        val json = JSONObject().apply {
            putPosition(this, lat, lng)
            put(ConfigKeys.ACTIVE, active)
            put(ConfigKeys.SIM_MODE, simMode)
            put(ConfigKeys.SIM_BEARING, simBearing.toDouble())
            put(ConfigKeys.SPEED_M_S, speedMs)
            put(ConfigKeys.START_TIMESTAMP, startTimestamp)
            put(ConfigKeys.ROUTE_POINTS, routeArray)
            put(ConfigKeys.IS_ROUTE_MODE, isRouteMode)
            put(ConfigKeys.STOP_AT_DESTINATION, stopAtDestination)
            putEnvironment(this, wifiJson, cellJson, bluetoothJson)
            put(ConfigKeys.MOCK_WIFI, mockWifi)
            put(ConfigKeys.MOCK_CELL, mockCell)
            put(ConfigKeys.MOCK_BLUETOOTH, mockBluetooth)
            put(ConfigKeys.ENABLE_JITTER, enableJitter)
            put(ConfigKeys.ALTITUDE, altitude)
            put(ConfigKeys.SATELLITE_COUNT, satelliteCount)
            put(ConfigKeys.ENABLE_STEP_SIMULATION, enableStepSimulation)
            put(ConfigKeys.STEP_CADENCE_SPM, stepCadenceSpm)
            put(ConfigKeys.IS_AUTO_CADENCE, isAutoCadence)

            // 全局方案按接口类型自动选择坐标系，不启用逐应用覆盖。
            put(ConfigKeys.APP_COORDINATE_SYSTEMS, JSONObject())

            put(ConfigKeys.ROUTE_DISTANCE_OFFSET, SpoofingState.routeDistanceOffset)
            putPersistentSettings(this)
        }
        write(json)
    }

    /**
     * 最近一次发布到框架的完整快照（副本）。进程重启后用于判断当前是否仍在跑路线，
     * 避免 recoverAfterBoot 用 STILL 覆盖正在推进的路线。
     */
    fun currentSnapshot(): JSONObject? = lastJson?.let {
        runCatching { JSONObject(it.toString()) }.getOrNull()
    }

    private val _writeFailures = MutableSharedFlow<Unit>(extraBufferCapacity = 1, onBufferOverflow = BufferOverflow.DROP_OLDEST)

    /** 框架配置发布失败时发出，界面据此提示用户（core-data 没有字符串资源，不在这里直接弹提示） */
    val writeFailures: SharedFlow<Unit> = _writeFailures

    /**
     * 在上一次写入的配置基础上只改动部分字段，其余字段原样保留；常驻设置项每次都刷新为最新值。
     * 暂停、摇杆、周边环境数据、开关设置等局部更新都走这里，避免某个调用方用自己手里过时的整份状态
     * 覆盖掉别人刚写入的字段（例如悬浮窗刚把路线暂停，界面的周边数据刷新又把路线模式写回去）。
     * 还没有配置（未开始模拟）或发布失败时返回 false；未发布的最新状态会在框架重连后重试。
     */
    suspend fun patchConfig(mutate: (JSONObject) -> Unit): Boolean = withContext(Dispatchers.IO) {
        // 读取、修改、写入整体放在锁内：并发的局部更新若各自基于同一份旧配置修改，后写的会冲掉先写的改动
        writeMutex.withLock {
            val base = lastJson ?: return@withLock false
            val json = JSONObject(base.toString())
            mutate(json)
            putPersistentSettings(json)
            writeLocked(json)
        }
    }

    /** 写入坐标及其派生字段（WGS-84 / BD-09 坐标、逆地理编码地址）；移动超过 500 米才重新逆地理编码。需在 IO 线程调用 */
    fun putPosition(json: JSONObject, lat: Double, lng: Double) {
        refreshGeocodeIfMoved(lat, lng)
        json.put(ConfigKeys.PROVINCE, cachedProvince)
        json.put(ConfigKeys.CITY, cachedCity)
        json.put(ConfigKeys.DISTRICT, cachedDistrict)
        json.put(ConfigKeys.STREET, cachedStreet)
        json.put(ConfigKeys.STREET_NUM, cachedStreetNum)
        json.put(ConfigKeys.ADDRESS, cachedAddressText)
        json.put(ConfigKeys.COUNTRY, cachedCountry)
        json.put(ConfigKeys.POI_NAME, cachedPoiName)

        val wgs = CoordinateUtils.gcj02ToWgs84(lat, lng)
        val bd = CoordinateUtils.gcj02ToBd09(lat, lng)
        json.put(ConfigKeys.WGS84_LAT, wgs.lat)
        json.put(ConfigKeys.WGS84_LNG, wgs.lng)
        json.put(ConfigKeys.BD09_LAT, bd.lat)
        json.put(ConfigKeys.BD09_LNG, bd.lng)
        json.put(ConfigKeys.LAT, lat)
        json.put(ConfigKeys.LNG, lng)
    }

    fun putEnvironment(json: JSONObject, wifiJson: String, cellJson: String, bluetoothJson: String) {
        val wifiObj = try {
            JSONObject(wifiJson)
        } catch (e: Exception) {
            JSONObject().apply {
                put(ConfigKeys.IS_CONNECTED, false)
                put(ConfigKeys.CONNECTED_WIFI, JSONObject.NULL)
                put(ConfigKeys.NEARBY_WIFI, JSONArray())
            }
        }
        json.put(ConfigKeys.WIFI_JSON_2, wifiObj)
        // 旧版本/导入数据里 cellJson、bluetoothJson 可能是空串或非法 JSON。
        // 解析失败时退回空数组，避免整个 saveConfig 中途抛异常导致模拟无法启动。
        json.put(
            ConfigKeys.CELL_JSON_2,
            runCatching { JSONArray(cellJson) }.getOrElse { JSONArray() }
        )
        json.put(
            ConfigKeys.BLUETOOTH_JSON_2,
            runCatching { JSONArray(bluetoothJson) }.getOrElse { JSONArray() }
        )
    }

    /** 独立于每次模拟会话的常驻设置项，调用方不逐层透传，每次发布时直接读取最新值 */
    private fun putPersistentSettings(json: JSONObject) {
        val systemHookPackagesArr = JSONArray()
        settingsManager.getSystemHookPackages().forEach { systemHookPackagesArr.put(it) }
        json.put(ConfigKeys.SYSTEM_HOOK_PACKAGES, systemHookPackagesArr)
        json.put(ConfigKeys.SYSTEM_HOOK_GLOBAL_MODE, settingsManager.isSystemHookGlobalMode)
        json.put(ConfigKeys.VENDOR_OVERRIDE, settingsManager.vendorOverride)
        json.put(ConfigKeys.FORCE_LOCATION_ENABLED, settingsManager.forceLocationEnabled)
        json.put(ConfigKeys.DEBUG_DUMP_SYSTEM_SERVICES, settingsManager.debugDumpSystemServices)
        // 运动真实度：Xposed 端据此给速度、步频、海拔、加速度加起伏；随机强度与速度浮动在会话内取开始时的快照
        json.put(ConfigKeys.REALISM_LEVEL, SpoofingState.realismLevel.takeIf { it >= 0 } ?: settingsManager.realismLevel)
        json.put(ConfigKeys.SPEED_FLUCTUATION_PCT, SpoofingState.speedFluctuationPct.takeIf { it >= 0 } ?: settingsManager.speedFluctuationPct)
        // 路线横向偏移也必须进入每次发布快照；否则 LOOP 路线不会经过
        // ConfigMotionSink.writeRoute，RouteEngine 永远读到 false/0。
        json.put(ConfigKeys.ROUTE_LATERAL_DEVIATION, SpoofingState.routeLateralDeviation)
        json.put(ConfigKeys.ROUTE_LATERAL_SEED, SpoofingState.routeLateralSeed)
        json.put(ConfigKeys.GAIT_TEMPLATE, if (settingsManager.useGaitTemplate) settingsManager.gaitTemplate else "")
        json.put(ConfigKeys.ALTITUDE_VARIATION_M, settingsManager.altitudeVariationM)
        // 上游 3.0.12：Xposed 端据此改写 TYPE_PRESSURE 事件，使其跟随模拟海拔
        json.put(ConfigKeys.BAROMETER_FLUCTUATION, settingsManager.barometerFluctuation)
        json.put(ConfigKeys.BAROMETER_SEA_LEVEL_HPA, settingsManager.barometerSeaLevelHpa.toDouble())
        // 路线/运动模拟时生成指南针、磁场与旋转矢量
        json.put(ConfigKeys.ENABLE_COMPASS_SIMULATION, settingsManager.compassSimulationEnabled)
    }

    private fun refreshGeocodeIfMoved(lat: Double, lng: Double) {
        val dist = FloatArray(1)
        if (lastGeocodedLat != -999.0) {
            android.location.Location.distanceBetween(lastGeocodedLat, lastGeocodedLng, lat, lng, dist)
        }
        if (lastGeocodedLat != -999.0 && dist[0] <= 500f) return
        lastGeocodedLat = lat
        lastGeocodedLng = lng
        try {
            val geocoder = android.location.Geocoder(context, java.util.Locale.CHINA)
            // lat/lng 是 GCJ-02，而 Geocoder 按 Android 规范接收 WGS-84；直接传 GCJ-02 会被后端再加密一次，
            // 偏出数百米、反查到错误的街道（issue #62：广州塔 → 赏湖街）
            val wgs = CoordinateUtils.gcj02ToWgs84(lat, lng)

            @Suppress("DEPRECATION")
            val addresses = geocoder.getFromLocation(wgs.lat, wgs.lng, 1)
            if (!addresses.isNullOrEmpty()) {
                val addr = addresses[0]
                cachedProvince = addr.adminArea ?: ""
                cachedCity = addr.locality ?: addr.subAdminArea ?: ""
                cachedDistrict = addr.subLocality ?: ""
                cachedStreet = addr.thoroughfare ?: ""
                cachedStreetNum = addr.subThoroughfare ?: ""
                cachedAddressText = addr.getAddressLine(0) ?: ""
                cachedCountry = addr.countryName ?: "中国"
                cachedPoiName = addr.featureName ?: ""
            }
        } catch (e: Exception) {
            // 逆地理编码失败时静默降级
        }
    }

    private val writeMutex = Mutex()

    private val transportPrefs = context.getSharedPreferences("framework_config_state", Context.MODE_PRIVATE)
    private val publisher = FrameworkConfigPublisher()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    @Volatile private var lastJson: JSONObject? = transportPrefs.getString(ConfigKeys.DESIRED_CONFIG, null)?.let {
        runCatching { JSONObject(it) }.getOrNull()
    }
    @Volatile private var publicationPending = lastJson != null
    private var nextCleanupAttemptAt = 0L

    init {
        // StateFlow delivers an already-connected service too, so initialization order is harmless.
        scope.launch {
            XposedModuleStatus.service.collect { service ->
                if (service != null) writeMutex.withLock {
                    publisher.onReconnect()
                    lastJson?.let { publishLocked(it, service) }
                }
            }
        }
        scope.launch {
            while (isActive) {
                delay(3_000)
                if (publicationPending) writeMutex.withLock {
                    val service = XposedModuleStatus.mService
                    if (publicationPending && service != null) lastJson?.let {
                        publishLocked(it, service, notifyFailure = false)
                    }
                }
            }
        }
    }

    private suspend fun write(json: JSONObject): Boolean = writeMutex.withLock { writeLocked(json) }

    private fun writeLocked(json: JSONObject): Boolean {
        // Remember the desired state even if a stop/pause happens while the service is disconnected.
        // Reconnection must never replay an older active session over a newer stop request.
        if (!transportPrefs.edit().putString("desired_config", json.toString()).commit()) {
            _writeFailures.tryEmit(Unit)
            return false
        }
        lastJson = json
        publicationPending = true
        val service = XposedModuleStatus.mService
        if (service == null) {
            android.util.Log.w("LocationSpoofer", "Framework disconnected; latest configuration queued")
            _writeFailures.tryEmit(Unit)
            return false
        }
        return publishLocked(json, service)
    }

    private fun publishLocked(
        json: JSONObject,
        service: io.github.libxposed.service.XposedService,
        notifyFailure: Boolean = true
    ): Boolean {
        return try {
            val prefs = service.getRemotePreferences(FrameworkConfigChannel.GROUP)
            publisher.publish(json.toString(), object : FrameworkConfigStore {
                override fun commit(snapshot: String): Boolean =
                    prefs.edit().putString(FrameworkConfigChannel.SNAPSHOT_KEY, snapshot).commit()

                override fun writeFile(name: String, payload: ByteArray) {
                    ParcelFileDescriptor.AutoCloseOutputStream(service.openRemoteFile(name)).use { it.write(payload) }
                }

                override fun listFiles(): List<String> = service.listRemoteFiles().toList()
                override fun deleteFile(name: String) { service.deleteRemoteFile(name) }
            })
            publicationPending = false
            // Migration runs only after the replacement channel accepted a complete snapshot.
            val now = System.currentTimeMillis()
            if (!transportPrefs.getBoolean(ConfigKeys.LEGACY_FILES_REMOVED, false) && now >= nextCleanupAttemptAt) {
                nextCleanupAttemptAt = now + 60_000
                // Root authorization/cleanup must not delay subsequent stop or coordinate updates.
                scope.launch {
                    if (rootManager.executeCommand(
                            SystemFileCommands.removeLegacyConfigs(context.packageName)
                        ) != "ERROR"
                    ) {
                        transportPrefs.edit().putBoolean("legacy_files_removed", true).apply()
                    }
                }
            }
            true
        } catch (error: Exception) {
            android.util.Log.e("LocationSpoofer", "Framework config publication failed", error)
            publicationPending = true
            if (notifyFailure) _writeFailures.tryEmit(Unit)
            false
        }
    }
}
