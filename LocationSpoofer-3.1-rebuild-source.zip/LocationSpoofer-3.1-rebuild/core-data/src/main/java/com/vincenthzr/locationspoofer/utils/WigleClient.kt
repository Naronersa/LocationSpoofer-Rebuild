package com.vincenthzr.locationspoofer.utils

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

class WigleClient {
    private val client = OkHttpClient.Builder()
        .connectTimeout(6, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(8, java.util.concurrent.TimeUnit.SECONDS)
        .callTimeout(10, java.util.concurrent.TimeUnit.SECONDS)
        .build()

    /** 验证 token 是否有效（调用 /profile/user 接口） */
    suspend fun validateToken(token: String): Boolean = withContext(Dispatchers.IO) {
        if (token.isBlank()) return@withContext false
        return@withContext try {
            val request = Request.Builder()
                .url("https://api.wigle.net/api/v2/profile/user")
                .addHeader("Authorization", "Basic $token")
                .addHeader("Accept", "application/json")
                .build()
            val response = client.newCall(request).execute()
            if (response.isSuccessful) {
                val body = response.body?.string() ?: return@withContext false
                org.json.JSONObject(body).optString(ConfigKeys.SUCCESS) == "true"
            } else false
        } catch (e: Exception) {
            false
        }
    }

    suspend fun fetchWifiData(lat: Double, lng: Double, token: String): String =
        withContext(Dispatchers.IO) {
            if (token.isBlank()) {
                return@withContext "[]"
            }

            val latrange1 = lat - 0.002
            val latrange2 = lat + 0.002
            val longrange1 = lng - 0.002
            val longrange2 = lng + 0.002

            val url =
                "https://api.wigle.net/api/v2/network/search?latrange1=$latrange1&latrange2=$latrange2&longrange1=$longrange1&longrange2=$longrange2&resultsPerPage=100"

            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Basic $token")
                .addHeader("Accept", "application/json")
                .build()

            try {
                val response = client.newCall(request).execute()
                if (response.isSuccessful) {
                    val body = response.body?.string() ?: return@withContext "[]"
                    val jsonObject = JSONObject(body)
                    val results = jsonObject.optJSONArray(ConfigKeys.RESULTS)
                    if (results == null || results.length() == 0) {
                        return@withContext "[]"
                    }

                    val wifiList = mutableListOf<JSONObject>()
                    // WiGLE 的 bbox 查询最多返回一个页；保留更多候选供路线重放使用。
                    val count = minOf(results.length(), 100)

                    for (i in 0 until count) {
                        val item = results.getJSONObject(i)
                        val bssid = item.optString(ConfigKeys.NETID, "")
                        if (bssid.isBlank()) continue
                        val wifi = JSONObject()
                        wifi.put(ConfigKeys.SSID, item.optString(ConfigKeys.SSID, "WLAN_${(1000..9999).random()}"))
                        wifi.put(ConfigKeys.BSSID, bssid)
                        // WiGLE 返回的 AP 观测位置；缺失时由调用方用查询点兜底。
                        val trilat = item.optDouble(ConfigKeys.TRILAT, Double.NaN)
                        val trilong = item.optDouble(ConfigKeys.TRILONG, Double.NaN)
                        if (trilat.isFinite() && trilong.isFinite() &&
                            trilat in -90.0..90.0 && trilong in -180.0..180.0
                        ) {
                            wifi.put(ConfigKeys.LAT, trilat)
                            wifi.put(ConfigKeys.LNG, trilong)
                        }
                        val channel = parseChannel(item)
                        wifi.put(ConfigKeys.CHANNEL, channel)
                        wifi.put(ConfigKeys.FREQUENCY, frequencyForChannel(channel, item))
                        wifi.put(
                            ConfigKeys.CAPABILITIES,
                            when (item.optString(ConfigKeys.ENCRYPTION, "").uppercase()) {
                                "WPA2", "WPA3", "WPA2/WPA3" -> "[WPA2-PSK-CCMP][ESS]"
                                "WEP" -> "[WEP][ESS]"
                                else -> "[ESS]"
                            }
                        )
                        wifiList.add(wifi)
                    }
                    return@withContext wifiList.toString()
                } else {
                    return@withContext "[]"
                }
            } catch (e: Exception) {
                return@withContext "[]"
            }
        }

    private fun parseChannel(item: JSONObject): Int {
        val raw = item.optString(ConfigKeys.CHANNEL, "")
        val direct = raw.toIntOrNull()
        if (direct != null && direct > 0) return direct
        val frequency = item.optString(ConfigKeys.FREQUENCY, "").toDoubleOrNull()
        if (frequency != null) {
            return when {
                frequency in 2400.0..2500.0 ->
                    (((frequency - 2407.0) / 5.0).toInt()).coerceIn(1, 14)
                frequency in 4900.0..5900.0 ->
                    ((frequency - 5000.0) / 5.0).toInt().coerceIn(32, 177)
                else -> 1
            }
        }
        return 1
    }

    private fun frequencyForChannel(channel: Int, item: JSONObject): Int {
        val direct = item.optString(ConfigKeys.FREQUENCY, "").toDoubleOrNull()
        if (direct != null && direct > 0) return direct.toInt()
        return when {
            channel in 1..13 -> 2407 + channel * 5
            channel == 14 -> 2484
            channel in 32..177 -> 5000 + channel * 5
            else -> 2412
        }
    }
}
