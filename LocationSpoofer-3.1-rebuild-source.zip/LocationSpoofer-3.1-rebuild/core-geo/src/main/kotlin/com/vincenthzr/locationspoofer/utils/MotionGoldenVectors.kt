package com.vincenthzr.locationspoofer.utils

/**
 * 姿态/角速度模型的固定输入与期望输出。
 *
 * 同一组常量用于 native 运行时自检；修改姿态公式时必须同步更新这里的
 * 期望值，避免 native 真实度模型悄然漂移。
 */
object MotionGoldenVectors {
    const val STEPS_FLOAT = 12.5
    const val SPEED_MPS = 3.0
    const val CADENCE_SPM = 160
    const val TRUE_HEADING_DEG = 90.0
    const val DECLINATION_DEG = -5.0
    const val YAW_RATE_RAD = 0.1
    const val REALISM_LEVEL = 3
    const val SEED = 123456789L
    const val TIME_SEC = 42.0

    /** yaw, pitch, roll, pitchRate, rollRate, yawRate（弧度或 rad/s）。 */
    val ATTITUDE = doubleArrayOf(
        1.668275986987822,
        0.003695750168121,
        0.034322105111358,
        -0.935500169441147,
        -0.214777230445939,
        0.104959909394808,
    )

    /** x, y, z, w。 */
    val QUATERNION = doubleArrayOf(
        0.011469600014435,
        0.012897043011643,
        -0.740628646998153,
        0.671692877588225,
    )

    /** body x, y, z（rad/s）。 */
    val GYRO = doubleArrayOf(
        0.938624913701506,
        -0.21389596518505,
        -0.07178456687313,
    )

    const val PRESSURE_ALTITUDE_M = 25.0
    const val PRESSURE_SEA_LEVEL_HPA = 1013.25
    const val PRESSURE_TIME_SEC = 42.0
    const val PRESSURE_HPA = 1010.5256744380252
}
