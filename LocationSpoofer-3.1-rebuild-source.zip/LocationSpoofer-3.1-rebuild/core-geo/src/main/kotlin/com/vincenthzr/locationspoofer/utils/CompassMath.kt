package com.vincenthzr.locationspoofer.utils

import kotlin.math.cos
import kotlin.math.sin

/**
 * 指南针/磁场传感器的纯数学工具。
 *
 * 约定：
 * - 方位角为度，正北 0°，顺时针增长；
 * - WMM 磁偏角东正；
 * - 磁方位 = 真方位 - 磁偏角；
 * - 设备视为水平：X 向右、Y 向屏幕上方、Z 向屏幕外。
 *
 * 这里不依赖 Android，方便在 JVM 单元测试中验证；`GeomagneticField` 的调用
 * 留在 xposed / sensor-native 等 Android 模块。
 */
object CompassMath {

    fun wrap360(deg: Double): Double {
        if (!deg.isFinite()) return 0.0
        val value = deg % 360.0
        return if (value < 0.0) value + 360.0 else value
    }

    /** 真北方位 -> 磁北方位（declination 东正）。 */
    fun trueToMagnetic(trueDeg: Double, declinationDeg: Double): Double =
        wrap360(trueDeg - declinationDeg)

    /** 磁北方位 -> 真北方位（declination 东正）。 */
    fun magneticToTrue(magneticDeg: Double, declinationDeg: Double): Double =
        wrap360(magneticDeg + declinationDeg)

    /** from -> to 的最短有符号角差，范围 [-180, 180)。 */
    fun shortestDeltaDegrees(fromDeg: Double, toDeg: Double): Double {
        var delta = wrap360(toDeg - fromDeg)
        if (delta >= 180.0) delta -= 360.0
        return delta
    }

    /**
     * 水平设备的磁场矢量（微特斯拉）。
     *
     * 设备顶部指向磁北时，磁场指向设备 +Y；顶部指向东时，北在设备左侧（-X）。
     * 因此 Bx = -H*sin(m)、By = H*cos(m)；Bz 保留真实垂直分量。
     * H 无效或过小时退回 25 µT，保证指南针 App 仍能算出方向。
     */
    fun flatMagneticFieldUt(
        magneticHeadingDeg: Double,
        horizontalUt: Float,
        zUt: Float
    ): FloatArray {
        val horizontal = if (horizontalUt.isFinite() && horizontalUt > 0.001f) {
            horizontalUt
        } else {
            25.0f
        }
        val z = if (zUt.isFinite()) zUt else 0.0f
        val rad = Math.toRadians(wrap360(magneticHeadingDeg))
        return floatArrayOf(
            (-horizontal * sin(rad)).toFloat(),
            (horizontal * cos(rad)).toFloat(),
            z
        )
    }

    /**
     * 水平设备、仅绕世界 Z 轴偏航的旋转矢量四元数 [x,y,z,w]。
     *
     * Android 设备坐标到 ENU 世界坐标：方位 90°（设备顶部朝东）对应绕 Z 轴
     * -90°，即 z = -sin(45°)、w = cos(45°)；身位与 -q 等价。
     */
    fun flatRotationVector(magneticHeadingDeg: Double): FloatArray {
        val half = Math.toRadians(wrap360(magneticHeadingDeg)) / 2.0
        return floatArrayOf(
            0.0f,
            0.0f,
            (-sin(half)).toFloat(),
            cos(half).toFloat()
        )
    }

    /** 旋转矢量第 5 个字段的航向精度单位为弧度（精度不是方位角，不做 360° 环绕）。 */
    fun accuracyDegreesToRadians(accuracyDeg: Double): Float =
        Math.toRadians(if (accuracyDeg.isFinite()) accuracyDeg else 0.0).toFloat()
}
