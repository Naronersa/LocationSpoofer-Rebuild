package com.vincenthzr.locationspoofer.utils

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * GNSS 观测质量的确定性模型。
 *
 * 真实 GPS 不会永远 20 颗卫星、2.5 米精度、HDOP 0.8：树荫/楼宇/高架下会短时
 * 掉星、HDOP 变差、水平精度升到几米甚至十几米。这里用开始时间和会话种子生成
 * 平滑的多尺度“压力”曲线，所有进程在任意时刻算出的精度/卫星数/HDOP 都一致，
 * 同时不再是一组写死的常量。
 *
 * 纯 Kotlin，不依赖 Android，方便 core-geo 单测和 native 共用。
 */
object GnssRealism {

    /** 小于 1 的精度值没有意义；正常户外约 1.2–4.5m，遮挡时可达 10m+。 */
    fun accuracyMeters(
        startTimestampMs: Long,
        realismLevel: Int,
        satelliteCount: Int,
        nowMs: Long,
    ): Double {
        val seed = seed(startTimestampMs)
        val realism = realismLevel.coerceIn(0, 3) / 3.0
        val t = nowMs / 1000.0
        val base = 1.7 + 0.5 * realism +
            0.35 * sin(TWO_PI * t / 19.0 + phase(seed, 1)) +
            0.20 * sin(TWO_PI * t / 7.3 + phase(seed, 2))
        val bad = degradation(seed, nowMs) * (6.0 + 2.0 * realism)
        return (base + bad).coerceIn(1.1, 18.0)
    }

    /** 参与定位解算的卫星数；配置值是“可见卫星”上限，不再等同于 usedInFix。 */
    fun usedSatellites(
        startTimestampMs: Long,
        realismLevel: Int,
        configuredCount: Int,
        nowMs: Long,
    ): Int {
        val seed = seed(startTimestampMs)
        val total = configuredCount.coerceIn(4, 32)
        val realism = realismLevel.coerceIn(0, 3) / 3.0
        val t = nowMs / 1000.0
        val fraction = (0.82 - 0.03 * realism +
            0.07 * sin(TWO_PI * t / 23.0 + phase(seed, 3)) -
            0.42 * degradation(seed, nowMs)).coerceIn(0.30, 0.98)
        return (total * fraction).roundToInt().coerceIn(4, total)
    }

    /**
     * HDOP 随 used 卫星数下降而变差，遮挡时额外抬升；GGA/GSA 与 Location.accuracy
     * 使用同一套压力曲线，避免“精度 12m 但 HDOP 0.8”的矛盾。
     */
    fun hdop(
        startTimestampMs: Long,
        realismLevel: Int,
        configuredCount: Int,
        used: Int,
        nowMs: Long,
    ): Double {
        val seed = seed(startTimestampMs)
        val realism = realismLevel.coerceIn(0, 3) / 3.0
        val t = nowMs / 1000.0
        val base = 0.75 + 2.8 / used.coerceAtLeast(4) +
            0.10 * sin(TWO_PI * t / 29.0 + phase(seed, 4)) +
            0.06 * sin(TWO_PI * t / 11.0 + phase(seed, 5))
        val bad = degradation(seed, nowMs) * (1.35 + 0.35 * realism)
        return (base + bad).coerceIn(0.7, 6.5)
    }

    fun vdop(
        startTimestampMs: Long,
        realismLevel: Int,
        configuredCount: Int,
        used: Int,
        nowMs: Long,
    ): Double {
        val seed = seed(startTimestampMs)
        val t = nowMs / 1000.0
        return (hdop(startTimestampMs, realismLevel, configuredCount, used, nowMs) * 1.25 +
            0.12 * sin(TWO_PI * t / 17.0 + phase(seed, 6))).coerceIn(0.8, 8.0)
    }

    fun pdop(
        startTimestampMs: Long,
        realismLevel: Int,
        configuredCount: Int,
        used: Int,
        nowMs: Long,
    ): Double = (hdop(
        startTimestampMs, realismLevel, configuredCount, used, nowMs
    ) * 1.35).coerceIn(1.0, 9.0)

    /** 0=良好，1=严重遮挡；用于精度、HDOP 和 raw measurement 的多路径标记。 */
    fun degradation(startTimestampMs: Long, nowMs: Long): Double {
        val seed = seed(startTimestampMs)
        val t = nowMs / 1000.0
        val a = 0.5 + 0.5 * sin(TWO_PI * t / 311.0 + phase(seed, 7))
        val b = 0.5 + 0.5 * sin(TWO_PI * t / 97.0 + phase(seed, 8))
        val c = 0.5 + 0.5 * sin(TWO_PI * t / 41.0 + phase(seed, 9))
        val stress = 0.5 * a + 0.3 * b + 0.2 * c
        return ((stress - 0.64) / 0.36).coerceIn(0.0, 1.0)
    }

    /** raw measurement 的伪距率量级：包含卫星径向运动和少量接收机速度分量。 */
    fun pseudorangeRateMps(
        startTimestampMs: Long,
        svid: Int,
        speedMps: Double,
        nowMs: Long,
    ): Double {
        val seed = seed(startTimestampMs)
        val t = nowMs / 1000.0
        val satelliteMotion = 320.0 * sin(
            TWO_PI * t / 47.0 + svid * 0.73 + phase(seed, 10)
        )
        val receiverMotion = speedMps.coerceIn(0.0, 12.0) *
            cos(TWO_PI * t / 13.0 + svid * 0.41)
        return satelliteMotion + receiverMotion
    }

    /** 多路径指示：0=UNKNOWN，1=DETECTED，2=NOT_DETECTED（Android 常量）。 */
    fun multipathIndicator(startTimestampMs: Long, nowMs: Long): Int =
        if (degradation(startTimestampMs, nowMs) > 0.58) 1 else 2

    fun absSin(seed: Long, index: Long, tSec: Double, periodSec: Double): Double =
        abs(sin(TWO_PI * tSec / periodSec + phase(seed, index)))

    private fun seed(startTimestampMs: Long): Long =
        if (startTimestampMs > 0L) startTimestampMs else 1L

    /** 与 RouteEngine/phase 相同的 64 位混合，保证不同进程的相位一致。 */
    private fun phase(seed: Long, index: Long): Double {
        var h = index * -7046029254386353131L + seed
        h = (h xor (h ushr 30)) * -4658895280553007687L
        h = (h xor (h ushr 27)) * -7723592293110705685L
        val u = (h xor (h ushr 31)) ushr 11
        return (u / 9.007199254740992E15) * 2.0 * PI
    }

    private const val TWO_PI = 2.0 * PI
}
