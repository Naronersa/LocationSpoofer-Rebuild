package com.vincenthzr.locationspoofer.utils

/**
 * 全项目唯一的坐标系标识。
 *
 * [storageId] 用于数据库、配置和导入导出持久化；[displayName] 只用于 UI/日志。
 * 旧版本曾在不同位置混用 `WGS84`/`WGS-84`/`GCJ02`/`GCJ-02`/`BD09`/`BD-09`，
 * 读取一律通过 [from] 归一化，写入一律使用 [storageId]。
 */
enum class CoordinateSystem(val storageId: String, val displayName: String) {
    WGS84("WGS84", "WGS-84"),
    GCJ02("GCJ02", "GCJ-02"),
    BD09("BD09", "BD-09");

    companion object {
        private val aliases: Map<String, CoordinateSystem> = buildMap {
            CoordinateSystem.entries.forEach { system ->
                put(system.storageId.lowercase(), system)
                put(system.displayName.lowercase(), system)
            }
            put(ConfigKeys.WGS_84, WGS84)
            put(ConfigKeys.GCJ_02, GCJ02)
            put(ConfigKeys.BD_09, BD09)
            put(ConfigKeys.BD09LL, BD09)
        }

        /** 解析持久化/UI 字符串；未知值返回 null，由调用方决定 fallback。 */
        fun from(raw: String?): CoordinateSystem? {
            val key = raw?.trim()?.lowercase() ?: return null
            if (key.isEmpty()) return null
            return aliases[key]
        }

        /** 解析失败时退回 [fallback]（默认 GCJ-02，与项目历史默认一致）。 */
        fun normalize(raw: String?, fallback: CoordinateSystem = GCJ02): CoordinateSystem =
            from(raw) ?: fallback

        /** `AUTO`、空字符串和纯空白都表示“按接口自动判断”。 */
        fun isAuto(raw: String?): Boolean =
            raw.isNullOrBlank() || raw.trim().equals("AUTO", ignoreCase = true)
    }
}
