package com.vincenthzr.locationspoofer.utils

import kotlin.math.PI
import kotlin.math.pow
import kotlin.math.sin

/**
 * 标准大气压换算与缓慢波动，供 Kotlin/native 共用同一组公式。
 * 时间参数为秒，结果单位为 hPa。
 */
object PressureMath {
    fun pressureHpa(altitudeM: Double, seaLevelHpa: Double, timeSec: Double): Double {
        val altitude = altitudeM.coerceIn(-500.0, 10_000.0)
        val seaLevel = seaLevelHpa.coerceIn(800.0, 1100.0)
        val base = (1.0 - altitude / 44330.0).pow(5.2550001983762575) * seaLevel
        val phase = timeSec * 2.0 * PI
        val wave =
            (sin(phase / 131.0 + 0.9) * 0.3 + sin(phase / 43.0) * 0.7) * 0.3
        val weather =
            sin(phase / 1200.0 + 0.7) * 0.25 + sin(phase / 420.0 + 1.9) * 0.15
        return base + wave + weather
    }
}
