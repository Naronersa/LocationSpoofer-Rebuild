package com.vincenthzr.locationspoofer.utils

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CoordinateSystemTest {

    @Test
    fun `canonical and legacy spellings resolve to the same system`() {
        for (raw in listOf("WGS84", "WGS-84", "wgs84", "wgs-84", " wgs_84 ")) {
            assertEquals(CoordinateSystem.WGS84, CoordinateSystem.from(raw))
        }
        for (raw in listOf("GCJ02", "GCJ-02", "gcj02", "gcj-02", " gcj_02 ")) {
            assertEquals(CoordinateSystem.GCJ02, CoordinateSystem.from(raw))
        }
        for (raw in listOf("BD09", "BD-09", "bd09", "bd-09", "bd09ll")) {
            assertEquals(CoordinateSystem.BD09, CoordinateSystem.from(raw))
        }
    }

    @Test
    fun `unknown values are null and normalize falls back`() {
        assertNull(CoordinateSystem.from(null))
        assertNull(CoordinateSystem.from(""))
        assertNull(CoordinateSystem.from("AUTO"))
        assertNull(CoordinateSystem.from("unknown"))
        assertEquals(CoordinateSystem.GCJ02, CoordinateSystem.normalize("unknown"))
        assertEquals(CoordinateSystem.WGS84, CoordinateSystem.normalize(null, CoordinateSystem.WGS84))
    }

    @Test
    fun `auto detection is explicit`() {
        assertTrue(CoordinateSystem.isAuto(null))
        assertTrue(CoordinateSystem.isAuto(""))
        assertTrue(CoordinateSystem.isAuto("  AUTO "))
        assertTrue(!CoordinateSystem.isAuto("WGS-84"))
    }

    @Test
    fun `storage ids are unique and canonical`() {
        assertEquals(
            CoordinateSystem.entries.map { it.storageId }.distinct().size,
            CoordinateSystem.entries.size
        )
        assertEquals("WGS84", CoordinateSystem.WGS84.storageId)
        assertEquals("GCJ02", CoordinateSystem.GCJ02.storageId)
        assertEquals("BD09", CoordinateSystem.BD09.storageId)
    }
}
