package com.vincenthzr.locationspoofer.utils

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.atan2
import kotlin.math.hypot

class CompassMathTest {

    @Test
    fun wrap360NormalizesNegativeAndOverflow() {
        assertEquals(350.0, CompassMath.wrap360(-10.0), 1e-9)
        assertEquals(10.0, CompassMath.wrap360(370.0), 1e-9)
        assertEquals(0.0, CompassMath.wrap360(0.0), 1e-9)
        assertEquals(0.0, CompassMath.wrap360(Double.NaN), 0.0)
    }

    @Test
    fun declinationSignIsEastPositive() {
        // WMM +10°: magnetic north is 10° east of true north.
        assertEquals(350.0, CompassMath.trueToMagnetic(0.0, 10.0), 1e-9)
        assertEquals(10.0, CompassMath.trueToMagnetic(0.0, -10.0), 1e-9)
        assertEquals(0.0, CompassMath.magneticToTrue(350.0, 10.0), 1e-9)
        assertEquals(0.0, CompassMath.magneticToTrue(10.0, -10.0), 1e-9)
    }

    @Test
    fun declinationRoundTrip() {
        for (heading in doubleArrayOf(0.0, 45.0, 90.0, 180.0, 270.0, 359.5)) {
            for (declination in doubleArrayOf(-20.0, -7.0, 0.0, 7.0, 20.0)) {
                val magnetic = CompassMath.trueToMagnetic(heading, declination)
                assertEquals(
                    CompassMath.wrap360(heading),
                    CompassMath.magneticToTrue(magnetic, declination),
                    1e-9
                )
            }
        }
    }

    @Test
    fun flatMagneticFieldCardinalDirections() {
        val north = CompassMath.flatMagneticFieldUt(0.0, 25.0f, -40.0f)
        assertEquals(0.0, north[0].toDouble(), 1e-5)
        assertEquals(25.0, north[1].toDouble(), 1e-5)
        assertEquals(-40.0, north[2].toDouble(), 1e-5)

        val east = CompassMath.flatMagneticFieldUt(90.0, 25.0f, -40.0f)
        assertEquals(-25.0, east[0].toDouble(), 1e-5)
        assertEquals(0.0, east[1].toDouble(), 1e-5)
        assertEquals(-40.0, east[2].toDouble(), 1e-5)
    }

    @Test
    fun flatMagneticFieldRecoversMagneticHeading() {
        for (heading in doubleArrayOf(0.0, 30.0, 90.0, 180.0, 270.0, 350.0)) {
            val field = CompassMath.flatMagneticFieldUt(heading, 42.0f, -30.0f)
            val recovered = CompassMath.wrap360(
                Math.toDegrees(atan2(-field[0].toDouble(), field[1].toDouble()))
            )
            assertEquals(heading, recovered, 1e-4)
            assertEquals(42.0, hypot(field[0].toDouble(), field[1].toDouble()), 1e-4)
        }
    }

    @Test
    fun flatMagneticFieldUsesSafeFallbackForInvalidHorizontalStrength() {
        val field = CompassMath.flatMagneticFieldUt(0.0, 0.0f, 0.0f)
        assertEquals(0.0, field[0].toDouble(), 1e-5)
        assertEquals(25.0, field[1].toDouble(), 1e-5)
        assertEquals(0.0, field[2].toDouble(), 1e-5)
    }

    @Test
    fun flatRotationVectorIsUnitAndYawIsConsistent() {
        val north = CompassMath.flatRotationVector(0.0)
        assertEquals(0.0, north[0].toDouble(), 1e-7)
        assertEquals(0.0, north[1].toDouble(), 1e-7)
        assertEquals(0.0, north[2].toDouble(), 1e-7)
        assertEquals(1.0, north[3].toDouble(), 1e-7)

        val east = CompassMath.flatRotationVector(90.0)
        assertEquals(-0.7071068, east[2].toDouble(), 1e-5)
        assertEquals(0.7071068, east[3].toDouble(), 1e-5)
        assertEquals(1.0, hypot(east[2].toDouble(), east[3].toDouble()), 1e-6)

        val south = CompassMath.flatRotationVector(180.0)
        assertEquals(-1.0, south[2].toDouble(), 1e-5)
        assertEquals(0.0, south[3].toDouble(), 1e-5)

        val west = CompassMath.flatRotationVector(270.0)
        assertEquals(-0.7071068, west[2].toDouble(), 1e-5)
        assertEquals(-0.7071068, west[3].toDouble(), 1e-5)
        assertTrue(hypot(west[2].toDouble(), west[3].toDouble()) > 0.999)
    }

    @Test
    fun shortestDeltaWrapsAcrossNorth() {
        assertEquals(-10.0, CompassMath.shortestDeltaDegrees(355.0, 345.0), 1e-9)
        assertEquals(10.0, CompassMath.shortestDeltaDegrees(355.0, 5.0), 1e-9)
        assertEquals(-170.0, CompassMath.shortestDeltaDegrees(0.0, 190.0), 1e-9)
        assertEquals(170.0, CompassMath.shortestDeltaDegrees(0.0, 170.0), 1e-9)
    }

    @Test
    fun accuracyUsesRadiansWithoutWrapping() {
        assertEquals(0.08726646, CompassMath.accuracyDegreesToRadians(5.0).toDouble(), 1e-8)
        assertEquals(0.0, CompassMath.accuracyDegreesToRadians(Double.NaN).toDouble(), 0.0)
    }
}
