package com.vincenthzr.locationspoofer.utils

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GnssRealismTest {

    @Test
    fun `quality is deterministic for the same session time`() {
        val t = 1_792_755_000_000L
        assertEquals(
            GnssRealism.accuracyMeters(123456L, 2, 20, t),
            GnssRealism.accuracyMeters(123456L, 2, 20, t),
            0.0
        )
        assertEquals(
            GnssRealism.usedSatellites(123456L, 2, 20, t),
            GnssRealism.usedSatellites(123456L, 2, 20, t)
        )
        assertEquals(
            GnssRealism.hdop(123456L, 2, 20, 16, t),
            GnssRealism.hdop(123456L, 2, 20, 16, t),
            0.0
        )
    }

    @Test
    fun `normal and degraded GNSS values stay in plausible ranges`() {
        val start = 1_792_755_000_000L
        var maxAccuracy = 0.0
        var maxDegradation = 0.0
        for (i in 0..7200 step 5) {
            val now = start + i * 1000L
            val accuracy = GnssRealism.accuracyMeters(start, 3, 24, now)
            val used = GnssRealism.usedSatellites(start, 3, 24, now)
            val hdop = GnssRealism.hdop(start, 3, 24, used, now)
            assertTrue(accuracy in 1.1..18.0)
            assertTrue(used in 4..24)
            assertTrue(hdop in 0.7..6.5)
            assertTrue(GnssRealism.vdop(start, 3, 24, used, now) >= hdop)
            maxAccuracy = maxOf(maxAccuracy, accuracy)
            maxDegradation = maxOf(maxDegradation, GnssRealism.degradation(start, now))
        }
        // 两小时内应至少出现一次明显遮挡，否则还是"永远满格"。
        assertTrue(maxAccuracy > 5.0)
        assertTrue(maxDegradation > 0.5)
    }

    @Test
    fun `pseudorange rate has satellite motion rather than a constant zero`() {
        val start = 1_792_755_000_000L
        val a = GnssRealism.pseudorangeRateMps(start, 7, 1.4, start + 1000L)
        val b = GnssRealism.pseudorangeRateMps(start, 7, 1.4, start + 6000L)
        assertTrue(kotlin.math.abs(a) > 1.0)
        assertTrue(kotlin.math.abs(b) > 1.0)
        assertTrue(kotlin.math.abs(a - b) > 0.01)
    }
}
