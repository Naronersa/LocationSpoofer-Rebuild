package com.vincenthzr.locationspoofer.utils

import org.junit.Assert.assertEquals
import org.junit.Test

class PressureMathTest {

    @Test
    fun matchesGoldenVector() {
        assertEquals(
            MotionGoldenVectors.PRESSURE_HPA,
            PressureMath.pressureHpa(
                MotionGoldenVectors.PRESSURE_ALTITUDE_M,
                MotionGoldenVectors.PRESSURE_SEA_LEVEL_HPA,
                MotionGoldenVectors.PRESSURE_TIME_SEC,
            ),
            1e-9,
        )
    }

    @Test
    fun clampsAltitudeAndSeaLevel() {
        val low = PressureMath.pressureHpa(-500.0, 800.0, 0.0)
        val lower = PressureMath.pressureHpa(-1000.0, 700.0, 0.0)
        assertEquals(low, lower, 0.0)
    }
}
