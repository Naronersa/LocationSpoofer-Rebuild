package com.vincenthzr.locationspoofer.xposed.hooks

import com.vincenthzr.locationspoofer.xposed.utils.HookLog

import com.vincenthzr.locationspoofer.utils.ConfigKeys

import android.annotation.SuppressLint
import android.os.Binder
import com.vincenthzr.locationspoofer.xposed.utils.SpoofedMotion
import com.vincenthzr.locationspoofer.xposed.utils.XposedBridge
import com.vincenthzr.locationspoofer.xposed.utils.XposedHelpers
import org.json.JSONObject

/**
 * 系统服务（system_server）调用方识别与权限判定工具
 *
 * `@SuppressLint("StaticFieldLeak")`：Lint 把 [cachedSystemContext] 报成"静态字段持有 Context 会
 * 内存泄漏"，但那是针对普通 App 进程里 Activity/Fragment 这类短生命周期 Context 设计的检查——
 * 这里缓存的是 system_server 自己的系统级 Context（`ActivityThread.getSystemContext()`），
 * 和 system_server 进程本身同生共死，没有 Activity/View 引用链，不会造成真实泄漏，可以放心 Suppress
 * （Lint 把这个警告挂在了 object 声明本身，而不是字段声明上，所以注解也要加在这里才生效）。
 */
@SuppressLint("StaticFieldLeak")
object SystemHookUtils {

    /**
     * 跨机型通用的基础豁免包名：本项目自身、系统核心进程、GMS、Qualcomm 定位 HAL 服务等——
     * 在任何 Android 设备上都存在、都不该被模拟的包。
     *
     * 厂商自有的定位融合 / 场景感知 / 省电策略服务（例如小米的 MetokNLP）不再堆在这里，
     * 改为在对应的 `hooks/vendor/profiles/XxxVendor.kt` 里通过
     * [com.vincenthzr.locationspoofer.xposed.hooks.vendor.SystemHookVendor.additionalExemptPackages]
     * 声明——同一个厂商专属的豁免名单不该出现在所有机型都会用到的通用名单里，否则每加一个新机型
     * 的专属豁免又会回到"全堆在一起"的老路。
     */
    private val BASE_EXEMPT_PACKAGES = setOf(
        "com.vincenthzr.locationspoofer",
        "com.vincenthzr.locationspoofer.rebuild",
        "android",
        "system_server",
        "system",
        "com.android.systemui",
        "com.android.phone",
        "com.android.server.telecom",
        "com.google.android.gms",
        "com.qualcomm.location",
        "com.qualcomm.atfwd",
        "com.android.ons",
        "com.android.location.fused",
    )

    /**
     * 系统豁免包名：绝对不进行模拟，保证系统基础运行与自身数据采集不受污染。
     * = 通用基线 [BASE_EXEMPT_PACKAGES] ∪ 当前机型通过 vendor 适配层追加的专属豁免包名
     * （[com.vincenthzr.locationspoofer.xposed.hooks.vendor.VendorRegistry.additionalExemptPackages]）。
     * 首次访问时求值并缓存，之后每次调用零额外开销。
     */
    val EXEMPT_PACKAGES: Set<String> by lazy {
        BASE_EXEMPT_PACKAGES + com.vincenthzr.locationspoofer.xposed.hooks.vendor.VendorRegistry.additionalExemptPackages
    }

    /** 本工程自身的两个包名：原包名与 `.rebuild` 共存包名都绝不模拟。 */
    fun isSelfPackage(packageName: String?): Boolean {
        val base = packageName?.substringBefore(":")?.trim() ?: return false
        return base == "com.vincenthzr.locationspoofer" ||
            base == "com.vincenthzr.locationspoofer.rebuild"
    }

    /** 缓存的 system_server 系统级 Context，见类注释里 `@SuppressLint("StaticFieldLeak")` 的说明。 */
    @Volatile
    private var cachedSystemContext: android.content.Context? = null

    // Lint 的 PrivateApi 检查是在提醒"反射调用的隐藏 API 在不同系统版本上可能改名/消失"——这个提醒
    // 本身是对的，但规避不了：本项目的定位就是在 system_server 里 Hook 系统内部实现，必然要通过
    // 反射拿到 ActivityThread 这类 @hide 类。真正的应对方式不是不用反射，而是本函数已经做到的：
    // 全程 try/catch 兜底、拿不到就返回 null，调用方（resolveCallingPackages）已经有降级路径
    // （退回 serviceInstance 的 mContext 字段），不会因为某个系统版本上这条反射链路失效而崩溃。
    @SuppressLint("PrivateApi")
    fun getSystemContext(): android.content.Context? {
        cachedSystemContext?.let { return it }
        return try {
            val atClass = Class.forName("android.app.ActivityThread")
            val currentAt = atClass.getMethod("currentActivityThread").invoke(null)
            val ctx = atClass.getMethod("getSystemContext").invoke(currentAt) as? android.content.Context
            cachedSystemContext = ctx
            ctx
        } catch (_: Throwable) {
            null
        }
    }

    /**
     * 通过 Binder.getCallingUid() 或传入的 overrideUid 反查系统服务调用者的已安装包名集合
     */
    fun resolveCallingPackages(serviceInstance: Any?, overrideUid: Int? = null): Set<String> {
        return try {
            val uid = if (overrideUid != null && overrideUid > 1000) overrideUid else Binder.getCallingUid()
            if (uid <= 1000) return emptySet() // 忽略 root (0) 和 system (1000) 核心调用

            // 优先使用 ActivityThread 的系统上下文（在 system_server 中最稳定）
            val sysCtx = getSystemContext()
            if (sysCtx != null) {
                val pkgs = sysCtx.packageManager.getPackagesForUid(uid)
                if (!pkgs.isNullOrEmpty()) {
                    return pkgs.toSet()
                }
            }

            // 降级使用 serviceInstance 中的 mContext
            if (serviceInstance != null) {
                val context = XposedHelpers.getObjectField(serviceInstance, "mContext") as? android.content.Context
                if (context != null) {
                    val pkgs = context.packageManager.getPackagesForUid(uid)
                    if (!pkgs.isNullOrEmpty()) {
                        return pkgs.toSet()
                    }
                }
            }
            emptySet()
        } catch (t: Throwable) {
            XposedBridge.log("[SysHook] resolveCallingPackages failed: $t")
            emptySet()
        }
    }

    /**
     * 从方法参数中提取 CallerIdentity 或请求对象中的 UID
     */
    fun extractCallerUid(args: List<Any?>): Int? {
        for (arg in args) {
            if (arg == null) continue
            val className = arg.javaClass.simpleName
            if (className.contains("Identity") || className.contains("Request") || className.contains("Registration") || className == "AttributionSource") {
                try {
                    val uid = XposedHelpers.callMethod(arg, "getUid") as? Int
                    if (uid != null && uid > 1000) return uid
                } catch (t: Throwable) { HookLog.swallowed("SystemHookUtils.kt:135", t) }
                try {
                    val uid = XposedHelpers.getIntField(arg, "mUid")
                    if (uid > 1000) return uid
                } catch (t: Throwable) { HookLog.swallowed("SystemHookUtils.kt:139", t) }
            }
        }
        return null
    }

    /**
     * 从方法参数中稳妥提取调用方传入的包名（过滤掉 provider、类名与标记，支持 CallerIdentity）
     */
    fun extractPackageName(args: List<Any?>): String? {
        for (arg in args) {
            if (arg == null) continue
            if (arg is String) {
                // 包名特征：必须包含点号，且不是 provider 名称，不是系统内部类名
                if (arg.contains(".") &&
                    !arg.startsWith("android.") &&
                    !arg.startsWith("com.android.server.") &&
                    arg != "gps" && arg != "network" && arg != "passive" && arg != "fused"
                ) {
                    return arg
                }
            }
            // 支持 CallerIdentity / Identity 对象
            val className = arg.javaClass.simpleName
            if (className.contains("Identity") || className.contains("Request") || className.contains("Registration") || className == "AttributionSource") {
                try {
                    val pkg = XposedHelpers.callMethod(arg, "getPackageName") as? String
                    if (!pkg.isNullOrEmpty() && pkg.contains(".") && !pkg.startsWith("android.")) {
                        return pkg
                    }
                } catch (t: Throwable) { HookLog.swallowed("SystemHookUtils.kt:169", t) }
                try {
                    val pkg = XposedHelpers.getObjectField(arg, "mPackageName") as? String
                    if (!pkg.isNullOrEmpty() && pkg.contains(".") && !pkg.startsWith("android.")) {
                        return pkg
                    }
                } catch (t: Throwable) { HookLog.swallowed("SystemHookUtils.kt:175", t) }
            }
            if (arg is android.app.PendingIntent) {
                val pkg = arg.creatorPackage
                if (!pkg.isNullOrEmpty() && pkg.contains(".")) return pkg
            }
        }
        return null
    }

    /**
     * 从方法参数中稳妥提取 provider（如 "gps", "network", "fused"）
     */
    fun extractProvider(args: List<Any?>): String {
        for (arg in args) {
            if (arg is String) {
                when (arg.lowercase()) {
                    "gps", "network", "passive", "fused" -> return arg
                }
            }
            if (arg != null && (arg.javaClass.simpleName.contains("Request") || arg.javaClass.simpleName.contains("Registration"))) {
                try {
                    val p = XposedHelpers.callMethod(arg, "getProvider") as? String
                    if (!p.isNullOrEmpty()) return p
                } catch (t: Throwable) { HookLog.swallowed("SystemHookUtils.kt:199", t) }
                try {
                    val p = XposedHelpers.getObjectField(arg, "mProvider") as? String
                    if (!p.isNullOrEmpty()) return p
                } catch (t: Throwable) { HookLog.swallowed("SystemHookUtils.kt:203", t) }
            }
        }
        return android.location.LocationManager.GPS_PROVIDER
    }

    /**
     * 解析配置中的白名单目标包名列表
     */
    fun resolveTargetPackages(config: JSONObject): Set<String> {
        return config.optJSONArray(ConfigKeys.SYSTEM_HOOK_PACKAGES)?.let { arr ->
            (0 until arr.length()).mapNotNull { arr.optString(it, null) }.toSet()
        } ?: emptySet()
    }

    /**
     * 核心判定方法：当前调用方是否属于需要被虚拟模拟的目标应用
     *
     * @param serviceInstance 系统服务实例（用于获取 Context 与 Binder UID）
     * @param explicitPackage 方法参数中显式传入的包名（如 callingPackage），若没有可传 null
     * @param config 当前全局配置 JSON
     * @param overrideUid 可选的调用方真实 UID（如来自 CallerIdentity），解决 clearCallingIdentity 后的 UID 漂移
     */
    fun isTargetCaller(
        serviceInstance: Any?,
        explicitPackage: String?,
        config: JSONObject,
        overrideUid: Int? = null,
        requireActive: Boolean = true
    ): Boolean {
        // 注册阶段的目标判定不能依赖 ACTIVE：目标 App 往往在模拟开启前就注册了
        // 定位/卫星/NMEA/基站监听，只有先把这些 binder 记下来，模拟开始后心跳
        // 才能接管它们。投递/改写路径仍使用默认 requireActive=true。
        if (requireActive && !config.optBoolean(ConfigKeys.ACTIVE, false)) return false

        val uid = if (overrideUid != null && overrideUid > 1000) overrideUid else Binder.getCallingUid()
        val cleanPkg = explicitPackage?.substringBefore(":")?.trim()

        // 1. 严格排除自身，绝不模拟自身
        if (isSelfPackage(cleanPkg) || isSelfPackage(explicitPackage)) {
            return false
        }

        // 若是 system_server 内部发起的调用（uid=1000）且无显式外部包名，则不干扰系统内部逻辑
        if (uid <= 1000 && explicitPackage == null) {
            return false
        }

        // 严格排除系统核心组件与定位服务
        if (cleanPkg != null && EXEMPT_PACKAGES.contains(cleanPkg)) {
            return false
        }

        val callingPackages = resolveCallingPackages(serviceInstance, uid)
        if (callingPackages.any { isSelfPackage(it) }) {
            return false
        }
        if (callingPackages.any { EXEMPT_PACKAGES.contains(it.substringBefore(":")) }) {
            return false
        }

        val isGlobalMode = config.optBoolean(ConfigKeys.SYSTEM_HOOK_GLOBAL_MODE, false)

        // 2. 全局模拟模式：只对普通用户应用（UID >= 10000）生效，绝不污染系统级服务
        if (isGlobalMode) {
            if (uid >= 10000) {
                if (cleanPkg != null && !EXEMPT_PACKAGES.contains(cleanPkg)) {
                    XposedBridge.log("[SysHook] GlobalMode match: explicitPkg=$explicitPackage (cleanPkg=$cleanPkg, uid=$uid)")
                    return true
                }
                val nonExempt = callingPackages.filter { !EXEMPT_PACKAGES.contains(it.substringBefore(":")) }
                if (nonExempt.isNotEmpty()) {
                    XposedBridge.log("[SysHook] GlobalMode match: callingPkgs=$nonExempt (uid=$uid)")
                    return true
                }
            }
            return false
        }

        // 3. 白名单模式：仅对用户在软件内勾选的目标包名生效
        val targetPackages = resolveTargetPackages(config)
        if (targetPackages.isEmpty()) return false

        if (cleanPkg != null && targetPackages.contains(cleanPkg)) {
            logWhitelistMatch("clean:$uid:$cleanPkg", "[SysHook] Whitelist match: cleanPkg=$cleanPkg (explicitPkg=$explicitPackage, uid=$uid)")
            return true
        }

        if (explicitPackage != null && targetPackages.contains(explicitPackage)) {
            logWhitelistMatch("exp:$explicitPackage", "[SysHook] Whitelist match: explicitPkg=$explicitPackage (uid=$uid)")
            return true
        }

        val matched = callingPackages.filter { pkg ->
            targetPackages.contains(pkg) || targetPackages.contains(pkg.substringBefore(":"))
        }
        if (matched.isNotEmpty()) {
            logWhitelistMatch("call:${matched.first()}", "[SysHook] Whitelist match: callingPkgs=$matched (uid=$uid)")
            return true
        }

        return false
    }

    private val lastWhitelistLogTimes = java.util.concurrent.ConcurrentHashMap<String, Long>()

    private fun logWhitelistMatch(key: String, message: String) {
        val now = System.currentTimeMillis()
        val last = lastWhitelistLogTimes[key] ?: 0L
        if (now - last > 5000L) {
            lastWhitelistLogTimes[key] = now
            XposedBridge.log(message)
        }
    }

    /**
     * 就地改写 Location 对象的坐标、精度、速度、航向、时间戳，并彻底抹除 mock 标志位
     */
    fun applyFakeLocationFields(
        locObj: Any,
        motion: SpoofedMotion,
        altitude: Double,
        accuracy: Float
    ) {
        try {
            XposedHelpers.callMethod(locObj, "setLatitude", motion.lat)
            XposedHelpers.callMethod(locObj, "setLongitude", motion.lng)
            XposedHelpers.callMethod(locObj, "setAccuracy", accuracy)
            XposedHelpers.callMethod(locObj, "setSpeed", motion.speed)
            XposedHelpers.callMethod(locObj, "setBearing", motion.bearing)
            XposedHelpers.callMethod(locObj, "setAltitude", altitude)
            XposedHelpers.callMethod(locObj, "setTime", System.currentTimeMillis())
            XposedHelpers.callMethod(
                locObj, "setElapsedRealtimeNanos",
                android.os.SystemClock.elapsedRealtimeNanos()
            )
            try {
                XposedHelpers.callMethod(locObj, "setVerticalAccuracyMeters", 1.5f)
            } catch (t: Throwable) { HookLog.swallowed("SystemHookUtils.kt:337", t) }
            try {
                XposedHelpers.callMethod(locObj, "setSpeedAccuracyMetersPerSecond", 0.3f)
            } catch (t: Throwable) { HookLog.swallowed("SystemHookUtils.kt:340", t) }
            try {
                XposedHelpers.callMethod(locObj, "setBearingAccuracyDegrees", 2.0f)
            } catch (t: Throwable) { HookLog.swallowed("SystemHookUtils.kt:343", t) }
            try {
                XposedHelpers.callMethod(locObj, "setMock", false)
            } catch (t: Throwable) { HookLog.swallowed("SystemHookUtils.kt:346", t) }
            try {
                XposedHelpers.callMethod(locObj, "setIsFromMockProvider", false)
            } catch (t: Throwable) { HookLog.swallowed("SystemHookUtils.kt:349", t) }
            try {
                // 运动 App 会同时看 provider 和 extras；统一为 gps + 动态卫星数，
                // 避免 network/wifi 与 gps 回调交替、或固定 20/18 与 NMEA 不一致。
                XposedHelpers.callMethod(locObj, "setProvider", FakeLocationMetadata.provider)
            } catch (t: Throwable) { HookLog.swallowed("SystemHookUtils.kt:354", t) }
            try {
                val extras = XposedHelpers.callMethod(locObj, "getExtras") as? android.os.Bundle
                if (extras != null) {
                    extras.remove("mockLocation")
                    // 原始 network/wifi 回调会把 provider/source 留在 extras 里；
                    // 只改 Location.provider 不够，部分运动 App 会读这两个字段。
                    extras.remove("provider")
                    extras.remove("source")
                    extras.putInt("satellites", FakeLocationMetadata.satellitesInView)
                    extras.putInt("satellites_in_view", FakeLocationMetadata.satellitesInView)
                    extras.putInt("satellites_used_in_fix", FakeLocationMetadata.satellitesUsed)
                } else {
                    val bundle = android.os.Bundle()
                    bundle.putInt("satellites", FakeLocationMetadata.satellitesInView)
                    bundle.putInt("satellites_in_view", FakeLocationMetadata.satellitesInView)
                    bundle.putInt("satellites_used_in_fix", FakeLocationMetadata.satellitesUsed)
                    XposedHelpers.callMethod(locObj, "setExtras", bundle)
                }
            } catch (t: Throwable) { HookLog.swallowed("SystemHookUtils.kt:373", t) }
        } catch (t: Throwable) { HookLog.swallowed("SystemHookUtils.kt:374", t) }
    }

    /**
     * 构造一个新的伪造 Location 对象
     */
    fun buildFakeLocation(
        classLoader: ClassLoader,
        provider: String,
        motion: SpoofedMotion,
        altitude: Double,
        accuracy: Float
    ): Any? {
        return try {
            val locClass = Class.forName("android.location.Location", false, classLoader)
            // 个别 ROM/类加载器下 String 构造器不可见；退回无参构造器，
            // provider 稍后由 applyFakeLocationFields 的 setProvider 写入。
            val fakeLoc = try {
                locClass.getConstructor(String::class.java).newInstance(provider)
            } catch (_: Throwable) {
                locClass.getDeclaredConstructor().also { it.isAccessible = true }.newInstance()
            }
            applyFakeLocationFields(fakeLoc, motion, altitude, accuracy)
            fakeLoc
        } catch (t: Throwable) {
            XposedBridge.log("[SysHook] buildFakeLocation failed: $t")
            null
        }
    }
}
