@file:Suppress(
    "UNUSED_PARAMETER",
    "UNUSED_VARIABLE",
    "UNNECESSARY_NOT_NULL_ASSERTION",
    "DEPRECATION",
    "NAME_SHADOWING",
    "FunctionName",
    "PrivatePropertyName",
    "SpellCheckingInspection",
    "RedundantUnitReturnType",
    "RemoveRedundantQualifierName",
    "OPT_IN_USAGE",
    "unused",
    "UnusedImport"
)

package com.vincenthzr.locationspoofer.xposed.hooks

import com.vincenthzr.locationspoofer.xposed.utils.HookLog

import com.vincenthzr.locationspoofer.utils.ConfigKeys

import android.util.Log
import com.vincenthzr.locationspoofer.xposed.LocationHooker
import com.vincenthzr.locationspoofer.xposed.diagnostics.HookStatus
import com.vincenthzr.locationspoofer.xposed.hooks.vendor.SystemClassLocator
import com.vincenthzr.locationspoofer.xposed.hooks.vendor.SystemComponent
import com.vincenthzr.locationspoofer.xposed.utils.XposedBridge
import com.vincenthzr.locationspoofer.xposed.utils.XposedHelpers
import org.json.JSONObject
import java.io.File
import java.lang.reflect.Array as ReflectArray
import java.util.Random

/**
 * system_server 级 Wi-Fi 服务（WifiServiceImpl）拦截与伪造模块
 *
 * 核心原理：
 * 全设备所有应用调用 WifiManager.getScanResults() 与 WifiManager.getConnectionInfo()
 * 都会通过 IWifiManager 远程 IPC 调用至 system_server 中的 WifiServiceImpl。
 *
 * 在 Android 12+ / HyperOS 中，WifiServiceImpl 被移动至 /apex/com.android.wifi/javalib/service-wifi.jar。
 * 本模块通过 ServiceManager.getService("wifi")、addService 拦截以及 APEX 动态类加载等多重机制
 * 确保稳定捕获 WifiServiceImpl 并完成挂载。
 */

@Volatile
internal var isWifiServiceHooked = false

private fun logWifi(msg: String) {
    XposedBridge.log(msg)
}

private fun findWifiServiceClass(classLoader: ClassLoader): Class<*>? =
    // Android 12+ 的 WifiServiceImpl 在 wifi APEX 里，默认 ClassLoader 找不到，靠后面几层兜底（见 SystemClassLocator）
    SystemClassLocator.locate(
        SystemComponent.WIFI_SERVICE, classLoader,
        threadKeywords = listOf("Wifi", "Scan", "wlan"),
        serviceNames = listOf("wifi", "wifiscanner"),
        deepScan = true
    )

internal fun LocationHooker.tryHookPendingSystemServices(classLoader: ClassLoader) {
    if (!isWifiServiceHooked) {
        try {
            val smClass = XposedHelpers.findClassIfExists("android.os.ServiceManager", classLoader)
            val wifiBinder = smClass?.let { XposedHelpers.callStaticMethod(it, "getService", "wifi") }
            if (wifiBinder != null && !wifiBinder.javaClass.name.contains("BinderProxy")) {
                val realClass = wifiBinder.javaClass
                val realCl = realClass.classLoader ?: classLoader
                logWifi("[SysWifi] Discovered REAL WifiServiceImpl via service poll: ${realClass.name}")
                HookStatus.classFound(SystemComponent.WIFI_SERVICE, realClass, "ServiceManager.getService")
                installWifiHooks(realClass, realCl)
                isWifiServiceHooked = true
            }
        } catch (t: Throwable) { HookLog.swallowed("SystemWifiServiceHooker.kt:74", t) }
    }
    if (!isConnectivityServiceHooked) {
        try {
            val smClass = XposedHelpers.findClassIfExists("android.os.ServiceManager", classLoader)
            val connBinder = smClass?.let { XposedHelpers.callStaticMethod(it, "getService", "connectivity") }
            if (connBinder != null && !connBinder.javaClass.name.contains("BinderProxy")) {
                val realClass = connBinder.javaClass
                val realCl = realClass.classLoader ?: classLoader
                logWifi("[SysWifi] Discovered REAL ConnectivityService via service poll: ${realClass.name}")
                HookStatus.classFound(SystemComponent.CONNECTIVITY_SERVICE, realClass, "ServiceManager.getService")
                installConnectivityHooks(realClass, realCl)
                isConnectivityServiceHooked = true
            }
        } catch (t: Throwable) { HookLog.swallowed("SystemWifiServiceHooker.kt:88", t) }
    }
}

/** 服务注册入口（publishBinderService / addService）只需要拦截一次；后台轮询会反复调用 hookSystemWifiService */
@Volatile
private var wifiRegistrationHooksInstalled = false

internal fun LocationHooker.hookSystemWifiService(classLoader: ClassLoader) {
    logWifi("[SysWifi] hookSystemWifiService invoked, searching for WifiServiceImpl...")

    val wifiClass = findWifiServiceClass(classLoader)
    if (wifiClass != null) {
        installWifiHooks(wifiClass, wifiClass.classLoader ?: classLoader)
        isWifiServiceHooked = true
        logWifi("[SysWifi] Successfully hooked WifiServiceImpl on ${wifiClass.name}")
    }

    if (wifiRegistrationHooksInstalled) return
    wifiRegistrationHooksInstalled = true

    try {
        val systemServiceClass = XposedHelpers.findClassIfExists("com.android.server.SystemService", classLoader)
        if (systemServiceClass != null) {
            XposedHelpers.hookAllMethods(systemServiceClass, "publishBinderService") { chain, _ ->
                val name = chain.args.firstOrNull { it is String } as? String
                val service = chain.args.getOrNull(1)
                if (service != null && !service.javaClass.name.contains("BinderProxy")) {
                    if (name == "wifi" || name == "wifiscanner") {
                        val realClass = service.javaClass
                        val realCl = realClass.classLoader ?: classLoader
                        logWifi("[SysWifi] Captured $name from publishBinderService: ${realClass.name}")
                        HookStatus.classFound(
                            if (name == "wifi") SystemComponent.WIFI_SERVICE else SystemComponent.WIFI_SCANNER_SERVICE,
                            realClass, "publishBinderService"
                        )
                        installWifiHooks(realClass, realCl)
                        isWifiServiceHooked = true
                    } else if (name == "connectivity") {
                        val realClass = service.javaClass
                        val realCl = realClass.classLoader ?: classLoader
                        logWifi("[SysWifi] Captured $name from publishBinderService: ${realClass.name}")
                        HookStatus.classFound(SystemComponent.CONNECTIVITY_SERVICE, realClass, "publishBinderService")
                        installConnectivityHooks(realClass, realCl)
                        isConnectivityServiceHooked = true
                    }
                }
                return@hookAllMethods chain.proceed(chain.args.toTypedArray())
            }
            logWifi("[SysWifi] SystemService.publishBinderService hooked")
        }
    } catch (t: Throwable) {
        logWifi("[SysWifi] Hook publishBinderService failed: $t")
    }

    try {
        val smClass = XposedHelpers.findClassIfExists("android.os.ServiceManager", classLoader)
        if (smClass != null) {
            // 直接尝试 getService("wifi")
            try {
                val service = XposedHelpers.callStaticMethod(smClass, "getService", "wifi")
                if (service != null && !service.javaClass.name.contains("BinderProxy")) {
                    HookStatus.classFound(SystemComponent.WIFI_SERVICE, service.javaClass, "ServiceManager.getService")
                    installWifiHooks(service.javaClass, service.javaClass.classLoader ?: classLoader)
                    isWifiServiceHooked = true
                    logWifi("[SysWifi] Hooked WifiServiceImpl directly from ServiceManager.getService(wifi): ${service.javaClass.name}")
                    return
                }
            } catch (t: Throwable) { HookLog.swallowed("SystemWifiServiceHooker.kt:156", t) }

            XposedHelpers.hookAllMethods(smClass, "addService") { chain, _ ->
                val name = chain.args.firstOrNull { it is String } as? String
                if ((name == "wifi" || name == "wifiscanner") && chain.args.size > 1) {
                    val service = chain.args[1]
                    if (service != null && !service.javaClass.name.contains("BinderProxy")) {
                        logWifi("[SysWifi] Captured $name from ServiceManager.addService: ${service.javaClass.name}")
                        HookStatus.classFound(
                            if (name == "wifi") SystemComponent.WIFI_SERVICE else SystemComponent.WIFI_SCANNER_SERVICE,
                            service.javaClass, "ServiceManager.addService"
                        )
                        installWifiHooks(service.javaClass, service.javaClass.classLoader ?: classLoader)
                        isWifiServiceHooked = true
                    }
                }
                return@hookAllMethods chain.proceed(chain.args.toTypedArray())
            }
        }
    } catch (t: Throwable) {
        logWifi("[SysWifi] Hook ServiceManager.addService for wifi failed: $t")
    }
}

internal fun LocationHooker.installWifiHooks(wifiServiceClass: Class<*>, classLoader: ClassLoader) {
    if (hookedCallbackClasses.putIfAbsent(wifiServiceClass, true) != null) {
        return
    }

    val realCapabilities = listOf(
        "[WPA2-PSK-CCMP][RSN-PSK-CCMP][ESS]",
        "[WPA2-PSK-CCMP+TKIP][RSN-PSK-CCMP+TKIP][ESS]",
        "[WPA2-PSK-CCMP][ESS][WPS]",
        "[WPA-PSK-TKIP+CCMP][WPA2-PSK-TKIP+CCMP][ESS]",
        "[RSN-PSK-CCMP][ESS]",
        "[WPA2-EAP-CCMP][RSN-EAP-CCMP][ESS]",
        "[ESS]",
        "[WPA2-PSK-CCMP][RSN-PSK-CCMP][ESS][WPS]",
        "[WPA2-SAE-CCMP][RSN-SAE-CCMP][ESS]",
        "[WPA2-PSK+SAE-CCMP][RSN-PSK+SAE-CCMP][ESS]"
    )

    // =========================================================================
    // 1. getScanResults：向目标应用派发伪造周边 Wi-Fi 列表
    // =========================================================================
    try {
        XposedHelpers.hookAllMethods(wifiServiceClass, "getScanResults") { chain, executable ->
            val config = readConfig() ?: return@hookAllMethods chain.proceed(chain.args.toTypedArray())
            if (!config.optBoolean(ConfigKeys.ACTIVE, false)) {
                return@hookAllMethods chain.proceed(chain.args.toTypedArray())
            }

            val explicitPkg = SystemHookUtils.extractPackageName(chain.args)
            val overrideUid = SystemHookUtils.extractCallerUid(chain.args)
            val isTarget = SystemHookUtils.isTargetCaller(chain.thisObject, explicitPkg, config, overrideUid)

            if (!isTarget) {
                return@hookAllMethods chain.proceed(chain.args.toTypedArray())
            }

            // mock_wifi 单独关闭时：目标应用仍处于全局/白名单模拟范围内，绝不能把真实周边 Wi-Fi
            // 透传给它（会暴露真实位置、与已伪造的 GPS 坐标产生矛盾导致环境不一致），但也不能像旧版本
            // 那样用坐标 Hash 兜底伪造一批假热点——用户关闭该开关就是不想让 Wi-Fi 子系统参与模拟，
            // 正确行为是让目标应用看到"周边无 Wi-Fi"（空列表），而不是真实数据或另一份假数据。
            val mockWifi = config.optBoolean(ConfigKeys.MOCK_WIFI, true)

            val fakeList = java.util.ArrayList<Any>()
            val wifiObj = config.optJSONObject(ConfigKeys.WIFI_JSON_2)

            try {
                val scanResultClass = XposedHelpers.findClass("android.net.wifi.ScanResult", classLoader)
                val baseTimestamp = android.os.SystemClock.elapsedRealtimeNanos()
                val rng = Random()

                fun addFakeScanResult(wifi: JSONObject, forceKeep: Boolean = false) {
                    val ssidVal = wifi.optString(ConfigKeys.SSID, "")
                    val bssidVal = wifi.optString(ConfigKeys.BSSID, "")
                    if (!forceKeep) {
                        // 真实扫描不会每次都看到同一份完整列表：按约 7 秒的
                        // 扫描桶稳定地“漏掉”少量 AP，下一次扫描又出现。
                        val bucket = System.currentTimeMillis() / 7000L
                        var h = bssidVal.hashCode().toLong() *
                            -7046029254386353131L + bucket
                        h = (h xor (h ushr 33)) * -4658895280553007687L
                        val u = (h xor (h ushr 31)) ushr 11
                        if (u % 100L < 7L) return
                    }
                    val fakeScanResult = XposedHelpers.newInstance(scanResultClass)
                    val finalSsid = if (ssidVal.isEmpty() || ssidVal == "<unknown ssid>") {
                        "WIFI_${bssidVal.takeLast(5).replace(":", "")}"
                    } else {
                        ssidVal
                    }
                    XposedHelpers.setObjectField(fakeScanResult, "SSID", finalSsid)
                    XposedHelpers.setObjectField(fakeScanResult, "BSSID", bssidVal)
                    // 每次 scan 加 2dB 左右抖动；路线环境重放负责随位置变化，
                    // 这里保证连续多次 getScanResults 不会出现完全相同的 RSSI。
                    val level = (wifi.optInt(ConfigKeys.LEVEL, -65) + rng.nextInt(5) - 2)
                        .coerceIn(-95, -25)
                    XposedHelpers.setIntField(fakeScanResult, "level", level)
                    XposedHelpers.setIntField(fakeScanResult, "frequency", wifi.optInt(ConfigKeys.FREQUENCY, 2412))
                    XposedHelpers.setObjectField(
                        fakeScanResult,
                        "capabilities",
                        wifi.optString(ConfigKeys.CAPABILITIES, realCapabilities[rng.nextInt(realCapabilities.size)])
                    )

                    // 适配 Android 10+ (API 29+): 设置 wifiSsid 对象，防止高德/微信等 SDK 读不到 SSID
                    try {
                        val wifiSsidClass = XposedHelpers.findClassIfExists("android.net.wifi.WifiSsid", classLoader)
                        if (wifiSsidClass != null) {
                            val wifiSsidObj = XposedHelpers.callStaticMethod(
                                wifiSsidClass,
                                "fromBytes",
                                finalSsid.toByteArray(Charsets.UTF_8)
                            )
                            if (wifiSsidObj != null) {
                                try { XposedHelpers.setObjectField(fakeScanResult, "wifiSsid", wifiSsidObj) } catch (t: Throwable) { HookLog.swallowed("SystemWifiServiceHooker.kt:273", t) }
                            }
                        }
                    } catch (t: Throwable) { HookLog.swallowed("SystemWifiServiceHooker.kt:276", t) }

                    // 适配 ColorOS / OxygenOS / HyperOS: 必须初始化 informationElements 和 radioChainInfos，
                    // 否则系统服务中的统计上报组件抛出 NPE
                    try {
                        val ieClass = XposedHelpers.findClassIfExists("android.net.wifi.ScanResult\$InformationElement", classLoader)
                        if (ieClass != null) {
                            val emptyIeArray = ReflectArray.newInstance(ieClass, 0)
                            XposedHelpers.setObjectField(fakeScanResult, "informationElements", emptyIeArray)
                        }
                    } catch (t: Throwable) { HookLog.swallowed("SystemWifiServiceHooker.kt:286", t) }

                    try {
                        val rciClass = XposedHelpers.findClassIfExists("android.net.wifi.ScanResult\$RadioChainInfo", classLoader)
                        if (rciClass != null) {
                            val emptyRciArray = ReflectArray.newInstance(rciClass, 0)
                            XposedHelpers.setObjectField(fakeScanResult, "radioChainInfos", emptyRciArray)
                        }
                    } catch (t: Throwable) { HookLog.swallowed("SystemWifiServiceHooker.kt:294", t) }

                    try {
                        // 扫描结果年龄 0–3 秒，模拟不同信道的扫描批次。
                        val offsetNanos = (rng.nextInt(3_000_000) * 1000L)
                        XposedHelpers.setLongField(fakeScanResult, "timestamp", (baseTimestamp - offsetNanos) / 1000)
                    } catch (t: Throwable) { HookLog.swallowed("SystemWifiServiceHooker.kt:300", t) }

                    fakeList.add(fakeScanResult)
                }

                if (mockWifi && wifiObj != null) {
                    val isConnected = wifiObj.optBoolean(ConfigKeys.IS_CONNECTED, false)
                    val connectedWifi = if (isConnected) wifiObj.optJSONObject(ConfigKeys.CONNECTED_WIFI) else null
                    if (connectedWifi != null) {
                        addFakeScanResult(connectedWifi, forceKeep = true)
                    }

                    val nearbyArray = wifiObj.optJSONArray(ConfigKeys.NEARBY_WIFI)
                    if (nearbyArray != null) {
                        for (i in 0 until nearbyArray.length()) {
                            val wifi = nearbyArray.getJSONObject(i)
                            addFakeScanResult(wifi)
                        }
                    }
                }

                // 若没有采集或设置 Wi-Fi 列表，按坐标 Hash 稳定生成 5 个虚拟热点（仅在开关开启时兜底）
                if (mockWifi && wifiObj == null && fakeList.isEmpty()) {
                    val lat = config.optDouble(ConfigKeys.LAT, 0.0)
                    val lng = config.optDouble(ConfigKeys.LNG, 0.0)
                    val seed = ((lat * 100000).toLong() xor (lng * 100000).toLong())
                    val random = Random(seed)
                    for (i in 0 until 5) {
                        val fakeWifi = JSONObject()
                        fakeWifi.put(ConfigKeys.SSID, "WIFI_${random.nextInt(9000) + 1000}")
                        val bssid = String.format(
                            "%02x:%02x:%02x:%02x:%02x:%02x",
                            random.nextInt(256), random.nextInt(256), random.nextInt(256),
                            random.nextInt(256), random.nextInt(256), random.nextInt(256)
                        )
                        fakeWifi.put(ConfigKeys.BSSID, bssid)
                        fakeWifi.put(ConfigKeys.LEVEL, -40 - random.nextInt(50))
                        fakeWifi.put(ConfigKeys.FREQUENCY, if (random.nextBoolean()) 2412 else 5180)
                        fakeWifi.put(ConfigKeys.CAPABILITIES, "[WPA2-PSK-CCMP][ESS]")
                        addFakeScanResult(fakeWifi, forceKeep = true)
                    }
                }

                logWifi("[SysWifi] Dispatched ${fakeList.size} fake scan results to ${explicitPkg ?: "caller"}")

                // 核心修复: Android 8~15 中 WifiServiceImpl.getScanResults 返回类型通常是 ParceledListSlice<ScanResult>
                // 在 APEX 模块中为 com.android.wifi.x.com.android.modules.utils.ParceledListSlice，必须用原方法 returnType 实例化
                val returnType = (executable as? java.lang.reflect.Method)?.returnType
                if (returnType != null && returnType.name.contains("ParceledListSlice")) {
                    try {
                        val slice = XposedHelpers.newInstance(returnType, fakeList)
                        if (slice != null && returnType.isInstance(slice)) {
                            return@hookAllMethods slice
                        }
                    } catch (t: Throwable) {
                        logWifi("[SysWifi] Instantiate returnType ParceledListSlice failed: $t")
                    }
                }

                val realResult = try { chain.proceed(chain.args.toTypedArray()) } catch (_: Throwable) { null }
                if (realResult != null && realResult.javaClass.name.contains("ParceledListSlice")) {
                    try {
                        val slice = XposedHelpers.newInstance(realResult.javaClass, fakeList)
                        if (slice != null && (returnType == null || returnType.isInstance(slice))) {
                            return@hookAllMethods slice
                        }
                    } catch (t: Throwable) {
                        logWifi("[SysWifi] Instantiate realResult ParceledListSlice failed: $t")
                    }
                }

                val sliceClass = XposedHelpers.findClassIfExists("android.content.pm.ParceledListSlice", classLoader)
                    ?: XposedHelpers.findClassIfExists("android.content.pm.ParceledListSlice", scanResultClass.classLoader)
                if (sliceClass != null && (returnType == null || returnType.isAssignableFrom(sliceClass))) {
                    try {
                        val slice = XposedHelpers.newInstance(sliceClass, fakeList)
                        if (slice != null) return@hookAllMethods slice
                    } catch (t: Throwable) { HookLog.swallowed("SystemWifiServiceHooker.kt:377", t) }
                }

                if (returnType == null || returnType.isAssignableFrom(java.util.ArrayList::class.java) || returnType.name.contains("List")) {
                    return@hookAllMethods fakeList
                }
                return@hookAllMethods realResult
            } catch (e: Throwable) {
                logWifi("[SysWifi] build fake scan results failed: $e")
                return@hookAllMethods chain.proceed(chain.args.toTypedArray())
            }
        }
        logWifi("[SysWifi] WifiServiceImpl.getScanResults hooked")
    } catch (e: Throwable) {
        logWifi("[SysWifi] hook getScanResults failed: $e")
    }

    // =========================================================================
    // 2. getConnectionInfo：向目标应用派发伪造已连接 Wi-Fi 属性
    // =========================================================================
    try {
        XposedHelpers.hookAllMethods(wifiServiceClass, "getConnectionInfo") { chain, _ ->
            val config = readConfig() ?: return@hookAllMethods chain.proceed(chain.args.toTypedArray())
            if (!config.optBoolean(ConfigKeys.ACTIVE, false)) {
                return@hookAllMethods chain.proceed(chain.args.toTypedArray())
            }

            val explicitPkg = SystemHookUtils.extractPackageName(chain.args)
            val overrideUid = SystemHookUtils.extractCallerUid(chain.args)
            val isTarget = SystemHookUtils.isTargetCaller(chain.thisObject, explicitPkg, config, overrideUid)

            if (!isTarget) {
                return@hookAllMethods chain.proceed(chain.args.toTypedArray())
            }

            val mockWifi = config.optBoolean(ConfigKeys.MOCK_WIFI, true)

            val wifiObj = config.optJSONObject(ConfigKeys.WIFI_JSON_2)
            val isConnected = mockWifi && (wifiObj?.optBoolean(ConfigKeys.IS_CONNECTED, false) ?: false)
            val connectedWifi = if (isConnected) wifiObj!!.optJSONObject(ConfigKeys.CONNECTED_WIFI) else null

            val ssidVal: String
            val bssidVal: String
            val freqVal: Int
            val macAddressVal: String
            val linkSpeedVal: Int
            val levelVal: Int
            val networkIdVal: Int

            if (!mockWifi) {
                // 开关关闭：既不能泄露真实 BSSID/SSID，也不伪造一份假连接——
                // 直接汇报"未连接任何 Wi-Fi"，与 mock_wifi 关闭时 getScanResults 返回空列表的语义一致。
                ssidVal = "<unknown ssid>"
                bssidVal = "02:00:00:00:00:00"
                freqVal = 0
                macAddressVal = "02:00:00:00:00:00"
                linkSpeedVal = -1
                levelVal = -127
                networkIdVal = -1
            } else if (isConnected && connectedWifi != null) {
                val rawSsid = connectedWifi.optString(ConfigKeys.SSID, "")
                ssidVal = if (rawSsid.isEmpty() || rawSsid == "<unknown ssid>") "HOME_WIFI" else rawSsid
                bssidVal = connectedWifi.optString(ConfigKeys.BSSID, "02:00:00:00:00:00")
                freqVal = connectedWifi.optInt(ConfigKeys.FREQUENCY, 2412)
                macAddressVal = connectedWifi.optString(ConfigKeys.MAC_ADDRESS, bssidVal)
                linkSpeedVal = connectedWifi.optInt(ConfigKeys.LINK_SPEED, 65)
                levelVal = connectedWifi.optInt(ConfigKeys.LEVEL, -65)
                networkIdVal = connectedWifi.optInt(ConfigKeys.NETWORK_ID, 1)
            } else {
                // 目标应用处于连入状态但用户未配置虚拟连入热点：坚决不能将用户家里的真实 BSSID 泄露给目标应用！
                val lat = config.optDouble(ConfigKeys.LAT, 0.0)
                val lng = config.optDouble(ConfigKeys.LNG, 0.0)
                val seed = ((lat * 100000).toLong() xor (lng * 100000).toLong())
                val random = Random(seed)
                bssidVal = String.format(
                    "02:%02x:%02x:%02x:%02x:%02x",
                    random.nextInt(256), random.nextInt(256),
                    random.nextInt(256), random.nextInt(256), random.nextInt(256)
                )
                ssidVal = "WIFI_${random.nextInt(9000) + 1000}"
                freqVal = if (random.nextBoolean()) 2412 else 5180
                macAddressVal = bssidVal
                linkSpeedVal = 144
                levelVal = -50 - random.nextInt(20)
                networkIdVal = 1
            }

            // 优先尝试 Android 12+ (API 30+) 的 WifiInfo.Builder 构建完全干净的隔离对象
            try {
                val builderClass = XposedHelpers.findClassIfExists("android.net.wifi.WifiInfo\$Builder", classLoader)
                if (builderClass != null) {
                    val builder = XposedHelpers.newInstance(builderClass)
                    XposedHelpers.callMethod(builder, "setSsid", ssidVal.toByteArray(Charsets.UTF_8))
                    XposedHelpers.callMethod(builder, "setBssid", bssidVal)
                    XposedHelpers.callMethod(builder, "setRssi", levelVal)
                    XposedHelpers.callMethod(builder, "setNetworkId", networkIdVal)
                    val cleanWifiInfo = XposedHelpers.callMethod(builder, "build")
                    if (cleanWifiInfo != null) {
                        try { XposedHelpers.setObjectField(cleanWifiInfo, "mMacAddress", macAddressVal) } catch (t: Throwable) { HookLog.swallowed("SystemWifiServiceHooker.kt:475", t) }
                        try { XposedHelpers.setIntField(cleanWifiInfo, "mLinkSpeed", linkSpeedVal) } catch (t: Throwable) { HookLog.swallowed("SystemWifiServiceHooker.kt:476", t) }
                        try { XposedHelpers.setIntField(cleanWifiInfo, "mFrequency", freqVal) } catch (t: Throwable) { HookLog.swallowed("SystemWifiServiceHooker.kt:477", t) }
                        logWifi("[SysWifi] Dispatched clean synthetic WifiInfo for ${explicitPkg ?: "caller"} (SSID=$ssidVal, BSSID=$bssidVal)")
                        return@hookAllMethods cleanWifiInfo
                    }
                }
            } catch (t: Throwable) { HookLog.swallowed("SystemWifiServiceHooker.kt:482", t) }

            // 降级使用原有对象就地修改
            val currentResult = chain.proceed(chain.args.toTypedArray())
            if (currentResult != null) {
                try {
                    // Android 10+ (API 29+) 核心：通过 WifiSsid.fromBytes 改写 mWifiSsid，杜绝真实 SSID 泄露！
                    try {
                        val wifiSsidClass = XposedHelpers.findClassIfExists("android.net.wifi.WifiSsid", classLoader)
                        if (wifiSsidClass != null) {
                            val wifiSsidObj = XposedHelpers.callStaticMethod(
                                wifiSsidClass,
                                "fromBytes",
                                ssidVal.toByteArray(Charsets.UTF_8)
                            )
                            if (wifiSsidObj != null) {
                                try { XposedHelpers.setObjectField(currentResult, "mWifiSsid", wifiSsidObj) } catch (t: Throwable) { HookLog.swallowed("SystemWifiServiceHooker.kt:498", t) }
                                try { XposedHelpers.callMethod(currentResult, "setSSID", wifiSsidObj) } catch (t: Throwable) { HookLog.swallowed("SystemWifiServiceHooker.kt:499", t) }
                            }
                        }
                    } catch (t: Throwable) { HookLog.swallowed("SystemWifiServiceHooker.kt:502", t) }

                    try { XposedHelpers.setObjectField(currentResult, "mSSID", "\"$ssidVal\"") } catch (t: Throwable) { HookLog.swallowed("SystemWifiServiceHooker.kt:504", t) }
                    try { XposedHelpers.setObjectField(currentResult, "mBSSID", bssidVal) } catch (t: Throwable) { HookLog.swallowed("SystemWifiServiceHooker.kt:505", t) }
                    try { XposedHelpers.callMethod(currentResult, "setBSSID", bssidVal) } catch (t: Throwable) { HookLog.swallowed("SystemWifiServiceHooker.kt:506", t) }
                    try { XposedHelpers.setObjectField(currentResult, "mMacAddress", macAddressVal) } catch (t: Throwable) { HookLog.swallowed("SystemWifiServiceHooker.kt:507", t) }
                    try { XposedHelpers.setIntField(currentResult, "mRssi", levelVal) } catch (t: Throwable) { HookLog.swallowed("SystemWifiServiceHooker.kt:508", t) }
                    try { XposedHelpers.setIntField(currentResult, "mLinkSpeed", linkSpeedVal) } catch (t: Throwable) { HookLog.swallowed("SystemWifiServiceHooker.kt:509", t) }
                    try { XposedHelpers.setIntField(currentResult, "mFrequency", freqVal) } catch (t: Throwable) { HookLog.swallowed("SystemWifiServiceHooker.kt:510", t) }
                    try { XposedHelpers.setIntField(currentResult, "mNetworkId", networkIdVal) } catch (t: Throwable) { HookLog.swallowed("SystemWifiServiceHooker.kt:511", t) }

                    logWifi("[SysWifi] Injected fake connection info for ${explicitPkg ?: "caller"} (SSID=$ssidVal, BSSID=$bssidVal, maskedRealBssid=true)")
                } catch (e: Throwable) {
                    logWifi("[SysWifi] modify WifiInfo in-place failed: $e")
                }
            }
            return@hookAllMethods currentResult
        }
        logWifi("[SysWifi] WifiServiceImpl.getConnectionInfo hooked")
    } catch (e: Throwable) {
        logWifi("[SysWifi] hook getConnectionInfo failed: $e")
    }

    // =========================================================================
    // 2.1 WifiScanningServiceImpl：拦截通过 WifiScanner.getSingleScanResults 获取热点的系统定位/第三方 SDK
    // =========================================================================
    try {
        // 扫描服务与 WifiServiceImpl 在同一个 APEX 里，优先用它的 ClassLoader
        val scannerClass = SystemClassLocator.locate(
            SystemComponent.WIFI_SCANNER_SERVICE, wifiServiceClass.classLoader ?: classLoader,
            extraLoaders = listOf(classLoader)
        )
        if (scannerClass != null && hookedCallbackClasses.putIfAbsent(scannerClass, true) == null) {
            val singleScanMethods = arrayOf("getSingleScanResults")
            for (mName in singleScanMethods) {
                XposedHelpers.hookAllMethods(scannerClass, mName) { chain, _ ->
                    val config = readConfig() ?: return@hookAllMethods chain.proceed(chain.args.toTypedArray())
                    if (!config.optBoolean(ConfigKeys.ACTIVE, false)) {
                        return@hookAllMethods chain.proceed(chain.args.toTypedArray())
                    }
                    val explicitPkg = SystemHookUtils.extractPackageName(chain.args)
                    val overrideUid = SystemHookUtils.extractCallerUid(chain.args)
                    val isTarget = SystemHookUtils.isTargetCaller(chain.thisObject, explicitPkg, config, overrideUid)
                    if (!isTarget) {
                        return@hookAllMethods chain.proceed(chain.args.toTypedArray())
                    }
                    val mockWifi = config.optBoolean(ConfigKeys.MOCK_WIFI, true)
                    val fakeList = java.util.ArrayList<Any>()
                    if (!mockWifi) {
                        // 与 getScanResults 一致：开关关闭时返回空列表，既不泄露真实热点也不伪造假数据
                        logWifi("[SysWifi] WifiScanningServiceImpl.getSingleScanResults suppressed (mock_wifi off) for ${explicitPkg ?: "caller"}")
                        return@hookAllMethods fakeList
                    }
                    val scanResultClass = XposedHelpers.findClass("android.net.wifi.ScanResult", classLoader)
                    // ScanResult.timestamp 的单位是“自开机起的微秒”，不是纳秒。
                    // getScanResults 路径已经 /1000，这里也必须保持一致，否则
                    // App 会看到约 1000 倍未来的时间戳并判定热点已过期。
                    val baseTimestampMicros = android.os.SystemClock.elapsedRealtimeNanos() / 1000
                    val rng = Random()
                    val lat = config.optDouble(ConfigKeys.LAT, 0.0)
                    val lng = config.optDouble(ConfigKeys.LNG, 0.0)
                    val seed = ((lat * 100000).toLong() xor (lng * 100000).toLong())
                    val random = Random(seed)
                    val wifiObj = config.optJSONObject(ConfigKeys.WIFI_JSON_2)
                    val configured = wifiObj?.optJSONArray(ConfigKeys.NEARBY_WIFI)
                    if (configured != null && configured.length() > 0) {
                        for (i in 0 until configured.length()) {
                            val wifi = configured.optJSONObject(i) ?: continue
                            val ssid = wifi.optString(ConfigKeys.SSID, "")
                            val bssid = wifi.optString(ConfigKeys.BSSID, "")
                            if (bssid.isEmpty()) continue
                            val fakeScanResult = XposedHelpers.newInstance(scanResultClass)
                            XposedHelpers.setObjectField(
                                fakeScanResult, "SSID",
                                if (ssid.isEmpty() || ssid == "<unknown ssid>") "WIFI_${bssid.takeLast(5).replace(":", "")}" else ssid
                            )
                            XposedHelpers.setObjectField(fakeScanResult, "BSSID", bssid)
                            XposedHelpers.setObjectField(
                                fakeScanResult, "capabilities",
                                wifi.optString(ConfigKeys.CAPABILITIES, "[WPA2-PSK-CCMP][ESS]")
                            )
                            XposedHelpers.setIntField(fakeScanResult, "level", wifi.optInt(ConfigKeys.LEVEL, -65))
                            XposedHelpers.setIntField(fakeScanResult, "frequency", wifi.optInt(ConfigKeys.FREQUENCY, 2412))
                            XposedHelpers.setLongField(
                                fakeScanResult, "timestamp",
                                baseTimestampMicros - rng.nextInt(3_000_000)
                            )
                            fakeList.add(fakeScanResult)
                        }
                    } else {
                        for (i in 0 until 5) {
                            val fakeScanResult = XposedHelpers.newInstance(scanResultClass)
                            XposedHelpers.setObjectField(fakeScanResult, "SSID", "WIFI_${random.nextInt(9000) + 1000}")
                            val bssid = String.format(
                                java.util.Locale.US,
                                "%02x:%02x:%02x:%02x:%02x:%02x",
                                random.nextInt(256), random.nextInt(256), random.nextInt(256),
                                random.nextInt(256), random.nextInt(256), random.nextInt(256)
                            )
                            XposedHelpers.setObjectField(fakeScanResult, "BSSID", bssid)
                            XposedHelpers.setObjectField(fakeScanResult, "capabilities", "[WPA2-PSK-CCMP][ESS]")
                            XposedHelpers.setIntField(fakeScanResult, "level", -40 - random.nextInt(50))
                            XposedHelpers.setIntField(fakeScanResult, "frequency", if (random.nextBoolean()) 2412 else 5180)
                            XposedHelpers.setLongField(
                                fakeScanResult, "timestamp",
                                baseTimestampMicros - rng.nextInt(3_000_000)
                            )
                            fakeList.add(fakeScanResult)
                        }
                    }
                    logWifi("[SysWifi] WifiScanningServiceImpl.getSingleScanResults intercepted for ${explicitPkg ?: "caller"} count=${fakeList.size}")
                    return@hookAllMethods fakeList
                }
            }
            logWifi("[SysWifi] WifiScanningServiceImpl.getSingleScanResults hooked")
        }
    } catch (t: Throwable) {
        logWifi("[SysWifi] hook WifiScanningServiceImpl failed: $t")
    }
}

// =========================================================================
// 3. ConnectivityService：拦截现代应用通过 ConnectivityManager.getNetworkCapabilities 读取真实 Wi-Fi BSSID
// =========================================================================

@Volatile
internal var isConnectivityServiceHooked = false

private fun findConnectivityServiceClass(classLoader: ClassLoader): Class<*>? =
    // Android 12+ 的 ConnectivityService 在 tethering APEX 里
    SystemClassLocator.locate(
        SystemComponent.CONNECTIVITY_SERVICE, classLoader,
        threadKeywords = listOf("Connect", "Tether", "Net"),
        serviceNames = listOf("connectivity"),
        deepScan = true
    )

internal fun LocationHooker.hookSystemConnectivityService(classLoader: ClassLoader) {
    if (isConnectivityServiceHooked) return

    val connClass = findConnectivityServiceClass(classLoader)
    if (connClass != null) {
        installConnectivityHooks(connClass, connClass.classLoader ?: classLoader)
        isConnectivityServiceHooked = true
        logWifi("[SysWifi] Successfully hooked ConnectivityService on ${connClass.name}")
    }

    try {
        val smClass = XposedHelpers.findClassIfExists("android.os.ServiceManager", classLoader)
        if (smClass != null) {
            XposedHelpers.hookAllMethods(smClass, "addService") { chain, _ ->
                val name = chain.args.firstOrNull { it is String } as? String
                if (name == "connectivity" && chain.args.size > 1) {
                    val service = chain.args[1]
                    if (service != null && !service.javaClass.name.contains("BinderProxy")) {
                        HookStatus.classFound(SystemComponent.CONNECTIVITY_SERVICE, service.javaClass, "ServiceManager.addService")
                        installConnectivityHooks(service.javaClass, service.javaClass.classLoader ?: classLoader)
                        isConnectivityServiceHooked = true
                        logWifi("[SysWifi] Captured $name from ServiceManager.addService: ${service.javaClass.name}")
                    }
                }
                return@hookAllMethods chain.proceed(chain.args.toTypedArray())
            }
        }
    } catch (t: Throwable) {
        logWifi("[SysWifi] Hook ServiceManager for connectivity failed: $t")
    }
}

internal fun LocationHooker.installConnectivityHooks(connClazz: Class<*>, classLoader: ClassLoader) {
    if (hookedCallbackClasses.putIfAbsent(connClazz, true) != null) {
        return
    }
    isConnectivityServiceHooked = true

    val targetMethods = arrayOf("getNetworkCapabilities", "getDefaultNetworkCapabilitiesForUser", "getRedactedNetworkCapabilitiesForPackage")
    for (methodName in targetMethods) {
        try {
            XposedHelpers.hookAllMethods(connClazz, methodName) { chain, _ ->
                val currentResult = chain.proceed(chain.args.toTypedArray()) ?: return@hookAllMethods null
                val config = readConfig() ?: return@hookAllMethods currentResult
                if (!config.optBoolean(ConfigKeys.ACTIVE, false)) return@hookAllMethods currentResult

                val explicitPkg = SystemHookUtils.extractPackageName(chain.args)
                val overrideUid = SystemHookUtils.extractCallerUid(chain.args)
                val isTarget = SystemHookUtils.isTargetCaller(chain.thisObject, explicitPkg, config, overrideUid)
                if (!isTarget) return@hookAllMethods currentResult

                // 注意：这里不受 mock_wifi 开关控制——sanitizeNetworkCapabilities 只是清除真实
                // BSSID/SSID（关闭时退化为按坐标生成的中性标识），不是"伪造一整套假热点列表"，
                // 所以不属于开关想要关闭的范畴；真正受开关控制的是 getScanResults/getConnectionInfo
                // 里"是否展示一份完整的假 Wi-Fi 环境"。这里永远执行，避免真实 BSSID 通过
                // NetworkCapabilities 泄露给目标应用，与已伪造的 GPS 坐标产生矛盾导致环境不一致。

                try {
                    sanitizeNetworkCapabilities(currentResult, config, classLoader, explicitPkg)
                } catch (e: Throwable) {
                    logWifi("[SysWifi] sanitizeNetworkCapabilities failed: $e")
                }
                return@hookAllMethods currentResult
            }
            logWifi("[SysWifi] ConnectivityService.$methodName hooked on ${connClazz.name}")
        } catch (e: Throwable) {
            logWifi("[SysWifi] hook ConnectivityService.$methodName failed: $e")
        }
    }
}

private fun LocationHooker.sanitizeNetworkCapabilities(
    resultObj: Any,
    config: JSONObject,
    classLoader: ClassLoader,
    explicitPkg: String?
) {
    if (resultObj is Array<*>) {
        for (item in resultObj) {
            if (item != null) sanitizeSingleNetworkCapabilities(item, config, classLoader, explicitPkg)
        }
    } else {
        sanitizeSingleNetworkCapabilities(resultObj, config, classLoader, explicitPkg)
    }
}

private fun LocationHooker.sanitizeSingleNetworkCapabilities(
    nc: Any,
    config: JSONObject,
    classLoader: ClassLoader,
    explicitPkg: String?
) {
    val transportInfo = try {
        XposedHelpers.getObjectField(nc, "mTransportInfo")
    } catch (_: Throwable) {
        try { XposedHelpers.callMethod(nc, "getTransportInfo") } catch (_: Throwable) { null }
    } ?: return

    val isWifiInfo = transportInfo.javaClass.name.contains("WifiInfo") ||
            LocationHooker.hasTypeByName(transportInfo.javaClass, "android.net.wifi.WifiInfo")

    if (!isWifiInfo) return

    val wifiObj = config.optJSONObject(ConfigKeys.WIFI_JSON_2)
    val isConnected = wifiObj?.optBoolean(ConfigKeys.IS_CONNECTED, false) ?: false
    val connectedWifi = if (isConnected) wifiObj!!.optJSONObject(ConfigKeys.CONNECTED_WIFI) else null

    val ssidVal: String
    val bssidVal: String
    val freqVal: Int
    val macAddressVal: String
    val linkSpeedVal: Int
    val levelVal: Int
    val networkIdVal: Int

    if (isConnected && connectedWifi != null) {
        val rawSsid = connectedWifi.optString(ConfigKeys.SSID, "")
        ssidVal = if (rawSsid.isEmpty() || rawSsid == "<unknown ssid>") "HOME_WIFI" else rawSsid
        bssidVal = connectedWifi.optString(ConfigKeys.BSSID, "02:00:00:00:00:00")
        freqVal = connectedWifi.optInt(ConfigKeys.FREQUENCY, 2412)
        macAddressVal = connectedWifi.optString(ConfigKeys.MAC_ADDRESS, bssidVal)
        linkSpeedVal = connectedWifi.optInt(ConfigKeys.LINK_SPEED, 65)
        levelVal = connectedWifi.optInt(ConfigKeys.LEVEL, -65)
        networkIdVal = connectedWifi.optInt(ConfigKeys.NETWORK_ID, 1)
    } else {
        val lat = config.optDouble(ConfigKeys.LAT, 0.0)
        val lng = config.optDouble(ConfigKeys.LNG, 0.0)
        val seed = ((lat * 100000).toLong() xor (lng * 100000).toLong())
        val random = Random(seed)
        bssidVal = String.format(
            "02:%02x:%02x:%02x:%02x:%02x",
            random.nextInt(256), random.nextInt(256),
            random.nextInt(256), random.nextInt(256), random.nextInt(256)
        )
        ssidVal = "WIFI_${random.nextInt(9000) + 1000}"
        freqVal = if (random.nextBoolean()) 2412 else 5180
        macAddressVal = bssidVal
        linkSpeedVal = 144
        levelVal = -50 - random.nextInt(20)
        networkIdVal = 1
    }

    var cleanWifiInfo: Any? = null
    try {
        val builderClass = XposedHelpers.findClassIfExists("android.net.wifi.WifiInfo\$Builder", classLoader)
        if (builderClass != null) {
            val builder = XposedHelpers.newInstance(builderClass)
            XposedHelpers.callMethod(builder, "setSsid", ssidVal.toByteArray(Charsets.UTF_8))
            XposedHelpers.callMethod(builder, "setBssid", bssidVal)
            XposedHelpers.callMethod(builder, "setRssi", levelVal)
            XposedHelpers.callMethod(builder, "setNetworkId", networkIdVal)
            cleanWifiInfo = XposedHelpers.callMethod(builder, "build")
            if (cleanWifiInfo != null) {
                try { XposedHelpers.setObjectField(cleanWifiInfo, "mMacAddress", macAddressVal) } catch (t: Throwable) { HookLog.swallowed("SystemWifiServiceHooker.kt:757", t) }
                try { XposedHelpers.setIntField(cleanWifiInfo, "mLinkSpeed", linkSpeedVal) } catch (t: Throwable) { HookLog.swallowed("SystemWifiServiceHooker.kt:758", t) }
                try { XposedHelpers.setIntField(cleanWifiInfo, "mFrequency", freqVal) } catch (t: Throwable) { HookLog.swallowed("SystemWifiServiceHooker.kt:759", t) }
            }
        }
    } catch (t: Throwable) { HookLog.swallowed("SystemWifiServiceHooker.kt:762", t) }

    val targetWifiInfo = if (cleanWifiInfo != null) {
        cleanWifiInfo
    } else {
        val copy = try {
            XposedHelpers.newInstance(transportInfo.javaClass, transportInfo)
        } catch (_: Throwable) {
            transportInfo
        }
        try {
            val wifiSsidClass = XposedHelpers.findClassIfExists("android.net.wifi.WifiSsid", classLoader)
            if (wifiSsidClass != null) {
                val wifiSsidObj = XposedHelpers.callStaticMethod(
                    wifiSsidClass,
                    "fromBytes",
                    ssidVal.toByteArray(Charsets.UTF_8)
                )
                if (wifiSsidObj != null) {
                    try { XposedHelpers.setObjectField(copy, "mWifiSsid", wifiSsidObj) } catch (t: Throwable) { HookLog.swallowed("SystemWifiServiceHooker.kt:781", t) }
                    try { XposedHelpers.callMethod(copy, "setSSID", wifiSsidObj) } catch (t: Throwable) { HookLog.swallowed("SystemWifiServiceHooker.kt:782", t) }
                }
            }
        } catch (t: Throwable) { HookLog.swallowed("SystemWifiServiceHooker.kt:785", t) }

        try { XposedHelpers.setObjectField(copy, "mSSID", "\"$ssidVal\"") } catch (t: Throwable) { HookLog.swallowed("SystemWifiServiceHooker.kt:787", t) }
        try { XposedHelpers.setObjectField(copy, "mBSSID", bssidVal) } catch (t: Throwable) { HookLog.swallowed("SystemWifiServiceHooker.kt:788", t) }
        try { XposedHelpers.callMethod(copy, "setBSSID", bssidVal) } catch (t: Throwable) { HookLog.swallowed("SystemWifiServiceHooker.kt:789", t) }
        try { XposedHelpers.setObjectField(copy, "mMacAddress", macAddressVal) } catch (t: Throwable) { HookLog.swallowed("SystemWifiServiceHooker.kt:790", t) }
        try { XposedHelpers.setIntField(copy, "mRssi", levelVal) } catch (t: Throwable) { HookLog.swallowed("SystemWifiServiceHooker.kt:791", t) }
        try { XposedHelpers.setIntField(copy, "mLinkSpeed", linkSpeedVal) } catch (t: Throwable) { HookLog.swallowed("SystemWifiServiceHooker.kt:792", t) }
        try { XposedHelpers.setIntField(copy, "mFrequency", freqVal) } catch (t: Throwable) { HookLog.swallowed("SystemWifiServiceHooker.kt:793", t) }
        try { XposedHelpers.setIntField(copy, "mNetworkId", networkIdVal) } catch (t: Throwable) { HookLog.swallowed("SystemWifiServiceHooker.kt:794", t) }
        copy
    }

    try {
        XposedHelpers.setObjectField(nc, "mTransportInfo", targetWifiInfo)
        logWifi("[SysWifi] Sanitized ConnectivityService NetworkCapabilities.mTransportInfo for ${explicitPkg ?: "caller"} (SSID=$ssidVal, BSSID=$bssidVal)")
    } catch (e: Throwable) {
        logWifi("[SysWifi] Set mTransportInfo on NetworkCapabilities failed: $e")
    }
}
