@file:Suppress(
    "UNUSED_PARAMETER",
    "UNUSED_VARIABLE",
    "UNNECESSARY_NOT_NULL_ASSERTION",
    "DEPRECATION",
    "NAME_SHADOWING",
    "FunctionName",
    "PrivatePropertyName",
    "SpellCheckingInspection",
    "RedundantUnitReturnType",
    "RemoveRedundantQualifierName",
    "OPT_IN_USAGE",
    "unused",
    "UnusedImport"
)

package com.vincenthzr.locationspoofer.xposed.utils

import com.vincenthzr.locationspoofer.utils.ConfigKeys

import com.vincenthzr.locationspoofer.utils.CoordinateSystem
import com.vincenthzr.locationspoofer.utils.CoordinateUtils
import com.vincenthzr.locationspoofer.utils.GnssRealism
import com.vincenthzr.locationspoofer.xposed.LocationHooker
import org.json.JSONObject
import kotlin.math.*

/**
 * 坐标系转换工具类 (Coordinate Converter)
 * 
 * 上下文:
 * - WGS-84: 国际标准 GPS 坐标。
 * - GCJ-02 (火星坐标系): 中国国家测绘局制定的强制加密坐标，中国大陆的所有地图(高德、腾讯)均使用此坐标。
 * - BD-09: 百度在 GCJ-02 的基础上再次加密的坐标系。
 * 
 * 作用:
 * 提供各个坐标系之间的精确数学转换。
 */

// 实际数学实现统一收敛到 com.vincenthzr.locationspoofer.utils.CoordinateUtils（唯一 source of truth），
// 这里保留 LocationHooker 扩展函数签名只是为了不改动 Hook 层现有的调用写法。
internal fun LocationHooker.wgs84ToGcj02(wgsLat: Double, wgsLng: Double): Pair<Double, Double> {
    val r = CoordinateUtils.wgs84ToGcj02(wgsLat, wgsLng)
    return Pair(r.lat, r.lng)
}

/**
 * GCJ-02 转 WGS-84（采用高精度反向迭代逼近算法，误差小于 0.5 毫米）
 */
internal fun LocationHooker.gcj02ToWgs84(gcjLat: Double, gcjLng: Double): Pair<Double, Double> {
    val r = CoordinateUtils.gcj02ToWgs84(gcjLat, gcjLng)
    return Pair(r.lat, r.lng)
}

// GCJ-02 转 BD-09 转换(百度坐标系)
internal fun LocationHooker.gcj02ToBd09(gcjLat: Double, gcjLng: Double): Pair<Double, Double> {
    val r = CoordinateUtils.gcj02ToBd09(gcjLat, gcjLng)
    return Pair(r.lat, r.lng)
}

internal fun LocationHooker.bd09ToGcj02(bdLat: Double, bdLng: Double): Pair<Double, Double> {
    val r = CoordinateUtils.bd09ToGcj02(bdLat, bdLng)
    return Pair(r.lat, r.lng)
}

/**
 * BD09ll (经纬度) 转 BD09mc (百度墨卡托米制平面坐标)
 * 百度地图引擎在进行底层瓦片渲染与路径规划时，常使用墨卡托投影米制单位。
 */
fun bd09llToBd09mc(bdLat: Double, bdLng: Double): Pair<Double, Double> {
    val x = bdLng * 20037508.342789244 / 180.0
    val latClamped = bdLat.coerceIn(-85.0511287798, 85.0511287798)
    var y = kotlin.math.ln(kotlin.math.tan((90.0 + latClamped) * Math.PI / 360.0)) / (Math.PI / 180.0)
    y = y * 20037508.342789244 / 180.0
    return Pair(y, x) // Pair(mcLat/Y, mcLng/X)
}

/**
 * 根据接口类型获取目标坐标。
 *
 * Hook 点在 system_server，不存在“按目标应用配置”，只按调用方传入的
 * [defaultSystem] 自动判断：标准 Location/NMEA 用 WGS-84，高德/腾讯用 GCJ-02，百度用 BD-09。
 *
 * @param rawGcjLat 基础 GCJ-02 纬度
 * @param rawGcjLng 基础 GCJ-02 经度
 * @param config 全局配置 JSON
 * @param defaultSystem 接口默认坐标系
 */
internal fun LocationHooker.getAppTargetCoordinate(
    rawGcjLat: Double,
    rawGcjLng: Double,
    config: JSONObject?,
    defaultSystem: String = "GCJ-02"
): Pair<Double, Double> {
    val targetSystem = CoordinateSystem.normalize(defaultSystem)
    return when (targetSystem) {
        CoordinateSystem.WGS84 -> gcj02ToWgs84(rawGcjLat, rawGcjLng)
        CoordinateSystem.BD09 -> gcj02ToBd09(rawGcjLat, rawGcjLng)
        CoordinateSystem.GCJ02 -> Pair(rawGcjLat, rawGcjLng)
    }
}

internal fun LocationHooker.getJitteredLocation(
    baseLat: Double,
    baseLng: Double
): Pair<Double, Double> {
    // 抖动已经统一由 RouteEngine 叠加到轨迹点上；这里保持原接口但不再二次
    // 随机，否则 Location/NMEA（走 getCurrentSpoofedMotion）与直接读取
    // RouteEngine 的消费者会拿到两套不同的坐标。
    return Pair(baseLat, baseLng)
}

internal fun LocationHooker.getJitteredAccuracy(): Float {
    val config = lastConfig
    if (config == null || !config.optBoolean(ConfigKeys.ACTIVE, false)) return 2.5f
    // 与 NMEA 的 HDOP/used 卫星共用同一条确定性质量曲线：正常户外约 1.2–4m，
    // 树荫/楼宇遮挡时会短时升到 6–18m，不再是永远 2.2m 的“完美信号”。
    return GnssRealism.accuracyMeters(
        config.optLong(ConfigKeys.START_TIMESTAMP, 0L),
        config.optInt(ConfigKeys.REALISM_LEVEL, 0),
        config.optInt(ConfigKeys.SATELLITE_COUNT, 20),
        System.currentTimeMillis(),
    ).toFloat()
}
