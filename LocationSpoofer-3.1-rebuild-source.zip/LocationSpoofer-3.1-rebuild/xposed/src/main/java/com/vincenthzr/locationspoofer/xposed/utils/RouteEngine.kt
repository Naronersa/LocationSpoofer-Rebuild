package com.vincenthzr.locationspoofer.xposed.utils

import com.vincenthzr.locationspoofer.utils.ConfigKeys

import com.vincenthzr.locationspoofer.utils.AltitudeModel
import com.vincenthzr.locationspoofer.utils.CoordinateUtils.LatLng
import com.vincenthzr.locationspoofer.utils.GeoMath
import com.vincenthzr.locationspoofer.utils.MotionRealism
import com.vincenthzr.locationspoofer.utils.RoutePath
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

data class SpoofedMotion(
    val lat: Double,
    val lng: Double,
    val bearing: Float,
    val speed: Float
)

/**
 * 根据配置和当前时间推导模拟位置：路线模式沿路线插值，摇杆模式按方向和速度推算，其余返回配置里的固定坐标。
 * 路线几何与 App 端共用 [RoutePath]，保证两端对同一时刻算出同一位置。
 */
object RouteEngine {

    /**
     * 摇杆模式：App 约每秒写一次"当前位置 + 方向 + 速度"，两次写入之间在这里按方向和速度往前推算，
     * 让被 Hook 的 App 看到连续移动而不是每秒跳一下。推算时长有上限，防止 App 被杀后位置一直漂走。
     */
    private const val JOYSTICK_MAX_EXTRAPOLATION_MS = 3000L

    // 配置 JSON 只在文件变化时才重新解析，同一个 JSONArray 实例对应同一条路线，按实例缓存即可
    @Volatile private var cachedRouteArray: JSONArray? = null
    @Volatile private var cachedPath: RoutePath? = null

    private fun routePath(routeArray: JSONArray): RoutePath {
        val cached = cachedPath
        if (routeArray === cachedRouteArray && cached != null) return cached
        val points = ArrayList<LatLng>(routeArray.length())
        for (i in 0 until routeArray.length()) {
            val obj = routeArray.optJSONObject(i) ?: continue
            points += LatLng(obj.optDouble(ConfigKeys.LAT, 0.0), obj.optDouble(ConfigKeys.LNG, 0.0))
        }
        return RoutePath(points).also {
            cachedPath = it
            cachedRouteArray = routeArray
        }
    }

    private fun extrapolateJoystick(config: JSONObject, now: Long, base: LatLng, bearing: Float): SpoofedMotion {
        val speed = config.optDouble(ConfigKeys.SPEED_M_S, 0.0)
        val startTime = config.optLong(ConfigKeys.START_TIMESTAMP, 0L)
        if (speed <= 0.0 || startTime <= 0L) {
            val p = applyJitter(base, config, now, 0.0, bearing)
            return SpoofedMotion(p.lat, p.lng, bearing, 0f)
        }

        val elapsedSec = (now - startTime).coerceIn(0L, JOYSTICK_MAX_EXTRAPOLATION_MS) / 1000.0
        val pos = GeoMath.destination(base, bearing.toDouble(), speed * elapsedSec)
        val p = applyJitter(pos, config, now, 0.0, bearing)
        return SpoofedMotion(p.lat, p.lng, bearing, speed.toFloat())
    }

    /**
     * 配置里显式写了 enable_jitter 才启用。App 生成的配置总会写这一项；
     * 旧配置 / JVM 测试里没有这个键时保持原来的纯几何结果。
     */
    private fun jitterEnabled(config: JSONObject): Boolean =
        config.has(ConfigKeys.ENABLE_JITTER) && config.optBoolean(ConfigKeys.ENABLE_JITTER, true)

    private fun jitterSeed(config: JSONObject): Long =
        config.optLong(ConfigKeys.ROUTE_LATERAL_SEED, 0L) xor
            config.optLong(ConfigKeys.START_TIMESTAMP, 0L).let {
                // 只让开始时间参与相位，不让毫秒级变化把噪声变成白噪声
                it / 1000L
            }

    /**
     * GPS 接收机的慢漂移，单位米（北, 东）。
     *
     * 这是唯一的定位抖动来源：Location、NMEA、路线 bearing、指南针都从
     * [applyJitter] 后的同一个轨迹点派生，避免“坐标在动、方向却是另一套噪声”的矛盾。
     * 幅度按真实度 0.09~0.14 米，慢波周期 4~12 秒；弯道额外叠加每 0.65 秒
     * 更新一次的 2~7 厘米横向修正，产生用户要求的“轻微突变”而不破坏轨迹自洽。
     */
    private fun jitterOffsetMeters(
        config: JSONObject,
        now: Long,
        curveFactor: Double,
        headingDeg: Float,
    ): DoubleArray {
        if (!jitterEnabled(config)) return doubleArrayOf(0.0, 0.0)
        val seed = jitterSeed(config)
        val realism = config.optInt(ConfigKeys.REALISM_LEVEL, 0).coerceIn(0, 3) / 3.0
        val amplitude = 0.09 + 0.045 * realism
        val t = now / 1000.0
        var north = amplitude * (
            0.65 * sin(2.0 * PI * t / 9.3 + phase(seed, 4L)) +
                0.35 * sin(2.0 * PI * t / 4.1 + phase(seed, 5L))
            )
        var east = amplitude * (
            0.65 * sin(2.0 * PI * t / 11.7 + phase(seed, 6L)) +
                0.35 * sin(2.0 * PI * t / 5.3 + phase(seed, 7L))
            )
        val cf = curveFactor.coerceIn(0.0, 1.0)
        if (cf > 0.02) {
            val step = curveStepMeters(seed, now, cf)
            // 横向（航向 +90°）：北向 -sin，东向 cos
            val rad = headingDeg.toDouble() * PI / 180.0
            north += -step * sin(rad)
            east += step * cos(rad)
        }
        return doubleArrayOf(north, east)
    }

    /** 把米制抖动叠加到经纬度；两次短距离 destination 比手写纬度缩放更稳。 */
    private fun applyJitter(
        point: LatLng,
        config: JSONObject,
        now: Long,
        curveFactor: Double,
        headingDeg: Float,
    ): LatLng {
        val offset = jitterOffsetMeters(config, now, curveFactor, headingDeg)
        if (offset[0] == 0.0 && offset[1] == 0.0) return point
        val north = GeoMath.destination(point, 0.0, offset[0])
        return GeoMath.destination(north, 90.0, offset[1])
    }

    private fun angleDelta(from: Float, to: Float): Float {
        var d = (to - from) % 360f
        if (d >= 180f) d -= 360f
        if (d < -180f) d += 360f
        return d
    }

    /** 当前附近的转向幅度（度）；直线接近 0，急弯接近 90+。 */
    private fun turnMagnitude(
        path: RoutePath,
        traveled: Double,
        stopAtDestination: Boolean,
    ): Double {
        val w = 4.0
        val before = path.positionAt(traveled - w, stopAtDestination).bearing
        val at = path.positionAt(traveled, stopAtDestination).bearing
        val after = path.positionAt(traveled + w, stopAtDestination).bearing
        return maxOf(
            kotlin.math.abs(angleDelta(before, at)),
            kotlin.math.abs(angleDelta(at, after)),
        ).toDouble()
    }

    /** 弯道每约 0.65 秒一次的横向修正（米），在 3 米窗口上约合 0.4~1.3°。 */
    private fun curveStepMeters(seed: Long, now: Long, curveFactor: Double): Double {
        var h = (now / 650L) * -7046029254386353131L + seed
        h = (h xor (h ushr 30)) * -4658895280553007687L
        h = (h xor (h ushr 27)) * -7723592293110705685L
        val u = ((h xor (h ushr 31)) ushr 11) / 9.007199254740992E15
        return (u * 2.0 - 1.0) * (0.02 + 0.05 * curveFactor.coerceIn(0.0, 1.0))
    }

    fun calculateCurrentPosition(config: JSONObject, now: Long = System.currentTimeMillis()): SpoofedMotion {
        val base = LatLng(config.optDouble(ConfigKeys.LAT, 0.0), config.optDouble(ConfigKeys.LNG, 0.0))
        val baseBearing = config.optDouble(ConfigKeys.SIM_BEARING, 0.0).toFloat()
        val routeArray = config.optJSONArray(ConfigKeys.ROUTE_POINTS)

        if (!config.optBoolean(ConfigKeys.IS_ROUTE_MODE, false) || routeArray == null || routeArray.length() < 2) {
            if (config.optString(ConfigKeys.SIM_MODE) == "JOYSTICK") {
                return extrapolateJoystick(config, now, base, baseBearing)
            }
            val point = applyJitter(base, config, now, 0.0, baseBearing)
            return SpoofedMotion(point.lat, point.lng, baseBearing, 0f)
        }

        val path = routePath(routeArray)
        if (!path.isValid) {
            val point = applyJitter(base, config, now, 0.0, baseBearing)
            return SpoofedMotion(point.lat, point.lng, baseBearing, 0f)
        }

        val speed = config.optDouble(ConfigKeys.SPEED_M_S, 3.0).coerceAtLeast(0.1)
        val rawStartTime = config.optLong(ConfigKeys.START_TIMESTAMP, 0L)
        val startTime = if (rawStartTime > 0L) rawStartTime else now
        val elapsedSec = (now - startTime).coerceAtLeast(0L) / 1000.0
        val realism = realismSession(config, startTime)
        // 暂停后继续时，路线从暂停处的累计距离接着走（start_timestamp 重置为继续的时刻）
        val offset = config.optDouble(ConfigKeys.ROUTE_DISTANCE_OFFSET, 0.0).coerceAtLeast(0.0)
        val traveled = offset + realism.distance(speed, elapsedSec)

        val stopAtDestination = config.optBoolean(ConfigKeys.STOP_AT_DESTINATION, false)
        val pos = path.positionAt(traveled, stopAtDestination)
        if (pos.arrived) {
            // 到达终点后停住；不要再叠加定位漂移，否则“停在终点”会来回蹭。
            return SpoofedMotion(pos.lat, pos.lng, pos.bearing, 0f)
        }
        val currentSpeed = realism.speed(speed, elapsedSec).toFloat()
        // 直线用较宽窗口保持平滑；转向越大窗口越小。窗口现在直接作用在
        // 叠加了 GPS 漂移/横向偏移的真实轨迹上，方向由“身后—身前”两点的
        // 位移反算，而不是再额外加一套与坐标无关的正弦噪声。
        val turn = turnMagnitude(path, traveled, stopAtDestination)
        val curveFactor = ((turn - 10.0) / 25.0).coerceIn(0.0, 1.0)
        val baseWindow = (currentSpeed * 3.0f).coerceIn(6f, 14f).toDouble()
        val curveWindow = (currentSpeed * 0.7f).coerceIn(1.5f, 3.0f).toDouble()
        val window = baseWindow * (1.0 - curveFactor) + curveWindow * curveFactor

        val lateral = config.optBoolean(ConfigKeys.ROUTE_LATERAL_DEVIATION, false)
        val seed = config.optLong(ConfigKeys.ROUTE_LATERAL_SEED, 0L)
        fun sample(distance: Double, timeMs: Long): LatLng {
            val along = distance.coerceAtLeast(0.0)
            val routePos = path.positionAt(along, stopAtDestination)
            val raw = if (lateral && !routePos.arrived) {
                lateralAt(path, along, stopAtDestination, seed)
            } else {
                LatLng(routePos.lat, routePos.lng)
            }
            return applyJitter(raw, config, timeMs, curveFactor, routePos.bearing)
        }

        val current = sample(traveled, now)
        if (currentSpeed <= 0.05f) {
            return SpoofedMotion(current.lat, current.lng, pos.bearing, 0f)
        }
        val timeWindowMs = (window / currentSpeed * 1000.0)
            .toLong().coerceIn(800L, 8_000L)
        // 首尾折返处跨窗口取点会把“掉头”平均成 0°，此时退回当前 segment 方向。
        val cycle = if (path.isClosedLoop) path.totalDistance else path.totalDistance * 2.0
        val inCycle = if (cycle > 0.0) traveled % cycle else 0.0
        val nearTurnaround = !path.isClosedLoop &&
            (inCycle < window || inCycle > cycle - window)
        val bearing = if (!nearTurnaround) {
            val behind = sample(traveled - window, now - timeWindowMs)
            val ahead = sample(traveled + window, now + timeWindowMs)
            if (GeoMath.distance(behind, ahead) > 0.05) {
                GeoMath.bearing(behind, ahead)
            } else {
                pos.bearing
            }
        } else if (inCycle < window) {
            // 起点没有“身后”点：用当前点→前方点，仍然从同一抖动轨迹
            // 反算方向，起跑后指南针就能立即出现微小变化。
            val ahead = sample(traveled + window, now + timeWindowMs)
            if (GeoMath.distance(current, ahead) > 0.05) {
                GeoMath.bearing(current, ahead)
            } else {
                pos.bearing
            }
        } else {
            // 非闭环终点折返：用身后点→当前点，避免把掉头平均成 0°。
            val behind = sample(traveled - window, now - timeWindowMs)
            if (GeoMath.distance(behind, current) > 0.05) {
                GeoMath.bearing(behind, current)
            } else {
                pos.bearing
            }
        }
        return SpoofedMotion(current.lat, current.lng, bearing, currentSpeed)
    }

    /** 上游 RouteEngine 的横向偏移采样：余弦渐隐 + 三个不同波长正弦叠加。 */
    private fun lateralAt(
        path: RoutePath,
        distance: Double,
        stopAtDestination: Boolean,
        seed: Long
    ): LatLng {
        val alongDistance = distance.coerceAtLeast(0.0)
        val base = path.positionAt(alongDistance, stopAtDestination)
        if (base.arrived) return LatLng(base.lat, base.lng)

        val total = path.totalDistance
        val cycle = if (path.isClosedLoop) total else total * 2.0
        var along = if (cycle > 0.0) alongDistance % cycle else 0.0
        if (along > total) along = cycle - along
        val edge = min(along, (total - along).coerceAtLeast(0.0)).coerceAtLeast(0.0)
        val fadeLength = min(12.0, total / 4.0).coerceAtLeast(0.001)
        val t = (edge / fadeLength).coerceIn(0.0, 1.0)
        val fade = (((6.0 * t - 15.0) * t + 10.0) * t * t * t)
        if (fade <= 0.0) return LatLng(base.lat, base.lng)

        val wave = alongDistance * 2.0 * PI
        val wobble =
            0.5 * sin(phase(seed, 1L) + wave / 83.0) +
                0.3 * sin(phase(seed, 2L) + wave / 139.0) +
                0.2 * sin(phase(seed, 3L) + wave / 227.0)
        val offsetMeters = wobble * 1.8 * fade
        return GeoMath.destination(
            LatLng(base.lat, base.lng),
            base.bearing + 90.0,
            offsetMeters
        )
    }

    /** 上游 dw2.P：按会话种子生成三个固定相位，保证同一次模拟的偏移可复现。 */
    private fun phase(seed: Long, index: Long): Double {
        var h = index * -7046029254386353131L + seed
        h = (h xor (h ushr 30)) * -4658895280553007687L
        h = (h xor (h ushr 27)) * -7723592293110705685L
        val u = (h xor (h ushr 31)) ushr 11
        return (u / 9.007199254740992E15) * 2.0 * PI
    }

    /**
     * 当前位置的海拔：基准海拔 ± 变化范围内随地形起伏，叠加随机强度对应的缓慢漂移（见 [AltitudeModel]），
     * 各进程对同一时刻给出一致的值。旧版配置没有变化范围字段时，按随机强度的漂移幅度处理。
     */
    fun realisticAltitude(config: JSONObject, now: Long = System.currentTimeMillis()): Double {
        val base = config.optDouble(ConfigKeys.ALTITUDE, 25.0)
        val drift = MotionRealism.Level.fromId(config.optInt(ConfigKeys.REALISM_LEVEL, MotionRealism.Level.OFF.id)).altitudeAmplitudeM
        val variation = config.optDouble(ConfigKeys.ALTITUDE_VARIATION_M, drift)
        if (variation <= 0.0) return base
        val pos = calculateCurrentPosition(config, now)
        return AltitudeModel.altitude(base, variation, drift, pos.lat, pos.lng, now)
    }

    /** 配置里缺少真实度字段（旧版 App 写的配置）时按"关闭 + 不浮动"处理，行为与旧版一致 */
    fun realismSession(config: JSONObject, startTimestamp: Long = config.optLong(ConfigKeys.START_TIMESTAMP, 0L)): MotionRealism.Session =
        MotionRealism.session(
            startTimestamp,
            config.optInt(ConfigKeys.REALISM_LEVEL, MotionRealism.Level.OFF.id),
            config.optInt(ConfigKeys.SPEED_FLUCTUATION_PCT, 0)
        )
}
