package com.vincenthzr.locationspoofer.xposed.hooks

import android.os.SystemClock
import com.vincenthzr.locationspoofer.utils.GnssRealism
import com.vincenthzr.locationspoofer.xposed.utils.XposedBridge
import com.vincenthzr.locationspoofer.xposed.utils.XposedHelpers
import java.lang.reflect.Constructor
import java.lang.reflect.Field
import java.util.Collections
import java.util.concurrent.ConcurrentHashMap

/**
 * 为目标 App 构造与 GnssStatus / NMEA 同一卫星模型的 GnssMeasurementsEvent。
 *
 * Android 13 的 GnssMeasurement/GnssClock 只有隐藏的无参构造器，字段也是私有的；
 * 这里用 Xposed 反射创建并按 AOSP 字段名填充。系统进程内不需要普通 App 的
 * hidden-API 白名单。
 */
internal object GnssMeasurementsFactory {

    private class Holder(val classLoader: ClassLoader) {
        var eventClass: Class<*>? = null
        var clockClass: Class<*>? = null
        var measurementClass: Class<*>? = null
        var eventCtor: Constructor<*>? = null

        fun init() {
            eventClass = XposedHelpers.findClassIfExists(
                "android.location.GnssMeasurementsEvent", classLoader
            )
            clockClass = XposedHelpers.findClassIfExists(
                "android.location.GnssClock", classLoader
            )
            measurementClass = XposedHelpers.findClassIfExists(
                "android.location.GnssMeasurement", classLoader
            )
            eventCtor = eventClass?.declaredConstructors?.firstOrNull {
                it.parameterCount == 3 &&
                    it.parameterTypes[0].name == "android.location.GnssClock" &&
                    List::class.java.isAssignableFrom(it.parameterTypes[1]) &&
                    List::class.java.isAssignableFrom(it.parameterTypes[2])
            }?.apply { isAccessible = true }
        }
    }

    private val holders = ConcurrentHashMap<ClassLoader, Holder>()

    private fun holder(classLoader: ClassLoader): Holder =
        holders.getOrPut(classLoader) { Holder(classLoader).also { it.init() } }

    private fun setInt(target: Any, name: String, value: Int) {
        runCatching { XposedHelpers.setIntField(target, name, value) }
    }

    private fun setLong(target: Any, name: String, value: Long) {
        runCatching { XposedHelpers.setLongField(target, name, value) }
    }

    private fun setDouble(target: Any, name: String, value: Double) {
        runCatching { XposedHelpers.setDoubleField(target, name, value) }
    }

    private fun setFloat(target: Any, name: String, value: Float) {
        runCatching { XposedHelpers.setObjectField(target, name, value) }
    }

    private fun setObject(target: Any, name: String, value: Any?) {
        runCatching { XposedHelpers.setObjectField(target, name, value) }
    }

    /** 构造一次 1Hz 的原始测量事件；失败返回 null，不影响位置/NMEA。 */
    fun build(
        classLoader: ClassLoader,
        satelliteCount: Int,
        enableJitter: Boolean,
        startTimestampMs: Long = 0L,
        speedMps: Double = 0.0
    ): Any? {
        val h = holder(classLoader)
        val eventClass = h.eventClass ?: return null
        val clockClass = h.clockClass ?: return null
        val measurementClass = h.measurementClass ?: return null
        val ctor = h.eventCtor ?: return null
        return try {
            val nowMs = System.currentTimeMillis()
            val elapsedNanos = SystemClock.elapsedRealtimeNanos()

            // timeNanos/fullBiasNanos 采用真实 GNSS 接收机的量级：
            // timeNanos - fullBiasNanos ≈ Unix epoch 纳秒。
            val timeNanos = elapsedNanos + 1_400_000_000_000_000_000L
            val fullBiasNanos = timeNanos - nowMs * 1_000_000L

            val clock = XposedHelpers.newInstance(clockClass)
            setLong(clock, "mTimeNanos", timeNanos)
            setDouble(clock, "mTimeUncertaintyNanos", 50.0)
            setLong(clock, "mFullBiasNanos", fullBiasNanos)
            setDouble(clock, "mBiasNanos", 0.0)
            setDouble(clock, "mBiasUncertaintyNanos", 50.0)
            setDouble(clock, "mDriftNanosPerSecond", 0.0)
            setDouble(clock, "mDriftUncertaintyNanosPerSecond", 0.01)
            setLong(clock, "mElapsedRealtimeNanos", elapsedNanos)
            setDouble(clock, "mElapsedRealtimeUncertaintyNanos", 1000.0)
            setInt(clock, "mLeapSecond", 18)
            setInt(clock, "mHardwareClockDiscontinuityCount", 0)
            // HAS_LEAP_SECOND | HAS_TIME_UNCERTAINTY | HAS_FULL_BIAS |
            // HAS_ELAPSED_REALTIME_NANOS | HAS_ELAPSED_REALTIME_UNCERTAINTY_NANOS
            setInt(clock, "mFlags", 1 or 2 or 4 or 128 or 256)

            val sats = GnssFastMockEngine.mockSatellites(
                satelliteCount, nowMs, enableJitter
            )
            val measurements = ArrayList<Any>(sats.size)
            val seedTs = if (startTimestampMs > 0L) startTimestampMs else nowMs
            val multipath = GnssRealism.multipathIndicator(seedTs, nowMs)
            for (sat in sats) {
                val m = XposedHelpers.newInstance(measurementClass)
                setInt(m, "mSvid", sat.svid)
                setInt(m, "mConstellationType", sat.constellationType)
                // CODE_LOCK | BIT_SYNC | SUBFRAME_SYNC | TOW_DECODED
                setInt(m, "mState", 1 or 2 or 4 or 8)
                setDouble(m, "mCn0DbHz", sat.cn0DbHz.toDouble())
                setDouble(m, "mBasebandCn0DbHz", sat.basebandCn0DbHz.toDouble())
                setFloat(m, "mCarrierFrequencyHz", sat.carrierFrequencyHz)
                // 伪距率不能是 0：真实接收机同时看到卫星径向运动（数百 m/s）
                // 和接收机自身速度。多路径时 uncertainty 也会变差。
                val rate = GnssRealism.pseudorangeRateMps(
                    seedTs, sat.svid, speedMps, nowMs
                )
                setDouble(m, "mPseudorangeRateMetersPerSecond", rate)
                setDouble(
                    m,
                    "mPseudorangeRateUncertaintyMetersPerSecond",
                    0.12 + if (multipath == 1) 0.45 else 0.12
                )
                setLong(m, "mReceivedSvTimeNanos", timeNanos % 604_800_000_000_000L)
                setLong(m, "mReceivedSvTimeUncertaintyNanos", 100L)
                setDouble(m, "mTimeOffsetNanos", 0.0)
                setInt(m, "mMultipathIndicator", multipath)
                setInt(m, "mAccumulatedDeltaRangeState", 1) // VALID
                setDouble(
                    m,
                    "mAccumulatedDeltaRangeMeters",
                    rate * 0.02 * kotlin.math.sin(nowMs / 1000.0 + sat.svid)
                )
                setDouble(
                    m,
                    "mAccumulatedDeltaRangeUncertaintyMeters",
                    if (multipath == 1) 0.35 else 0.05
                )
                setDouble(m, "mCarrierPhase", Double.NaN)
                setDouble(m, "mCarrierPhaseUncertainty", Double.NaN)
                setDouble(m, "mSnrInDb", Double.NaN)
                setObject(m, "mCodeType", null)
                // HAS_CARRIER_FREQUENCY | HAS_BASEBAND_CN0
                setInt(m, "mFlags", 0x200 or 0x8000)
                measurements.add(m)
            }

            ctor.newInstance(clock, measurements, Collections.emptyList<Any>())
        } catch (t: Throwable) {
            XposedBridge.log("[SysLoc] build GNSS measurements failed: $t")
            null
        }
    }
}
