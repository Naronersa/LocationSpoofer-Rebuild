@file:Suppress(
    "UNUSED_PARAMETER",
    "UNUSED_VARIABLE",
    "UNNECESSARY_NOT_NULL_ASSERTION",
    "DEPRECATION",
    "NAME_SHADOWING",
    "FunctionName",
    "PrivatePropertyName",
    "SpellCheckingInspection",
    "RedundantUnitReturnType",
    "RemoveRedundantQualifierName",
    "OPT_IN_USAGE",
    "unused",
    "UnusedImport"
)

package com.vincenthzr.locationspoofer.xposed.hooks.network

import com.vincenthzr.locationspoofer.xposed.utils.HookLog

import com.vincenthzr.locationspoofer.utils.ConfigKeys

import com.vincenthzr.locationspoofer.xposed.LocationHooker
import com.vincenthzr.locationspoofer.xposed.utils.*
import com.vincenthzr.locationspoofer.xposed.hooks.*
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import java.lang.reflect.Member
import java.lang.reflect.Method
import java.lang.reflect.Proxy
import java.lang.reflect.InvocationHandler
import java.lang.reflect.Array as ReflectArray
import kotlin.math.*
import io.github.libxposed.api.*

/**
 * WifiInfo 相关 getter（BSSID/SSID/RSSI 等）与 WifiManager.getConnectionInfo() 伪造。
 */
internal fun LocationHooker.hookWifiConnectionInfo(
    classLoader: ClassLoader,
    isCoreSystemProcess: Boolean = false
) {

    // 1. WifiInfo getter Hook
    try {
        val wifiInfoMethods = listOf(
            "getBSSID", "getMacAddress", "getSSID", "getNetworkId",
            "getRssi", "getLinkSpeed", "getFrequency", "getIpAddress"
        )
        for (method in wifiInfoMethods) {
            try {
                XposedHelpers.hookMethod(
                    "android.net.wifi.WifiInfo", classLoader, method
                ) { chain, method ->
                    val config =
                        readConfig() ?: return@hookMethod chain.proceed(chain.args.toTypedArray())
                    if (!config.optBoolean(
                            ConfigKeys.ACTIVE,
                            false
                        )
                    ) return@hookMethod chain.proceed(chain.args.toTypedArray())
                    val mockWifi = config.optBoolean(ConfigKeys.MOCK_WIFI, true)
                    val wifiObj = if (mockWifi) config.optJSONObject(ConfigKeys.WIFI_JSON_2) else null
                    val isConnected = wifiObj?.optBoolean(ConfigKeys.IS_CONNECTED, false) ?: false
                    val connectedWifi =
                        if (isConnected) wifiObj!!.optJSONObject(ConfigKeys.CONNECTED_WIFI) else null

                    when (method.name) {
                        "getBSSID" -> return@hookMethod connectedWifi?.optString(ConfigKeys.BSSID)
                            ?: "02:00:00:00:00:00"

                        "getMacAddress" -> return@hookMethod connectedWifi?.optString(ConfigKeys.MAC_ADDRESS)
                            ?: "02:00:00:00:00:00"

                        "getSSID" -> {
                            val ssidVal = connectedWifi?.optString(ConfigKeys.SSID, "") ?: ""
                            val finalSsid =
                                if (ssidVal.isEmpty() || ssidVal == "<unknown ssid>") "" else ssidVal
                            return@hookMethod if (finalSsid.isEmpty()) "<unknown ssid>" else "\"$finalSsid\""
                        }

                        "getNetworkId" -> return@hookMethod connectedWifi?.optInt(ConfigKeys.NETWORK_ID, -1)
                            ?: -1

                        "getRssi" -> return@hookMethod connectedWifi?.optInt(ConfigKeys.LEVEL, -127) ?: -127

                        "getLinkSpeed" -> return@hookMethod connectedWifi?.optInt(ConfigKeys.LINK_SPEED, -1)
                            ?: -1

                        "getFrequency" -> return@hookMethod connectedWifi?.optInt(ConfigKeys.FREQUENCY, -1)
                            ?: -1

                        "getIpAddress" -> return@hookMethod if (isConnected) 0x6401A8C0 else 0 // 192.168.1.100 小端序
                    }
                    return@hookMethod chain.proceed(chain.args.toTypedArray())
                }
            } catch (e: Throwable) { /* 部分方法在低版本可能不存在 */
            }
        }
    } catch (e: Throwable) {
        XposedBridge.log(e)
    }

    // 1b. WifiInfo.getSupplicantState()
    try {
        XposedHelpers.hookMethod(
            "android.net.wifi.WifiInfo", classLoader, "getSupplicantState"
        ) { chain, method ->
            val config = readConfig() ?: return@hookMethod chain.proceed(chain.args.toTypedArray())
            if (!config.optBoolean(
                    ConfigKeys.ACTIVE,
                    false
                )
            ) return@hookMethod chain.proceed(chain.args.toTypedArray())
            val mockWifi = config.optBoolean(ConfigKeys.MOCK_WIFI, true)
            val wifiObj = if (mockWifi) config.optJSONObject(ConfigKeys.WIFI_JSON_2) else null
            val isConnected = wifiObj?.optBoolean(ConfigKeys.IS_CONNECTED, false) ?: false
            try {
                val enumClass = XposedHelpers.findClass(
                    "android.net.wifi.SupplicantState", classLoader
                )
                val stateStr =
                    if (mockWifi && isConnected) "COMPLETED" else "DISCONNECTED"
                return@hookMethod enumClass.getField(stateStr).get(null)
            } catch (e: Throwable) { /* 忽略 */
            }
            return@hookMethod chain.proceed(chain.args.toTypedArray())
        }
    } catch (e: Throwable) { /* 忽略 */
    }

    // getConnectionInfo() — 返回伪造的 WifiInfo 对象
    try {
        XposedHelpers.hookMethod(
            "android.net.wifi.WifiManager", classLoader, "getConnectionInfo"
        ) { chain, method ->
            val config = readConfig() ?: return@hookMethod chain.proceed(chain.args.toTypedArray())
            if (!config.optBoolean(
                    ConfigKeys.ACTIVE,
                    false
                )
            ) return@hookMethod chain.proceed(chain.args.toTypedArray())
            val mockWifi = config.optBoolean(ConfigKeys.MOCK_WIFI, true)
            val wifiObj = if (mockWifi) config.optJSONObject(ConfigKeys.WIFI_JSON_2) else null
            val isConnected = wifiObj?.optBoolean(ConfigKeys.IS_CONNECTED, false) ?: false
            val connectedWifi =
                if (isConnected) wifiObj!!.optJSONObject(ConfigKeys.CONNECTED_WIFI) else null

            val currentResult = chain.proceed(chain.args.toTypedArray())
            if (isConnected && connectedWifi != null) {
                try {
                    val ssidVal = connectedWifi.optString(ConfigKeys.SSID, "")
                    val finalSsid =
                        if (ssidVal.isEmpty() || ssidVal == "<unknown ssid>") "HOME_WIFI" else ssidVal
                    val bssidVal = connectedWifi.optString(ConfigKeys.BSSID, "02:00:00:00:00:00")
                    val freqVal = connectedWifi.optInt(ConfigKeys.FREQUENCY, 2412)
                    val macAddressVal = connectedWifi.optString(ConfigKeys.MAC_ADDRESS, bssidVal)
                    val linkSpeedVal = connectedWifi.optInt(ConfigKeys.LINK_SPEED, 65)
                    val standardVal = connectedWifi.optInt(ConfigKeys.WIFI_STANDARD, 6)
                    val levelVal = connectedWifi.optInt(ConfigKeys.LEVEL, -65)
                    val networkIdVal = connectedWifi.optInt(ConfigKeys.NETWORK_ID, 1)

                    if (currentResult != null) {
                        // 就地修改返回值以避免在 ColorOS 的 system_server 中发生 ClassCastException
                        try {
                            XposedHelpers.setObjectField(
                                currentResult,
                                "mSSID",
                                "\"$finalSsid\""
                            )
                        } catch (t: Throwable) { HookLog.swallowed("WifiConnectionInfoHooker.kt:169", t) }
                        try {
                            val wifiSsidClass = XposedHelpers.findClassIfExists(
                                "android.net.wifi.WifiSsid",
                                classLoader
                            )
                            if (wifiSsidClass != null) {
                                val createMethod = XposedHelpers.findMethodExact(
                                    wifiSsidClass,
                                    "createFromAsciiEncoded",
                                    String::class.java
                                )
                                val wifiSsid = createMethod.invoke(null, finalSsid)
                                XposedHelpers.setObjectField(
                                    currentResult,
                                    "mWifiSsid",
                                    wifiSsid
                                )
                            }
                        } catch (t: Throwable) { HookLog.swallowed("WifiConnectionInfoHooker.kt:189", t) }
                        try {
                            XposedHelpers.setObjectField(currentResult, "mBSSID", bssidVal)
                        } catch (t: Throwable) { HookLog.swallowed("WifiConnectionInfoHooker.kt:193", t) }
                        try {
                            XposedHelpers.setObjectField(
                                currentResult,
                                "mMacAddress",
                                macAddressVal
                            )
                        } catch (t: Throwable) { HookLog.swallowed("WifiConnectionInfoHooker.kt:201", t) }
                        try {
                            XposedHelpers.setIntField(currentResult, "mRssi", levelVal)
                        } catch (t: Throwable) { HookLog.swallowed("WifiConnectionInfoHooker.kt:205", t) }
                        try {
                            XposedHelpers.setIntField(currentResult, "mFrequency", freqVal)
                        } catch (t: Throwable) { HookLog.swallowed("WifiConnectionInfoHooker.kt:209", t) }
                        try {
                            XposedHelpers.setIntField(
                                currentResult,
                                "mLinkSpeed",
                                linkSpeedVal
                            )
                        } catch (t: Throwable) { HookLog.swallowed("WifiConnectionInfoHooker.kt:217", t) }
                        try {
                            XposedHelpers.setIntField(
                                currentResult,
                                "mNetworkId",
                                networkIdVal
                            )
                        } catch (t: Throwable) { HookLog.swallowed("WifiConnectionInfoHooker.kt:225", t) }
                        try {
                            XposedHelpers.setIntField(
                                currentResult,
                                "mWifiStandard",
                                standardVal
                            )
                        } catch (t: Throwable) { HookLog.swallowed("WifiConnectionInfoHooker.kt:233", t) }
                    } else {
                        if (isCoreSystemProcess) return@hookMethod currentResult

                        var builtWithBuilder = false
                        var builtInfo: Any? = null
                        try {
                            val builderClass = XposedHelpers.findClass(
                                "android.net.wifi.WifiInfo\$Builder",
                                classLoader
                            )
                            val builder = XposedHelpers.newInstance(builderClass)
                            XposedHelpers.callMethod(builder, "setSsid", finalSsid)
                            XposedHelpers.callMethod(builder, "setBssid", bssidVal)
                            XposedHelpers.callMethod(builder, "setRssi", levelVal)
                            XposedHelpers.callMethod(builder, "setFrequency", freqVal)
                            XposedHelpers.callMethod(builder, "setLinkSpeed", linkSpeedVal)
                            builtInfo = XposedHelpers.callMethod(builder, "build")
                            builtWithBuilder = true
                        } catch (t: Throwable) { HookLog.swallowed("WifiConnectionInfoHooker.kt:253", t) }

                        val fakeWifiInfo = if (builtWithBuilder) {
                            builtInfo!!
                        } else {
                            val wifiInfoClass = XposedHelpers.findClass(
                                "android.net.wifi.WifiInfo",
                                classLoader
                            )
                            val info = XposedHelpers.newInstance(wifiInfoClass)
                            try {
                                XposedHelpers.setObjectField(
                                    info,
                                    "mSSID",
                                    "\"$finalSsid\""
                                )
                            } catch (t: Throwable) { HookLog.swallowed("WifiConnectionInfoHooker.kt:270", t) }
                            try {
                                XposedHelpers.setObjectField(info, "mBSSID", bssidVal)
                            } catch (t: Throwable) { HookLog.swallowed("WifiConnectionInfoHooker.kt:274", t) }
                            try {
                                XposedHelpers.setObjectField(
                                    info,
                                    "mMacAddress",
                                    macAddressVal
                                )
                            } catch (t: Throwable) { HookLog.swallowed("WifiConnectionInfoHooker.kt:282", t) }
                            try {
                                XposedHelpers.setIntField(info, "mRssi", levelVal)
                            } catch (t: Throwable) { HookLog.swallowed("WifiConnectionInfoHooker.kt:286", t) }
                            try {
                                XposedHelpers.setIntField(info, "mFrequency", freqVal)
                            } catch (t: Throwable) { HookLog.swallowed("WifiConnectionInfoHooker.kt:290", t) }
                            try {
                                XposedHelpers.setIntField(info, "mLinkSpeed", linkSpeedVal)
                            } catch (t: Throwable) { HookLog.swallowed("WifiConnectionInfoHooker.kt:294", t) }
                            try {
                                XposedHelpers.setIntField(info, "mNetworkId", networkIdVal)
                            } catch (t: Throwable) { HookLog.swallowed("WifiConnectionInfoHooker.kt:298", t) }
                            info
                        }
                        return@hookMethod fakeWifiInfo
                    }
                } catch (t: Throwable) { HookLog.swallowed("WifiConnectionInfoHooker.kt:304", t) }
            } else {
                if (currentResult != null) {
                    try {
                        XposedHelpers.setObjectField(
                            currentResult,
                            "mBSSID",
                            "02:00:00:00:00:00"
                        )
                    } catch (t: Throwable) { HookLog.swallowed("WifiConnectionInfoHooker.kt:314", t) }
                    try {
                        XposedHelpers.setObjectField(
                            currentResult,
                            "mMacAddress",
                            "02:00:00:00:00:00"
                        )
                    } catch (t: Throwable) { HookLog.swallowed("WifiConnectionInfoHooker.kt:322", t) }
                    try {
                        XposedHelpers.setIntField(currentResult, "mNetworkId", -1)
                    } catch (t: Throwable) { HookLog.swallowed("WifiConnectionInfoHooker.kt:326", t) }
                    try {
                        XposedHelpers.setIntField(currentResult, "mRssi", -127)
                    } catch (t: Throwable) { HookLog.swallowed("WifiConnectionInfoHooker.kt:330", t) }
                    try {
                        XposedHelpers.setIntField(currentResult, "mLinkSpeed", -1)
                    } catch (t: Throwable) { HookLog.swallowed("WifiConnectionInfoHooker.kt:334", t) }
                    try {
                        XposedHelpers.setIntField(currentResult, "mFrequency", -1)
                    } catch (t: Throwable) { HookLog.swallowed("WifiConnectionInfoHooker.kt:338", t) }
                } else {
                    if (isCoreSystemProcess) return@hookMethod currentResult
                    try {
                        val wifiInfoClass = XposedHelpers.findClass(
                            "android.net.wifi.WifiInfo",
                            classLoader
                        )
                        val fakeWifiInfo = XposedHelpers.newInstance(wifiInfoClass)
                        try {
                            XposedHelpers.setObjectField(
                                fakeWifiInfo,
                                "mBSSID",
                                "02:00:00:00:00:00"
                            )
                        } catch (t: Throwable) { HookLog.swallowed("WifiConnectionInfoHooker.kt:354", t) }
                        try {
                            XposedHelpers.setObjectField(
                                fakeWifiInfo,
                                "mMacAddress",
                                "02:00:00:00:00:00"
                            )
                        } catch (t: Throwable) { HookLog.swallowed("WifiConnectionInfoHooker.kt:362", t) }
                        try {
                            XposedHelpers.setIntField(fakeWifiInfo, "mNetworkId", -1)
                        } catch (t: Throwable) { HookLog.swallowed("WifiConnectionInfoHooker.kt:366", t) }
                        try {
                            XposedHelpers.setIntField(fakeWifiInfo, "mRssi", -127)
                        } catch (t: Throwable) { HookLog.swallowed("WifiConnectionInfoHooker.kt:370", t) }
                        try {
                            XposedHelpers.setIntField(fakeWifiInfo, "mLinkSpeed", -1)
                        } catch (t: Throwable) { HookLog.swallowed("WifiConnectionInfoHooker.kt:374", t) }
                        try {
                            XposedHelpers.setIntField(fakeWifiInfo, "mFrequency", -1)
                        } catch (t: Throwable) { HookLog.swallowed("WifiConnectionInfoHooker.kt:378", t) }
                        return@hookMethod fakeWifiInfo
                    } catch (t: Throwable) { HookLog.swallowed("WifiConnectionInfoHooker.kt:381", t) }
                }
            }
            return@hookMethod currentResult
        }
    } catch (e: Throwable) {
        XposedBridge.log(e)
    }
}
