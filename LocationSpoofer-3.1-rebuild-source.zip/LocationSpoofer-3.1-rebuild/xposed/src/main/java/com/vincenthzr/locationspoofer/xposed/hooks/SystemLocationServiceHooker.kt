@file:Suppress(
    "UNUSED_PARAMETER",
    "UNUSED_VARIABLE",
    "UNNECESSARY_NOT_NULL_ASSERTION",
    "DEPRECATION",
    "NAME_SHADOWING",
    "FunctionName",
    "PrivatePropertyName",
    "SpellCheckingInspection",
    "RedundantUnitReturnType",
    "RemoveRedundantQualifierName",
    "OPT_IN_USAGE",
    "unused",
    "UnusedImport"
)

package com.vincenthzr.locationspoofer.xposed.hooks

import com.vincenthzr.locationspoofer.xposed.utils.HookLog

import com.vincenthzr.locationspoofer.utils.ConfigKeys

import com.vincenthzr.locationspoofer.xposed.hooks.vendor.VendorRegistry
import android.os.IBinder
import android.os.IInterface
import android.util.Log
import com.vincenthzr.locationspoofer.utils.GnssRealism
import com.vincenthzr.locationspoofer.xposed.LocationHooker
import com.vincenthzr.locationspoofer.xposed.hooks.vendor.SystemComponent
import com.vincenthzr.locationspoofer.xposed.hooks.vendor.SystemClassLocator
import com.vincenthzr.locationspoofer.xposed.utils.*
import io.github.libxposed.api.*
import org.json.JSONObject
import java.lang.ref.WeakReference
import java.lang.reflect.Method
import java.util.Collections
import java.util.Timer
import java.util.TimerTask
import java.util.WeakHashMap
import java.util.concurrent.ConcurrentHashMap

/**
 * system_server 系统级定位服务拦截与主动派发引擎
 *
 * 核心原理：
 * 全设备所有 App 的原生定位请求（LocationManager / FusedLocation）最终均通过 Binder IPC
 * 汇聚至 system_server 的 LocationManagerService。
 *
 * 本模块直接拦截 LocationManagerService，并在每次 IPC 入口处根据调用方 UID 与包名进行规则判定：
 * 1. 命中用户在 LocationSpoofer 中指定的应用白名单，或开启了【全局模拟模式】时，向该应用派发伪造的
 *    Location 对象、GNSS 20+ 卫星星座以及 NMEA-0183 报文流；
 * 2. 严禁污染 LocationSpoofer 自身与系统核心组件（SystemUI、电话、紧急呼叫）；
 * 3. 内置主动心跳推送定时器：当物理 GPS 芯片在室内无锁定时，主动向目标应用的 ILocationListener
 *    周期性推送平滑的伪造坐标序列，彻底杜绝目标应用无限期等待真实 GPS 回调的问题；
 * 4. 监听者通过 IBinder.linkToDeath 实现自动垃圾回收，客户端进程退出即刻清理，保证系统服务零内存泄露。
 */

internal fun logLoc(msg: String) {
    XposedBridge.log(msg)
}

/** 在 args 里递归找出所有 android.location.Location（单个、List、或 LocationResult 形态）并就地改写 */
private fun rewriteLocationArgs(
    args: List<Any?>,
    motion: SpoofedMotion,
    altitude: Double,
    accuracy: Float
) {
    for (arg in args) {
        when {
            arg == null -> continue
            LocationHooker.hasTypeByName(arg.javaClass, "android.location.Location") -> {
                SystemHookUtils.applyFakeLocationFields(arg, motion, altitude, accuracy)
            }
            arg.javaClass.name.contains("LocationResult") -> {
                try {
                    val list = XposedHelpers.callMethod(arg, "asList") as? List<*>
                    list?.forEach { item ->
                        if (item != null && LocationHooker.hasTypeByName(
                                item.javaClass,
                                "android.location.Location"
                            )
                        ) {
                            SystemHookUtils.applyFakeLocationFields(item, motion, altitude, accuracy)
                        }
                    }
                } catch (t: Throwable) { HookLog.swallowed("SystemLocationServiceHooker.kt:222", t) }
            }
            arg is List<*> -> {
                arg.forEach { item ->
                    if (item != null && LocationHooker.hasTypeByName(
                            item.javaClass,
                            "android.location.Location"
                        )
                    ) {
                        SystemHookUtils.applyFakeLocationFields(item, motion, altitude, accuracy)
                    }
                }
            }
        }
    }
}

/** 找到目标监听者/回调对象类之后，Hook 一次，按实例身份决定要不要改写投递内容 */
internal fun LocationHooker.ensureCallbackHooked(callback: Any, vararg deliveryMethodNames: String) {
    val clazz = callback.javaClass
    if (hookedCallbackClasses.putIfAbsent(clazz, true) != null) return
    for (methodName in deliveryMethodNames) {
        try {
            XposedHelpers.hookAllMethods(clazz, methodName) { innerChain, _ ->
                val binder = (innerChain.thisObject as? IInterface)?.asBinder() ?: (innerChain.thisObject as? IBinder)
                val config = readConfig()
                val isGlobal = config?.optBoolean(ConfigKeys.SYSTEM_HOOK_GLOBAL_MODE, false) == true
                val isTracked = (binder != null && (activeListenerBinders.containsKey(binder) || activeCallbackBinders.containsKey(binder))) ||
                        spoofedListenerInstances.contains(innerChain.thisObject)
                val isTarget = isTracked || isGlobal
                if (isTarget && config != null && config.optBoolean(ConfigKeys.ACTIVE, false)) {
                    val motion = getCurrentSpoofedMotion("WGS-84")
                    if (motion != null) {
                        rewriteLocationArgs(
                            innerChain.args,
                            motion,
                            RouteEngine.realisticAltitude(config),
                            getJitteredAccuracy()
                        )
                        logLoc("[SysLoc] Rewrote location in callback $methodName for target binder (lat=${motion.lat}, lng=${motion.lng}, isGlobal=$isGlobal)"
                        )
                    }
                }
                return@hookAllMethods innerChain.proceed(innerChain.args.toTypedArray())
            }
        } catch (t: Throwable) { HookLog.swallowed("SystemLocationServiceHooker.kt:267", t) }
    }
}

internal fun createDummyRemoteCallback(): Any {
    return object : android.os.Binder(), android.os.IInterface {
        override fun asBinder(): android.os.IBinder = this
        override fun onTransact(code: Int, data: android.os.Parcel, reply: android.os.Parcel?, flags: Int): Boolean {
            reply?.writeNoException()
            return true
        }
    }
}

private fun createDummyCancellationSignal(): Any {
    return object : android.os.Binder(), android.os.IInterface {
        override fun asBinder(): android.os.IBinder = this
        override fun onTransact(code: Int, data: android.os.Parcel, reply: android.os.Parcel?, flags: Int): Boolean {
            reply?.writeNoException()
            return true
        }
    }
}

internal fun LocationHooker.hookSystemLocationService(classLoader: ClassLoader) {
    val serviceClazz = SystemClassLocator.locate(SystemComponent.LOCATION_MANAGER_SERVICE, classLoader)

    if (serviceClazz == null) {
        logLoc("[SysHook] LocationManagerService not found, skip system-level location hook")
        return
    }
    logLoc("[SysHook] hookSystemLocationService invoked on ${serviceClazz.name}")
    startSystemLocationHeartbeat(classLoader)

    val needsGenericHooks = !VendorRegistry.active.usesFrameworkLocationDelivery ||
        VendorRegistry.frameworkLocationFallback
    if (!needsGenericHooks) return
    if (hookedCallbackClasses.putIfAbsent(serviceClazz, true) != null) {
        return
    }

    if (needsGenericHooks) {
    // =========================================================================
    // 1. getLastLocation：同步返回，命中目标应用直接替换为伪造 Location
    // =========================================================================
    try {
        XposedHelpers.hookAllMethods(serviceClazz, "getLastLocation") { chain, _ ->
            val config = readConfig() ?: return@hookAllMethods chain.proceed(chain.args.toTypedArray())
            val explicitPkg = SystemHookUtils.extractPackageName(chain.args)
            val overrideUid = SystemHookUtils.extractCallerUid(chain.args)
            val isTarget = SystemHookUtils.isTargetCaller(chain.thisObject, explicitPkg, config, overrideUid)

            if (!isTarget) {
                return@hookAllMethods chain.proceed(chain.args.toTypedArray())
            }

            val motion = getCurrentSpoofedMotion("WGS-84")
                ?: return@hookAllMethods chain.proceed(chain.args.toTypedArray())

            val provider = SystemHookUtils.extractProvider(chain.args)

            val fakeLoc = SystemHookUtils.buildFakeLocation(
                classLoader,
                provider,
                motion,
                RouteEngine.realisticAltitude(config),
                getJitteredAccuracy()
            )

            if (fakeLoc != null) {
                logLoc(
                    "[SysHook] Injected fake location for ${explicitPkg ?: "caller"} (getLastLocation): lat=${motion.lat}, lng=${motion.lng}, provider=$provider"
                )
                return@hookAllMethods fakeLoc
            }

            // 活跃模拟中构造 fake Location 失败时，宁可返回 null（没有 last fix），
            // 也不能把真实 Location 交给目标 App。
            return@hookAllMethods null
        }
        logLoc("[SysHook] LocationManagerService.getLastLocation hooked")
    } catch (e: Throwable) {
        logLoc("[SysHook] hook getLastLocation failed: $e")
    }

    // =========================================================================
    // 2. registerLocationListener (Android 12+), requestLocationUpdates & registerLocationPendingIntent
    // =========================================================================
    val listenerRegisterMethodNames = arrayOf("registerLocationListener", "requestLocationUpdates", "registerLocationPendingIntent")
    for (methodName in listenerRegisterMethodNames) {
        try {
            XposedHelpers.hookAllMethods(serviceClazz, methodName) { chain, _ ->
                try {
                    val config = readConfig()
                    if (config != null) {
                        val explicitPkg = SystemHookUtils.extractPackageName(chain.args)
                        val overrideUid = SystemHookUtils.extractCallerUid(chain.args)
                        val isTarget = SystemHookUtils.isTargetCaller(chain.thisObject, explicitPkg, config, overrideUid, requireActive = false)

                        if (isTarget) {
                            val listener = chain.args.firstOrNull { arg ->
                                arg != null && LocationHooker.hasTypeByName(
                                    arg.javaClass,
                                    "android.location.ILocationListener"
                                )
                            }
                            val provider = SystemHookUtils.extractProvider(chain.args)
                            if (listener != null) {
                                val binder = (listener as? IInterface)?.asBinder() ?: (listener as? IBinder)
                                val pkgName = explicitPkg ?: "unknown"
                                if (binder != null) {
                                    activeListenerBinders[binder] = ListenerRegistrationInfo(
                                        listener = listener,
                                        packageName = pkgName,
                                        provider = provider
                                    )
                                    try {
                                        ModuleBinderDeaths.watch(binder) {
                                            activeListenerBinders.remove(binder)
                                            logLoc("[SysHook] Listener died and removed for $pkgName")
                                        }
                                    } catch (t: Throwable) { HookLog.swallowed("SystemLocationServiceHooker.kt:823", t) }
                                }
                                spoofedListenerInstances.add(listener)
                                ensureCallbackHooked(listener, "onLocationChanged")

                                logLoc("[SysHook] Registered target location listener for ${explicitPkg ?: "caller"} (total active: ${activeListenerBinders.size})"
                                )

                                // ★ 核心修复: 注册瞬间立即主动同步派发首帧伪造位置，实现 0ms 瞬间定位，
                                // 彻底消除等待 1 秒心跳导致的定位重试与真实位置闪现
                                val motion = getCurrentSpoofedMotion("WGS-84")
                                if (motion != null) {
                                    val fakeLoc = SystemHookUtils.buildFakeLocation(
                                        classLoader,
                                        provider,
                                        motion,
                                        RouteEngine.realisticAltitude(config),
                                        getJitteredAccuracy()
                                    )
                                    if (fakeLoc != null) {
                                        try {
                                            dispatchFakeLocationToListener(listener, fakeLoc)
                                            logLoc("[SysHook] Proactively dispatched instant fake location to listener for ${explicitPkg ?: "caller"} (provider=$provider)"
                                            )
                                        } catch (t: Throwable) {
                                            logLoc("[SysHook] instant proactive dispatch failed: $t")
                                        }
                                    }
                                }
                            }

                            val pendingIntent = chain.args.firstOrNull { it is android.app.PendingIntent } as? android.app.PendingIntent
                            if (pendingIntent != null) {
                                val pkgName = explicitPkg ?: pendingIntent.creatorPackage ?: "unknown"
                                activePendingIntents[pendingIntent] = pkgName
                                logLoc("[SysHook] Registered target location PendingIntent for $pkgName (total active: ${activePendingIntents.size})")
                            }
                        }
                    }
                } catch (e: Throwable) {
                    logLoc("[SysHook] $methodName pre-hook error: $e")
                }
                return@hookAllMethods chain.proceed(chain.args.toTypedArray())
            }
            logLoc("[SysHook] LocationManagerService.$methodName hooked")
        } catch (e: Throwable) {
            logLoc("[SysHook] hook $methodName failed: $e")
        }
    }

    // =========================================================================
    // 3. unregisterLocationListener (Android 12+) & removeUpdates (Android 8-11)
    // =========================================================================
    val unregisterMethodNames = arrayOf("unregisterLocationListener", "removeUpdates")
    for (methodName in unregisterMethodNames) {
        try {
            XposedHelpers.hookAllMethods(serviceClazz, methodName) { chain, _ ->
                try {
                    val listener = chain.args.firstOrNull { arg ->
                        arg != null && LocationHooker.hasTypeByName(
                            arg.javaClass,
                            "android.location.ILocationListener"
                        )
                    }
                    if (listener != null) {
                        val binder = (listener as? IInterface)?.asBinder() ?: (listener as? IBinder)
                        if (binder != null) {
                            activeListenerBinders.remove(binder)
                        }
                        spoofedListenerInstances.remove(listener)
                    }
                    val pendingIntent = chain.args.firstOrNull { it is android.app.PendingIntent } as? android.app.PendingIntent
                    if (pendingIntent != null) {
                        activePendingIntents.remove(pendingIntent)
                    }
                } catch (t: Throwable) { HookLog.swallowed("SystemLocationServiceHooker.kt:898", t) }
                return@hookAllMethods chain.proceed(chain.args.toTypedArray())
            }
        } catch (t: Throwable) { HookLog.swallowed("SystemLocationServiceHooker.kt:901", t) }
    }

    // =========================================================================
    // 4. getCurrentLocation：单次定位回调拦截与主动投递
    // =========================================================================
    try {
        XposedHelpers.hookAllMethods(serviceClazz, "getCurrentLocation") { chain, _ ->
            try {
                val config = readConfig()
                if (config != null) {
                    val explicitPkg = SystemHookUtils.extractPackageName(chain.args)
                    val overrideUid = SystemHookUtils.extractCallerUid(chain.args)
                    val isTarget = SystemHookUtils.isTargetCaller(chain.thisObject, explicitPkg, config, overrideUid, requireActive = false)

                    if (isTarget) {
                        val callback = chain.args.firstOrNull { arg ->
                            arg != null && LocationHooker.hasTypeByName(
                                arg.javaClass,
                                "android.location.ILocationCallback"
                            )
                        }
                        if (callback != null) {
                            val binder = (callback as? IInterface)?.asBinder() ?: (callback as? IBinder)
                            val pkgName = explicitPkg ?: "caller"
                            val provider = SystemHookUtils.extractProvider(chain.args)
                            if (binder != null) {
                                activeCallbackBinders[binder] = CallbackRegistrationInfo(
                                    callback = callback,
                                    packageName = pkgName,
                                    provider = provider
                                )
                                try {
                                    ModuleBinderDeaths.watch(binder) {
                                        activeCallbackBinders.remove(binder)
                                        logLoc("[SysLoc] Callback binder died: $pkgName")
                                    }
                                } catch (t: Throwable) { HookLog.swallowed("SystemLocationServiceHooker.kt:936", t) }
                            }

                            spoofedListenerInstances.add(callback)
                            ensureCallbackHooked(callback, "onLocation")
                            logLoc("[SysLoc] Registered getCurrentLocation callback for $pkgName (active callbacks: ${activeCallbackBinders.size})"
                            )

                            // 主动推送单次定位结果，防止在室内真实 GPS 未锁定导致目标 App 持续等待超时
                            val motion = getCurrentSpoofedMotion("WGS-84")
                            if (motion != null) {
                                val fakeLoc = SystemHookUtils.buildFakeLocation(
                                    classLoader,
                                    provider,
                                    motion,
                                    RouteEngine.realisticAltitude(config),
                                    getJitteredAccuracy()
                                )
                                if (fakeLoc != null) {
                                    val onLocationMethod = callback.javaClass.methods.firstOrNull {
                                        it.name == "onLocation" && it.parameterTypes.size == 1
                                    }
                                    if (onLocationMethod != null) {
                                        try {
                                            onLocationMethod.invoke(callback, fakeLoc)
                                            logLoc("[SysLoc] Proactively dispatched fake location to getCurrentLocation callback for $pkgName (lat=${motion.lat}, lng=${motion.lng}, provider=$provider)"
                                            )
                                            // getCurrentLocation 是一次性的：已经投递成功就移除，
                                            // 避免心跳或其他路径重复回调同一个 callback。
                                            binder?.let { activeCallbackBinders.remove(it) }
                                            return@hookAllMethods createDummyCancellationSignal()
                                        } catch (t: Throwable) {
                                            logLoc("[SysLoc] proactive callback invoke failed: $t")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            } catch (e: Throwable) {
                logLoc("[SysLoc] getCurrentLocation pre-hook failed: $e")
            }
            return@hookAllMethods chain.proceed(chain.args.toTypedArray())
        }
        logLoc("[SysLoc] LocationManagerService.getCurrentLocation hooked")
    } catch (e: Throwable) {
        logLoc("[SysLoc] hook getCurrentLocation failed: $e")
    }

    }

    // =========================================================================
    // 5. isProviderEnabled & isProviderEnabledForUser：对目标应用强制汇报 GPS 可用
    // =========================================================================
    val providerEnabledMethods = arrayOf("isProviderEnabled", "isProviderEnabledForUser")
    for (methodName in providerEnabledMethods) {
        try {
            XposedHelpers.hookAllMethods(serviceClazz, methodName) { chain, _ ->
                val config = readConfig()
                if (config != null && config.optBoolean(ConfigKeys.ACTIVE, false) &&
                    (!com.vincenthzr.locationspoofer.xposed.hooks.vendor.VendorRegistry.active.requiresVirtualLocationOptIn ||
                        config.optBoolean(ConfigKeys.FORCE_LOCATION_ENABLED, false))) {
                    val providerArg = SystemHookUtils.extractProvider(chain.args)
                    if (providerArg == "gps" || providerArg == "network" || providerArg == "passive" || providerArg == "fused") {
                        val explicitPkg = SystemHookUtils.extractPackageName(chain.args)
                        val overrideUid = SystemHookUtils.extractCallerUid(chain.args)
                        if (SystemHookUtils.isTargetCaller(chain.thisObject, explicitPkg, config, overrideUid)) {
                            return@hookAllMethods true
                        }
                    }
                }
                return@hookAllMethods chain.proceed(chain.args.toTypedArray())
            }
        } catch (t: Throwable) { HookLog.swallowed("SystemLocationServiceHooker.kt:1008", t) }
    }

    // =========================================================================
    // 6. GNSS 卫星与 NMEA 拦截与注册 (registerGnssStatusCallback / registerGnssNmeaCallback)
    // =========================================================================
    val registerGnssMethods = arrayOf("registerGnssStatusCallback", "addGpsStatusListener")
    for (mName in registerGnssMethods) {
        try {
            XposedHelpers.hookAllMethods(serviceClazz, mName) { chain, _ ->
                try {
                    val config = readConfig()
                    if (config != null) {
                        val explicitPkg = SystemHookUtils.extractPackageName(chain.args)
                        val overrideUid = SystemHookUtils.extractCallerUid(chain.args)
                        val isTarget = SystemHookUtils.isTargetCaller(chain.thisObject, explicitPkg, config, overrideUid, requireActive = false)
                        if (isTarget) {
                            val callback = chain.args.firstOrNull { arg ->
                                arg != null && (arg is IInterface || arg is IBinder ||
                                        LocationHooker.hasTypeByName(arg.javaClass, "android.location.IGnssStatusListener") ||
                                        LocationHooker.hasTypeByName(arg.javaClass, "android.location.IGnssStatusCallback") ||
                                        LocationHooker.hasTypeByName(arg.javaClass, "android.location.IGpsStatusListener") ||
                                        arg.javaClass.name.contains("Gnss") || arg.javaClass.name.contains("Gps"))
                            }
                            if (callback != null) {
                                val binder = (callback as? IInterface)?.asBinder() ?: (callback as? IBinder)
                                if (binder != null) {
                                    val pkgName = explicitPkg ?: "unknown"
                                    val info = GnssStatusRegistrationInfo(
                                        listener = callback,
                                        packageName = pkgName
                                    )
                                    activeGnssStatusBinders[binder] = info
                                    try {
                                        ModuleBinderDeaths.watch(binder) {
                                            activeGnssStatusBinders.remove(binder)
                                            logLoc("[SysLoc] GNSS status listener died: $pkgName")
                                        }
                                    } catch (t: Throwable) { HookLog.swallowed("SystemLocationServiceHooker.kt:1045", t) }

                                    // 注册时若模拟已开启，立即派发一次卫星数据；若未开启，
                                    // 只登记 binder，等心跳在模拟启动后统一派发。
                                    if (config.optBoolean(ConfigKeys.ACTIVE, false)) {
                                        val gnssStatus = GnssFastMockEngine.getOrCreateSpoofedGnssStatus(
                                            classLoader,
                                            config.optInt(ConfigKeys.SATELLITE_COUNT, 20),
                                            config.optBoolean(ConfigKeys.ENABLE_JITTER, true),
                                            null
                                        )
                                        notifyGnssSessionStarted(callback)
                                        info.sessionStarted = true
                                        dispatchGnssStatus(callback, gnssStatus, config, classLoader)
                                    }
                                    hookGnssStatusListenerCallback(callback)

                                    logLoc("[SysLoc] Registered & dispatched target GNSS status callback for $pkgName (active: ${activeGnssStatusBinders.size})"
                                    )
                                }
                            }
                        }
                    }
                } catch (e: Throwable) {
                    logLoc("[SysLoc] $mName pre-hook failed: $e")
                }
                return@hookAllMethods chain.proceed(chain.args.toTypedArray())
            }
            logLoc("[SysLoc] LocationManagerService.$mName hooked")
        } catch (e: Throwable) {
            logLoc("[SysLoc] hook $mName failed: $e")
        }
    }

    val unregisterGnssMethods = arrayOf("unregisterGnssStatusCallback", "removeGpsStatusListener")
    for (mName in unregisterGnssMethods) {
        try {
            XposedHelpers.hookAllMethods(serviceClazz, mName) { chain, _ ->
                val callback = chain.args.firstOrNull { arg ->
                    arg != null && (arg is IInterface || arg is IBinder)
                }
                if (callback != null) {
                    val binder = (callback as? IInterface)?.asBinder() ?: (callback as? IBinder)
                    if (binder != null) {
                        activeGnssStatusBinders.remove(binder)
                    }
                }
                return@hookAllMethods chain.proceed(chain.args.toTypedArray())
            }
        } catch (t: Throwable) { HookLog.swallowed("SystemLocationServiceHooker.kt:1089", t) }
    }

    val registerNmeaMethods = arrayOf("registerGnssNmeaCallback", "addGnssBatchingCallback", "addNmeaListener")
    for (mName in registerNmeaMethods) {
        try {
            XposedHelpers.hookAllMethods(serviceClazz, mName) { chain, _ ->
                try {
                    val config = readConfig()
                    if (config != null) {
                        val explicitPkg = SystemHookUtils.extractPackageName(chain.args)
                        val overrideUid = SystemHookUtils.extractCallerUid(chain.args)
                        val isTarget = SystemHookUtils.isTargetCaller(chain.thisObject, explicitPkg, config, overrideUid, requireActive = false)
                        if (isTarget) {
                            val callback = chain.args.firstOrNull { arg ->
                                arg != null && (arg is IInterface || arg is IBinder || arg.javaClass.name.contains("Nmea"))
                            }
                            if (callback != null) {
                                val binder = (callback as? IInterface)?.asBinder() ?: (callback as? IBinder)
                                if (binder != null) {
                                    val pkgName = explicitPkg ?: "unknown"
                                    activeGnssNmeaBinders[binder] = GnssNmeaRegistrationInfo(
                                        listener = callback,
                                        packageName = pkgName
                                    )
                                    try {
                                        ModuleBinderDeaths.watch(binder) {
                                            activeGnssNmeaBinders.remove(binder)
                                            logLoc("[SysLoc] NMEA listener died: $pkgName")
                                        }
                                    } catch (t: Throwable) { HookLog.swallowed("SystemLocationServiceHooker.kt:1119", t) }

                                    ensureNmeaCallbackHooked(callback)
                                    val motion = getCurrentSpoofedMotion("WGS-84")
                                    if (motion != null) {
                                        val sentences = buildMockNmeaSentences(motion, RouteEngine.realisticAltitude(config), getJitteredAccuracy(), config)
                                        val nowMs = System.currentTimeMillis()
                                        syntheticNmeaDelivery.withValue(true) {
                                            for (line in sentences) {
                                                dispatchNmea(callback, nowMs, line)
                                            }
                                        }
                                    }
                                    logLoc("[SysLoc] Registered & dispatched NMEA callback for $pkgName (active: ${activeGnssNmeaBinders.size})")
                                }
                            }
                        }
                    }
                } catch (t: Throwable) { HookLog.swallowed("SystemLocationServiceHooker.kt:1137", t) }
                return@hookAllMethods chain.proceed(chain.args.toTypedArray())
            }
        } catch (t: Throwable) { HookLog.swallowed("SystemLocationServiceHooker.kt:1140", t) }
    }

    val unregisterNmeaMethods = arrayOf("unregisterGnssNmeaCallback", "removeNmeaListener")
    for (mName in unregisterNmeaMethods) {
        try {
            XposedHelpers.hookAllMethods(serviceClazz, mName) { chain, _ ->
                val callback = chain.args.firstOrNull { arg ->
                    arg != null && (arg is IInterface || arg is IBinder)
                }
                if (callback != null) {
                    val binder = (callback as? IInterface)?.asBinder() ?: (callback as? IBinder)
                    if (binder != null) {
                        activeGnssNmeaBinders.remove(binder)
                    }
                }
                return@hookAllMethods chain.proceed(chain.args.toTypedArray())
            }
        } catch (t: Throwable) { HookLog.swallowed("SystemLocationServiceHooker.kt:1158", t) }
    }

    // =========================================================================
    // 7. GNSS 原始测量 (registerGnssMeasurementsCallback)
    //    目标 App 注册 raw measurements 时，主动派发与 status/NMEA 同源的合成事件；
    //    否则会出现“有 GPS fix、有 21 颗星，但 measurementEventCount=0”的矛盾。
    // =========================================================================
    val registerMeasurementMethods = arrayOf("addGnssMeasurementsListener")
    for (mName in registerMeasurementMethods) {
        try {
            XposedHelpers.hookAllMethods(serviceClazz, mName) { chain, _ ->
                try {
                    val config = readConfig()
                    if (config != null) {
                        val explicitPkg = SystemHookUtils.extractPackageName(chain.args)
                        val overrideUid = SystemHookUtils.extractCallerUid(chain.args)
                        val isTarget = SystemHookUtils.isTargetCaller(chain.thisObject, explicitPkg, config, overrideUid, requireActive = false)
                        if (isTarget) {
                            val callback = chain.args.firstOrNull { arg ->
                                arg != null && (arg is IInterface || arg is IBinder ||
                                        arg.javaClass.name.contains("GnssMeasurements") ||
                                        arg.javaClass.name.contains("MeasurementsCallback"))
                            }
                            if (callback != null) {
                                val binder = (callback as? IInterface)?.asBinder() ?: (callback as? IBinder)
                                if (binder != null) {
                                    val pkgName = explicitPkg ?: "unknown"
                                    activeGnssMeasurementBinders[binder] = GnssMeasurementRegistrationInfo(
                                        listener = callback,
                                        packageName = pkgName
                                    )
                                    try {
                                        ModuleBinderDeaths.watch(binder) {
                                            activeGnssMeasurementBinders.remove(binder)
                                            logLoc("[SysLoc] GNSS measurement listener died: $pkgName")
                                        }
                                    } catch (t: Throwable) { HookLog.swallowed("SystemLocationServiceHooker.kt:1195", t) }
                                    ensureMeasurementCallbackHooked(callback)

                                    val event = GnssMeasurementsFactory.build(
                                        classLoader,
                                        config.optInt(ConfigKeys.SATELLITE_COUNT, 20),
                                        config.optBoolean(ConfigKeys.ENABLE_JITTER, true),
                                        config.optLong(ConfigKeys.START_TIMESTAMP, 0L),
                                        config.optDouble(ConfigKeys.SPEED_M_S, 0.0)
                                    )
                                    if (event != null) {
                                        dispatchGnssMeasurements(callback, event)
                                    }
                                    logLoc("[SysLoc] Registered GNSS measurement callback for $pkgName (active: ${activeGnssMeasurementBinders.size})")
                                }
                            }
                        }
                    }
                } catch (t: Throwable) { HookLog.swallowed("SystemLocationServiceHooker.kt:1213", t) }
                return@hookAllMethods chain.proceed(chain.args.toTypedArray())
            }
        } catch (t: Throwable) { HookLog.swallowed("SystemLocationServiceHooker.kt:1216", t) }
    }

    val unregisterMeasurementMethods = arrayOf("removeGnssMeasurementsListener")
    for (mName in unregisterMeasurementMethods) {
        try {
            XposedHelpers.hookAllMethods(serviceClazz, mName) { chain, _ ->
                val callback = chain.args.firstOrNull { arg ->
                    arg != null && (arg is IInterface || arg is IBinder)
                }
                if (callback != null) {
                    val binder = (callback as? IInterface)?.asBinder() ?: (callback as? IBinder)
                    if (binder != null) {
                        activeGnssMeasurementBinders.remove(binder)
                    }
                }
                return@hookAllMethods chain.proceed(chain.args.toTypedArray())
            }
        } catch (t: Throwable) { HookLog.swallowed("SystemLocationServiceHooker.kt:1234", t) }
    }

    try {
        XposedHelpers.hookAllMethods(serviceClazz, "getGnssYearOfHardware") { chain, _ ->
            val result = chain.proceed(chain.args.toTypedArray()) as? Int
            if (result == null || result < 2020) {
                return@hookAllMethods 2024
            }
            return@hookAllMethods result
        }
    } catch (t: Throwable) { HookLog.swallowed("SystemLocationServiceHooker.kt:1245", t) }

    // 屏蔽目标应用的底层伪距与导航电文回调，防止泄露真实原始测量特征
    val suppressCallbackMethods = arrayOf("registerGnssMeasurementsCallback", "registerGnssNavigationMessageCallback")
    for (mName in suppressCallbackMethods) {
        try {
            XposedHelpers.hookAllMethods(serviceClazz, mName) { chain, _ ->
                val config = readConfig()
                if (config != null && config.optBoolean(ConfigKeys.ACTIVE, false)) {
                    val explicitPkg = SystemHookUtils.extractPackageName(chain.args)
                    if (SystemHookUtils.isTargetCaller(chain.thisObject, explicitPkg, config)) {
                        val cb = chain.args.firstOrNull { arg ->
                            arg != null && arg !is String && arg !is Int
                        }
                        if (cb != null) {
                            suppressCallbackMethods(cb, "onGnssMeasurementsReceived", "onGnssNavigationMessageReceived")
                        }
                    }
                }
                return@hookAllMethods chain.proceed(chain.args.toTypedArray())
            }
        } catch (t: Throwable) { HookLog.swallowed("SystemLocationServiceHooker.kt:1266", t) }
    }

    if (!VendorRegistry.active.usesFrameworkLocationDelivery) {
    // =========================================================================
    // 7. LocationProviderManager 底层引擎挂载 (Android 12+)
    // 直接在 providerManager 层拦截 getLastLocation 与 getCurrentLocation，
    // 全面覆盖所有原生与定制 provider ("gps", "network", "fused", "passive")
    // =========================================================================
    val providerManagerClazz = SystemClassLocator.locate(SystemComponent.LOCATION_PROVIDER_MANAGER, classLoader)
    if (providerManagerClazz != null && hookedCallbackClasses.putIfAbsent(providerManagerClazz, true) == null) {
        try {
            val getLastLocationMethods = arrayOf("getLastLocation", "getLastLocationUnsafe")
            for (mName in getLastLocationMethods) {
                XposedHelpers.hookAllMethods(providerManagerClazz, mName) { chain, _ ->
                    val config = readConfig() ?: return@hookAllMethods chain.proceed(chain.args.toTypedArray())
                    val pkgName = SystemHookUtils.extractPackageName(chain.args)
                    val overrideUid = SystemHookUtils.extractCallerUid(chain.args)
                    val isTarget = SystemHookUtils.isTargetCaller(chain.thisObject, pkgName, config, overrideUid)
                    if (isTarget) {
                        val motion = getCurrentSpoofedMotion("WGS-84")
                        if (motion != null) {
                            val provider = try {
                                XposedHelpers.getObjectField(chain.thisObject, "mName") as? String
                            } catch (_: Throwable) { null } ?: SystemHookUtils.extractProvider(chain.args)
                            val fakeLoc = SystemHookUtils.buildFakeLocation(
                                classLoader,
                                provider,
                                motion,
                                RouteEngine.realisticAltitude(config),
                                getJitteredAccuracy()
                            )
                            if (fakeLoc != null) {
                                logLoc("[SysLoc] LocationProviderManager.$mName intercepted for $pkgName (lat=${motion.lat}, lng=${motion.lng}, provider=$provider)")
                                return@hookAllMethods fakeLoc
                            }
                        }
                    }
                    return@hookAllMethods null
                }
            }
            logLoc("[SysLoc] LocationProviderManager.getLastLocation hooked")
        } catch (e: Throwable) {
            logLoc("[SysLoc] hook LocationProviderManager.getLastLocation failed: $e")
        }

        try {
            XposedHelpers.hookAllMethods(providerManagerClazz, "getCurrentLocation") { chain, _ ->
                try {
                    val config = readConfig()
                    if (config != null) {
                        val pkgName = SystemHookUtils.extractPackageName(chain.args)
                        val overrideUid = SystemHookUtils.extractCallerUid(chain.args)
                        val isTarget = SystemHookUtils.isTargetCaller(chain.thisObject, pkgName, config, overrideUid, requireActive = false)
                        if (isTarget) {
                            val callback = chain.args.firstOrNull { arg ->
                                arg != null && LocationHooker.hasTypeByName(
                                    arg.javaClass,
                                    "android.location.ILocationCallback"
                                )
                            }
                            if (callback != null) {
                                val binder = (callback as? IInterface)?.asBinder() ?: (callback as? IBinder)
                                val targetPkg = pkgName ?: "caller"
                                val provider = try {
                                    XposedHelpers.getObjectField(chain.thisObject, "mName") as? String
                                } catch (_: Throwable) { null } ?: SystemHookUtils.extractProvider(chain.args)
                                if (binder != null) {
                                    activeCallbackBinders[binder] = CallbackRegistrationInfo(
                                        callback = callback,
                                        packageName = targetPkg,
                                        provider = provider
                                    )
                                    try {
                                        ModuleBinderDeaths.watch(binder) { activeCallbackBinders.remove(binder) }
                                    } catch (t: Throwable) { HookLog.swallowed("SystemLocationServiceHooker.kt:1337", t) }
                                }
                                spoofedListenerInstances.add(callback)
                                ensureCallbackHooked(callback, "onLocation")
                                val motion = getCurrentSpoofedMotion("WGS-84")
                                if (motion != null) {
                                    val fakeLoc = SystemHookUtils.buildFakeLocation(
                                        classLoader,
                                        provider,
                                        motion,
                                        RouteEngine.realisticAltitude(config),
                                        getJitteredAccuracy()
                                    )
                                    if (fakeLoc != null) {
                                        val onLocMethod = callback.javaClass.methods.firstOrNull {
                                            it.name == "onLocation" && it.parameterTypes.size == 1
                                        }
                                        onLocMethod?.invoke(callback, fakeLoc)
                                        logLoc("[SysLoc] LocationProviderManager.getCurrentLocation proactive dispatch for $targetPkg (lat=${motion.lat}, lng=${motion.lng}, provider=$provider)")
                                        binder?.let { activeCallbackBinders.remove(it) }
                                        return@hookAllMethods createDummyCancellationSignal()
                                    }
                                }
                            }
                        }
                    }
                } catch (t: Throwable) { HookLog.swallowed("SystemLocationServiceHooker.kt:1365", t) }
                return@hookAllMethods chain.proceed(chain.args.toTypedArray())
            }
            logLoc("[SysLoc] LocationProviderManager.getCurrentLocation hooked")
        } catch (e: Throwable) {
            logLoc("[SysLoc] hook LocationProviderManager.getCurrentLocation failed: $e")
        }

        val registerMethodNames = arrayOf("registerLocationRequest", "registerLocationListener", "registerLocationPendingIntent")
        for (mName in registerMethodNames) {
            try {
                XposedHelpers.hookAllMethods(providerManagerClazz, mName) { chain, _ ->
                    val config = readConfig()
                    if (config != null) {
                        val pkgName = SystemHookUtils.extractPackageName(chain.args)
                        val overrideUid = SystemHookUtils.extractCallerUid(chain.args)
                        val isTarget = SystemHookUtils.isTargetCaller(chain.thisObject, pkgName, config, overrideUid, requireActive = false)
                        if (isTarget) {
                            var listener = chain.args.firstOrNull { arg ->
                                arg != null && (LocationHooker.hasTypeByName(arg.javaClass, "android.location.ILocationListener") ||
                                        arg.javaClass.simpleName.contains("Listener"))
                            }
                            if (listener == null) {
                                for (arg in chain.args) {
                                    if (arg != null && arg.javaClass.simpleName.contains("Registration")) {
                                        try {
                                            listener = XposedHelpers.getObjectField(arg, "mListener")
                                            if (listener != null) break
                                        } catch (t: Throwable) { HookLog.swallowed("SystemLocationServiceHooker.kt:1393", t) }
                                        try {
                                            listener = XposedHelpers.callMethod(arg, "getListener")
                                            if (listener != null) break
                                        } catch (t: Throwable) { HookLog.swallowed("SystemLocationServiceHooker.kt:1397", t) }
                                    }
                                }
                            }
                            val providerName = try {
                                XposedHelpers.getObjectField(chain.thisObject, "mName") as? String
                            } catch (_: Throwable) { null } ?: SystemHookUtils.extractProvider(chain.args)

                            if (listener != null) {
                                val binder = (listener as? IInterface)?.asBinder() ?: (listener as? IBinder)
                                if (binder != null) {
                                    activeListenerBinders[binder] = ListenerRegistrationInfo(
                                        listener = listener,
                                        packageName = pkgName ?: "target",
                                        provider = providerName
                                    )
                                    try { ModuleBinderDeaths.watch(binder) { activeListenerBinders.remove(binder) } } catch (t: Throwable) { HookLog.swallowed("SystemLocationServiceHooker.kt:1413", t) }
                                }
                                spoofedListenerInstances.add(listener)
                                ensureCallbackHooked(listener, "onLocationChanged")

                                // 立即主动投递首帧伪造位置
                                val motion = getCurrentSpoofedMotion("WGS-84")
                                if (motion != null) {
                                    val fakeLoc = SystemHookUtils.buildFakeLocation(
                                        classLoader,
                                        providerName,
                                        motion,
                                        RouteEngine.realisticAltitude(config),
                                        getJitteredAccuracy()
                                    )
                                    if (fakeLoc != null) {
                                        try {
                                            dispatchFakeLocationToListener(listener, fakeLoc)
                                            logLoc("[SysLoc] LocationProviderManager.$mName proactive dispatch for $pkgName (lat=${motion.lat}, lng=${motion.lng}, provider=$providerName)")
                                        } catch (t: Throwable) {
                                            logLoc("[SysLoc] proactive dispatch error: $t")
                                        }
                                    }
                                }
                                logLoc("[SysLoc] LocationProviderManager.$mName captured for $pkgName (active listeners: ${activeListenerBinders.size})")
                            }

                            val pi = chain.args.firstOrNull { it is android.app.PendingIntent } as? android.app.PendingIntent
                            if (pi != null) {
                                val targetPkg = pkgName ?: pi.creatorPackage ?: "target"
                                activePendingIntents[pi] = targetPkg
                                logLoc("[SysLoc] LocationProviderManager.$mName PendingIntent captured for $targetPkg")
                            }
                        }
                    }
                    return@hookAllMethods chain.proceed(chain.args.toTypedArray())
                }
                logLoc("[SysLoc] LocationProviderManager.$mName hooked")
            } catch (e: Throwable) {
                logLoc("[SysLoc] hook LocationProviderManager.$mName failed: $e")
            }
        }

        val unregisterMethods = arrayOf("unregisterLocationRequest", "unregisterLocationListener")
        for (mName in unregisterMethods) {
            try {
                XposedHelpers.hookAllMethods(providerManagerClazz, mName) { chain, _ ->
                    try {
                        for (arg in chain.args) {
                            if (arg != null) {
                                val binder = (arg as? IInterface)?.asBinder() ?: (arg as? IBinder)
                                if (binder != null) {
                                    activeListenerBinders.remove(binder)
                                }
                                spoofedListenerInstances.remove(arg)
                            }
                        }
                    } catch (t: Throwable) { HookLog.swallowed("SystemLocationServiceHooker.kt:1470", t) }
                    return@hookAllMethods chain.proceed(chain.args.toTypedArray())
                }
            } catch (t: Throwable) { HookLog.swallowed("SystemLocationServiceHooker.kt:1473", t) }
        }

        // 核心修复: 拦截底层 Provider 上报真实位置 (onReportLocation)
        // 在全局模拟模式下，直接就地改写 LocationResult，防止 MetokNLP/GPS 真实数据污染系统内部缓存
        try {
            XposedHelpers.hookAllMethods(providerManagerClazz, "onReportLocation") { chain, _ ->
                val config = readConfig()
                if (config != null && config.optBoolean(ConfigKeys.ACTIVE, false)) {
                    val isGlobal = config.optBoolean(ConfigKeys.SYSTEM_HOOK_GLOBAL_MODE, false)
                    if (isGlobal) {
                        val motion = getCurrentSpoofedMotion("WGS-84")
                        if (motion != null) {
                            rewriteLocationArgs(chain.args, motion, RouteEngine.realisticAltitude(config), getJitteredAccuracy())
                            logLoc("[SysLoc] LocationProviderManager.onReportLocation rewrote location globally")
                        }
                    }
                }
                return@hookAllMethods chain.proceed(chain.args.toTypedArray())
            }
            logLoc("[SysLoc] LocationProviderManager.onReportLocation hooked")
        } catch (e: Throwable) {
            logLoc("[SysLoc] hook LocationProviderManager.onReportLocation failed: $e")
        }

        // 核心修复: 拦截向目标注册客户端 (Registration) 分发真实位置的关键节点 acceptLocationChange
        // 彻底解决抖音/淘宝两边跳：当 MetokNLP 或真实 GPS 产生定位推向目标 App 时，在 Registration 处直接改写为模拟坐标
        val regClasses = listOfNotNull(
            XposedHelpers.findClassIfExists("com.android.server.location.provider.LocationProviderManager\$Registration", classLoader),
            XposedHelpers.findClassIfExists("com.android.server.location.provider.LocationProviderManager\$LocationRegistration", classLoader),
            XposedHelpers.findClassIfExists("com.android.server.location.provider.LocationProviderManager\$LocationListenerRegistration", classLoader)
        )
        for (regClazz in regClasses) {
            if (hookedCallbackClasses.putIfAbsent(regClazz, true) != null) continue
            try {
                XposedHelpers.hookAllMethods(regClazz, "acceptLocationChange") { chain, _ ->
                    val config = readConfig()
                    if (config != null && config.optBoolean(ConfigKeys.ACTIVE, false)) {
                        val identity = try {
                            XposedHelpers.getObjectField(chain.thisObject, "mIdentity")
                        } catch (_: Throwable) {
                            try { XposedHelpers.callMethod(chain.thisObject, "getIdentity") } catch (_: Throwable) { null }
                        }
                        val pkg = identity?.let {
                            try { XposedHelpers.callMethod(it, "getPackageName") as? String } catch (_: Throwable) {
                                try { XposedHelpers.getObjectField(it, "mPackageName") as? String } catch (_: Throwable) { null }
                            }
                        }
                        val uid = identity?.let {
                            try { XposedHelpers.callMethod(it, "getUid") as? Int } catch (_: Throwable) {
                                try { XposedHelpers.getIntField(it, "mUid") } catch (_: Throwable) { null }
                            }
                        }
                        val isTarget = SystemHookUtils.isTargetCaller(chain.thisObject, pkg, config, uid)
                        if (isTarget) {
                            val motion = getCurrentSpoofedMotion("WGS-84")
                            if (motion != null) {
                                rewriteLocationArgs(chain.args, motion, RouteEngine.realisticAltitude(config), getJitteredAccuracy())
                                logLoc("[SysLoc] Registration.acceptLocationChange rewrote location for $pkg (lat=${motion.lat}, lng=${motion.lng})")
                            }
                        }
                    }
                    return@hookAllMethods chain.proceed(chain.args.toTypedArray())
                }
                logLoc("[SysLoc] ${regClazz.name}.acceptLocationChange hooked")
            } catch (e: Throwable) {
                logLoc("[SysLoc] hook ${regClazz.name}.acceptLocationChange failed: $e")
            }
        }

        // 核心修复: 拦截向目标 Binder 派发位置的 ProviderTransport
        val transportClasses = listOfNotNull(
            XposedHelpers.findClassIfExists("com.android.server.location.provider.LocationProviderManager\$LocationListenerTransport", classLoader),
            XposedHelpers.findClassIfExists("com.android.server.location.provider.LocationProviderManager\$LocationPendingIntentTransport", classLoader),
            XposedHelpers.findClassIfExists("com.android.server.location.provider.LocationProviderManager\$GetCurrentLocationTransport", classLoader)
        )
        for (tClazz in transportClasses) {
            if (hookedCallbackClasses.putIfAbsent(tClazz, true) != null) continue
            try {
                XposedHelpers.hookAllMethods(tClazz, "deliverOnLocationChanged") { chain, _ ->
                    val config = readConfig()
                    if (config != null && config.optBoolean(ConfigKeys.ACTIVE, false)) {
                        val isGlobal = config.optBoolean(ConfigKeys.SYSTEM_HOOK_GLOBAL_MODE, false)
                        var isTarget = isGlobal
                        if (!isTarget) {
                            val listener = try { XposedHelpers.getObjectField(chain.thisObject, "mListener") } catch (_: Throwable) { null }
                            val binder = (listener as? IInterface)?.asBinder() ?: (listener as? IBinder)
                            if (binder != null && activeListenerBinders.containsKey(binder)) {
                                isTarget = true
                            } else if (listener != null && spoofedListenerInstances.contains(listener)) {
                                isTarget = true
                            }
                            if (!isTarget) {
                                val pi = try { XposedHelpers.getObjectField(chain.thisObject, "mPendingIntent") as? android.app.PendingIntent } catch (_: Throwable) { null }
                                if (pi != null && activePendingIntents.containsKey(pi)) {
                                    isTarget = true
                                }
                            }
                            if (!isTarget) {
                                val cb = try { XposedHelpers.getObjectField(chain.thisObject, "mCallback") } catch (_: Throwable) { null }
                                val cbBinder = (cb as? IInterface)?.asBinder() ?: (cb as? IBinder)
                                if (cbBinder != null && activeCallbackBinders.containsKey(cbBinder)) {
                                    isTarget = true
                                } else if (cb != null && spoofedListenerInstances.contains(cb)) {
                                    isTarget = true
                                }
                            }
                        }
                        if (isTarget) {
                            val motion = getCurrentSpoofedMotion("WGS-84")
                            if (motion != null) {
                                rewriteLocationArgs(chain.args, motion, RouteEngine.realisticAltitude(config), getJitteredAccuracy())
                                logLoc("[SysLoc] ${tClazz.simpleName}.deliverOnLocationChanged rewrote location (lat=${motion.lat}, lng=${motion.lng})")
                            }
                        }
                    }
                    return@hookAllMethods chain.proceed(chain.args.toTypedArray())
                }
                logLoc("[SysLoc] ${tClazz.name}.deliverOnLocationChanged hooked")
            } catch (e: Throwable) {
                logLoc("[SysLoc] hook ${tClazz.name}.deliverOnLocationChanged failed: $e")
            }
        }
    }

    }

    // =========================================================================
    // 8. 逆地理编码 Geocoder 拦截 (reverseGeocode / getFromLocation)
    // 防止系统 Geocoder（如小米 MetokGeocodeService / MetokNLP）返回真实住址
    // =========================================================================
    val geocodeMethods = arrayOf("reverseGeocode", "forwardGeocode", "getFromLocation")
    for (mName in geocodeMethods) {
        try {
            XposedHelpers.hookAllMethods(serviceClazz, mName) { chain, _ ->
                val config = readConfig()
                if (config != null && config.optBoolean(ConfigKeys.ACTIVE, false)) {
                    val explicitPkg = SystemHookUtils.extractPackageName(chain.args)
                    val overrideUid = SystemHookUtils.extractCallerUid(chain.args)
                    val isTarget = SystemHookUtils.isTargetCaller(chain.thisObject, explicitPkg, config, overrideUid)
                    if (isTarget) {
                        val motion = getCurrentSpoofedMotion("GCJ-02")
                        if (motion != null) {
                            try {
                                val addressClass = XposedHelpers.findClass("android.location.Address", classLoader)
                                val addressObj = XposedHelpers.newInstance(addressClass, java.util.Locale.getDefault())
                                XposedHelpers.callMethod(addressObj, "setLatitude", motion.lat)
                                XposedHelpers.callMethod(addressObj, "setLongitude", motion.lng)
                                val province = cachedProvince.ifEmpty { "北京市" }
                                val city = cachedCity.ifEmpty { "北京市" }
                                val district = cachedDistrict.ifEmpty { "东城区" }
                                val street = cachedStreet.ifEmpty { "南长街" }
                                val fullAddr = cachedAddress.ifEmpty { "$province$city$district$street" }
                                XposedHelpers.callMethod(addressObj, "setAdminArea", province)
                                XposedHelpers.callMethod(addressObj, "setLocality", city)
                                XposedHelpers.callMethod(addressObj, "setSubLocality", district)
                                XposedHelpers.callMethod(addressObj, "setThoroughfare", street)
                                XposedHelpers.callMethod(addressObj, "setAddressLine", 0, fullAddr)

                                // 1. 回调式接口 (Android 13+ IGeocodeListener)
                                val listener = chain.args.firstOrNull { arg ->
                                    arg != null && (arg is IInterface || arg is IBinder ||
                                            arg.javaClass.simpleName.contains("Listener") ||
                                            arg.javaClass.simpleName.contains("Callback"))
                                }
                                if (listener != null) {
                                    val onResultsMethod = listener.javaClass.methods.firstOrNull {
                                        it.name == "onResults" || it.name == "onGeocode" || it.name == "onLocation"
                                    }
                                    if (onResultsMethod != null) {
                                        val params = arrayOfNulls<Any>(onResultsMethod.parameterTypes.size)
                                        for (i in params.indices) {
                                            val pType = onResultsMethod.parameterTypes[i]
                                            if (List::class.java.isAssignableFrom(pType)) {
                                                params[i] = listOf(addressObj)
                                            } else if (pType == addressClass) {
                                                params[i] = addressObj
                                            }
                                        }
                                        onResultsMethod.invoke(listener, *params)
                                        logLoc("[SysLoc] Intercepted $mName (callback) for ${explicitPkg ?: "caller"}, returned: $fullAddr")
                                        return@hookAllMethods null
                                    }
                                }

                                // 2. 入参集合修改 (Android 11-12 inout List<Address>)
                                @Suppress("UNCHECKED_CAST")
                                val addrs = chain.args.firstOrNull { it is List<*> } as? MutableList<Any>
                                if (addrs != null) {
                                    addrs.clear()
                                    addrs.add(addressObj)
                                    logLoc("[SysLoc] Intercepted $mName (inout list) for ${explicitPkg ?: "caller"}, returned: $fullAddr")
                                    return@hookAllMethods null
                                }

                                logLoc("[SysLoc] Intercepted $mName for ${explicitPkg ?: "caller"}, returned: $fullAddr")
                                return@hookAllMethods listOf(addressObj)
                            } catch (e: Throwable) {
                                logLoc("[SysLoc] mock Geocoder Address failed: $e")
                            }
                        }
                    }
                }
                return@hookAllMethods chain.proceed(chain.args.toTypedArray())
            }
            logLoc("[SysLoc] LocationManagerService.$mName hooked")
        } catch (e: Throwable) {
            logLoc("[SysLoc] hook $mName failed: $e")
        }
    }

    if (!VendorRegistry.active.usesFrameworkLocationDelivery) hookPendingIntentDelivery(classLoader)
}

/** 拦截 PendingIntent.send(...) 改写通过 PendingIntent 投递给目标应用的 Location 广播与服务 Intent */
private fun LocationHooker.hookPendingIntentDelivery(classLoader: ClassLoader) {
    val piClass = XposedHelpers.findClassIfExists("android.app.PendingIntent", classLoader) ?: return
    if (hookedCallbackClasses.putIfAbsent(piClass, true) != null) return

    XposedHelpers.hookAllMethods(piClass, "send") { chain, _ ->
        val config = readConfig()
        if (config != null && config.optBoolean(ConfigKeys.ACTIVE, false)) {
            val pi = chain.thisObject as? android.app.PendingIntent
            val isTarget = if (pi != null && activePendingIntents.containsKey(pi)) {
                true
            } else {
                val pkg = pi?.creatorPackage
                pkg != null && SystemHookUtils.isTargetCaller(chain.thisObject, pkg, config)
            }
            if (isTarget) {
                val motion = getCurrentSpoofedMotion("WGS-84")
                if (motion != null) {
                    val altitude = RouteEngine.realisticAltitude(config)
                    val accuracy = getJitteredAccuracy()
                    for (arg in chain.args) {
                        if (arg is android.content.Intent) {
                            @Suppress("DEPRECATION")
                            val loc = arg.getParcelableExtra<android.location.Location>(android.location.LocationManager.KEY_LOCATION_CHANGED)
                                ?: arg.getParcelableExtra<android.location.Location>("location")
                            if (loc != null) {
                                SystemHookUtils.applyFakeLocationFields(loc, motion, altitude, accuracy)
                            }
                            try {
                                @Suppress("DEPRECATION")
                                val locList = arg.getParcelableArrayListExtra<android.location.Location>("locations")
                                locList?.forEach { SystemHookUtils.applyFakeLocationFields(it, motion, altitude, accuracy) }
                            } catch (t: Throwable) { HookLog.swallowed("SystemLocationServiceHooker.kt:1719", t) }
                        }
                    }
                }
            }
        }
        return@hookAllMethods chain.proceed(chain.args.toTypedArray())
    }
    logLoc("[SysLoc] PendingIntent.send hooked for location intent rewrite")
}

/** Hook IGnssStatusListener 实例的 onSvStatusChanged 回调，注入 20+ 真实卫星矩阵 */
private fun LocationHooker.hookGnssStatusListenerCallback(listener: Any) {
    val clazz = listener.javaClass
    if (hookedCallbackClasses.putIfAbsent(clazz, true) != null) return

    try {
        XposedHelpers.hookAllMethods(clazz, "onSvStatusChanged") { chain, _ ->
            val config = readConfig()
            if (config != null && config.optBoolean(ConfigKeys.ACTIVE, false)) {
                val args = chain.args
                val satCount = config.optInt(ConfigKeys.SATELLITE_COUNT, 20)
                val enableJitter = config.optBoolean(ConfigKeys.ENABLE_JITTER, true)

                if (args.size == 1) {
                    // Android 11+ 标准：GnssStatus 单参数
                    val fakeStatus = GnssFastMockEngine.getOrCreateSpoofedGnssStatus(
                        clazz.classLoader ?: ClassLoader.getSystemClassLoader(),
                        satCount,
                        enableJitter,
                        args[0]
                    )
                    if (fakeStatus != null) {
                        return@hookAllMethods chain.proceed(arrayOf(fakeStatus))
                    }
                } else if (args.size == 6 || args.size == 7) {
                    // Android 7~10：6 个数组参数；Android 11：7 个（额外 basebandCn0s）。
                    // 使用与 NMEA/心跳相同的卫星模型，并按对应版本的位布局打包
                    // svidWithFlags，避免 SVID/星座类型全部解错。
                    val legacy = buildLegacyGnssArrays(
                        config,
                        System.currentTimeMillis(),
                        includeBaseband = args.size >= 7
                    )

                    val newArgs = args.toMutableList()
                    newArgs[0] = legacy.svCount
                    newArgs[1] = legacy.svidWithFlags
                    newArgs[2] = legacy.cn0DbHz
                    newArgs[3] = legacy.elevations
                    newArgs[4] = legacy.azimuths
                    newArgs[5] = legacy.carrierFrequencies
                    if (args.size >= 7) {
                        // 长度必须与 svCount 一致，否则 App 侧 GnssStatus.wrap 会因
                        // baseband 数组过短而抛异常。
                        newArgs[6] = legacy.basebandCn0DbHz ?: FloatArray(legacy.svCount)
                    }
                    return@hookAllMethods chain.proceed(newArgs.toTypedArray())
                }
            }
            return@hookAllMethods chain.proceed(chain.args.toTypedArray())
        }
    } catch (t: Throwable) { HookLog.swallowed("SystemLocationServiceHooker.kt:1789", t) }
}

/** 吞掉真实 GNSS 测量回调 */
private fun suppressCallbackMethods(callback: Any, vararg methodNames: String) {
    val clazz = callback.javaClass
    for (mName in methodNames) {
        try {
            XposedHelpers.hookAllMethods(clazz, mName) { innerChain, _ ->
                return@hookAllMethods null
            }
        } catch (t: Throwable) { HookLog.swallowed("SystemLocationServiceHooker.kt:1800", t) }
    }
}
