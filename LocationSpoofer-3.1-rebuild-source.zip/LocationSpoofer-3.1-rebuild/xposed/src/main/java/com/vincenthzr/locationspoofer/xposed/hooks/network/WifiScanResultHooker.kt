@file:Suppress(
    "UNUSED_PARAMETER",
    "UNUSED_VARIABLE",
    "UNNECESSARY_NOT_NULL_ASSERTION",
    "DEPRECATION",
    "NAME_SHADOWING",
    "FunctionName",
    "PrivatePropertyName",
    "SpellCheckingInspection",
    "RedundantUnitReturnType",
    "RemoveRedundantQualifierName",
    "OPT_IN_USAGE",
    "unused",
    "UnusedImport"
)

package com.vincenthzr.locationspoofer.xposed.hooks.network

import com.vincenthzr.locationspoofer.xposed.utils.HookLog

import com.vincenthzr.locationspoofer.utils.ConfigKeys

import com.vincenthzr.locationspoofer.xposed.LocationHooker
import com.vincenthzr.locationspoofer.xposed.utils.*
import com.vincenthzr.locationspoofer.xposed.hooks.*
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import java.lang.reflect.Member
import java.lang.reflect.Method
import java.lang.reflect.Proxy
import java.lang.reflect.InvocationHandler
import java.lang.reflect.Array as ReflectArray
import kotlin.math.*
import io.github.libxposed.api.*

/**
 * Wi-Fi 环境伪造模块入口，以及 WifiManager.getScanResults() 扫描结果伪造。
 */
internal fun LocationHooker.hookWifiEnvironment(
    classLoader: ClassLoader,
    isCoreSystemProcess: Boolean = false
) {
    hookWifiScanResults(classLoader)
    hookWifiConnectionInfo(classLoader, isCoreSystemProcess)
    hookWifiState(classLoader, isCoreSystemProcess)
}

internal fun LocationHooker.hookWifiScanResults(classLoader: ClassLoader) {
    val realCapabilities = listOf(
        "[WPA2-PSK-CCMP][RSN-PSK-CCMP][ESS]",
        "[WPA2-PSK-CCMP+TKIP][RSN-PSK-CCMP+TKIP][ESS]",
        "[WPA2-PSK-CCMP][ESS][WPS]",
        "[WPA-PSK-TKIP+CCMP][WPA2-PSK-TKIP+CCMP][ESS]",
        "[RSN-PSK-CCMP][ESS]",
        "[WPA2-EAP-CCMP][RSN-EAP-CCMP][ESS]",
        "[ESS]",
        "[WPA2-PSK-CCMP][RSN-PSK-CCMP][ESS][WPS]",
        "[WPA2-SAE-CCMP][RSN-SAE-CCMP][ESS]",
        "[WPA2-PSK+SAE-CCMP][RSN-PSK+SAE-CCMP][ESS]"
    )

    // Wi-Fi 扫描结果伪造 (getScanResults)
    try {
        XposedHelpers.hookMethod(
            "android.net.wifi.WifiManager", classLoader, "getScanResults"
        ) { chain, method ->
            val config = readConfig() ?: return@hookMethod chain.proceed(chain.args.toTypedArray())
            if (!config.optBoolean(
                    ConfigKeys.ACTIVE,
                    false
                )
            ) return@hookMethod chain.proceed(chain.args.toTypedArray())
            val fakeList = java.util.ArrayList<Any>()
            val mockWifi = config.optBoolean(ConfigKeys.MOCK_WIFI, true)
            val wifiObj = if (mockWifi) config.optJSONObject(ConfigKeys.WIFI_JSON_2) else null
            if (mockWifi) {
                try {
                    val scanResultClass =
                        XposedHelpers.findClass("android.net.wifi.ScanResult", classLoader)
                    val baseTimestamp = android.os.SystemClock.elapsedRealtimeNanos()

                    fun addFakeScanResult(wifi: org.json.JSONObject, forceKeep: Boolean = false) {
                        val ssidVal = wifi.optString(ConfigKeys.SSID, "")
                        val bssidVal = wifi.optString(ConfigKeys.BSSID, "")
                        if (!forceKeep) {
                            val bucket = System.currentTimeMillis() / 7000L
                            var h = bssidVal.hashCode().toLong() *
                                -7046029254386353131L + bucket
                            h = (h xor (h ushr 33)) * -4658895280553007687L
                            val u = (h xor (h ushr 31)) ushr 11
                            if (u % 100L < 7L) return
                        }
                        val fakeScanResult = XposedHelpers.newInstance(scanResultClass)
                        val finalSsid = if (ssidVal.isEmpty() || ssidVal == "<unknown ssid>") {
                            "WIFI_${bssidVal.takeLast(5).replace(":", "")}"
                        } else {
                            ssidVal
                        }
                        XposedHelpers.setObjectField(fakeScanResult, "SSID", finalSsid)
                        XposedHelpers.setObjectField(fakeScanResult, "BSSID", bssidVal)
                        val level = wifi.optInt(ConfigKeys.LEVEL, -65)
                        XposedHelpers.setIntField(fakeScanResult, "level", level)
                        XposedHelpers.setIntField(
                            fakeScanResult, "frequency",
                            wifi.optInt(ConfigKeys.FREQUENCY, 2412)
                        )
                        XposedHelpers.setObjectField(
                            fakeScanResult, "capabilities",
                            wifi.optString(ConfigKeys.CAPABILITIES, realCapabilities.random())
                        )
                        // 适配 ColorOS / OxygenOS / HyperOS: 必须初始化 informationElements 和 radioChainInfos，否则 ColorOS OplusWifiScanStatistics 会报 NPE 导致 system_server 崩溃重启进入安全模式
                        try {
                            val ieClass = XposedHelpers.findClassIfExists(
                                "android.net.wifi.ScanResult\$InformationElement",
                                classLoader
                            )
                            if (ieClass != null) {
                                val emptyIeArray = ReflectArray.newInstance(ieClass, 0)
                                XposedHelpers.setObjectField(fakeScanResult, "informationElements", emptyIeArray)
                            }
                        } catch (t: Throwable) { HookLog.swallowed("WifiScanResultHooker.kt:119", t) }
                        try {
                            val rciClass = XposedHelpers.findClassIfExists(
                                "android.net.wifi.ScanResult\$RadioChainInfo",
                                classLoader
                            )
                            if (rciClass != null) {
                                val emptyRciArray = ReflectArray.newInstance(rciClass, 0)
                                XposedHelpers.setObjectField(fakeScanResult, "radioChainInfos", emptyRciArray)
                            }
                        } catch (t: Throwable) { HookLog.swallowed("WifiScanResultHooker.kt:130", t) }
                        try {
                            val offsetNanos = (rng.nextInt(3_000_000) * 1000L)
                            XposedHelpers.setLongField(
                                fakeScanResult, "timestamp",
                                (baseTimestamp - offsetNanos) / 1000
                            )
                        } catch (t: Throwable) { HookLog.swallowed("WifiScanResultHooker.kt:138", t) }
                        fakeList.add(fakeScanResult)
                    }

                    if (wifiObj != null) {
                        val isConnected = wifiObj.optBoolean(ConfigKeys.IS_CONNECTED, false)
                        val connectedWifi =
                            if (isConnected) wifiObj.optJSONObject(ConfigKeys.CONNECTED_WIFI) else null
                        if (connectedWifi != null) {
                            addFakeScanResult(connectedWifi, forceKeep = true)
                        }

                        val nearbyArray = wifiObj.optJSONArray(ConfigKeys.NEARBY_WIFI)
                        if (nearbyArray != null) {
                            for (i in 0 until nearbyArray.length()) {
                                val wifi = nearbyArray.getJSONObject(i)
                                addFakeScanResult(wifi)
                            }
                        }
                    }

                    if (wifiObj == null && fakeList.isEmpty()) {
                        val lat = config.optDouble(ConfigKeys.LAT, 0.0)
                        val lng = config.optDouble(ConfigKeys.LNG, 0.0)
                        val seed = ((lat * 100000).toLong() xor (lng * 100000).toLong())
                        val random = java.util.Random(seed)
                        for (i in 0 until 5) {
                            val fakeWifi = org.json.JSONObject()
                            fakeWifi.put(ConfigKeys.SSID, "WIFI_${random.nextInt(9000) + 1000}")
                            val bssid = String.format(
                                "%02x:%02x:%02x:%02x:%02x:%02x",
                                random.nextInt(256), random.nextInt(256), random.nextInt(256),
                                random.nextInt(256), random.nextInt(256), random.nextInt(256)
                            )
                            fakeWifi.put(ConfigKeys.BSSID, bssid)
                            fakeWifi.put(ConfigKeys.LEVEL, -40 - random.nextInt(50))
                            fakeWifi.put(ConfigKeys.FREQUENCY, if (random.nextBoolean()) 2412 else 5180)
                            fakeWifi.put(ConfigKeys.CAPABILITIES, "[WPA2-PSK-CCMP][ESS]")
                            addFakeScanResult(fakeWifi, forceKeep = true)
                        }
                    }
                } catch (e: Throwable) { /* 忽略 */
                }
            }
            return@hookMethod fakeList
        }
    } catch (e: Throwable) {
        XposedBridge.log(e)
    }
}
