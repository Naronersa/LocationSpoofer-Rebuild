package com.vincenthzr.locationspoofer.xposed.utils

import android.util.Log
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * Hook 兜底异常的统一出口。
 *
 * Hook 回调必须吞掉异常，避免把宿主进程一起带崩；但完全静默会让排障只能靠猜。
 * 这里按调用点限频记录，并累计次数，既保留兜底语义，也不会在 50–200 Hz 回调里刷爆日志。
 */
object HookLog {
    private const val TAG = "LocHook"
    private const val INTERVAL_MS = 60_000L

    private val counts = ConcurrentHashMap<String, AtomicLong>()
    private val lastLoggedAt = ConcurrentHashMap<String, Long>()

    @JvmStatic
    fun swallowed(site: String, error: Throwable) {
        val count = counts.computeIfAbsent(site) { AtomicLong() }.incrementAndGet()
        val now = System.currentTimeMillis()
        val last = lastLoggedAt.putIfAbsent(site, now)
        if (last == null || now - last >= INTERVAL_MS) {
            lastLoggedAt[site] = now
            val message = "swallowed $site #$count: ${error.javaClass.simpleName}: ${error.message}"
            try {
                Log.w(TAG, message, error)
            } catch (_: Throwable) {
                // JVM 单测里 android.util.Log 可能是未实现的桩，退回 stderr。
                System.err.println("$TAG: $message")
            }
        }
    }
}
