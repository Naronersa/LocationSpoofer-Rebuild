@file:Suppress(
    "UNUSED_PARAMETER",
    "UNUSED_VARIABLE",
    "UNNECESSARY_NOT_NULL_ASSERTION",
    "DEPRECATION",
    "NAME_SHADOWING",
    "FunctionName",
    "PrivatePropertyName",
    "SpellCheckingInspection",
    "RedundantUnitReturnType",
    "RemoveRedundantQualifierName",
    "OPT_IN_USAGE",
    "unused",
    "UnusedImport")

package com.vincenthzr.locationspoofer.xposed.hooks

import com.vincenthzr.locationspoofer.xposed.utils.HookLog

import com.vincenthzr.locationspoofer.utils.ConfigKeys

import com.vincenthzr.locationspoofer.xposed.LocationHooker
import com.vincenthzr.locationspoofer.xposed.hooks.vendor.SystemComponent
import com.vincenthzr.locationspoofer.xposed.hooks.vendor.SystemClassLocator
import com.vincenthzr.locationspoofer.xposed.utils.XposedBridge
import com.vincenthzr.locationspoofer.xposed.utils.XposedHelpers
import org.json.JSONObject

private fun sysLog(msg: String) = XposedBridge.log(msg)

/**
 * system_server 级 AppOps 与系统设置（AppOpsService / Settings）环境兼容模块
 *
 * 核心原理：
 * 考勤与第三方 SDK 会通过 AppOpsManager.checkOp(OP_MOCK_LOCATION, ...) 或读取 Settings.Secure
 * 查询系统是否开启了“允许模拟位置”。
 *
 * 本模块在 system_server 中的 AppOpsService 根节点拦截该查询，向目标应用返回 MODE_IGNORED (1)，
 * 并在设置层返回 0，从系统内核层面彻底隐蔽模拟定位的存在。
 */

internal fun LocationHooker.hookSystemAppOpsService(classLoader: ClassLoader) {
    val appOpsServiceClass = SystemClassLocator.locate(SystemComponent.APPOPS_SERVICE, classLoader)

    if (appOpsServiceClass != null && hookedCallbackClasses.putIfAbsent(appOpsServiceClass, true) == null) {
        val opMethods = arrayOf("checkOperation", "noteOperation", "checkAudioOperation")
        for (methodName in opMethods) {
            try {
                XposedHelpers.hookAllMethods(appOpsServiceClass, methodName) { chain, _ ->
                    val config = readConfig()
                    if (config != null && config.optBoolean(ConfigKeys.ACTIVE, false)) {
                        val codeArg = chain.args.firstOrNull { it is Int } as? Int
                        if (codeArg == 58) { // OP_MOCK_LOCATION
                            val explicitPkg = SystemHookUtils.extractPackageName(chain.args)
                            if (SystemHookUtils.isTargetCaller(chain.thisObject, explicitPkg, config)) {
                                return@hookAllMethods 1 // MODE_IGNORED
                            }
                        }
                    }
                    return@hookAllMethods chain.proceed(chain.args.toTypedArray())
                }
            } catch (t: Throwable) { HookLog.swallowed("SystemAppOpsHooker.kt:60", t) }
        }
        sysLog("[SysHook] AppOpsService OP_MOCK_LOCATION hooked")
    }

    // 拦截 Settings.Secure 中 mock_location 开关读取
    try {
        val settingsSecureClass = XposedHelpers.findClassIfExists("android.provider.Settings\$Secure", classLoader)
        if (settingsSecureClass != null) {
            XposedHelpers.hookAllMethods(settingsSecureClass, "getString") { chain, _ ->
                val config = readConfig()
                if (config != null && config.optBoolean(ConfigKeys.ACTIVE, false)) {
                    val key = chain.args.firstOrNull { it is String } as? String
                    if (key == "mock_location" || key == "allow_mock_location") {
                        return@hookAllMethods "0"
                    }
                }
                return@hookAllMethods chain.proceed(chain.args.toTypedArray())
            }
        }
    } catch (t: Throwable) { HookLog.swallowed("SystemAppOpsHooker.kt:80", t) }
}
