// LocationSpoofer global 系统级传感器层（native）
//
// 目标设备：Xiaomi 10S (thyme), Android 13 (SDK 33), HyperOS 1.0.4.0
//
// 通过 libc send/sendto/sendmsg 函数入口观察 SensorService 事件。
// 只有 fd、UID、事件布局和整批数据都验证通过后才使用有界副本；
// 任一条件不确定时调用原函数并透传原始参数。
//
// 能力：
//   - 按目标 UID 集合过滤（白名单 UID 或全局普通应用 UID 段）：
//     Hook SensorEventConnection 构造函数，建立 fd -> uid；
//   - 改写目标 UID 的 STEP_COUNTER / STEP_DETECTOR；
//   - 按配置速度/步频/步态模板改写加速度计（程序化步态或录制模板）；
//   - 按目标步频注入合成步数（每个 UID 每 tick 只注入一条连接，防重复）。

#include <jni.h>
#include <android/log.h>
#include <dlfcn.h>
#include <elf.h>
#include <link.h>
#include <shadowhook.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <sys/syscall.h>
#include <sys/uio.h>
#include <unistd.h>

#include <algorithm>
#include <array>
#include <atomic>
#include <cerrno>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <functional>
#include <memory>
#include <mutex>
#include <pthread.h>
#include <random>
#include <string>
#include <vector>

#define LOG_TAG "SysSensorNative"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace {

constexpr double kPi = 3.14159265358979323846;
// 超过这个速度按“驾车”处理：不再合成步态/步数；指南针仍按路线方向工作。
constexpr double kMaxSimulatedStepSpeedMps = 7.0;

constexpr const char* kLibSensorservice = "libsensorservice.so";
constexpr const char* kLibcName = "libc.so";
// libc __sendto: bti c; mov x8,#0xce; svc #0 (10S fallback, validated before use)
constexpr uintptr_t kLibcSvcOffset = 0xe1918;
constexpr uint8_t kLibcSvcBytes[4] = {0x01, 0x00, 0x00, 0xd4};

// Xiaomi/AOSP fallback for libsensorservice SensorEventConnection::C1.
constexpr uintptr_t kConnectionCtorOffset = 0x58160;
constexpr const char* kConnectionCtorSymbol =
    "_ZN7android13SensorService21SensorEventConnectionC1ERKNS_2spIS0_EEjNS_7String8EbRKNS_8String16ES9_";
// Android 14/15 可能改构造签名或参数类型；先匹配完整符号，失败后按前缀
// 在所有 dynsym 里找 SensorEventConnection 的 C1/C2 构造函数。
constexpr const char* kConnectionCtorSymbolPrefixes[] = {
    "_ZN7android13SensorService21SensorEventConnectionC1",
    "_ZN7android13SensorService21SensorEventConnectionC2",
};
constexpr uint8_t kConnectionCtorPrologue[16] = {
    0x3f, 0x23, 0x03, 0xd5, 0xfd, 0x7b, 0xbb, 0xa9,
    0xfa, 0x67, 0x01, 0xa9, 0xfd, 0x03, 0x00, 0x91,
};
// this+0x30 = sp<BitTube>；BitTube+0x10 = 发送 fd；this+0x38 = uid
constexpr size_t kConnectionBitTubeOffset = 0x30;
constexpr size_t kConnectionUidOffset = 0x38;

// Linux socket cookie prevents a recycled fd number from inheriting an old UID mapping.
#ifndef SO_COOKIE
#define SO_COOKIE 57
#endif

// Android 13 / arm64 sensors_event_t
struct SensorsEvent {
  int32_t version;
  int32_t sensor;
  int32_t type;
  int32_t reserved0;
  int64_t timestamp;
  union {
    float data[16];
    uint64_t step_counter;
  } u;
  uint32_t flags;
  int32_t reserved1[3];
};
static_assert(sizeof(SensorsEvent) == 0x68, "unexpected sensors_event_t size");
static_assert(offsetof(SensorsEvent, sensor) == 0x04, "sensor offset");
static_assert(offsetof(SensorsEvent, type) == 0x08, "type offset");
static_assert(offsetof(SensorsEvent, timestamp) == 0x10, "timestamp offset");
static_assert(offsetof(SensorsEvent, u) == 0x18, "data offset");

constexpr int32_t kTypeAccelerometer = 1;
constexpr int32_t kTypeMagneticField = 2;
constexpr int32_t kTypeOrientation = 3;
constexpr int32_t kTypeGyroscope = 4;
constexpr int32_t kTypePressure = 6;
constexpr int32_t kTypeGravity = 9;
constexpr int32_t kTypeLinearAcceleration = 10;
constexpr int32_t kTypeRotationVector = 11;
constexpr int32_t kTypeGyroscopeUncalibrated = 16;
constexpr int32_t kTypeMagneticFieldUncalibrated = 14;
constexpr int32_t kTypeGameRotationVector = 15;
constexpr int32_t kTypeStepDetector = 18;
constexpr int32_t kTypeStepCounter = 19;
constexpr int32_t kTypeGeomagneticRotationVector = 20;
constexpr int32_t kTypeAccelerometerUncalibrated = 35;
constexpr int32_t kTypeHeading = 42;

bool isAccelerometerFamily(int32_t type) {
  return type == kTypeAccelerometer || type == kTypeGravity ||
         type == kTypeLinearAcceleration ||
         type == kTypeAccelerometerUncalibrated;
}

bool isCompassType(int32_t type) {
  switch (type) {
    case kTypeMagneticField:
    case kTypeOrientation:
    case kTypeRotationVector:
    case kTypeMagneticFieldUncalibrated:
    case kTypeGameRotationVector:
    case kTypeGeomagneticRotationVector:
    case kTypeHeading:
      return true;
    default:
      return false;
  }
}

bool isGyroType(int32_t type) {
  return type == kTypeGyroscope || type == kTypeGyroscopeUncalibrated;
}

double normalizeDegrees(double degrees) {
  if (!std::isfinite(degrees)) return 0.0;
  double value = std::fmod(degrees, 360.0);
  if (value < 0.0) value += 360.0;
  return value;
}

double shortestDeltaDegrees(double fromDegrees, double toDegrees) {
  double delta = normalizeDegrees(toDegrees - fromDegrees);
  if (delta >= 180.0) delta -= 360.0;
  return delta;
}

struct Attitude {
  double yawMagneticRad = 0.0;
  double pitchRad = 0.0;
  double rollRad = 0.0;
  double pitchRateRad = 0.0;
  double rollRateRad = 0.0;
  double yawRateRad = 0.0;
};

struct Quat {
  double x = 0.0;
  double y = 0.0;
  double z = 0.0;
  double w = 1.0;
};

Quat quatFromYawPitchRoll(double yaw, double pitch, double roll) {
  // 与 Android SensorManager.getOrientation 的顺序一致：
  // q = qz(yaw) * qx(-pitch) * qy(roll)
  // 这样 getOrientation(q) 的 azimuth/pitch/roll 与本函数的三个参数一致，
  // 且 R^T * gravity 与 rotateByTilt 使用同一个倾斜约定。
  const double cy = std::cos(yaw * 0.5), sy = std::sin(yaw * 0.5);
  const double cp = std::cos(pitch * 0.5), sp = std::sin(-pitch * 0.5);
  const double cr = std::cos(roll * 0.5), sr = std::sin(roll * 0.5);
  Quat q;
  q.x = sp * cr * cy - cp * sr * sy;
  q.y = cp * sr * cy + sp * cr * sy;
  q.z = sp * sr * cy + cp * cr * sy;
  q.w = cp * cr * cy - sp * sr * sy;
  return q;
}

Quat quatMultiply(const Quat& a, const Quat& b) {
  Quat r;
  r.x = a.w * b.x + a.x * b.w + a.y * b.z - a.z * b.y;
  r.y = a.w * b.y - a.x * b.z + a.y * b.w + a.z * b.x;
  r.z = a.w * b.z + a.x * b.y - a.y * b.x + a.z * b.w;
  r.w = a.w * b.w - a.x * b.x - a.y * b.y - a.z * b.z;
  return r;
}

// q 为 body->world；用 q 的数值导数求身体角速度，保证 gyro 与
// orientation/gravity/magnetic 来自同一姿态。
void bodyAngularVelocity(const Quat& q, const Quat& qPrev, double dt,
                         float out[3]) {
  // q 与 -q 表示同一姿态；跨越 180° 时先对齐符号，避免差分出现尖峰。
  Quat prev = qPrev;
  if (q.x * prev.x + q.y * prev.y + q.z * prev.z + q.w * prev.w < 0.0) {
    prev = Quat{-prev.x, -prev.y, -prev.z, -prev.w};
  }
  const double inv = 1.0 / std::max(1e-4, dt);
  Quat qDot{
      (q.x - prev.x) * inv,
      (q.y - prev.y) * inv,
      (q.z - prev.z) * inv,
      (q.w - prev.w) * inv,
  };
  Quat qInv{-q.x, -q.y, -q.z, q.w};
  const Quat w = quatMultiply(qInv, qDot);
  out[0] = static_cast<float>(2.0 * w.x);
  out[1] = static_cast<float>(2.0 * w.y);
  out[2] = static_cast<float>(2.0 * w.z);
}

void rotateByTilt(double x, double y, double z, double pitch, double roll,
                  double out[3]) {
  // 世界/导航坐标 -> 身体坐标：Ry(-roll) * Rx(pitch)。
  // 与上面的 quaternion（R^T）严格对应；yaw 由 orientation/quaternion 表达。
  const double cp = std::cos(pitch), sp = std::sin(pitch);
  const double cr = std::cos(roll), sr = std::sin(roll);
  const double x1 = x;
  const double y1 = y * cp - z * sp;
  const double z1 = y * sp + z * cp;
  out[0] = x1 * cr - z1 * sr;
  out[1] = y1;
  out[2] = x1 * sr + z1 * cr;
}

// 64 位哈希在下面步态波形区定义；姿态/传感器偏置需要提前使用。
double hashUnit(uint64_t seed, int64_t n);

double hashPhase(uint64_t seed, int64_t index) {
  return (hashUnit(seed, index) * 0.5 + 0.5) * 2.0 * kPi;
}

/** 身体坐标下的缓慢手持偏置（米/秒²），不同轴不同相位，避免三轴完全同步。 */
void accelerometerBias(double timeSec, uint64_t seed, double out[3]) {
  out[0] = 0.018 * std::sin(2.0 * kPi * timeSec / 29.0 + hashPhase(seed, 13)) +
           0.006 * std::sin(2.0 * kPi * timeSec / 7.3 + hashPhase(seed, 14));
  out[1] = 0.016 * std::sin(2.0 * kPi * timeSec / 37.0 + hashPhase(seed, 15)) +
           0.005 * std::sin(2.0 * kPi * timeSec / 6.1 + hashPhase(seed, 16));
  out[2] = 0.020 * std::sin(2.0 * kPi * timeSec / 41.0 + hashPhase(seed, 17)) +
           0.006 * std::sin(2.0 * kPi * timeSec / 8.7 + hashPhase(seed, 18));
}

Attitude computeAttitude(double stepsFloat, double speedMps, int cadenceSpm,
                         double trueHeadingDeg, double declinationDeg,
                         double yawRateRad, int realismLevel,
                         uint64_t seed, double timeSec) {
  Attitude a;
  const double magneticHeading =
      normalizeDegrees(trueHeadingDeg - declinationDeg);
  if (!std::isfinite(stepsFloat) || !std::isfinite(speedMps) ||
      speedMps <= 0.05 || speedMps > kMaxSimulatedStepSpeedMps) {
    // 静止或驾车速度：只保留路线航向，不叠加跑步俯仰/横滚/步态摆动。
    a.yawMagneticRad = magneticHeading * kPi / 180.0;
    return a;
  }
  const double realism = std::clamp(realismLevel, 0, 3) / 3.0;
  const double running = speedMps >= 2.2 ? 1.0 : 0.55;
  const double phase = 2.0 * kPi * stepsFloat;
  const double cadence = std::clamp(cadenceSpm, 60, 240);
  const double omega = 2.0 * kPi * cadence / 60.0;

  // 跑步时 pitch 约 ±3°、roll 约 ±2.5°；走路幅度更小。
  const double pitchAmp = (running * (2.2 + 1.0 * realism)) * kPi / 180.0;
  const double rollAmp = (running * (1.7 + 0.9 * realism)) * kPi / 180.0;
  const double yawSwayAmp = (running * 0.45) * kPi / 180.0;
  // 手持方向不是严格等于运动方向：加一条 0.2–0.6°、周期 7–23 秒的
  // 缓慢手腕/握持偏航，以及更小的 pitch/roll 偏置。它不改变 GPS bearing，
  // 只让指南针与运动方向出现真实手机常见的轻微偏差。
  const double handYawAmp = (0.30 + 0.30 * running) * kPi / 180.0;
  const double hy1 = 2.0 * kPi * timeSec / 17.3 + hashPhase(seed, 21);
  const double hy2 = 2.0 * kPi * timeSec / 7.1 + hashPhase(seed, 22);
  const double handYaw = handYawAmp *
      (0.62 * std::sin(hy1) + 0.38 * std::sin(hy2));
  const double handYawRate = handYawAmp * (
      0.62 * (2.0 * kPi / 17.3) * std::cos(hy1) +
      0.38 * (2.0 * kPi / 7.1) * std::cos(hy2));
  const double handPitchAmp = (0.10 + 0.12 * running) * kPi / 180.0;
  const double handRollAmp = (0.08 + 0.10 * running) * kPi / 180.0;
  const double hp = 2.0 * kPi * timeSec / 23.0 + hashPhase(seed, 23);
  const double hr = 2.0 * kPi * timeSec / 13.7 + hashPhase(seed, 24);
  const double handPitch = handPitchAmp * std::sin(hp);
  const double handRoll = handRollAmp * std::sin(hr);

  a.pitchRad = pitchAmp * std::sin(phase) + handPitch;
  a.rollRad = rollAmp * std::sin(phase * 0.5 + 0.6) + handRoll;
  a.yawMagneticRad = (magneticHeading * kPi / 180.0) +
      yawSwayAmp * std::sin(phase * 0.5) + handYaw;
  a.pitchRateRad = pitchAmp * omega * std::cos(phase) +
      handPitchAmp * (2.0 * kPi / 23.0) * std::cos(hp);
  a.rollRateRad =
      rollAmp * (omega * 0.5) * std::cos(phase * 0.5 + 0.6) +
      handRollAmp * (2.0 * kPi / 13.7) * std::cos(hr);
  a.yawRateRad = yawRateRad +
      yawSwayAmp * (omega * 0.5) * std::cos(phase * 0.5) + handYawRate;
  return a;
}

constexpr size_t kMaxTargetFds = 32;
constexpr size_t kFdMapSize = 1024;
// Keep per-thread hook scratch modest. Larger batches are passed through intact.
constexpr size_t kMaxNativeBatchBytes = 0x200 * 64;
constexpr size_t kMaxNativeIov = 8;
constexpr int kFdMapBusy = -2;
constexpr uint64_t kStepSalt = 0x57E9057EULL;

// ---------------------------------------------------------------- 步态波形
// 与 core-geo MotionRealism 的程序化波形一致：256 点查表、去均值。

using ShapeTable = std::array<double, 256>;

double bump(double p, double center, double width) {
  double d = std::fabs(p - center);
  if (d > 0.5) d = 1.0 - d;
  return std::exp(-0.5 * (d / width) * (d / width));
}

ShapeTable zeroMeanTable(const std::function<double(double)>& shape) {
  ShapeTable table{};
  double sum = 0.0;
  for (size_t i = 0; i < table.size(); ++i) {
    table[i] = shape(static_cast<double>(i) / table.size());
    sum += table[i];
  }
  const double mean = sum / table.size();
  for (auto& v : table) v -= mean;
  return table;
}

const ShapeTable kWalkVertical = zeroMeanTable([](double p) {
  return 1.0 * bump(p, 0.00, 0.045) - 0.45 * bump(p, 0.13, 0.07) +
         0.55 * bump(p, 0.42, 0.09) - 0.65 * bump(p, 0.72, 0.13);
});
const ShapeTable kWalkForward = zeroMeanTable([](double p) {
  return -0.5 * bump(p, 0.03, 0.05) + 0.45 * bump(p, 0.40, 0.09) -
         0.15 * bump(p, 0.75, 0.15);
});
const ShapeTable kRunVertical = zeroMeanTable([](double p) {
  return 1.0 * bump(p, 0.00, 0.035) + 0.55 * bump(p, 0.16, 0.09) -
         0.85 * bump(p, 0.62, 0.18);
});
const ShapeTable kRunForward = zeroMeanTable([](double p) {
  return -0.6 * bump(p, 0.02, 0.04) + 0.5 * bump(p, 0.25, 0.08);
});

double lookup(const ShapeTable& table, double phase) {
  const double pos = (phase - std::floor(phase)) * table.size();
  const int i = static_cast<int>(pos) % static_cast<int>(table.size());
  const double frac = pos - std::floor(pos);
  return table[i] * (1.0 - frac) +
         table[(i + 1) % table.size()] * frac;
}

// 与 MotionRealism.hashUnit 一致的 64 位混合
double hashUnit(uint64_t seed, int64_t n) {
  uint64_t x = seed ^ (static_cast<uint64_t>(n) * 0x9E3779B97F4A7C15ULL);
  x = (x ^ (x >> 33)) * 0xFF51AFD7ED558CCDULL;
  x = (x ^ (x >> 33)) * 0xC4CEB9FE1A85EC53ULL;
  x ^= (x >> 33);
  return static_cast<double>(x >> 11) / static_cast<double>(1ULL << 53) * 2.0 - 1.0;
}

void proceduralGait(double stepPhase, double stepsFloat, int64_t stepIndex,
                    double speed, double strength, float out[3]) {
  const bool running = speed >= 2.2;
  const double amplitude = running ? 6.0 + 1.5 * speed : 2.0 + 1.0 * speed;
  const double vertical = lookup(running ? kRunVertical : kWalkVertical, stepPhase);
  const double forward = lookup(running ? kRunForward : kWalkForward, stepPhase);
  const double side = (stepIndex % 2 == 0) ? 1.0 : -1.0;
  const double lateral =
      0.12 * amplitude * std::sin(kPi * stepsFloat) +
      0.1 * amplitude * side * bump(stepPhase, 0.02, 0.05);
  const double z = std::max(0.0, 9.80665 + strength * amplitude * vertical);
  out[0] = static_cast<float>(strength * lateral);
  out[1] = static_cast<float>(strength * 0.35 * amplitude * forward);
  out[2] = static_cast<float>(z);
}

// 录制的个人步态模板：v1;cadence;strides;x0..x63;y...;z...
struct GaitTemplate {
  std::array<float, 64> x{};
  std::array<float, 64> y{};
  std::array<float, 64> z{};
  float meanX = 0.0f;
  float meanY = 0.0f;
  float meanZ = 0.0f;
  // 录制时的一个跨步周期对应的步频；0 表示模板没有可用步频。
  int32_t cadenceSpm = 0;
  int32_t strideCount = 0;
};

std::vector<std::string> split(const std::string& s, char sep) {
  std::vector<std::string> out;
  size_t start = 0;
  while (true) {
    const size_t pos = s.find(sep, start);
    if (pos == std::string::npos) {
      out.push_back(s.substr(start));
      break;
    }
    out.push_back(s.substr(start, pos - start));
    start = pos + 1;
  }
  return out;
}

bool parseAxis(const std::string& text, std::array<float, 64>& axis) {
  const auto parts = split(text, ',');
  if (parts.size() != axis.size()) return false;
  for (size_t i = 0; i < axis.size(); ++i) {
    char* end = nullptr;
    const float v = std::strtof(parts[i].c_str(), &end);
    if (end == parts[i].c_str() || !std::isfinite(v)) return false;
    axis[i] = v;
  }
  return true;
}

std::shared_ptr<const GaitTemplate> parseGait(const std::string& encoded) {
  if (encoded.empty()) return nullptr;
  const auto parts = split(encoded, ';');
  if (parts.size() != 6 || parts[0] != "v1") return nullptr;
  auto t = std::make_shared<GaitTemplate>();
  if (!parseAxis(parts[3], t->x) || !parseAxis(parts[4], t->y) ||
      !parseAxis(parts[5], t->z)) {
    return nullptr;
  }
  char* cadenceEnd = nullptr;
  const long parsedCadence = std::strtol(parts[1].c_str(), &cadenceEnd, 10);
  if (cadenceEnd != parts[1].c_str() && parsedCadence >= 60 &&
      parsedCadence <= 240) {
    t->cadenceSpm = static_cast<int32_t>(parsedCadence);
  }
  char* strideEnd = nullptr;
  const long parsedStrides = std::strtol(parts[2].c_str(), &strideEnd, 10);
  if (strideEnd != parts[2].c_str() && parsedStrides > 0 &&
      parsedStrides < 1000000) {
    t->strideCount = static_cast<int32_t>(parsedStrides);
  }
  double sx = 0.0, sy = 0.0, sz = 0.0;
  for (size_t i = 0; i < t->x.size(); ++i) {
    sx += t->x[i];
    sy += t->y[i];
    sz += t->z[i];
  }
  t->meanX = static_cast<float>(sx / t->x.size());
  t->meanY = static_cast<float>(sy / t->y.size());
  t->meanZ = static_cast<float>(sz / t->z.size());
  return t;
}

void sampleGait(const GaitTemplate& t, double stridePhase, double strength,
                float out[3]) {
  const double pos = (stridePhase - std::floor(stridePhase)) * t.x.size();
  const int i = static_cast<int>(pos) % static_cast<int>(t.x.size());
  const int j = (i + 1) % static_cast<int>(t.x.size());
  const float frac = static_cast<float>(pos - std::floor(pos));
  const std::array<float, 64>* axes[3] = {&t.x, &t.y, &t.z};
  const float means[3] = {t.meanX, t.meanY, t.meanZ};
  for (int a = 0; a < 3; ++a) {
    const float v = (*axes[a])[i] * (1.0f - frac) + (*axes[a])[j] * frac;
    out[a] = means[a] + (v - means[a]) * static_cast<float>(strength);
  }
}

// java.util.Random 的逐位复刻。SmoothNoise/AltitudeModel 的相位必须与 scoped
// Java 进程一致，否则同一时刻的 global 步数/海拔会对不上。
class JavaRandom {
 public:
  explicit JavaRandom(uint64_t seed) { setSeed(seed); }

  void setSeed(uint64_t seed) {
    state_ = (seed ^ kMultiplier) & kMask;
    haveNextGaussian_ = false;
    nextGaussian_ = 0.0;
  }

  int32_t next(int bits) {
    state_ = (state_ * kMultiplier + kAddend) & kMask;
    return static_cast<int32_t>(state_ >> (48 - bits));
  }

  double nextDouble() {
    const uint64_t high = static_cast<uint64_t>(next(26));
    const uint64_t low = static_cast<uint64_t>(next(27));
    return static_cast<double>((high << 27) + low) *
           (1.0 / 9007199254740992.0);
  }

  double nextGaussian() {
    if (haveNextGaussian_) {
      haveNextGaussian_ = false;
      return nextGaussian_;
    }
    double v1 = 0.0;
    double v2 = 0.0;
    double s = 0.0;
    do {
      v1 = 2.0 * nextDouble() - 1.0;
      v2 = 2.0 * nextDouble() - 1.0;
      s = v1 * v1 + v2 * v2;
    } while (s >= 1.0 || s == 0.0);
    const double scale = std::sqrt(-2.0 * std::log(s) / s);
    nextGaussian_ = v2 * scale;
    haveNextGaussian_ = true;
    return v1 * scale;
  }

 private:
  static constexpr uint64_t kMultiplier = 0x5DEECE66DULL;
  static constexpr uint64_t kAddend = 0xBULL;
  static constexpr uint64_t kMask = (1ULL << 48) - 1;
  uint64_t state_ = 0;
  bool haveNextGaussian_ = false;
  double nextGaussian_ = 0.0;
};

// MotionRealism.SmoothNoise 的 1:1 移植：4 个正弦分量。
struct SmoothNoise {
  std::array<double, 4> periods{};
  std::array<double, 4> phases{};
  std::array<double, 4> weights{};
};

SmoothNoise makeNoise(uint64_t seed, double minPeriod, double maxPeriod) {
  JavaRandom rnd(seed);
  SmoothNoise noise;
  // 与 Kotlin 的构造顺序完全一致：先全部 periods，再 phases，最后 weights。
  for (auto& period : noise.periods) {
    period = minPeriod *
             std::pow(maxPeriod / minPeriod, rnd.nextDouble());
  }
  for (auto& phase : noise.phases) {
    phase = rnd.nextDouble() * 2.0 * kPi;
  }
  double weightSum = 0.0;
  for (auto& weight : noise.weights) {
    weight = 0.5 + rnd.nextDouble();
    weightSum += weight;
  }
  for (auto& weight : noise.weights) weight /= weightSum;
  return noise;
}

// AltitudeModel.Terrain 的 1:1 移植：5 个平面正弦波。
constexpr uint64_t kTerrainSeed = 0x7E22A1A7ULL;
constexpr uint64_t kDriftSeed = 0x0A171707ULL;

struct Terrain {
  std::array<double, 5> kx{};
  std::array<double, 5> ky{};
  std::array<double, 5> phases{};
  std::array<double, 5> weights{};

  double value(double x, double y) const {
    double v = 0.0;
    for (size_t i = 0; i < weights.size(); ++i) {
      v += weights[i] *
           std::sin(kx[i] * x + ky[i] * y + phases[i]);
    }
    return v;
  }
};

Terrain makeTerrain(double minWavelengthM) {
  JavaRandom rnd(kTerrainSeed);
  Terrain terrain;
  for (size_t i = 0; i < terrain.kx.size(); ++i) {
    const double wavelength =
        minWavelengthM * std::pow(4.0, rnd.nextDouble());
    const double direction = rnd.nextDouble() * 2.0 * kPi;
    terrain.kx[i] = 2.0 * kPi / wavelength * std::cos(direction);
    terrain.ky[i] = 2.0 * kPi / wavelength * std::sin(direction);
  }
  for (auto& phase : terrain.phases) {
    phase = rnd.nextDouble() * 2.0 * kPi;
  }
  double weightSum = 0.0;
  for (auto& weight : terrain.weights) {
    weight = 0.5 + rnd.nextDouble();
    weightSum += weight;
  }
  for (auto& weight : terrain.weights) weight /= weightSum;
  return terrain;
}

double noiseValue(const SmoothNoise& noise, double t) {
  double value = 0.0;
  for (size_t i = 0; i < noise.periods.size(); ++i) {
    value += noise.weights[i] *
             std::sin(2.0 * kPi * t / noise.periods[i] + noise.phases[i]);
  }
  return value;
}

double noiseIntegral(const SmoothNoise& noise, double t) {
  double value = 0.0;
  for (size_t i = 0; i < noise.periods.size(); ++i) {
    const double omega = 2.0 * kPi / noise.periods[i];
    value += noise.weights[i] / omega *
             (std::cos(noise.phases[i]) -
              std::cos(omega * t + noise.phases[i]));
  }
  return value;
}

struct LevelParams {
  double cadenceVariation;
  double stepAmplitudeVariation;
  double sensorNoise;
};
constexpr LevelParams kLevels[4] = {
    {0.0, 0.0, 0.0}, {0.015, 0.05, 0.03},
    {0.03, 0.10, 0.06}, {0.05, 0.18, 0.10}};

// ---------------------------------------------------------------- 配置与时钟

struct Config {
  std::vector<int32_t> targetUids;
  bool allApps = false;
  double speedMps = 1.4;
  int32_t cadenceSpm = 0;  // 0 = 按速度自动
  int32_t stepDetectorHandle = 3;
  int32_t stepCounterHandle = 5;
  int32_t accelerometerHandle = 0x37;
  int32_t realismLevel = 0;
  int32_t fluctuationPct = 0;
  bool active = true;
  bool stepSimulation = true;
  bool accelerometerSimulation = true;
  bool pressureEnabled = false;
  double pressureAltitudeM = 25.0;
  double pressureVariationM = 0.0;
  double pressureLat = 0.0;
  double pressureLng = 0.0;
  double pressureDriftM = 0.0;
  double pressureSeaLevelHpa = 1013.25;
  Terrain pressureTerrain;
  bool pressureTerrainReady = false;
  double pressureTerrainAmp = 0.0;
  bool compassSimulation = false;
  double compassTrueHeadingDeg = 0.0;
  double compassDeclinationDeg = 0.0;
  double compassAccuracyDeg = 5.0;
  double compassHorizontalUt = 0.0;
  double compassVerticalUt = 0.0;
  bool compassFieldValid = false;
  double compassYawRateRad = 0.0;
  int64_t compassHeadingAtNs = 0;
  bool compassHeadingValid = false;
  std::string gaitEncoded;
};

std::mutex g_config_mutex;
Config g_config;
int64_t g_clock_origin_ns = 0;
double g_clock_base_steps = 0.0;
bool g_counter_base_captured = false;
int64_t g_session_start_ns = 0;
bool g_session_start_configured = false;
uint64_t g_noise_seed = 0;
SmoothNoise g_speedNoise;
SmoothNoise g_cadenceNoise;
bool g_noise_ready = false;
SmoothNoise g_driftNoise;
bool g_drift_ready = false;
std::atomic<int64_t> g_last_real_step_ns{0};
std::atomic<uint64_t> g_pressure_rewritten_events{0};
std::shared_ptr<const GaitTemplate> g_gait;

std::atomic<bool> g_installed{false};
std::atomic<int> g_target_fds[kMaxTargetFds];
std::atomic<uint64_t> g_target_fd_cookies[kMaxTargetFds];
std::atomic<int> g_target_fd_uids[kMaxTargetFds];
std::atomic<uint64_t> g_target_generation{0};
std::atomic<int> g_fd_map[kFdMapSize];
std::atomic<int> g_fd_uid_map[kFdMapSize];
std::atomic<uint64_t> g_fd_cookie_map[kFdMapSize];
std::atomic<size_t> g_fd_evict_next{0};
// SensorEventConnection 的 sp<BitTube> 字段 / BitTube 发送 fd 字段。
// 默认采用 AOSP 布局；其他布局只能来自显式设备 profile。
std::atomic<int> g_bit_tube_offset{static_cast<int>(kConnectionBitTubeOffset)};
std::atomic<int> g_bit_tube_fd_offset{0x10};
std::atomic<int> g_connection_uid_offset{static_cast<int>(kConnectionUidOffset)};
std::atomic<bool> g_layout_discovered{false};
std::atomic<bool> g_layout_warning_logged{false};
// 多 ROM 描述符覆盖（配置下发；在 nativeInit 安装 Hook 前设置）。
// svcOffset 保留 JNI 兼容，但不再用于选择 Hook 地址。
std::atomic<int64_t> g_profile_svc_offset{0};
std::atomic<int64_t> g_profile_ctor_offset{0};
std::atomic<int64_t> g_profile_plt_offset{0};
std::atomic<bool> g_profile_force{false};
// 事件步长 profile：默认 Android 13 的 0x68；只允许在安装 Hook 前设置。
// 某些版本只在 sensors_event_t 末尾追加字段，这时 stride 变化、字段偏移不变。
std::atomic<size_t> g_event_stride{sizeof(SensorsEvent)};
std::atomic<uint64_t> g_invalid_batches{0};
std::atomic<uint64_t> g_cookie_failures{0};
std::atomic<uint64_t> g_version_skips{0};
std::atomic<uint64_t> g_iov_skips{0};
std::atomic<uint64_t> g_map_evictions{0};
std::atomic<uint64_t> g_mapping_rejects{0};
std::atomic<uint64_t> g_send_fallbacks{0};
std::atomic<size_t> g_last_batch_len{0};
enum HookKind { kHookNone = 0, kHookSend = 1, kHookSendto = 2, kHookSendmsg = 4 };
std::atomic<int> g_hook_kind{kHookNone};
std::atomic<bool> g_svc_hook_active{false};
// 0 unknown, 1 discovered, 2 profile, 3 fallback, 4 symbol, 5 ELF exact,
// 6 ELF prefix, 7 libc function entry hooks
std::atomic<int> g_svc_source{0};
std::atomic<int> g_ctor_source{0};
std::atomic<uint64_t> g_rewritten_events{0};
std::atomic<uint64_t> g_accel_rewritten_events{0};
std::atomic<uint64_t> g_compass_rewritten_events{0};
std::atomic<uint64_t> g_gyro_rewritten_events{0};
std::atomic<uint64_t> g_injected_events{0};

struct NativeHookScratch {
  alignas(16) std::array<uint8_t, kMaxNativeBatchBytes> bytes{};
  msghdr message{};
  std::array<iovec, kMaxNativeIov> iov{};
  size_t used = 0;
};
thread_local NativeHookScratch g_native_hook_scratch;
thread_local bool g_native_send_rewrote = false;
thread_local unsigned g_native_send_hook_depth = 0;

// 构造函数入口 hook 在本 ROM 上会漏掉部分连接；PLT pre-interceptor 记录
// (this, uid)，后台线程在构造完成后读取 BitTube fd，作为兜底映射。
constexpr size_t kPendingCtors = 64;
struct PendingCtor {
  uintptr_t thiz = 0;
  int32_t uid = -1;
  int64_t at = 0;
  bool used = false;
};
std::mutex g_pending_mutex;
PendingCtor g_pending[kPendingCtors];
size_t g_pending_pos = 0;

thread_local std::mt19937 g_rng(0x5EED);

int64_t nowNanos() {
  timespec ts{};
  clock_gettime(CLOCK_BOOTTIME, &ts);
  return static_cast<int64_t>(ts.tv_sec) * 1000000000LL + ts.tv_nsec;
}

int64_t wallMillis() {
  timespec ts{};
  clock_gettime(CLOCK_REALTIME, &ts);
  return static_cast<int64_t>(ts.tv_sec) * 1000LL + ts.tv_nsec / 1000000LL;
}

uintptr_t untagPtr(uint64_t p) { return p & 0x00FFFFFFFFFFFFULL; }

int autoCadence(double speedMs) {
  if (speedMs <= 0.8) return 95;
  if (speedMs <= 1.5) return static_cast<int>(100 + (speedMs - 0.8) / 0.7 * 25);
  if (speedMs <= 2.8) return static_cast<int>(135 + (speedMs - 1.5) / 1.3 * 25);
  if (speedMs <= 4.0) return static_cast<int>(160 + (speedMs - 2.8) / 1.2 * 20);
  if (speedMs <= 5.5) return static_cast<int>(180 + (speedMs - 4.0) / 1.5 * 15);
  return 200;
}

// 自动步频以“当前瞬时速度”为输入；有个人步态模板时把模板录制步频
// 按 25% 融入，让指南针/6DoF 的步态节奏与录制的加速度曲线一致。
// 最后按 0.35~2.0 米的合理步幅范围反推步频上下限，避免速度变化时出现
// “步频 200、步幅 0.1 米”这类物理上不可能的步态。
int effectiveCadenceLocked(double speedMps) {
  const bool autoMode = g_config.cadenceSpm <= 0;
  double cadence = autoMode
      ? static_cast<double>(autoCadence(std::max(0.0, speedMps)))
      : static_cast<double>(std::clamp(g_config.cadenceSpm, 60, 240));
  if (autoMode && g_gait && g_gait->cadenceSpm >= 60) {
    cadence = cadence * 0.75 + g_gait->cadenceSpm * 0.25;
  }
  if (speedMps > 0.05 && std::isfinite(speedMps)) {
    const double minCadence = speedMps / 2.0 * 60.0;   // 步幅上限 2.0m
    const double maxCadence = speedMps / 0.35 * 60.0;  // 步幅下限 0.35m
    cadence = std::clamp(cadence, std::max(60.0, minCadence),
                         std::min(240.0, maxCadence));
  }
  return static_cast<int>(std::lround(std::clamp(cadence, 60.0, 240.0)));
}

void ensureNoiseLocked(int64_t now) {
  if (!g_session_start_configured) {
    g_session_start_ns = now;
    g_session_start_configured = true;
  }
  if (g_noise_seed == 0) {
    g_noise_seed = static_cast<uint64_t>(g_session_start_ns / 1000000LL);
  }
  if (g_noise_ready) return;
  g_speedNoise =
      makeNoise(g_noise_seed ^ 0x5EED5EEDULL, 20.0, 600.0);
  g_cadenceNoise =
      makeNoise(g_noise_seed ^ 0x0CADE0CEULL, 3.0, 60.0);
  g_noise_ready = true;
}

double sessionSeconds(int64_t now) {
  return static_cast<double>(now - g_session_start_ns) / 1e9;
}

double speedNowLocked(int64_t now) {
  ensureNoiseLocked(now);
  const double t = std::max(0.0, sessionSeconds(now));
  const double fluct =
      std::clamp(g_config.fluctuationPct, 0, 30) / 100.0;
  return std::max(
      0.0, g_config.speedMps * (1.0 + fluct * noiseValue(g_speedNoise, t)));
}

double cadenceNowLocked(int64_t now) {
  ensureNoiseLocked(now);
  const double t = std::max(0.0, sessionSeconds(now));
  const double fluct =
      std::clamp(g_config.fluctuationPct, 0, 30) / 100.0;
  const auto& level = kLevels[std::clamp(g_config.realismLevel, 0, 3)];
  // 自动步频跟随瞬时速度，而不是配置里的基准速度：速度浮动/上下坡时
  // 步频与当前速度保持同步，步幅不会越走越离谱。
  const double base = static_cast<double>(
      effectiveCadenceLocked(speedNowLocked(now)));
  const double cadence = base * (
      1.0 + 0.4 * fluct * noiseValue(g_speedNoise, t) +
      level.cadenceVariation * noiseValue(g_cadenceNoise, t));
  return std::clamp(cadence, 60.0, 240.0);
}

double currentStepsLocked(int64_t now) {
  if (g_clock_origin_ns <= 0) return g_clock_base_steps;
  ensureNoiseLocked(now);
  const double anchor = std::max(0.0, sessionSeconds(g_clock_origin_ns));
  const double current = std::max(anchor, sessionSeconds(now));
  const double span = current - anchor;
  if (span <= 0.0) return g_clock_base_steps;

  const double fluct =
      std::clamp(g_config.fluctuationPct, 0, 30) / 100.0;
  const auto& level = kLevels[std::clamp(g_config.realismLevel, 0, 3)];
  const double speedIntegral =
      noiseIntegral(g_speedNoise, current) - noiseIntegral(g_speedNoise, anchor);
  const double cadenceIntegral =
      noiseIntegral(g_cadenceNoise, current) - noiseIntegral(g_cadenceNoise, anchor);
  // 步数积分仍以基准速度为锚，保证任意时刻可由公式独立复现；
  // 每次采样的瞬时步频（cadenceNowLocked）只用于波形/指南针的节奏。
  const double cadence = static_cast<double>(
      effectiveCadenceLocked(g_config.speedMps));
  return g_clock_base_steps + cadence / 60.0 * (
      span + 0.4 * fluct * speedIntegral +
      level.cadenceVariation * cadenceIntegral);
}

// AltitudeModel 的 1:1 移植：地形只由坐标决定，漂移用固定的绝对时间种子。
double pressureAltitudeLocked(int64_t epochMs) {
  const double range =
      std::clamp(g_config.pressureVariationM, 0.0, 100.0);
  if (range <= 0.0) return g_config.pressureAltitudeM;
  const double driftAmp =
      std::min(std::max(g_config.pressureDriftM, 0.0), range / 2.0);
  const double terrainAmp = range - driftAmp;
  double altitude = g_config.pressureAltitudeM;
  if (terrainAmp > 0.0) {
    if (!g_config.pressureTerrainReady ||
        std::abs(g_config.pressureTerrainAmp - terrainAmp) > 1e-9) {
      const double minWavelength =
          std::max(250.0, 2.0 * kPi * terrainAmp / 0.08);
      g_config.pressureTerrain = makeTerrain(minWavelength);
      g_config.pressureTerrainAmp = terrainAmp;
      g_config.pressureTerrainReady = true;
    }
    const double x = g_config.pressureLng * 111320.0 *
                     std::cos(g_config.pressureLat * kPi / 180.0);
    const double y = g_config.pressureLat * 110540.0;
    altitude += terrainAmp * g_config.pressureTerrain.value(x, y);
  }
  if (driftAmp > 0.0) {
    if (!g_drift_ready) {
      g_driftNoise = makeNoise(kDriftSeed, 30.0, 400.0);
      g_drift_ready = true;
    }
    altitude += driftAmp *
        noiseValue(g_driftNoise, static_cast<double>(epochMs) / 1000.0);
  }
  return altitude;
}

// 与 SensorPressurePolicy 相同的标准大气压公式 + 缓慢波动。
double pressureNowLocked(int64_t now) {
  const double altitude = pressureAltitudeLocked(wallMillis());
  const double clamped = std::clamp(altitude, -500.0, 10000.0);
  const double seaLevel = std::clamp(g_config.pressureSeaLevelHpa, 800.0, 1100.0);
  const double base =
      std::pow(1.0 - clamped / 44330.0, 5.2550001983762575) * seaLevel;
  const double phase = static_cast<double>(now) / 1e9 * 2.0 * kPi;
  const double wave =
      (std::sin(phase / 131.0 + 0.9) * 0.3 +
       std::sin(phase / 43.0) * 0.7) * 0.3;
  // 20 分钟/7 分钟尺度的天气/QNH 漂移：真实海平面气压不是常数，
  // 第三方指南针用自身 QNH 计算海拔时会看到缓慢起伏。
  const double weather =
      std::sin(phase / 1200.0 + 0.7) * 0.25 +
      std::sin(phase / 420.0 + 1.9) * 0.15;
  return base + wave + weather;
}

// 与官方 SystemSensorPolicy.isTarget 一致：
// 白名单模式按 UID 精确匹配；全局模式只命中普通应用 UID（uid % 100000 ∈ [10000,20000)）。
bool isTargetUidLocked(int32_t uid) {
  if (uid <= 0) return false;
  if (g_config.allApps) {
    const int32_t app = uid % 100000;
    return app >= 10000 && app < 20000;
  }
  return std::find(g_config.targetUids.begin(), g_config.targetUids.end(), uid) !=
         g_config.targetUids.end();
}

bool rewriteStepEvent(SensorsEvent& e, int64_t now, uint64_t stepValue) {
  if (e.type == kTypeStepDetector) {
    e.u.data[0] = 1.0f;
    e.timestamp = now;
    return true;
  }
  if (e.type == kTypeStepCounter) {
    e.u.step_counter = stepValue;
    e.timestamp = now;
    return true;
  }
  return false;
}

void applyGait(SensorsEvent& e, int64_t now, const Config& cfg,
               const GaitTemplate* tmpl, double stepsFloat, double speedMps,
               double forwardAccelMps2, uint64_t seed,
               const Attitude& attitude) {
  const int64_t stepIndex = static_cast<int64_t>(std::floor(stepsFloat));
  const double stepPhase = stepsFloat - static_cast<double>(stepIndex);
  const auto& level = kLevels[std::clamp(cfg.realismLevel, 0, 3)];
  const double timeSec = static_cast<double>(now) / 1e9;
  // 除了逐步力度差异，再叠加 19s/6.7s 的慢调制和每 7 步可能出现的
  // “重一步/轻一步”；真实跑步不会每步都像节拍器。
  const double gaitWave = 1.0 +
      0.05 * std::sin(2.0 * kPi * timeSec / 19.0 + hashPhase(seed, 31)) +
      0.03 * std::sin(2.0 * kPi * timeSec / 6.7 + hashPhase(seed, 32));
  const double rareStep =
      hashUnit(seed ^ 0x53545249444542ULL, stepIndex / 7) > 0.94
          ? 0.18 : 0.0;
  const double strength = (1.0 +
      level.stepAmplitudeVariation * hashUnit(seed ^ kStepSalt, stepIndex)) *
      gaitWave * (1.0 + rareStep);
  float out[3];
  if (tmpl != nullptr) {
    sampleGait(*tmpl, stepsFloat / 2.0, strength, out);
  } else {
    proceduralGait(stepPhase, stepsFloat, stepIndex, speedMps, strength, out);
  }
  if (level.sensorNoise > 0.0) {
    std::normal_distribution<double> dist(0.0, level.sensorNoise);
    for (int i = 0; i < 3; ++i) out[i] += static_cast<float>(dist(g_rng));
  }

  // 把模板/程序步态统一到“屏幕朝上、Z 轴向上”的 canonical 身体坐标，
  // 再叠加 6DoF 俯仰/横滚。模板录制时手机可能竖握（重力在 Y 轴），
  // 直接沿用模板均值会让 orientation 与重力方向互相矛盾。
  const double meanX = tmpl != nullptr ? tmpl->meanX : 0.0;
  const double meanY = tmpl != nullptr ? tmpl->meanY : 0.0;
  const double meanZ = tmpl != nullptr ? tmpl->meanZ : 9.80665;
  double linear[3] = {
      static_cast<double>(out[0]) - meanX,
      static_cast<double>(out[1]) - meanY,
      static_cast<double>(out[2]) - meanZ,
  };
  // 低频前向加速度 = d(speed)/dt。它让线性加速度计除了步态高频分量
  // 之外，还能与 RouteEngine 的速度变化对上；幅度很小，不会掩盖步态冲击。
  if (std::isfinite(forwardAccelMps2)) {
    linear[1] += std::clamp(forwardAccelMps2, -2.0, 2.0);
  }
  // 弯道向心加速度 a_lat = v * yawRate。yawRate 来自 RouteEngine 路线
  // bearing（非步态摆动），方向与转弯一致；直线时接近 0。
  if (std::isfinite(cfg.compassYawRateRad)) {
    linear[0] += std::clamp(
        speedMps * cfg.compassYawRateRad, -3.0, 3.0);
  }
  // 每约 11 步才可能触发一次的轻微踉跄/路面冲击；确定性生成，频率很低。
  if (hashUnit(seed ^ 0x5354554D424C45ULL, stepIndex / 11) > 0.965) {
    linear[1] += 0.45;
    linear[2] += 0.70;
  }
  // 给线性分量加一个缓慢的传感器偏置；gravity 保持纯重力。
  double accelBias[3];
  accelerometerBias(timeSec, seed, accelBias);
  for (int axis = 0; axis < 3; ++axis) linear[axis] += accelBias[axis];
  double gravityWorld[3] = {0.0, 0.0, 9.80665};
  double gravityBody[3];
  double linearBody[3];
  rotateByTilt(gravityWorld[0], gravityWorld[1], gravityWorld[2],
               attitude.pitchRad, attitude.rollRad, gravityBody);
  rotateByTilt(linear[0], linear[1], linear[2],
               attitude.pitchRad, attitude.rollRad, linearBody);

  const float rawX = static_cast<float>(gravityBody[0] + linearBody[0]);
  const float rawY = static_cast<float>(gravityBody[1] + linearBody[1]);
  const float rawZ = static_cast<float>(gravityBody[2] + linearBody[2]);
  switch (e.type) {
    case kTypeGravity:
      e.u.data[0] = static_cast<float>(gravityBody[0]);
      e.u.data[1] = static_cast<float>(gravityBody[1]);
      e.u.data[2] = static_cast<float>(gravityBody[2]);
      break;
    case kTypeLinearAcceleration:
      e.u.data[0] = static_cast<float>(linearBody[0]);
      e.u.data[1] = static_cast<float>(linearBody[1]);
      e.u.data[2] = static_cast<float>(linearBody[2]);
      break;
    case kTypeAccelerometerUncalibrated:
      e.u.data[0] = rawX;
      e.u.data[1] = rawY;
      e.u.data[2] = rawZ;
      e.u.data[3] = 0.0f;
      e.u.data[4] = 0.0f;
      e.u.data[5] = 0.0f;
      break;
    default:
      e.u.data[0] = rawX;
      e.u.data[1] = rawY;
      e.u.data[2] = rawZ;
      break;
  }
  e.timestamp = now;
}

// ---------------------------------------------------------------- 目标 fd 管理

void recordTargetFd(int fd, uint64_t cookie, int32_t uid) {
  if (fd < 0 || uid <= 0 || cookie == 0) return;
  for (size_t i = 0; i < kMaxTargetFds; ++i) {
    const int cur = g_target_fds[i].load(std::memory_order_acquire);
    if (cur == fd) {
      const uint64_t oldCookie =
          g_target_fd_cookies[i].load(std::memory_order_relaxed);
      if (oldCookie == cookie) {
        if (g_target_fd_uids[i].load(std::memory_order_relaxed) != uid) {
          g_target_fd_uids[i].store(uid, std::memory_order_relaxed);
        }
        return;
      }
      int expected = fd;
      if (!g_target_fds[i].compare_exchange_strong(
              expected, kFdMapBusy, std::memory_order_acq_rel)) {
        continue;
      }
      g_target_fd_cookies[i].store(cookie, std::memory_order_relaxed);
      g_target_fd_uids[i].store(uid, std::memory_order_relaxed);
      g_target_fds[i].store(fd, std::memory_order_release);
      return;
    }
  }
  for (size_t i = 0; i < kMaxTargetFds; ++i) {
    int expected = -1;
    if (g_target_fds[i].compare_exchange_strong(
            expected, kFdMapBusy, std::memory_order_acq_rel)) {
      g_target_fd_cookies[i].store(cookie, std::memory_order_relaxed);
      g_target_fd_uids[i].store(uid, std::memory_order_relaxed);
      g_target_fds[i].store(fd, std::memory_order_release);
      return;
    }
  }
}

void clearTargetFd(size_t index, int expectedFd, uint64_t expectedCookie) {
  if (g_target_fd_cookies[index].load(std::memory_order_acquire) !=
      expectedCookie) {
    return;
  }
  int expected = expectedFd;
  if (!g_target_fds[index].compare_exchange_strong(
          expected, kFdMapBusy, std::memory_order_acq_rel)) {
    return;
  }
  // Re-check after winning the CAS. The slot may have been reused with a
  // different cookie between the first check and the CAS.
  if (g_target_fd_cookies[index].load(std::memory_order_acquire) !=
      expectedCookie) {
    g_target_fds[index].store(expectedFd, std::memory_order_release);
    return;
  }
  g_target_fd_cookies[index].store(0, std::memory_order_relaxed);
  g_target_fd_uids[index].store(0, std::memory_order_relaxed);
  g_target_fds[index].store(-1, std::memory_order_release);
}

bool recordFdUid(int fd, int uid, uint64_t cookie) {
  if (fd < 0 || uid <= 0 || cookie == 0) return false;
  for (size_t i = 0; i < kFdMapSize; ++i) {
    const int cur = g_fd_map[i].load(std::memory_order_acquire);
    if (cur == fd) {
      const uint64_t oldCookie =
          g_fd_cookie_map[i].load(std::memory_order_relaxed);
      if (oldCookie == cookie) {
        g_fd_uid_map[i].store(uid, std::memory_order_relaxed);
        return true;
      }
      int expected = fd;
      if (!g_fd_map[i].compare_exchange_strong(
              expected, kFdMapBusy, std::memory_order_acq_rel)) {
        continue;
      }
      g_fd_cookie_map[i].store(cookie, std::memory_order_relaxed);
      g_fd_uid_map[i].store(uid, std::memory_order_relaxed);
      g_fd_map[i].store(fd, std::memory_order_release);
      return true;
    }
  }
  for (size_t i = 0; i < kFdMapSize; ++i) {
    int expected = -1;
    if (g_fd_map[i].compare_exchange_strong(
            expected, kFdMapBusy, std::memory_order_acq_rel)) {
      g_fd_cookie_map[i].store(cookie, std::memory_order_relaxed);
      g_fd_uid_map[i].store(uid, std::memory_order_relaxed);
      g_fd_map[i].store(fd, std::memory_order_release);
      return true;
    }
  }
  // The map is full. Evict one live slot; the cookie check makes a stale
  // mapping harmless if the same fd number appears again later.
  for (size_t attempt = 0; attempt < kFdMapSize; ++attempt) {
    const size_t slot =
        g_fd_evict_next.fetch_add(1, std::memory_order_relaxed) % kFdMapSize;
    int expected = g_fd_map[slot].load(std::memory_order_acquire);
    if (expected < 0) continue;
    if (!g_fd_map[slot].compare_exchange_strong(
            expected, kFdMapBusy, std::memory_order_acq_rel)) {
      continue;
    }
    g_fd_cookie_map[slot].store(cookie, std::memory_order_relaxed);
    g_fd_uid_map[slot].store(uid, std::memory_order_relaxed);
    g_fd_map[slot].store(fd, std::memory_order_release);
    g_map_evictions.fetch_add(1, std::memory_order_relaxed);
    return true;
  }
  return false;
}

int uidForFd(int fd, uint64_t cookie) {
  if (fd < 0 || cookie == 0) return -1;
  for (size_t i = 0; i < kFdMapSize; ++i) {
    const int cur = g_fd_map[i].load(std::memory_order_acquire);
    if (cur != fd) continue;
    const uint64_t mappedCookie =
        g_fd_cookie_map[i].load(std::memory_order_relaxed);
    const int uid = g_fd_uid_map[i].load(std::memory_order_relaxed);
    if (g_fd_map[i].load(std::memory_order_acquire) == fd &&
        mappedCookie == cookie) {
      return uid;
    }
    // A concurrent record may have created another slot for the same fd.
    // Keep scanning instead of returning a false negative on the first one.
  }
  return -1;
}

bool readSelfMemory(uintptr_t address, void* out, size_t length) {
  iovec local{out, length};
  iovec remote{reinterpret_cast<void*>(address), length};
  return process_vm_readv(getpid(), &local, 1, &remote, 1, 0) ==
         static_cast<ssize_t>(length);
}

bool isSeqpacketFd(int fd) {
  if (fd < 0) return false;
  int domain = 0;
  socklen_t length = sizeof(domain);
  if (getsockopt(fd, SOL_SOCKET, SO_DOMAIN, &domain, &length) != 0 ||
      domain != AF_UNIX) {
    return false;
  }
  int type = 0;
  length = sizeof(type);
  return getsockopt(fd, SOL_SOCKET, SO_TYPE, &type, &length) == 0 &&
         type == SOCK_SEQPACKET;
}

bool socketCookieForFd(int fd, uint64_t* cookie) {
  if (cookie == nullptr || !isSeqpacketFd(fd)) return false;
  uint64_t value = 0;
  socklen_t length = sizeof(value);
  if (getsockopt(fd, SOL_SOCKET, SO_COOKIE, &value, &length) != 0 ||
      length != sizeof(value) || value == 0) {
    return false;
  }
  *cookie = value;
  return true;
}

// Read only the configured/AOSP fields. Guessing another pointer from a live
// system_server object could associate an unrelated socket with an app UID.
bool recordConnectionUid(uintptr_t object, int32_t uid) {
  if (object < 0x1000 || uid <= 0) return false;
  const int uidOffset = g_connection_uid_offset.load(std::memory_order_relaxed);
  if (uidOffset <= 0 ||
      uidOffset > static_cast<int>(0x200 - sizeof(int32_t))) {
    g_mapping_rejects.fetch_add(1, std::memory_order_relaxed);
    return false;
  }
  int32_t objectUid = -1;
  if (!readSelfMemory(object + static_cast<uintptr_t>(uidOffset), &objectUid,
                      sizeof(objectUid)) ||
      objectUid != uid) {
    g_mapping_rejects.fetch_add(1, std::memory_order_relaxed);
    return false;
  }
  const int tubeOffset = g_bit_tube_offset.load(std::memory_order_relaxed);
  const int fdOffset = g_bit_tube_fd_offset.load(std::memory_order_relaxed);
  uintptr_t tube = 0;
  if (!readSelfMemory(object + static_cast<uintptr_t>(tubeOffset), &tube,
                      sizeof(tube))) {
    g_mapping_rejects.fetch_add(1, std::memory_order_relaxed);
    return false;
  }
  tube = untagPtr(tube);
  if (tube < 0x1000 || (tube % alignof(uintptr_t)) != 0) {
    g_mapping_rejects.fetch_add(1, std::memory_order_relaxed);
    return false;
  }
  int fd = -1;
  uint64_t cookie = 0;
  if (!readSelfMemory(tube + static_cast<uintptr_t>(fdOffset), &fd, sizeof(fd))) {
    g_mapping_rejects.fetch_add(1, std::memory_order_relaxed);
    return false;
  }
  if (!socketCookieForFd(fd, &cookie)) {
    g_cookie_failures.fetch_add(1, std::memory_order_relaxed);
    g_mapping_rejects.fetch_add(1, std::memory_order_relaxed);
    return false;
  }
  if (!recordFdUid(fd, uid, cookie)) {
    g_mapping_rejects.fetch_add(1, std::memory_order_relaxed);
    return false;
  }
  g_layout_discovered.store(true, std::memory_order_relaxed);
  return true;
}

// C1 PLT stub: x0=this, x1=sp<SensorService>, w2=uid。
void ctorPltPreInterceptor(shadowhook_cpu_context_t* ctx, void*) {
  if (ctx == nullptr) return;
  const uintptr_t thiz = untagPtr(ctx->regs[0]);
  const int32_t uid = static_cast<int32_t>(ctx->regs[2]);
  if (thiz < 0x1000 || uid <= 0) return;
  std::unique_lock<std::mutex> lock(g_pending_mutex, std::try_to_lock);
  if (!lock.owns_lock()) return;
  PendingCtor& pending = g_pending[g_pending_pos];
  pending.thiz = thiz;
  pending.uid = uid;
  pending.at = nowNanos();
  pending.used = true;
  g_pending_pos = (g_pending_pos + 1) % kPendingCtors;
}

void* ctorPendingThread(void*) {
  while (true) {
    usleep(20 * 1000);
    const int64_t now = nowNanos();
    std::lock_guard<std::mutex> lock(g_pending_mutex);
    for (auto& pending : g_pending) {
      if (!pending.used) continue;
      if (now - pending.at > 1000000000LL) {
        pending.used = false;
        continue;
      }
      if (!recordConnectionUid(pending.thiz, pending.uid)) continue;
      pending.used = false;
    }
  }
  return nullptr;
}

// ---------------------------------------------------------------- 合成步数注入

void* stepInjectThread(void*) {
  uint64_t tick = 0;
  int64_t lastInject = 0;
  int64_t lastDetectorStep = -1;
  while (true) {
    usleep(100 * 1000);
    const int64_t now = nowNanos();
    int cadence = 0;
    int64_t interval = 0;
    uint64_t value = 0;
    int64_t delta = 0;
    int32_t counterHandle = -1;
    int32_t detectorHandle = -1;
    uint64_t targetGeneration = 0;
    {
      std::lock_guard<std::mutex> lock(g_config_mutex);
      if (!g_config.active || !g_config.stepSimulation ||
          g_event_stride.load(std::memory_order_relaxed) !=
              sizeof(SensorsEvent)) continue;
      if (speedNowLocked(now) > kMaxSimulatedStepSpeedMps) continue;

      cadence = static_cast<int>(std::lround(cadenceNowLocked(now)));
      if (cadence < 1) continue;
      interval = static_cast<int64_t>(60000000000.0 / cadence);
      interval = std::max<int64_t>(interval, 100000000LL);
      if (now - lastInject < interval) continue;

      // 真实步事件到达时跳过本 tick，避免与合成事件重复
      const int64_t lastRealStep =
          g_last_real_step_ns.load(std::memory_order_relaxed);
      if (lastRealStep > 0 && now - lastRealStep < interval * 3 / 4) {
        continue;
      }
      lastInject = now;

      const double stepsFloat = currentStepsLocked(now);
      value = static_cast<uint64_t>(std::floor(stepsFloat));
      delta = static_cast<int64_t>(value) - lastDetectorStep;
      counterHandle = g_config.stepCounterHandle;
      detectorHandle = g_config.stepDetectorHandle;
      targetGeneration = g_target_generation.load(std::memory_order_relaxed);
    }

    // Do not hold g_config_mutex across fcntl/send: the send hook must still
    // be able to take its own short snapshot.
    if (targetGeneration !=
        g_target_generation.load(std::memory_order_acquire)) {
      continue;
    }

    int32_t sentUids[kMaxTargetFds];
    size_t sentCount = 0;
    bool detectorSent = false;

    for (size_t i = 0; i < kMaxTargetFds; ++i) {
      const int fd = g_target_fds[i].load(std::memory_order_acquire);
      if (fd < 0) continue;

      const uint64_t cookie =
          g_target_fd_cookies[i].load(std::memory_order_acquire);
      int32_t uid = g_target_fd_uids[i].load(std::memory_order_acquire);
      if (uid <= 0) uid = uidForFd(fd, cookie);
      if (uid <= 0) {
        clearTargetFd(i, fd, cookie);
        continue;
      }
      if (targetGeneration !=
          g_target_generation.load(std::memory_order_acquire)) {
        break;
      }
      bool alreadySent = false;
      for (size_t j = 0; j < sentCount; ++j) {
        if (sentUids[j] == uid) {
          alreadySent = true;
          break;
        }
      }
      // 同一 UID 可能有多条 SensorEventConnection，每个 tick 只注入一条
      if (alreadySent) continue;

      // 先复制 fd 固定住 socket 身份，避免检查后 fd 被关闭并复用。
      const int sendFd = fcntl(fd, F_DUPFD_CLOEXEC, 0);
      uint64_t sendCookie = 0;
      if (sendFd < 0 || !socketCookieForFd(sendFd, &sendCookie) ||
          sendCookie != cookie) {
        if (sendFd >= 0) close(sendFd);
        clearTargetFd(i, fd, cookie);
        continue;
      }
      sentUids[sentCount++] = uid;

      SensorsEvent counter{};
      counter.version = static_cast<int32_t>(sizeof(SensorsEvent));
      counter.sensor = counterHandle;
      counter.type = kTypeStepCounter;
      counter.timestamp = now;
      counter.u.step_counter = value;

      const ssize_t rc = syscall(__NR_sendto, sendFd, &counter, sizeof(counter),
                                 MSG_DONTWAIT | MSG_NOSIGNAL, nullptr, 0);
      if (rc != static_cast<ssize_t>(sizeof(counter))) {
        if (rc < 0 && errno != EAGAIN && errno != EWOULDBLOCK &&
            errno != ENOBUFS) {
          clearTargetFd(i, fd, cookie);
        }
        close(sendFd);
        continue;
      }
      g_injected_events.fetch_add(1, std::memory_order_relaxed);

      if (delta > 0 && detectorHandle >= 0) {
        // 一次 tick 内可能跨过多个整数步；最多补 4 个 step detector 事件并按时间戳插值
        const int64_t count = std::min<int64_t>(delta, 4);
        const int64_t spacing = interval / std::max<int64_t>(count, 1);
        for (int64_t k = 0; k < count; ++k) {
          SensorsEvent detector{};
          detector.version = static_cast<int32_t>(sizeof(SensorsEvent));
          detector.sensor = detectorHandle;
          detector.type = kTypeStepDetector;
          detector.timestamp = now - (count - 1 - k) * spacing;
          detector.u.data[0] = 1.0f;
          if (syscall(__NR_sendto, sendFd, &detector, sizeof(detector),
                      MSG_DONTWAIT | MSG_NOSIGNAL, nullptr, 0) ==
              static_cast<ssize_t>(sizeof(detector))) {
            g_injected_events.fetch_add(1, std::memory_order_relaxed);
            detectorSent = true;
          }
        }
      }
      close(sendFd);
    }
    if (delta > 0 && detectorSent) {
      lastDetectorStep = static_cast<int64_t>(value);
    }

    if ((++tick % 25) == 0) {
      LOGI("inject tick=%llu value=%llu cadence=%d targets=%zu total=%llu",
           static_cast<unsigned long long>(tick),
           static_cast<unsigned long long>(value), cadence, sentCount,
           static_cast<unsigned long long>(g_injected_events.load()));
    }
  }
  return nullptr;
}

// ---------------------------------------------------------------- Hook

using ConnectionCtorFn = void (*)(void* thiz, const void* service, uint32_t uid,
                                  const void* name, bool wakeup, const void* opPkg,
                                  const void* attribution);
ConnectionCtorFn g_orig_connection_ctor = nullptr;

void probeConnectionCtor(void* thiz, const void* service, uint32_t uid,
                         const void* name, bool wakeup, const void* opPkg,
                         const void* attribution) {
  if (g_orig_connection_ctor != nullptr) {
    g_orig_connection_ctor(thiz, service, uid, name, wakeup, opPkg, attribution);
  }
  if (thiz == nullptr) return;
  const uintptr_t object = untagPtr(reinterpret_cast<uintptr_t>(thiz));
  // 只建立 fd -> uid 映射；目标 fd 在首次看到该连接的步/加速度事件时登记，
  // 避免向没有注册相关传感器的连接注入事件。
  if (!recordConnectionUid(object, static_cast<int32_t>(uid)) &&
      !g_layout_warning_logged.exchange(true, std::memory_order_relaxed)) {
    LOGE("configured BitTube layout did not validate; native mapping will pass through");
  }
}

// 按路线真北 + WMM 磁偏角改写指南针类事件。
// TYPE_HEADING 使用真北；其余磁北参考类型使用 magnetic = true - declination。
// pitch/roll 来自 6DoF 步态姿态模型；磁场/旋转矢量与 orientation 使用同一姿态。
void rewriteCompassEvent(SensorsEvent& e, double trueHeadingDeg,
                         double declinationDeg, double accuracyDeg,
                         bool fieldValid, double horizontalUt,
                         double verticalUt, const Attitude& attitude,
                         uint64_t seed, double timeSec) {
  // attitude 的 yaw 已包含路线转向 + 直线微扰；所有指南针类型共用它。
  const double magnetic = std::isfinite(attitude.yawMagneticRad)
      ? normalizeDegrees(attitude.yawMagneticRad * 180.0 / kPi)
      : normalizeDegrees(trueHeadingDeg - declinationDeg);
  const double trueHeading = normalizeDegrees(magnetic + declinationDeg);
  const double magneticRad = magnetic * kPi / 180.0;
  // 指南针精度随磁场质量/手持姿态缓慢变化，不再永远 5.0°。
  const double accuracyNow = std::max(0.0, accuracyDeg) * (
      1.0 + 0.12 * std::sin(
          2.0 * kPi * timeSec / 31.0 + hashPhase(seed, 70)) +
      0.06 * std::sin(
          2.0 * kPi * timeSec / 9.0 + hashPhase(seed, 71)));

  switch (e.type) {
    case kTypeHeading:
      e.u.data[0] = static_cast<float>(trueHeading);
      e.u.data[1] = static_cast<float>(accuracyNow);
      break;

    case kTypeOrientation:
      e.u.data[0] = static_cast<float>(magnetic);
      // quaternion 已按 Android getOrientation 的 yaw/pitch/roll 顺序构造，
      // 这里直接写同一姿态的 pitch/roll，不再做符号翻转。
      e.u.data[1] = static_cast<float>(attitude.pitchRad * 180.0 / kPi);
      e.u.data[2] = static_cast<float>(attitude.rollRad * 180.0 / kPi);
      break;

    case kTypeMagneticField:
    case kTypeMagneticFieldUncalibrated: {
      float horizontal;
      float z;
      if (fieldValid && std::isfinite(horizontalUt) &&
          std::isfinite(verticalUt) && horizontalUt > 1.0) {
        // WMM 给出的当地水平/垂直分量；传感器 Z 轴向上，WMM 垂直分量向下为正。
        horizontal = static_cast<float>(std::clamp(horizontalUt, 5.0, 80.0));
        z = static_cast<float>(std::clamp(-verticalUt, -80.0, 80.0));
      } else {
        // worker 尚未提供 WMM 数据时退回真实事件，并做安全限幅。
        const float rawX = e.u.data[0];
        const float rawY = e.u.data[1];
        const float rawZ = e.u.data[2];
        float rawHorizontal = std::sqrt(rawX * rawX + rawY * rawY);
        if (!std::isfinite(rawHorizontal) || rawHorizontal < 0.001f) {
          rawHorizontal = 25.0f;
        }
        // 部分 ROM 的 magnetometer 事件是未标定/放大值（可能到数百 µT）；
        // 归一到地球磁场量级，避免指南针因“异常磁场”进入校准界面。
        horizontal = std::clamp(rawHorizontal, 12.0f, 60.0f);
        z = std::isfinite(rawZ) ? rawZ : 0.0f;
        if (z < -70.0f || z > 70.0f) {
          z = rawZ >= 0.0f ? 45.0f : -45.0f;
        }
      }
      double field[3] = {
          -horizontal * static_cast<double>(std::sin(magneticRad)),
          horizontal * static_cast<double>(std::cos(magneticRad)),
          static_cast<double>(z),
      };
      double tilted[3];
      rotateByTilt(field[0], field[1], field[2],
                   attitude.pitchRad, attitude.rollRad, tilted);
      // 真实磁力计有轻微硬铁/软铁误差和温漂；这里给每个轴独立的小偏置，
      // 让指南针不再精确等于 WMM 理论值（约 0.2–0.5µT，航向影响 <1°）。
      // uncalibrated 的 bias 字段同步填这个偏置，保证 raw - bias 仍有意义。
      const double magBias[3] = {
          0.30 * std::sin(2.0 * kPi * timeSec / 97.0 + hashPhase(seed, 41)) +
              0.10 * std::sin(2.0 * kPi * timeSec / 13.0 + hashPhase(seed, 42)),
          0.28 * std::sin(2.0 * kPi * timeSec / 83.0 + hashPhase(seed, 43)) +
              0.09 * std::sin(2.0 * kPi * timeSec / 17.0 + hashPhase(seed, 44)),
          0.24 * std::sin(2.0 * kPi * timeSec / 109.0 + hashPhase(seed, 45)) +
              0.08 * std::sin(2.0 * kPi * timeSec / 11.0 + hashPhase(seed, 46)),
      };
      for (int axis = 0; axis < 3; ++axis) {
        const double soft =
            1.0 + 0.002 * std::sin(
                2.0 * kPi * timeSec / (53.0 + axis * 7.0) +
                hashPhase(seed, 50 + axis));
        tilted[axis] = tilted[axis] * soft + magBias[axis];
        e.u.data[axis] = static_cast<float>(tilted[axis]);
      }
      if (e.type == kTypeMagneticFieldUncalibrated) {
        e.u.data[3] = static_cast<float>(magBias[0]);
        e.u.data[4] = static_cast<float>(magBias[1]);
        e.u.data[5] = static_cast<float>(magBias[2]);
      }
      break;
    }

    case kTypeRotationVector:
    case kTypeGameRotationVector:
    case kTypeGeomagneticRotationVector: {
      // 沿用 Android rotation-vector 的 z 轴符号：heading 增大时 z 为负。
      const Quat q = quatFromYawPitchRoll(
          -magneticRad, attitude.pitchRad, attitude.rollRad);
      e.u.data[0] = static_cast<float>(q.x);
      e.u.data[1] = static_cast<float>(q.y);
      e.u.data[2] = static_cast<float>(q.z);
      e.u.data[3] = static_cast<float>(q.w);
      if (e.type == kTypeRotationVector) {
        // TYPE_ROTATION_VECTOR 第 5 个字段是弧度单位的航向精度。
        e.u.data[4] = static_cast<float>(accuracyNow * kPi / 180.0);
      }
      break;
    }

    default:
      break;
  }
}

// 与 core-geo GyroMotion 对齐的手持跑步角速度模型（rad/s）。
constexpr uint64_t kGyroSaltX = 0x4759524F58ULL;
constexpr uint64_t kGyroSaltY = 0x4759524F59ULL;
constexpr uint64_t kGyroSaltZ = 0x4759524F5AULL;
constexpr uint64_t kGyroSaltNoiseX = 0x4E4F49534558ULL;
constexpr uint64_t kGyroSaltNoiseY = 0x4E4F49534559ULL;
constexpr uint64_t kGyroSaltNoiseZ = 0x4E4F4953455AULL;
constexpr uint64_t kGyroSaltStep = 0x53544550ULL;

double gyroNoise(double amplitude, double tSec, uint64_t seed) {
  if (amplitude <= 0.0) return 0.0;
  const double p1 = 2.0 * kPi * hashUnit(seed, 1);
  const double p2 = 2.0 * kPi * hashUnit(seed, 2);
  const double p3 = 2.0 * kPi * hashUnit(seed, 3);
  return amplitude * (
      0.55 * std::sin(2.0 * kPi * tSec / 1.7 + p1) +
      0.30 * std::sin(2.0 * kPi * tSec / 0.63 + p2) +
      0.15 * std::sin(2.0 * kPi * tSec / 0.27 + p3));
}

void gyroSample(double stepsFloat, int cadenceSpm, double speedMps,
                int realismLevel, int fluctuationPct, uint64_t startMs,
                double yawRateRad, double elapsedSec, float out[3]) {
  out[0] = out[1] = out[2] = 0.0f;
  if (!std::isfinite(stepsFloat) || !std::isfinite(speedMps) ||
      !std::isfinite(elapsedSec) || speedMps <= 0.05) {
    return;
  }
  const double speed = std::max(0.0, speedMps);
  const double realism = std::clamp(realismLevel, 0, 3) / 3.0;
  const double fluctuation = std::clamp(fluctuationPct, 0, 30) / 100.0;
  const bool running = speed >= 2.2;
  const double runningScale =
      !running ? 1.0 : (realism >= 0.9 ? 1.75 : 1.60);
  const double baseScale = (0.65 + 0.35 * realism) * runningScale;
  const double rollAmp =
      std::max(0.03, 0.10 + 0.045 * speed) * baseScale;
  const double pitchAmp =
      std::max(0.025, 0.08 + 0.038 * speed) * baseScale;
  const double yawAmp =
      std::max(0.02, 0.06 + 0.028 * speed) * baseScale;
  const double noiseAmp = (0.02 + 0.012 * speed) *
      (0.5 + 0.5 * realism) * (1.0 + 0.5 * fluctuation) *
      (running ? 1.25 : 1.0);

  const int cadence = std::clamp(cadenceSpm, 60, 240);
  const double strikeWidth =
      std::clamp(0.075 * 120.0 / cadence, 0.055, 0.110);
  const double step = std::floor(stepsFloat);
  const int64_t stepIndex = static_cast<int64_t>(step);
  const double phase = 2.0 * kPi * (stepsFloat - step);
  const double strike = std::exp(
      -0.5 * std::pow((stepsFloat - step - 0.02) / strikeWidth, 2));
  const double stepStrength = hashUnit(startMs ^ kGyroSaltStep, stepIndex);
  const double alternating = (stepIndex % 2 == 0) ? 1.0 : -1.0;

  const double x1 = 2.0 * kPi * hashUnit(startMs ^ kGyroSaltX, 1);
  const double x2 = 2.0 * kPi * hashUnit(startMs ^ kGyroSaltX, 2);
  const double x3 = 2.0 * kPi * hashUnit(startMs ^ kGyroSaltX, 3);
  const double y1 = 2.0 * kPi * hashUnit(startMs ^ kGyroSaltY, 1);
  const double y2 = 2.0 * kPi * hashUnit(startMs ^ kGyroSaltY, 2);
  const double z1 = 2.0 * kPi * hashUnit(startMs ^ kGyroSaltZ, 1);
  const double z2 = 2.0 * kPi * hashUnit(startMs ^ kGyroSaltZ, 2);

  const double gaitX = rollAmp * (
      0.72 * std::sin(phase + x1) +
      0.20 * std::sin(2.0 * phase + x2) +
      0.08 * std::sin(3.0 * phase + x3)) +
      rollAmp * 0.35 * stepStrength * strike;
  const double gaitY = pitchAmp * (
      0.68 * std::sin(phase + y1) +
      0.24 * std::sin(2.0 * phase + y2)) +
      pitchAmp * 0.25 * alternating * strike;
  const double gaitZ = yawAmp * (
      0.75 * std::sin(phase + z1) +
      0.25 * std::sin(3.0 * phase + z2)) +
      yawAmp * 0.20 * alternating * strike;

  const double turn = std::clamp(yawRateRad, -3.5, 3.5);
  const double noiseX =
      gyroNoise(noiseAmp, elapsedSec, startMs ^ kGyroSaltNoiseX);
  const double noiseY =
      gyroNoise(noiseAmp, elapsedSec, startMs ^ kGyroSaltNoiseY);
  const double noiseZ =
      gyroNoise(noiseAmp, elapsedSec, startMs ^ kGyroSaltNoiseZ);

  out[0] = static_cast<float>(std::clamp(gaitX + noiseX, -6.0, 6.0));
  out[1] = static_cast<float>(std::clamp(gaitY + noiseY, -6.0, 6.0));
  out[2] = static_cast<float>(std::clamp(gaitZ + turn + noiseZ, -6.0, 6.0));
}

bool eventVersionMatches(int32_t version, size_t stride) {
  // Some vendor HALs leave sensors_event_t.version at zero; the record size
  // is still known from the configured stride.
  return version == 0 || version == static_cast<int32_t>(stride);
}

// __sendto svc 拦截器：在 syscall 执行前改写目标 UID 的事件
bool rewriteEventBatch(void* base, size_t rawLen, int fd, int32_t uid,
                       uint64_t cookie) {
  if (base == nullptr) return false;
  const size_t stride = g_event_stride.load(std::memory_order_relaxed);
  if (stride < sizeof(SensorsEvent) || stride > 0x200 ||
      (stride % alignof(SensorsEvent)) != 0 ||
      rawLen < stride || rawLen % stride != 0 ||
      rawLen > stride * 256 || rawLen > kMaxNativeBatchBytes) {
    g_invalid_batches.fetch_add(1, std::memory_order_relaxed);
    g_last_batch_len.store(rawLen, std::memory_order_relaxed);
    return false;
  }
  auto* eventBytes = static_cast<char*>(base);
  auto eventAt = [&](size_t i) -> SensorsEvent& {
    return *reinterpret_cast<SensorsEvent*>(eventBytes + i * stride);
  };
  const size_t count = rawLen / stride;

  // AOSP sensors_event_t.version must identify its complete record size.
  // Unknown layouts are passed through without touching any event bytes.
  for (size_t i = 0; i < count; ++i) {
    if (!eventVersionMatches(eventAt(i).version, stride)) {
      g_invalid_batches.fetch_add(1, std::memory_order_relaxed);
      g_version_skips.fetch_add(1, std::memory_order_relaxed);
      g_last_batch_len.store(rawLen, std::memory_order_relaxed);
      return false;
    }
  }

  bool hasStep = false;
  bool hasAccel = false;
  bool hasPressure = false;
  bool hasCompass = false;
  bool hasGyro = false;
  for (size_t i = 0; i < count; ++i) {
    if (eventAt(i).type == kTypeStepDetector || eventAt(i).type == kTypeStepCounter) {
      hasStep = true;
    } else if (isAccelerometerFamily(eventAt(i).type)) {
      hasAccel = true;
    } else if (eventAt(i).type == kTypePressure) {
      hasPressure = true;
    } else if (isCompassType(eventAt(i).type)) {
      hasCompass = true;
    } else if (isGyroType(eventAt(i).type)) {
      hasGyro = true;
    }
  }
  if (!hasStep && !hasAccel && !hasPressure && !hasCompass && !hasGyro) {
    return false;
  }
  if (fd < 0) return false;

  if (uid <= 0 || cookie == 0) return false;
  int rewritten = 0;
  bool changed = false;
  {
    std::unique_lock<std::mutex> lock(g_config_mutex, std::try_to_lock);
    if (!lock.owns_lock()) return false;
    if (!g_config.active) return false;
    if (!isTargetUidLocked(uid)) {
      return false;
    }

    const int64_t now = nowNanos();
    // 第一次看到目标 App 的真实计步事件时，以它的累计值为起点续接，
    // 避免合成计数器从 0 开始导致用户看到步数回退。
    if (!g_counter_base_captured && g_config.stepSimulation) {
      for (size_t i = 0; i < count; ++i) {
        if (eventAt(i).type == kTypeStepCounter) {
          g_clock_base_steps = static_cast<double>(eventAt(i).u.step_counter);
          g_clock_origin_ns = now;
          g_counter_base_captured = true;
          break;
        }
      }
    }
    if (hasStep) {
      // 真实步事件用于抑制同 tick 的合成事件，减少重复投递
      g_last_real_step_ns.store(now, std::memory_order_relaxed);
    }
    const bool motionBatch = hasStep || hasAccel || hasGyro;
    const double speedNow = motionBatch ? speedNowLocked(now) : 0.0;
    if (motionBatch && g_config.stepSimulation &&
        speedNow > kMaxSimulatedStepSpeedMps) {
      // 高速段冻结步数时钟：既不会在驾车时刷步数，也不会在速度降回
      // 步行后突然把高速段“欠下的”步数一次性补出来。
      g_clock_base_steps = currentStepsLocked(now);
      g_clock_origin_ns = now;
    }
    const double stepsFloat =
        motionBatch ? currentStepsLocked(now) : 0.0;
    const uint64_t stepValue = static_cast<uint64_t>(std::floor(stepsFloat));
    // 200ms 差分足以滤掉步态高频，保留速度浮动/加减速带来的低频分量。
    const double forwardAccel = motionBatch
        ? (speedNow - speedNowLocked(now - 200000000LL)) / 0.2
        : 0.0;
    const double cadenceNow = cadenceNowLocked(now);
    const double attitudeHeading =
        g_config.compassHeadingValid ? g_config.compassTrueHeadingDeg : 0.0;
    const double attitudeDeclination =
        g_config.compassHeadingValid ? g_config.compassDeclinationDeg : 0.0;
    const Attitude attitude = computeAttitude(
        stepsFloat, speedNow, static_cast<int>(std::lround(cadenceNow)),
        attitudeHeading, attitudeDeclination,
        g_config.compassYawRateRad, g_config.realismLevel,
        static_cast<uint64_t>(g_clock_origin_ns),
        static_cast<double>(now) / 1e9);
    const GaitTemplate* tmpl = g_gait.get();
    const bool stepMotion = g_config.stepSimulation &&
        speedNow <= kMaxSimulatedStepSpeedMps;
    const bool accelMotion = g_config.accelerometerSimulation &&
        speedNow <= kMaxSimulatedStepSpeedMps;
    int compassRewritten = 0;
    int gyroRewritten = 0;
    for (size_t i = 0; i < count; ++i) {
      if (stepMotion &&
          (eventAt(i).type == kTypeStepDetector ||
           eventAt(i).type == kTypeStepCounter)) {
        if (rewriteStepEvent(eventAt(i), now, stepValue)) {
          ++rewritten;
          changed = true;
        }
      } else if (accelMotion &&
                 speedNow > 0.1 &&
                 isAccelerometerFamily(eventAt(i).type)) {
        // 不按 accelerometerHandle 过滤：目标 App 可能注册多个加速度计
        // （默认/未校准/线性加速度/重力传感器等），全部改写。
        applyGait(eventAt(i), now, g_config, tmpl, stepsFloat, speedNow,
                  forwardAccel,
                  static_cast<uint64_t>(g_clock_origin_ns), attitude);
        g_accel_rewritten_events.fetch_add(1, std::memory_order_relaxed);
        changed = true;
      } else if (g_config.pressureEnabled &&
                 eventAt(i).type == kTypePressure) {
        // 与 SensorPressurePolicy 对齐：只改写时间戳在合理窗口内的真实事件。
        const int64_t eventTs = eventAt(i).timestamp;
        if (eventTs > 0 &&
            (eventTs > now + 100000000LL ||
             now - eventTs > 1500000000LL)) {
          continue;
        }
        eventAt(i).u.data[0] = static_cast<float>(pressureNowLocked(now));
        eventAt(i).timestamp = now;
        g_pressure_rewritten_events.fetch_add(1, std::memory_order_relaxed);
        changed = true;
      } else if (g_config.compassSimulation &&
                 isCompassType(eventAt(i).type)) {
        // 方位最多 2 秒未刷新时退回真实事件，避免 worker 停止后持续使用旧方位。
        if (!g_config.compassHeadingValid ||
            now - g_config.compassHeadingAtNs > 2000000000LL) {
          continue;
        }
        const int64_t eventTs = eventAt(i).timestamp;
        if (eventTs > 0 &&
            (eventTs > now + 100000000LL ||
             now - eventTs > 1500000000LL)) {
          continue;
        }
        rewriteCompassEvent(
            eventAt(i),
            g_config.compassTrueHeadingDeg,
            g_config.compassDeclinationDeg,
            g_config.compassAccuracyDeg,
            g_config.compassFieldValid,
            g_config.compassHorizontalUt,
            g_config.compassVerticalUt,
            attitude,
            static_cast<uint64_t>(g_clock_origin_ns),
            static_cast<double>(now) / 1e9);
        ++compassRewritten;
        changed = true;
      } else if (g_config.compassSimulation &&
                 isGyroType(eventAt(i).type)) {
        if (!g_config.compassHeadingValid ||
            now - g_config.compassHeadingAtNs > 2000000000LL ||
            speedNow <= 0.05) {
          continue;
        }
        const int64_t eventTs = eventAt(i).timestamp;
        if (eventTs > 0 &&
            (eventTs > now + 100000000LL ||
             now - eventTs > 1500000000LL)) {
          continue;
        }
        // 用同一姿态在 t 与 t-dt 的四元数差分求身体角速度；
        // orientation/gravity/magnetic 也使用这个姿态，避免三组波形各说各话。
        constexpr double kGyroDtSec = 0.01;
        const Quat qNow = quatFromYawPitchRoll(
            -attitude.yawMagneticRad, attitude.pitchRad, attitude.rollRad);
        const Quat qPrev = quatFromYawPitchRoll(
            -(attitude.yawMagneticRad - attitude.yawRateRad * kGyroDtSec),
            attitude.pitchRad - attitude.pitchRateRad * kGyroDtSec,
            attitude.rollRad - attitude.rollRateRad * kGyroDtSec);
        float gyro[3] = {0.0f, 0.0f, 0.0f};
        bodyAngularVelocity(qNow, qPrev, kGyroDtSec, gyro);
        const double tSec = static_cast<double>(now) / 1e9;
        const uint64_t gyroSeed = static_cast<uint64_t>(g_clock_origin_ns);
        std::normal_distribution<double> gyroNoise(0.0, 0.0016);
        float gyroBias[3];
        for (int axis = 0; axis < 3; ++axis) {
          gyroBias[axis] = static_cast<float>(
              0.0040 * std::sin(
                  2.0 * kPi * tSec / (43.0 + axis * 9.0) +
                  hashPhase(gyroSeed, 60 + axis)) +
              0.0015 * std::sin(
                  2.0 * kPi * tSec / (3.7 + axis) +
                  hashPhase(gyroSeed, 64 + axis)));
          gyro[axis] = static_cast<float>(
              std::clamp(static_cast<double>(gyro[axis]) +
                             gyroBias[axis] + gyroNoise(g_rng),
                         -6.0, 6.0));
        }
        eventAt(i).u.data[0] = gyro[0];
        eventAt(i).u.data[1] = gyro[1];
        eventAt(i).u.data[2] = gyro[2];
        if (eventAt(i).type == kTypeGyroscopeUncalibrated) {
          eventAt(i).u.data[3] = gyroBias[0];
          eventAt(i).u.data[4] = gyroBias[1];
          eventAt(i).u.data[5] = gyroBias[2];
        }
        ++gyroRewritten;
        changed = true;
      }
    }
    if (compassRewritten > 0) {
      g_compass_rewritten_events.fetch_add(
          static_cast<uint64_t>(compassRewritten),
          std::memory_order_relaxed);
    }
    if (gyroRewritten > 0) {
      g_gyro_rewritten_events.fetch_add(
          static_cast<uint64_t>(gyroRewritten),
          std::memory_order_relaxed);
    }
    if (hasStep) {
      g_rewritten_events.fetch_add(static_cast<uint64_t>(rewritten),
                                   std::memory_order_relaxed);
    }
  }
  if (hasStep || hasAccel) {
    recordTargetFd(fd, cookie, uid);
  }
  if (changed) g_native_send_rewrote = true;
  return changed;
}

bool readRemoteMemory(uintptr_t address, void* out, size_t size) {
  if (address < 0x1000 || out == nullptr || size == 0) return false;
  iovec local{out, size};
  iovec remote{reinterpret_cast<void*>(address), size};
  return process_vm_readv(getpid(), &local, 1, &remote, 1, 0) ==
         static_cast<ssize_t>(size);
}

using SendFn = ssize_t (*)(int, const void*, size_t, int);
using SendtoFn = ssize_t (*)(int, const void*, size_t, int,
                             const sockaddr*, socklen_t);
using SendmsgFn = ssize_t (*)(int, const msghdr*, int);
SendFn g_orig_send = nullptr;
SendtoFn g_orig_sendto = nullptr;
SendmsgFn g_orig_sendmsg = nullptr;

struct NativeSendHookScope {
  bool outermost;
  NativeSendHookScope() : outermost(g_native_send_hook_depth++ == 0) {
    if (outermost) g_native_send_rewrote = false;
  }
  ~NativeSendHookScope() {
    --g_native_send_hook_depth;
    if (outermost) g_native_send_rewrote = false;
  }
};

bool targetUidForFd(int fd, uint64_t* cookie, int32_t* uid) {
  if (cookie == nullptr || uid == nullptr) return false;
  uint64_t observedCookie = 0;
  if (!socketCookieForFd(fd, &observedCookie)) return false;
  // Active target connections carry their UID directly. This keeps rewriting
  // working even if the generic fd map evicted their entry.
  for (size_t i = 0; i < kMaxTargetFds; ++i) {
    if (g_target_fds[i].load(std::memory_order_acquire) != fd) continue;
    const uint64_t targetCookie =
        g_target_fd_cookies[i].load(std::memory_order_acquire);
    const int32_t targetUid =
        g_target_fd_uids[i].load(std::memory_order_acquire);
    if (targetCookie == observedCookie && targetUid > 0) {
      *cookie = observedCookie;
      *uid = targetUid;
      return true;
    }
  }
  const int observedUid = uidForFd(fd, observedCookie);
  if (observedUid <= 0) return false;
  *cookie = observedCookie;
  *uid = observedUid;
  return true;
}

bool peerUidForFd(int fd, uint64_t cookie, int32_t* uid) {
  if (fd < 0 || cookie == 0 || uid == nullptr) return false;
  ucred cred{};
  socklen_t length = sizeof(cred);
  if (getsockopt(fd, SOL_SOCKET, SO_PEERCRED, &cred, &length) != 0 ||
      length != sizeof(cred) || cred.uid == 0) {
    return false;
  }
  const int32_t peerUid = static_cast<int32_t>(cred.uid);
  if (!recordFdUid(fd, peerUid, cookie)) return false;
  *uid = peerUid;
  return true;
}

// Svc fallback needs the peer-uid path when the constructor hook missed a
// connection (for example a process that connected before the hook was in
// place). Function-entry hooks still use the stricter map-only lookup.
bool targetUidForFdPeer(int fd, uint64_t* cookie, int32_t* uid) {
  if (targetUidForFd(fd, cookie, uid)) return true;
  uint64_t observedCookie = 0;
  if (!socketCookieForFd(fd, &observedCookie)) return false;
  int32_t observedUid = -1;
  if (!peerUidForFd(fd, observedCookie, &observedUid)) return false;
  *cookie = observedCookie;
  *uid = observedUid;
  return true;
}

int fdFromBitTube(uintptr_t tube) {
  if (tube <= 0x1000) return -1;
  int32_t candidate = -1;
  const int fdOffset = g_bit_tube_fd_offset.load(std::memory_order_relaxed);
  if (!readRemoteMemory(tube + static_cast<uintptr_t>(fdOffset), &candidate,
                        sizeof(candidate))) {
    return -1;
  }
  return isSeqpacketFd(candidate) ? candidate : -1;
}

bool eventBufferLength(size_t length, size_t stride) {
  return stride >= sizeof(SensorsEvent) && stride <= 0x200 &&
         (stride % alignof(SensorsEvent)) == 0 && length >= stride &&
         (length % stride) == 0 && length <= stride * 256 &&
         length <= kMaxNativeBatchBytes;
}

ssize_t callOriginalSend(int fd, const void* buffer, size_t length, int flags) {
  if (g_orig_send == nullptr) {
    errno = ENOSYS;
    return -1;
  }
  return g_orig_send(fd, buffer, length, flags);
}

ssize_t callOriginalSendto(int fd, const void* buffer, size_t length, int flags,
                           const sockaddr* address, socklen_t addressLength) {
  if (g_orig_sendto == nullptr) {
    errno = ENOSYS;
    return -1;
  }
  return g_orig_sendto(fd, buffer, length, flags, address, addressLength);
}

ssize_t callOriginalSendmsg(int fd, const msghdr* message, int flags) {
  if (g_orig_sendmsg == nullptr) {
    errno = ENOSYS;
    return -1;
  }
  return g_orig_sendmsg(fd, message, flags);
}

bool writeMsgFlags(const msghdr* message, int msgFlags) {
  if (message == nullptr) return false;
  const uintptr_t address = reinterpret_cast<uintptr_t>(message) +
      offsetof(msghdr, msg_flags);
  iovec local{&msgFlags, sizeof(msgFlags)};
  iovec remote{reinterpret_cast<void*>(address), sizeof(msgFlags)};
  return process_vm_writev(getpid(), &local, 1, &remote, 1, 0) ==
         static_cast<ssize_t>(sizeof(msgFlags));
}

ssize_t nativeSendProxy(int fd, const void* buffer, size_t length, int flags) {
  NativeSendHookScope scope;
  if (!scope.outermost) return callOriginalSend(fd, buffer, length, flags);
  const size_t stride = g_event_stride.load(std::memory_order_relaxed);
  uint64_t cookie = 0;
  int32_t uid = -1;
  if (!eventBufferLength(length, stride) || buffer == nullptr ||
      !targetUidForFd(fd, &cookie, &uid)) {
    return callOriginalSend(fd, buffer, length, flags);
  }

  NativeHookScratch& scratch = g_native_hook_scratch;
  if (!readRemoteMemory(untagPtr(reinterpret_cast<uintptr_t>(buffer)),
                        scratch.bytes.data(), length) ||
      !rewriteEventBatch(scratch.bytes.data(), length, fd, uid, cookie)) {
    return callOriginalSend(fd, buffer, length, flags);
  }
  return callOriginalSend(fd, scratch.bytes.data(), length, flags);
}

ssize_t nativeSendtoProxy(int fd, const void* buffer, size_t length, int flags,
                          const sockaddr* address, socklen_t addressLength) {
  NativeSendHookScope scope;
  if (!scope.outermost) {
    return callOriginalSendto(fd, buffer, length, flags, address, addressLength);
  }
  const size_t stride = g_event_stride.load(std::memory_order_relaxed);
  uint64_t cookie = 0;
  int32_t uid = -1;
  if (!eventBufferLength(length, stride) || buffer == nullptr ||
      !targetUidForFd(fd, &cookie, &uid)) {
    return callOriginalSendto(fd, buffer, length, flags, address, addressLength);
  }

  NativeHookScratch& scratch = g_native_hook_scratch;
  if (!readRemoteMemory(untagPtr(reinterpret_cast<uintptr_t>(buffer)),
                        scratch.bytes.data(), length) ||
      !rewriteEventBatch(scratch.bytes.data(), length, fd, uid, cookie)) {
    return callOriginalSendto(fd, buffer, length, flags, address, addressLength);
  }
  return callOriginalSendto(fd, scratch.bytes.data(), length, flags, address,
                            addressLength);
}

ssize_t nativeSendmsgProxy(int fd, const msghdr* message, int flags) {
  NativeSendHookScope scope;
  if (!scope.outermost) return callOriginalSendmsg(fd, message, flags);

  uint64_t cookie = 0;
  int32_t uid = -1;
  if (message == nullptr || !targetUidForFd(fd, &cookie, &uid)) {
    return callOriginalSendmsg(fd, message, flags);
  }

  NativeHookScratch& scratch = g_native_hook_scratch;
  scratch.used = 0;
  msghdr copiedMessage{};
  if (!readRemoteMemory(untagPtr(reinterpret_cast<uintptr_t>(message)),
                        &copiedMessage, sizeof(copiedMessage)) ||
      copiedMessage.msg_iov == nullptr || copiedMessage.msg_iovlen == 0 ||
      copiedMessage.msg_iovlen > kMaxNativeIov) {
    return callOriginalSendmsg(fd, message, flags);
  }
  if (!readRemoteMemory(
          untagPtr(reinterpret_cast<uintptr_t>(copiedMessage.msg_iov)),
          scratch.iov.data(), sizeof(iovec) * copiedMessage.msg_iovlen)) {
    return callOriginalSendmsg(fd, message, flags);
  }

  const size_t stride = g_event_stride.load(std::memory_order_relaxed);
  std::array<bool, kMaxNativeIov> candidates{};
  std::array<size_t, kMaxNativeIov> offsets{};
  bool anyCandidate = false;
  for (size_t i = 0; i < copiedMessage.msg_iovlen; ++i) {
    const size_t length = scratch.iov[i].iov_len;
    if (length == 0) continue;
    // A small header iovec is normal on some paths; it must not prevent the
    // event iovecs in the same sendmsg from being rewritten.
    if (length < stride || scratch.iov[i].iov_base == nullptr ||
        !eventBufferLength(length, stride)) {
      g_iov_skips.fetch_add(1, std::memory_order_relaxed);
      continue;
    }
    if (scratch.used > kMaxNativeBatchBytes - length) {
      g_iov_skips.fetch_add(1, std::memory_order_relaxed);
      continue;
    }
    const uintptr_t address =
        untagPtr(reinterpret_cast<uintptr_t>(scratch.iov[i].iov_base));
    const uintptr_t end = address + length;
    if (address < 0x1000 || end < address) {
      g_iov_skips.fetch_add(1, std::memory_order_relaxed);
      continue;
    }
    bool overlaps = false;
    for (size_t j = 0; j < i; ++j) {
      if (!candidates[j]) continue;
      const uintptr_t prior =
          untagPtr(reinterpret_cast<uintptr_t>(scratch.iov[j].iov_base));
      const uintptr_t priorEnd = prior + scratch.iov[j].iov_len;
      if (address < priorEnd && prior < end) {
        overlaps = true;
        break;
      }
    }
    if (overlaps) {
      g_iov_skips.fetch_add(1, std::memory_order_relaxed);
      continue;
    }

    const size_t offset = scratch.used;
    if (!readRemoteMemory(address, scratch.bytes.data() + offset, length)) {
      g_iov_skips.fetch_add(1, std::memory_order_relaxed);
      continue;
    }
    offsets[i] = offset;
    scratch.used += length;
    candidates[i] = true;
    anyCandidate = true;
  }
  if (!anyCandidate) return callOriginalSendmsg(fd, message, flags);

  // Every iovec is independent. Skip one with an unknown record version
  // instead of dropping the whole message.
  for (size_t i = 0; i < copiedMessage.msg_iovlen; ++i) {
    if (!candidates[i]) continue;
    const auto* events = reinterpret_cast<const SensorsEvent*>(
        scratch.bytes.data() + offsets[i]);
    const size_t count = scratch.iov[i].iov_len / stride;
    for (size_t eventIndex = 0; eventIndex < count; ++eventIndex) {
      if (!eventVersionMatches(events[eventIndex].version, stride)) {
        g_version_skips.fetch_add(1, std::memory_order_relaxed);
        candidates[i] = false;
        break;
      }
    }
  }

  bool changed = false;
  for (size_t i = 0; i < copiedMessage.msg_iovlen; ++i) {
    if (!candidates[i]) continue;
    if (rewriteEventBatch(scratch.bytes.data() + offsets[i],
                          scratch.iov[i].iov_len, fd, uid, cookie)) {
      scratch.iov[i].iov_base = scratch.bytes.data() + offsets[i];
      changed = true;
    }
  }
  if (!changed) return callOriginalSendmsg(fd, message, flags);

  scratch.message = copiedMessage;
  scratch.message.msg_iov = scratch.iov.data();
  const ssize_t rc = callOriginalSendmsg(fd, &scratch.message, flags);
  if (rc >= 0) writeMsgFlags(message, scratch.message.msg_flags);
  return rc;
}

// Last-resort fallback: SensorService on some ROMs reaches the __sendto svc
// instruction through a path that the libc function-entry hooks do not see.
// The function hooks set g_native_send_rewrote when they changed the buffer,
// so this interceptor never rewrites the same batch twice.
void sendtoSvcPreInterceptor(shadowhook_cpu_context_t* ctx, void*) {
  if (ctx == nullptr || ctx->regs[8] != __NR_sendto) return;
  if (g_native_send_hook_depth > 0 && g_native_send_rewrote) return;
  const size_t rawLen = static_cast<size_t>(ctx->regs[2]);
  const size_t stride = g_event_stride.load(std::memory_order_relaxed);
  if (!eventBufferLength(rawLen, stride)) return;
  const uintptr_t buffer = untagPtr(ctx->regs[1]);
  if (buffer < 0x1000) return;

  int fd = static_cast<int>(ctx->regs[0]);
  uint64_t cookie = 0;
  int32_t uid = -1;
  if (!targetUidForFdPeer(fd, &cookie, &uid)) {
    const int tubeFd = fdFromBitTube(untagPtr(ctx->regs[24]));
    if (tubeFd < 0 || !targetUidForFdPeer(tubeFd, &cookie, &uid)) return;
    fd = tubeFd;
  }
  rewriteEventBatch(reinterpret_cast<void*>(buffer), rawLen, fd, uid, cookie);
}

// ---------------------------------------------------------------- 安装

struct LibBase {
  const char* name;
  uintptr_t base;
  char path[256] = {};
};

int findLibCallback(struct dl_phdr_info* info, size_t, void* data) {
  auto* target = static_cast<LibBase*>(data);
  if (info->dlpi_name != nullptr && strstr(info->dlpi_name, target->name) != nullptr) {
    target->base = static_cast<uintptr_t>(info->dlpi_addr);
    if (target->path[0] == '\0') {
      strncpy(target->path, info->dlpi_name, sizeof(target->path) - 1);
      target->path[sizeof(target->path) - 1] = '\0';
    }
    return 1;
  }
  return 0;
}

// ---------------------------------------------------------------- ELF 静态发现

bool readFileBytes(const char* path, std::vector<uint8_t>& data) {
  FILE* file = fopen(path, "rb");
  if (file == nullptr) return false;
  if (fseek(file, 0, SEEK_END) != 0) {
    fclose(file);
    return false;
  }
  const long length = ftell(file);
  if (length <= 0 || length > 4 * 1024 * 1024) {
    fclose(file);
    return false;
  }
  if (fseek(file, 0, SEEK_SET) != 0) {
    fclose(file);
    return false;
  }
  data.resize(static_cast<size_t>(length));
  const size_t read = fread(data.data(), 1, data.size(), file);
  fclose(file);
  return read == data.size();
}

bool elfSections(const std::vector<uint8_t>& data, const Elf64_Shdr** sections,
                 size_t* count) {
  if (data.size() < sizeof(Elf64_Ehdr)) return false;
  const auto* header = reinterpret_cast<const Elf64_Ehdr*>(data.data());
  if (memcmp(header->e_ident, ELFMAG, SELFMAG) != 0 ||
      header->e_ident[EI_CLASS] != ELFCLASS64 ||
      header->e_shentsize != sizeof(Elf64_Shdr) ||
      header->e_shoff == 0 || header->e_shnum == 0 ||
      header->e_shoff + header->e_shnum * sizeof(Elf64_Shdr) > data.size()) {
    return false;
  }
  *sections = reinterpret_cast<const Elf64_Shdr*>(data.data() + header->e_shoff);
  *count = header->e_shnum;
  return true;
}

bool findSyscallSvc(void* function, uint32_t syscallNumber,
                    uintptr_t* svcAddress) {
  if (function == nullptr) return false;
  const uint32_t movW8 = 0x52800008u | ((syscallNumber & 0xFFFFu) << 5);
  const uint32_t movX8 = 0xD2800008u | ((syscallNumber & 0xFFFFu) << 5);
  const auto* code = reinterpret_cast<const uint32_t*>(function);
  for (size_t i = 0; i < 0x600 / 4; ++i) {
    if (code[i] != 0xD4000001u) continue;
    for (size_t j = 1; j <= 4 && j <= i; ++j) {
      const uint32_t previous = code[i - j];
      if (previous == movW8 || previous == movX8) {
        *svcAddress = reinterpret_cast<uintptr_t>(&code[i]);
        return true;
      }
    }
  }
  return false;
}

bool findSendtoSvc(void* function, uintptr_t* svcAddress) {
  return findSyscallSvc(function, __NR_sendto, svcAddress);
}

bool findSyscallSvcInFile(const std::vector<uint8_t>& data,
                          uint32_t syscallNumber, uintptr_t* svcVma) {
  const uint32_t movW8 = 0x52800008u | ((syscallNumber & 0xFFFFu) << 5);
  const uint32_t movX8 = 0xD2800008u | ((syscallNumber & 0xFFFFu) << 5);
  const Elf64_Shdr* sections = nullptr;
  size_t sectionCount = 0;
  if (!elfSections(data, &sections, &sectionCount)) return false;
  for (size_t s = 0; s < sectionCount; ++s) {
    const Elf64_Shdr& section = sections[s];
    if ((section.sh_flags & SHF_EXECINSTR) == 0 ||
        section.sh_type != SHT_PROGBITS || section.sh_size < 8 ||
        section.sh_offset + section.sh_size > data.size()) {
      continue;
    }
    const auto* code = reinterpret_cast<const uint32_t*>(
        data.data() + section.sh_offset);
    const size_t words = section.sh_size / 4;
    for (size_t i = 1; i < words; ++i) {
      if (code[i] != 0xD4000001u) continue;
      for (size_t j = 1; j <= 4 && j <= i; ++j) {
        const uint32_t previous = code[i - j];
        if (previous == movW8 || previous == movX8) {
          *svcVma = section.sh_addr + i * 4;
          return true;
        }
      }
    }
  }
  return false;
}

bool findSendtoSvcInFile(const std::vector<uint8_t>& data,
                         uintptr_t* svcVma) {
  return findSyscallSvcInFile(data, __NR_sendto, svcVma);
}

bool elfSectionName(const std::vector<uint8_t>& data,
                    const Elf64_Shdr* sections, size_t sectionCount,
                    size_t shstrIndex, const Elf64_Shdr& section,
                    std::string& name) {
  if (shstrIndex >= sectionCount) return false;
  const Elf64_Shdr& shstr = sections[shstrIndex];
  if (section.sh_name >= shstr.sh_size) return false;
  const size_t offset = shstr.sh_offset + section.sh_name;
  if (offset >= data.size()) return false;
  const size_t maxLength = std::min<size_t>(
      shstr.sh_size - section.sh_name, data.size() - offset);
  const char* text = reinterpret_cast<const char*>(data.data() + offset);
  const size_t length = strnlen(text, maxLength);
  if (length == maxLength) return false;
  name.assign(text, length);
  return true;
}

bool findDynsymSymbolInFile(const std::vector<uint8_t>& data,
                            const char* symbol, uintptr_t* value,
                            size_t* symbolIndex) {
  const Elf64_Shdr* sections = nullptr;
  size_t sectionCount = 0;
  if (!elfSections(data, &sections, &sectionCount)) return false;
  const auto* header = reinterpret_cast<const Elf64_Ehdr*>(data.data());

  for (size_t i = 0; i < sectionCount; ++i) {
    const Elf64_Shdr& dynsym = sections[i];
    if (dynsym.sh_type != SHT_DYNSYM || dynsym.sh_entsize == 0 ||
        dynsym.sh_link >= sectionCount) {
      continue;
    }
    const Elf64_Shdr& strtab = sections[dynsym.sh_link];
    if (dynsym.sh_offset + dynsym.sh_size > data.size() ||
        strtab.sh_offset + strtab.sh_size > data.size()) {
      continue;
    }
    const size_t count = dynsym.sh_size / dynsym.sh_entsize;
    const auto* symbols =
        reinterpret_cast<const Elf64_Sym*>(data.data() + dynsym.sh_offset);
    const char* strings =
        reinterpret_cast<const char*>(data.data() + strtab.sh_offset);
    for (size_t s = 0; s < count; ++s) {
      const Elf64_Sym& entry = symbols[s];
      if (entry.st_name >= strtab.sh_size || entry.st_value == 0) continue;
      const size_t remaining = strtab.sh_size - entry.st_name;
      const char* name = strings + entry.st_name;
      if (strnlen(name, remaining) == remaining) continue;
      if (strcmp(name, symbol) == 0) {
        *value = entry.st_value;
        *symbolIndex = s;
        return true;
      }
    }
  }
  (void)header;
  return false;
}

bool findDynsymSymbolPrefixInFile(const std::vector<uint8_t>& data,
                                  const char* prefix, std::string* name,
                                  uintptr_t* value, size_t* symbolIndex) {
  const Elf64_Shdr* sections = nullptr;
  size_t sectionCount = 0;
  if (!elfSections(data, &sections, &sectionCount)) return false;
  const size_t prefixLength = strlen(prefix);
  if (prefixLength == 0) return false;
  for (size_t i = 0; i < sectionCount; ++i) {
    const Elf64_Shdr& dynsym = sections[i];
    if (dynsym.sh_type != SHT_DYNSYM || dynsym.sh_entsize == 0 ||
        dynsym.sh_link >= sectionCount) {
      continue;
    }
    const Elf64_Shdr& strtab = sections[dynsym.sh_link];
    if (dynsym.sh_offset + dynsym.sh_size > data.size() ||
        strtab.sh_offset + strtab.sh_size > data.size()) {
      continue;
    }
    const size_t count = dynsym.sh_size / dynsym.sh_entsize;
    const auto* symbols =
        reinterpret_cast<const Elf64_Sym*>(data.data() + dynsym.sh_offset);
    const char* strings =
        reinterpret_cast<const char*>(data.data() + strtab.sh_offset);
    for (size_t s = 0; s < count; ++s) {
      const Elf64_Sym& entry = symbols[s];
      if (entry.st_name >= strtab.sh_size || entry.st_value == 0) continue;
      const size_t remaining = strtab.sh_size - entry.st_name;
      const char* symbolName = strings + entry.st_name;
      if (strnlen(symbolName, remaining) == remaining) continue;
      if (strncmp(symbolName, prefix, prefixLength) != 0) continue;
      if (name != nullptr) name->assign(symbolName);
      *value = entry.st_value;
      *symbolIndex = s;
      return true;
    }
  }
  return false;
}

int64_t decodeAdrpImmediate(uint32_t instruction) {
  const int64_t immlo = (instruction >> 29) & 0x3;
  const int64_t immhi = (instruction >> 5) & 0x7FFFF;
  int64_t immediate = (immhi << 2) | immlo;
  return (immediate << 43) >> 43;
}

bool findPltForSymbolInFile(const std::vector<uint8_t>& data,
                            const char* symbol, uintptr_t* pltVma) {
  uintptr_t symbolValue = 0;
  size_t symbolIndex = 0;
  if (!findDynsymSymbolInFile(data, symbol, &symbolValue, &symbolIndex)) {
    return false;
  }
  const Elf64_Shdr* sections = nullptr;
  size_t sectionCount = 0;
  if (!elfSections(data, &sections, &sectionCount)) return false;
  const auto* header = reinterpret_cast<const Elf64_Ehdr*>(data.data());

  uint64_t gotVma = 0;
  auto findGotSlot = [&](const char* wantedName) -> bool {
    for (size_t i = 0; i < sectionCount; ++i) {
      const Elf64_Shdr& rela = sections[i];
      if (rela.sh_type != SHT_RELA ||
          rela.sh_entsize != sizeof(Elf64_Rela) ||
          rela.sh_offset + rela.sh_size > data.size()) {
        continue;
      }
      std::string name;
      if (!elfSectionName(data, sections, sectionCount, header->e_shstrndx,
                          rela, name) ||
          name != wantedName) {
        continue;
      }
      const size_t count = rela.sh_size / sizeof(Elf64_Rela);
      const auto* entries =
          reinterpret_cast<const Elf64_Rela*>(data.data() + rela.sh_offset);
      for (size_t r = 0; r < count; ++r) {
        if (ELF64_R_SYM(entries[r].r_info) == symbolIndex) {
          gotVma = entries[r].r_offset;
          return true;
        }
      }
    }
    return false;
  };
  if (!findGotSlot(".rela.plt") && !findGotSlot(".rela.dyn")) return false;

  auto scanSection = [&](const Elf64_Shdr& section) -> bool {
    if ((section.sh_flags & SHF_EXECINSTR) == 0 ||
        section.sh_size < 16 ||
        section.sh_offset + section.sh_size > data.size()) {
      return false;
    }
    for (uint64_t offset = 0; offset + 16 <= section.sh_size; offset += 16) {
      const auto* code = reinterpret_cast<const uint32_t*>(
          data.data() + section.sh_offset + offset);
      if ((code[0] & 0x9F000000u) != 0x90000000u ||
          code[3] != 0xD61F0220u) {
        continue;
      }
      if ((code[1] & 0xFFC00000u) != 0xF9400000u) continue;
      const uint64_t pc = section.sh_addr + offset;
      const int64_t immediate = decodeAdrpImmediate(code[0]);
      const uint64_t page = pc & ~0xFFFULL;
      const uint64_t got = page + (immediate << 12) +
                           ((code[1] >> 10) & 0xFFF) * 8;
      if (got != gotVma) continue;
      *pltVma = pc;
      return true;
    }
    return false;
  };

  for (size_t i = 0; i < sectionCount; ++i) {
    std::string name;
    if (!elfSectionName(data, sections, sectionCount, header->e_shstrndx,
                        sections[i], name)) {
      continue;
    }
    if (name == ".plt" && scanSection(sections[i])) return true;
  }
  for (size_t i = 0; i < sectionCount; ++i) {
    if (scanSection(sections[i])) return true;
  }
  return false;
}

bool resolveCtorAndPlt(const LibBase& library, uintptr_t* ctorAddress,
                       uintptr_t* pltAddress) {
  const char* path = library.path[0] != '\0'
                         ? library.path
                         : "/system/lib64/libsensorservice.so";
  uintptr_t ctorVma = 0;
  bool found = false;
  int source = 0;
  std::string resolvedSymbol = kConnectionCtorSymbol;
  void* symbol = dlsym(RTLD_DEFAULT, kConnectionCtorSymbol);
  if (symbol != nullptr) {
    const uintptr_t address = reinterpret_cast<uintptr_t>(symbol);
    Dl_info symbolInfo{};
    const bool belongsToSensorservice =
        dladdr(symbol, &symbolInfo) != 0 && symbolInfo.dli_fname != nullptr &&
        strstr(symbolInfo.dli_fname, kLibSensorservice) != nullptr;
    if (belongsToSensorservice && address > library.base &&
        address - library.base < 0x1000000) {
      ctorVma = address - library.base;
      found = true;
      source = 4;  // dlsym exact
    }
  }

  std::vector<uint8_t> data;
  if (readFileBytes(path, data)) {
    size_t symbolIndex = 0;
    uintptr_t fileValue = 0;
    if (!found &&
        findDynsymSymbolInFile(data, kConnectionCtorSymbol, &fileValue,
                               &symbolIndex)) {
      ctorVma = fileValue;
      found = true;
      source = 5;  // ELF exact
    }
    if (!found) {
      // Android 14/15 可能改变构造参数；按前缀匹配实际 mangled name，
      // 这样不必依赖某一个固定签名。
      for (const char* prefix : kConnectionCtorSymbolPrefixes) {
        std::string matched;
        if (findDynsymSymbolPrefixInFile(data, prefix, &matched, &fileValue,
                                         &symbolIndex)) {
          ctorVma = fileValue;
          resolvedSymbol = matched;
          found = true;
          source = 6;  // ELF prefix
          break;
        }
      }
    }
    if (found) {
      uintptr_t pltVma = 0;
      if (findPltForSymbolInFile(data, resolvedSymbol.c_str(), &pltVma)) {
        *pltAddress = library.base + pltVma;
      }
    }
  }
  if (!found) return false;
  *ctorAddress = library.base + ctorVma;
  g_ctor_source.store(source, std::memory_order_relaxed);
  LOGI("ELF resolved ctor=%p plt=%p lib=%s symbol=%s source=%d",
       reinterpret_cast<void*>(*ctorAddress),
       reinterpret_cast<void*>(*pltAddress), path, resolvedSymbol.c_str(),
       source);
  return true;
}

// onSystemServerStarting 时 libsensorservice 尚未加载，轮询到它出现后再 Hook 构造函数
void* ctorPollThread(void*) {
  int transientFailures = 0;
  auto retryTransient = [&]() -> bool {
    if (++transientFailures > 100) return false;
    usleep(100 * 1000);
    return true;
  };
  for (int i = 0; i < 1200; ++i) {
    LibBase sensors{kLibSensorservice, 0};
    dl_iterate_phdr(findLibCallback, &sensors);
    if (sensors.base != 0) {
      uintptr_t resolvedCtor = 0;
      uintptr_t resolvedPlt = 0;
      const bool dynamicResolved =
          resolveCtorAndPlt(sensors, &resolvedCtor, &resolvedPlt);
      const int resolvedSource =
          g_ctor_source.load(std::memory_order_relaxed);
      const int64_t profileCtor =
          g_profile_ctor_offset.load(std::memory_order_relaxed);
      const int64_t profilePlt =
          g_profile_plt_offset.load(std::memory_order_relaxed);
      const bool forceProfile =
          g_profile_force.load(std::memory_order_relaxed);
      const bool useProfileCtor =
          profileCtor > 0 &&
          (forceProfile || !dynamicResolved || resolvedCtor == 0);
      const bool useProfilePlt =
          profilePlt > 0 &&
          (forceProfile || resolvedPlt == 0);

      // Prefix-only symbols can have a different C++ signature. The entry
      // proxy reads UID from the known Xiaomi/AOSP constructor argument slot,
      // so an unknown signature is deliberately left untouched.
      if (dynamicResolved && resolvedSource == 6 && !useProfileCtor) {
        LOGE("unknown SensorEventConnection ctor signature; skipping native mapping hook");
        return nullptr;
      }

      auto* ctorAddr = reinterpret_cast<void*>(
          useProfileCtor
              ? sensors.base + profileCtor
              : (dynamicResolved && resolvedCtor != 0
                     ? resolvedCtor
                     : sensors.base + kConnectionCtorOffset));
      uint8_t ctorPrologue[sizeof(kConnectionCtorPrologue)]{};
      if (!readSelfMemory(untagPtr(reinterpret_cast<uintptr_t>(ctorAddr)),
                          ctorPrologue, sizeof(ctorPrologue))) {
        LOGE("SensorEventConnection ctor address unreadable at %p", ctorAddr);
        if (retryTransient()) continue;
        return nullptr;
      }
      if (!dynamicResolved && !useProfileCtor &&
          memcmp(ctorPrologue, kConnectionCtorPrologue,
                 sizeof(kConnectionCtorPrologue)) != 0) {
        LOGE("SensorEventConnection ctor prologue mismatch at %p (base=%p)",
             ctorAddr, reinterpret_cast<void*>(sensors.base));
        if (retryTransient()) continue;
        return nullptr;
      }
      void* stub = shadowhook_hook_func_addr(
          ctorAddr, reinterpret_cast<void*>(&probeConnectionCtor),
          reinterpret_cast<void**>(&g_orig_connection_ctor));
      if (stub == nullptr || g_orig_connection_ctor == nullptr) {
        if (stub != nullptr) shadowhook_unhook(stub);
        LOGE("ctor hook failed: %d (%s)", shadowhook_get_errno(),
             shadowhook_to_errmsg(shadowhook_get_errno()));
        if (retryTransient()) continue;
        return nullptr;
      }
      const char* ctorSource = useProfileCtor
                                   ? "profile"
                                   : (dynamicResolved ? "ELF symbol"
                                                      : "offset fallback");
      if (useProfileCtor) {
        g_ctor_source.store(2, std::memory_order_relaxed);
      } else if (!dynamicResolved) {
        g_ctor_source.store(3, std::memory_order_relaxed);
      }
      LOGI("SensorEventConnection ctor hook installed at %p (base=%p, %s)",
           ctorAddr, reinterpret_cast<void*>(sensors.base), ctorSource);

      const bool haveValidatedPlt = useProfilePlt ||
          (dynamicResolved && resolvedSource != 6 && resolvedPlt != 0);
      if (haveValidatedPlt) {
        auto* pltAddr = reinterpret_cast<void*>(
            useProfilePlt ? sensors.base + profilePlt : resolvedPlt);
        uint32_t pltInsns[4]{};
        const bool pltReadable = readSelfMemory(
            untagPtr(reinterpret_cast<uintptr_t>(pltAddr)), pltInsns,
            sizeof(pltInsns));
        const bool pltLooksValid = pltReadable &&
            (pltInsns[0] & 0x9F000000u) == 0x90000000u &&  // adrp x16, ...
            pltInsns[3] == 0xD61F0220u;                    // br x17
        if (!pltLooksValid) {
          LOGE("ctor PLT prologue unreadable or mismatched at %p", pltAddr);
        } else {
          void* pltStub = shadowhook_intercept_instr_addr(
              pltAddr, ctorPltPreInterceptor, nullptr, 0);
          if (pltStub == nullptr) {
            LOGE("ctor PLT intercept failed: %d (%s)", shadowhook_get_errno(),
                 shadowhook_to_errmsg(shadowhook_get_errno()));
          } else {
            LOGI("ctor PLT intercept installed at %p", pltAddr);
            pthread_t pendingTid{};
            if (pthread_create(&pendingTid, nullptr, ctorPendingThread, nullptr) == 0) {
              pthread_detach(pendingTid);
              LOGI("ctor pending thread started");
            } else {
              LOGE("ctor pending thread create failed");
            }
          }
        }
      } else {
        LOGI("no validated constructor PLT; using constructor hook only");
      }

      pthread_t injectTid{};
      if (pthread_create(&injectTid, nullptr, stepInjectThread, nullptr) == 0) {
        pthread_detach(injectTid);
        LOGI("step inject thread started");
      } else {
        LOGE("step inject thread create failed");
      }
      return nullptr;
    }
    usleep(100 * 1000);
  }
  LOGE("timeout waiting for libsensorservice.so");
  return nullptr;
}

bool install() {
  // 验证工具模块与 global native 层会 Hook 同一发送函数/构造函数，导致事件被重复改写。
  // 若验证工具的 native 库已经加载，拒绝安装第二套 Hook；验证工具侧也有反向保护。
  LibBase probeLibrary{"libsensorprobe.so", 0};
  dl_iterate_phdr(findLibCallback, &probeLibrary);
  if (probeLibrary.base != 0) {
    LOGE("sensorprobe native library already loaded; refusing double sensor hooks");
    return false;
  }

  const int init = shadowhook_init(SHADOWHOOK_MODE_SHARED, false);
  if (init != 0) {
    LOGE("shadowhook_init failed: %d", init);
    return false;
  }

  auto installFunctionHook = [&](const char* symbolName, void* replacement,
                                 void** original, HookKind kind) -> bool {
    void* target = dlsym(RTLD_DEFAULT, symbolName);
    if (target == nullptr) {
      LOGE("libc %s symbol unavailable", symbolName);
      return false;
    }
    Dl_info symbolInfo{};
    if (dladdr(target, &symbolInfo) == 0 || symbolInfo.dli_fname == nullptr ||
        strstr(symbolInfo.dli_fname, "libc.so") == nullptr) {
      LOGE("%s did not resolve to libc; leaving this path untouched", symbolName);
      return false;
    }
    void* stub = shadowhook_hook_func_addr(target, replacement, original);
    if (stub == nullptr || *original == nullptr) {
      if (stub != nullptr) shadowhook_unhook(stub);
      LOGE("libc %s hook failed: %d (%s)", symbolName,
           shadowhook_get_errno(), shadowhook_to_errmsg(shadowhook_get_errno()));
      return false;
    }
    g_hook_kind.fetch_or(kind, std::memory_order_relaxed);
    LOGI("libc %s function hook installed at %p", symbolName, target);
    return true;
  };

  // send() commonly delegates to sendto(). If the two public symbols alias the
  // same entry, skip both: their different signatures make a shared trampoline
  // ambiguous, so preserving normal calls is safer than guessing.
  void* sendAddress = dlsym(RTLD_DEFAULT, "send");
  void* sendtoAddress = dlsym(RTLD_DEFAULT, "sendto");
  bool hookInstalled = false;
  bool sendPathsSkipped = false;
  if (sendAddress != nullptr && sendtoAddress != nullptr &&
      sendAddress == sendtoAddress) {
    LOGE("libc send/sendto share an entry; trying __sendto fallback");
    sendPathsSkipped = true;
  } else {
    hookInstalled |= installFunctionHook(
        "send", reinterpret_cast<void*>(&nativeSendProxy),
        reinterpret_cast<void**>(&g_orig_send), kHookSend);
    hookInstalled |= installFunctionHook(
        "sendto", reinterpret_cast<void*>(&nativeSendtoProxy),
        reinterpret_cast<void**>(&g_orig_sendto), kHookSendto);
  }
  if (sendPathsSkipped || !hookInstalled) {
    // If both public send/sendto entry points are aliases or unavailable,
    // __sendto is the shared implementation and keeps the syscall covered.
    g_send_fallbacks.fetch_add(1, std::memory_order_relaxed);
    if (g_orig_sendto == nullptr) {
      hookInstalled |= installFunctionHook(
          "__sendto", reinterpret_cast<void*>(&nativeSendtoProxy),
          reinterpret_cast<void**>(&g_orig_sendto), kHookSendto);
    }
  }
  hookInstalled |= installFunctionHook(
      "sendmsg", reinterpret_cast<void*>(&nativeSendmsgProxy),
      reinterpret_cast<void**>(&g_orig_sendmsg), kHookSendmsg);

  // Some SensorService builds reach the __sendto svc instruction without
  // passing through the libc function entry points we hooked above. Keep the
  // old instruction-level path as a last-resort fallback. The two paths share
  // g_native_send_hook_depth/g_native_send_rewrote, so a batch is never
  // rewritten twice.
  bool svcHookInstalled = false;
  {
    LibBase libc{kLibcName, 0};
    dl_iterate_phdr(findLibCallback, &libc);
    if (libc.base != 0) {
      std::vector<uint8_t> libcData;
      const char* libcPath =
          libc.path[0] != '\0' ? libc.path : "/system/lib64/libc.so";
      readFileBytes(libcPath, libcData);
      uintptr_t svcVma = 0;
      const bool found = findSendtoSvcInFile(libcData, &svcVma);
      const uintptr_t svcAddress =
          found ? libc.base + svcVma : libc.base + kLibcSvcOffset;
      uint8_t probe[sizeof(kLibcSvcBytes)]{};
      if (readSelfMemory(svcAddress, probe, sizeof(probe)) &&
          memcmp(probe, kLibcSvcBytes, sizeof(probe)) == 0) {
        void* svcStub = shadowhook_intercept_instr_addr(
            reinterpret_cast<void*>(svcAddress), sendtoSvcPreInterceptor,
            nullptr, 0);
        if (svcStub != nullptr) {
          svcHookInstalled = true;
          g_svc_hook_active.store(true, std::memory_order_relaxed);
          LOGI("__sendto svc %s hook installed at %p",
               found ? "discovered" : "fallback",
               reinterpret_cast<void*>(svcAddress));
        } else {
          LOGE("__sendto svc hook failed: %d (%s)", shadowhook_get_errno(),
               shadowhook_to_errmsg(shadowhook_get_errno()));
        }
      } else {
        LOGE("__sendto svc bytes mismatch at %p (base=%p)",
             reinterpret_cast<void*>(svcAddress),
             reinterpret_cast<void*>(libc.base));
      }
    } else {
      LOGE("libc.so not found; svc fallback unavailable");
    }
  }
  hookInstalled |= svcHookInstalled;
  if (hookInstalled) {
    // svc offsets in older device profiles no longer select native hook sites.
    g_svc_source.store(7, std::memory_order_relaxed);
  }
  if (!hookInstalled) {
    LOGE("no usable libc send hooks");
    return false;
  }

  g_installed.store(true, std::memory_order_relaxed);

  pthread_t ctorTid{};
  if (pthread_create(&ctorTid, nullptr, ctorPollThread, nullptr) == 0) {
    pthread_detach(ctorTid);
    LOGI("ctor poll thread started");
  } else {
    LOGE("ctor poll thread create failed");
  }
  return true;
}

// ---------------------------------------------------------------- JNI

std::string jstringToStd(JNIEnv* env, jstring value) {
  if (value == nullptr) return {};
  const char* utf = env->GetStringUTFChars(value, nullptr);
  std::string out = utf != nullptr ? utf : "";
  if (utf != nullptr) env->ReleaseStringUTFChars(value, utf);
  return out;
}

std::vector<int32_t> jintArrayToVec(JNIEnv* env, jintArray array) {
  if (array == nullptr) return {};
  const jsize length = env->GetArrayLength(array);
  if (length <= 0) return {};
  std::vector<jint> tmp(static_cast<size_t>(length));
  env->GetIntArrayRegion(array, 0, length, tmp.data());
  return std::vector<int32_t>(tmp.begin(), tmp.end());
}

bool configure(const std::vector<int32_t>& targetUids, bool allApps,
               double speedMps, int32_t cadenceSpm, int32_t stepDetectorHandle,
               int32_t stepCounterHandle, int32_t accelerometerHandle,
               int32_t realismLevel, int32_t fluctuationPct, bool active,
               bool stepSimulation, bool accelerometerSimulation,
               const std::string& gait) {
  std::lock_guard<std::mutex> lock(g_config_mutex);
  const int64_t now = nowNanos();
  const double current = currentStepsLocked(now);
  g_clock_base_steps = current;
  g_clock_origin_ns = now;

  const bool targetsChanged =
      allApps != g_config.allApps || targetUids != g_config.targetUids;
  g_config.targetUids = targetUids;
  g_config.allApps = allApps;
  g_config.speedMps = speedMps;
  g_config.cadenceSpm = cadenceSpm;
  g_config.stepDetectorHandle = stepDetectorHandle;
  g_config.stepCounterHandle = stepCounterHandle;
  g_config.accelerometerHandle = accelerometerHandle;
  g_config.realismLevel = realismLevel;
  g_config.fluctuationPct = fluctuationPct;
  g_config.active = active;
  g_config.stepSimulation = stepSimulation;
  g_config.accelerometerSimulation = accelerometerSimulation;
  g_config.gaitEncoded = gait;
  g_gait = parseGait(gait);

  if (targetsChanged) {
    // 目标集合变化：清空注入 fd，等待下一次步/加速度事件按新目标重新登记
    for (size_t i = 0; i < kMaxTargetFds; ++i) {
      g_target_fds[i].store(-1, std::memory_order_relaxed);
      g_target_fd_cookies[i].store(0, std::memory_order_relaxed);
      g_target_fd_uids[i].store(0, std::memory_order_relaxed);
    }
    g_target_generation.fetch_add(1, std::memory_order_relaxed);
  }

  LOGI("configure targets=%zu allApps=%d speed=%.2f cadence=%d handles=%d/%d/0x%x "
       "realism=%d pct=%d active=%d step=%d accel=%d gait=%zu steps=%.1f",
       targetUids.size(), allApps ? 1 : 0, speedMps, cadenceSpm,
       stepDetectorHandle, stepCounterHandle, accelerometerHandle, realismLevel,
       fluctuationPct, active ? 1 : 0, stepSimulation ? 1 : 0,
       accelerometerSimulation ? 1 : 0, gait.size(), current);
  return true;
}

}  // namespace

extern "C" JNIEXPORT jboolean JNICALL
Java_com_vincenthzr_locationspoofer_sensor_SystemAccelNative_nativeSetProfile(
    JNIEnv*, jobject, jint svcOffset, jint ctorOffset, jint pltOffset,
    jint bitTubeOffset, jint bitTubeFdOffset, jint uidOffset,
    jboolean force) {
  if (g_installed.load(std::memory_order_relaxed)) {
    LOGE("native profile ignored: hooks already installed");
    return JNI_FALSE;
  }
  if (ctorOffset < 0 || ctorOffset > 0x1000000 ||
      (ctorOffset > 0 && (ctorOffset % 4) != 0) || pltOffset < 0 ||
      pltOffset > 0x1000000 || (pltOffset > 0 && (pltOffset % 4) != 0) ||
      (bitTubeOffset > 0 &&
       (bitTubeOffset > 0x200 - static_cast<jint>(sizeof(uintptr_t)) ||
        (bitTubeOffset % static_cast<jint>(alignof(uintptr_t))) != 0)) ||
      (bitTubeFdOffset > 0 &&
       (bitTubeFdOffset > 0x100 - static_cast<jint>(sizeof(int)) ||
        (bitTubeFdOffset % 4) != 0)) ||
      (uidOffset < 0 ||
       (uidOffset > 0 &&
        (uidOffset > 0x200 - static_cast<jint>(sizeof(int32_t)) ||
         (uidOffset % 4) != 0)))) {
    LOGE("native profile rejected: offsets out of bounds");
    return JNI_FALSE;
  }
  g_profile_svc_offset.store(svcOffset > 0 ? svcOffset : 0,
                             std::memory_order_relaxed);
  g_profile_ctor_offset.store(ctorOffset > 0 ? ctorOffset : 0,
                              std::memory_order_relaxed);
  g_profile_plt_offset.store(pltOffset > 0 ? pltOffset : 0,
                             std::memory_order_relaxed);
  if (bitTubeOffset > 0) {
    g_bit_tube_offset.store(bitTubeOffset, std::memory_order_relaxed);
  }
  if (bitTubeFdOffset > 0) {
    g_bit_tube_fd_offset.store(bitTubeFdOffset, std::memory_order_relaxed);
  }
  if (uidOffset > 0) {
    g_connection_uid_offset.store(uidOffset, std::memory_order_relaxed);
  }
  g_profile_force.store(force == JNI_TRUE, std::memory_order_relaxed);
  LOGI("native profile svc=0x%x(ignored) ctor=0x%x plt=0x%x tube=%d fd=%d uid=%d force=%d",
       svcOffset, ctorOffset, pltOffset, bitTubeOffset, bitTubeFdOffset,
       uidOffset, force == JNI_TRUE ? 1 : 0);
  return JNI_TRUE;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_vincenthzr_locationspoofer_sensor_SystemAccelNative_nativeSetEventLayout(
    JNIEnv*, jobject, jint stride) {
  if (g_installed.load(std::memory_order_relaxed)) {
    LOGE("native event layout ignored: hooks already installed");
    return JNI_FALSE;
  }
  if (stride < static_cast<jint>(sizeof(SensorsEvent)) || stride > 0x200 ||
      (stride % static_cast<jint>(alignof(SensorsEvent))) != 0) {
    LOGE("native event layout rejected: stride=%d", stride);
    return JNI_FALSE;
  }
  g_event_stride.store(static_cast<size_t>(stride), std::memory_order_relaxed);
  LOGI("native event stride=%d (default=%zu)", stride, sizeof(SensorsEvent));
  return JNI_TRUE;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_vincenthzr_locationspoofer_sensor_SystemAccelNative_nativeInit(
    JNIEnv* env, jobject, jintArray targetUids, jboolean allApps) {
  const bool firstInstall = !g_installed.load(std::memory_order_relaxed);
  std::vector<int32_t> uids = jintArrayToVec(env, targetUids);
  {
    std::lock_guard<std::mutex> lock(g_config_mutex);
    if (g_clock_origin_ns <= 0) {
      g_clock_origin_ns = nowNanos();
      g_clock_base_steps = 0.0;
      g_counter_base_captured = false;
    }
    if (!g_session_start_configured) {
      g_session_start_ns = g_clock_origin_ns;
      g_session_start_configured = true;
      g_noise_ready = false;
    }
    g_last_real_step_ns.store(0, std::memory_order_relaxed);
    const bool targetsChanged =
        allApps != g_config.allApps || uids != g_config.targetUids;
    g_config.targetUids = uids;
    g_config.allApps = allApps == JNI_TRUE;
    if (targetsChanged) {
      for (size_t i = 0; i < kMaxTargetFds; ++i) {
        g_target_fds[i].store(-1, std::memory_order_relaxed);
        g_target_fd_cookies[i].store(0, std::memory_order_relaxed);
        g_target_fd_uids[i].store(0, std::memory_order_relaxed);
      }
      g_target_generation.fetch_add(1, std::memory_order_relaxed);
    }
  }
  if (firstInstall) {
    for (size_t i = 0; i < kMaxTargetFds; ++i) {
      g_target_fds[i].store(-1, std::memory_order_relaxed);
      g_target_fd_cookies[i].store(0, std::memory_order_relaxed);
      g_target_fd_uids[i].store(0, std::memory_order_relaxed);
    }
    g_target_generation.fetch_add(1, std::memory_order_relaxed);
    for (size_t i = 0; i < kFdMapSize; ++i) {
      g_fd_map[i].store(-1, std::memory_order_relaxed);
      g_fd_uid_map[i].store(-1, std::memory_order_relaxed);
      g_fd_cookie_map[i].store(0, std::memory_order_relaxed);
    }
  }
  LOGI("nativeInit targets=%zu allApps=%d first=%d", uids.size(),
       allApps == JNI_TRUE ? 1 : 0, firstInstall ? 1 : 0);
  if (!firstInstall) return JNI_TRUE;
  return install() ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_vincenthzr_locationspoofer_sensor_SystemAccelNative_nativeConfigure(
    JNIEnv* env, jobject, jintArray targetUids, jboolean allApps,
    jdouble speedMps, jint cadenceSpm, jint stepDetectorHandle,
    jint stepCounterHandle, jint accelerometerHandle, jint realismLevel,
    jint fluctuationPct, jboolean active, jboolean stepSimulation,
    jboolean accelerometerSimulation, jstring gait) {
  const bool ok = configure(
      jintArrayToVec(env, targetUids), allApps == JNI_TRUE, speedMps, cadenceSpm,
      stepDetectorHandle, stepCounterHandle, accelerometerHandle, realismLevel,
      fluctuationPct, active == JNI_TRUE, stepSimulation == JNI_TRUE,
      accelerometerSimulation == JNI_TRUE, jstringToStd(env, gait));
  return ok ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_vincenthzr_locationspoofer_sensor_SystemAccelNative_nativeSetClockStart(
    JNIEnv*, jobject, jlong startTimestampMs) {
  std::lock_guard<std::mutex> lock(g_config_mutex);
  const int64_t now = nowNanos();
  // 先按旧会话结算当前步数，切换种子/起点时不回退。
  g_clock_base_steps = currentStepsLocked(now);
  g_clock_origin_ns = now;

  // start_timestamp 是 System.currentTimeMillis() 的墙钟毫秒；native 的事件时钟
  // 用 CLOCK_BOOTTIME，两者不能直接相减。先求墙钟已过去的时间，再换算到 boot 时间轴。
  const int64_t wallNowMs = wallMillis();
  const int64_t rawStartMs =
      startTimestampMs > 0 ? static_cast<int64_t>(startTimestampMs)
                           : wallNowMs;
  int64_t elapsedMs = wallNowMs - rawStartMs;
  if (elapsedMs < 0) elapsedMs = 0;
  const int64_t startBootNs = now - elapsedMs * 1000000LL;
  const uint64_t seed = static_cast<uint64_t>(rawStartMs);
  if (!g_session_start_configured ||
      g_session_start_ns != startBootNs || g_noise_seed != seed) {
    g_session_start_ns = startBootNs;
    g_session_start_configured = true;
    g_noise_seed = seed;
    g_noise_ready = false;
  }
  ensureNoiseLocked(now);
  LOGI("clock start=%lld wallNow=%lld elapsedMs=%lld startBoot=%.3fs "
       "seed=%llu",
       static_cast<long long>(startTimestampMs),
       static_cast<long long>(wallNowMs),
       static_cast<long long>(elapsedMs),
       static_cast<double>(startBootNs) / 1e9,
       static_cast<unsigned long long>(seed));
  return JNI_TRUE;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_vincenthzr_locationspoofer_sensor_SystemAccelNative_nativeSetCompassHeading(
    JNIEnv*, jobject, jdouble trueHeadingDeg, jdouble declinationDeg,
    jdouble accuracyDeg, jdouble horizontalUt, jdouble verticalUt,
    jboolean enabled) {
  std::lock_guard<std::mutex> lock(g_config_mutex);
  const bool on = enabled == JNI_TRUE &&
      std::isfinite(trueHeadingDeg) && std::isfinite(declinationDeg);
  const int64_t now = nowNanos();
  g_config.compassSimulation = on;
  if (on) {
    const double normalizedHeading = normalizeDegrees(trueHeadingDeg);
    double yawRate = 0.0;
    if (g_config.compassHeadingValid && g_config.compassHeadingAtNs > 0) {
      const int64_t deltaNs = now - g_config.compassHeadingAtNs;
      // 20 Hz 正常更新；线程暂停/配置切换超过 0.5s 时不做角速度外推。
      if (deltaNs > 0 && deltaNs <= 500000000LL) {
        yawRate = shortestDeltaDegrees(
            g_config.compassTrueHeadingDeg, normalizedHeading) *
            kPi / 180.0 / (static_cast<double>(deltaNs) / 1e9);
        yawRate = std::clamp(yawRate, -3.5, 3.5);
      }
    }
    g_config.compassYawRateRad = yawRate;
    g_config.compassTrueHeadingDeg = normalizedHeading;
    g_config.compassDeclinationDeg =
        std::isfinite(declinationDeg) ? declinationDeg : 0.0;
    g_config.compassAccuracyDeg =
        std::isfinite(accuracyDeg) ? std::max(0.0, accuracyDeg) : 5.0;
    const bool fieldValid = std::isfinite(horizontalUt) &&
        std::isfinite(verticalUt) && horizontalUt > 1.0;
    g_config.compassFieldValid = fieldValid;
    g_config.compassHorizontalUt = fieldValid ? horizontalUt : 0.0;
    g_config.compassVerticalUt = fieldValid ? verticalUt : 0.0;
    g_config.compassHeadingAtNs = now;
    g_config.compassHeadingValid = true;
  } else {
    g_config.compassYawRateRad = 0.0;
    g_config.compassFieldValid = false;
    g_config.compassHeadingValid = false;
    g_config.compassHeadingAtNs = 0;
  }

  static std::atomic<int64_t> lastCompassLog{0};
  static std::atomic<bool> lastCompassEnabled{false};
  const int64_t previousLog = lastCompassLog.load(std::memory_order_relaxed);
  const bool previousEnabled =
      lastCompassEnabled.load(std::memory_order_relaxed);
  if (on != previousEnabled || now - previousLog > 10000000000LL) {
    lastCompassLog.store(now, std::memory_order_relaxed);
    lastCompassEnabled.store(on, std::memory_order_relaxed);
    LOGI("configure compass enabled=%d true=%.1f decl=%.1f accuracy=%.1f "
         "h=%.1f v=%.1f field=%d",
         on ? 1 : 0, g_config.compassTrueHeadingDeg,
         g_config.compassDeclinationDeg, g_config.compassAccuracyDeg,
         g_config.compassHorizontalUt, g_config.compassVerticalUt,
         g_config.compassFieldValid ? 1 : 0);
  }
  return JNI_TRUE;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_vincenthzr_locationspoofer_sensor_SystemAccelNative_nativeConfigurePressure(
    JNIEnv*, jobject, jdouble altitudeM, jdouble altitudeVariationM,
    jdouble latitude, jdouble longitude, jdouble driftM,
    jdouble seaLevelHpa, jboolean enabled) {
  std::lock_guard<std::mutex> lock(g_config_mutex);
  g_config.pressureAltitudeM = altitudeM;
  g_config.pressureVariationM =
      std::clamp(altitudeVariationM, 0.0, 100.0);
  g_config.pressureLat = latitude;
  g_config.pressureLng = longitude;
  g_config.pressureDriftM = std::max(0.0, driftM);
  g_config.pressureSeaLevelHpa = std::clamp(seaLevelHpa, 800.0, 1100.0);
  g_config.pressureTerrainReady = false;
  g_config.pressureEnabled = enabled == JNI_TRUE;
  LOGI("configure pressure enabled=%d altitude=%.1f variation=%.1f "
       "lat=%.5f lng=%.5f drift=%.1f seaLevel=%.2f",
       g_config.pressureEnabled ? 1 : 0, g_config.pressureAltitudeM,
       g_config.pressureVariationM, g_config.pressureLat,
       g_config.pressureLng, g_config.pressureDriftM,
       g_config.pressureSeaLevelHpa);
  return JNI_TRUE;
}

const char* hookKindName(int kind) {
  switch (kind) {
    case kHookSend: return "send";
    case kHookSendto: return "sendto";
    case kHookSend | kHookSendto: return "send|sendto";
    case kHookSendmsg: return "sendmsg";
    case kHookSend | kHookSendmsg: return "send|sendmsg";
    case kHookSendto | kHookSendmsg: return "sendto|sendmsg";
    case kHookSend | kHookSendto | kHookSendmsg:
      return "send|sendto|sendmsg";
    default: return "none";
  }
}

const char* sourceName(int source) {
  switch (source) {
    case 1: return "discovered";
    case 2: return "profile";
    case 3: return "fallback";
    case 4: return "symbol";
    case 5: return "elf";
    case 6: return "elf-prefix";
    case 7: return "bionic-function";
    default: return "unknown";
  }
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_vincenthzr_locationspoofer_sensor_SystemAccelNative_nativeStatus(
    JNIEnv* env, jobject) {
  int fdCount = 0;
  for (auto& fd : g_target_fds) {
    if (fd.load(std::memory_order_relaxed) >= 0) ++fdCount;
  }
  char out[2048];
  {
    std::lock_guard<std::mutex> lock(g_config_mutex);
    snprintf(out, sizeof(out),
             "{\"installed\":%s,\"targets\":%zu,\"allApps\":%s,\"speed\":%.2f,"
             "\"cadence\":%d,\"active\":%s,\"step\":%s,\"accel\":%s,"
             "\"compass\":%s,\"compassTrue\":%.1f,\"compassDecl\":%.1f,"
             "\"compassH\":%.1f,\"compassV\":%.1f,\"compassField\":%s,"
             "\"gaitCadence\":%d,"
             "\"gyro\":%s,\"pressure\":%s,\"pressureAltitude\":%.1f,"
             "\"pressureVariation\":%.1f,\"gait\":%zu,\"fds\":%d,"
             "\"rewritten\":%llu,\"accelRewritten\":%llu,"
             "\"compassRewritten\":%llu,\"gyroRewritten\":%llu,"
             "\"pressureRewritten\":%llu,\"injected\":%llu,"
             "\"hook\":\"%s\",\"svcSource\":\"%s\",\"ctorSource\":\"%s\","
             "\"eventStride\":%zu,\"invalidBatches\":%llu,"
             "\"lastBatchLen\":%zu,\"tubeOffset\":%d,\"fdOffset\":%d,"
             "\"uidOffset\":%d,"
             "\"layoutDiscovered\":%s,\"mappingReady\":%s,"
             "\"cookieFailures\":%llu,\"versionSkips\":%llu,"
             "\"iovSkips\":%llu,\"mapEvictions\":%llu,"
             "\"mappingRejects\":%llu,\"sendFallbacks\":%llu,"
             "\"svcHook\":%s,"
             "\"errno\":%d,\"errmsg\":\"%s\"}",
             g_installed.load() ? "true" : "false", g_config.targetUids.size(),
             g_config.allApps ? "true" : "false", g_config.speedMps,
             effectiveCadenceLocked(speedNowLocked(nowNanos())),
             g_config.active ? "true" : "false",
             g_config.stepSimulation ? "true" : "false",
             g_config.accelerometerSimulation ? "true" : "false",
             g_config.compassSimulation ? "true" : "false",
             g_config.compassTrueHeadingDeg, g_config.compassDeclinationDeg,
             g_config.compassHorizontalUt, g_config.compassVerticalUt,
             g_config.compassFieldValid ? "true" : "false",
             g_gait ? g_gait->cadenceSpm : 0,
             g_config.compassSimulation ? "true" : "false",
             g_config.pressureEnabled ? "true" : "false",
             g_config.pressureAltitudeM, g_config.pressureVariationM,
             g_config.gaitEncoded.size(), fdCount,
             static_cast<unsigned long long>(g_rewritten_events.load()),
             static_cast<unsigned long long>(g_accel_rewritten_events.load()),
             static_cast<unsigned long long>(g_compass_rewritten_events.load()),
             static_cast<unsigned long long>(g_gyro_rewritten_events.load()),
             static_cast<unsigned long long>(g_pressure_rewritten_events.load()),
             static_cast<unsigned long long>(g_injected_events.load()),
             hookKindName(g_hook_kind.load(std::memory_order_relaxed)),
             sourceName(g_svc_source.load(std::memory_order_relaxed)),
             sourceName(g_ctor_source.load(std::memory_order_relaxed)),
             g_event_stride.load(std::memory_order_relaxed),
             static_cast<unsigned long long>(
                 g_invalid_batches.load(std::memory_order_relaxed)),
             g_last_batch_len.load(std::memory_order_relaxed),
             g_bit_tube_offset.load(std::memory_order_relaxed),
             g_bit_tube_fd_offset.load(std::memory_order_relaxed),
             g_connection_uid_offset.load(std::memory_order_relaxed),
             g_layout_discovered.load(std::memory_order_relaxed) ? "true"
                                                                 : "false",
             g_layout_discovered.load(std::memory_order_relaxed) ? "true"
                                                                 : "false",
             static_cast<unsigned long long>(
                 g_cookie_failures.load(std::memory_order_relaxed)),
             static_cast<unsigned long long>(
                 g_version_skips.load(std::memory_order_relaxed)),
             static_cast<unsigned long long>(
                 g_iov_skips.load(std::memory_order_relaxed)),
             static_cast<unsigned long long>(
                 g_map_evictions.load(std::memory_order_relaxed)),
             static_cast<unsigned long long>(
                 g_mapping_rejects.load(std::memory_order_relaxed)),
             static_cast<unsigned long long>(
                 g_send_fallbacks.load(std::memory_order_relaxed)),
             g_svc_hook_active.load(std::memory_order_relaxed) ? "true"
                                                                : "false",
             shadowhook_get_errno(),
             shadowhook_to_errmsg(shadowhook_get_errno()));
  }
  return env->NewStringUTF(out);
}
