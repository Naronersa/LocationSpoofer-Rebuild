package com.vincenthzr.locationprobe

import android.Manifest
import android.app.ActivityManager
import android.app.AppOpsManager
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.BluetoothLeScanner
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.GnssCapabilities
import android.location.GnssMeasurementsEvent
import android.location.GnssNavigationMessage
import android.location.GnssStatus
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.location.OnNmeaMessageListener
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.Debug
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.os.SystemClock
import android.provider.Settings
import android.telephony.TelephonyManager
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.util.ArrayDeque
import java.util.Collections
import java.util.IdentityHashMap
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs

/**
 * 框架层验证工具。所有采集都在本机完成，结果只写入本应用外部文件目录。
 * GNSS/传感器/位置回调在主线程注册，Root 命令在后台线程执行。
 */
internal class ProbeCollector(
    private val context: Context,
    private val durationMs: Long = 60_000L
) {
    private val mainHandler = Handler(Looper.getMainLooper())
    private val started = AtomicBoolean(false)
    @Volatile private var stopped = false
    private val startedWallMs = System.currentTimeMillis()
    private val startedElapsedMs = SystemClock.elapsedRealtime()

    private val locationEvents = Collections.synchronizedList(mutableListOf<JSONObject>())
    private val providerEvents = Collections.synchronizedList(mutableListOf<JSONObject>())
    private val lastKnown = Collections.synchronizedMap(LinkedHashMap<String, Location>())
    private val locationListeners = mutableListOf<LocationListener>()

    private val gnssStatusEvents = Collections.synchronizedList(mutableListOf<JSONObject>())
    private val gnssStatusTransitions = Collections.synchronizedList(mutableListOf<JSONObject>())
    private val gnssMeasurementSamples = Collections.synchronizedList(mutableListOf<JSONObject>())
    private val gnssMeasurementStatuses = Collections.synchronizedList(mutableListOf<Int>())
    private val gnssMeasurementCount = AtomicInteger(0)
    private val nmeaLines = Collections.synchronizedList(mutableListOf<JSONObject>())
    private val navMessageCounts = ConcurrentHashMap<String, AtomicInteger>()
    private val navMessageSamples = Collections.synchronizedList(mutableListOf<JSONObject>())
    private var gnssStatusCallback: GnssStatus.Callback? = null
    private var gnssMeasurementsCallback: GnssMeasurementsEvent.Callback? = null
    private var gnssNavigationCallback: GnssNavigationMessage.Callback? = null
    private var nmeaListener: OnNmeaMessageListener? = null

    private val sensorAccumulators = Collections.synchronizedMap(IdentityHashMap<Sensor, SensorAccumulator>())
    private val sensorRegistration = Collections.synchronizedMap(IdentityHashMap<Sensor, Boolean>())
    private var sensorListener: SensorEventListener? = null

    private val wifiScanResults = Collections.synchronizedList(mutableListOf<JSONObject>())
    private var wifiScanError: String? = null
    private val bleResults = Collections.synchronizedList(mutableListOf<JSONObject>())
    private var bleError: String? = null
    private var bluetoothAdapter: BluetoothAdapter? = null
    private var bleScanner: BluetoothLeScanner? = null
    private var bleCallback: ScanCallback? = null

    private val locationManager by lazy { context.getSystemService(LocationManager::class.java) }
    private val sensorManager by lazy { context.getSystemService(SensorManager::class.java) }
    private val wifiManager by lazy { context.applicationContext.getSystemService(WifiManager::class.java) }
    private val telephonyManager by lazy { context.getSystemService(TelephonyManager::class.java) }
    private val connectivityManager by lazy { context.getSystemService(ConnectivityManager::class.java) }
    private val bluetoothManager by lazy { context.getSystemService(BluetoothManager::class.java) }
    private val appOpsManager by lazy { context.getSystemService(AppOpsManager::class.java) }

    fun start(onComplete: (JSONObject) -> Unit) {
        if (!started.compareAndSet(false, true)) return
        registerLocation()
        registerSensors()
        registerGnss()
        startWifiScan()
        startBleScan()

        Thread({
            val system = runCatching { SystemProbe(context).collect() }
                .getOrElse { JSONObject().put("error", it.toString()) }
            val elapsed = SystemClock.elapsedRealtime() - startedElapsedMs
            val remaining = durationMs - elapsed
            if (remaining > 0) {
                try {
                    Thread.sleep(remaining)
                } catch (_: InterruptedException) {
                }
            }
            mainHandler.post {
                stopFramework()
                val result = buildResult(system)
                onComplete(result)
            }
        }, "probe-system").start()
    }

    private fun registerLocation() {
        val manager = locationManager ?: return
        val providers = runCatching { manager.allProviders }.getOrDefault(emptyList())
        for (provider in providers.distinct()) {
            runCatching {
                manager.getLastKnownLocation(provider)?.let { lastKnown[provider] = it }
            }
            val listener = object : LocationListener {
                override fun onLocationChanged(location: Location) {
                    if (locationEvents.size < 1000) {
                        locationEvents.add(locationToJson(location, "update"))
                    }
                }

                override fun onProviderEnabled(provider: String) {
                    providerEvents.add(JSONObject().put("provider", provider).put("event", "enabled").put("elapsedMs", SystemClock.elapsedRealtime()))
                }

                override fun onProviderDisabled(provider: String) {
                    providerEvents.add(JSONObject().put("provider", provider).put("event", "disabled").put("elapsedMs", SystemClock.elapsedRealtime()))
                }

                @Deprecated("Deprecated in API 29")
                override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {
                    providerEvents.add(
                        JSONObject()
                            .put("provider", provider ?: "")
                            .put("event", "status")
                            .put("status", status)
                            .put("extras", extras.toJsonObject())
                            .put("elapsedMs", SystemClock.elapsedRealtime())
                    )
                }
            }
            val ok = runCatching {
                manager.requestLocationUpdates(provider, 1000L, 0f, listener, Looper.getMainLooper())
                true
            }.getOrDefault(false)
            if (ok) locationListeners.add(listener)
        }
        if (Build.VERSION.SDK_INT >= 31) {
            runCatching {
                if (!providers.contains(LocationManager.FUSED_PROVIDER)) {
                    val listener = object : LocationListener {
                        override fun onLocationChanged(location: Location) {
                            if (locationEvents.size < 1000) {
                                locationEvents.add(locationToJson(location, "update"))
                            }
                        }
                    }
                    manager.requestLocationUpdates(LocationManager.FUSED_PROVIDER, 1000L, 0f, listener, Looper.getMainLooper())
                    locationListeners.add(listener)
                }
            }
        }
    }

    private fun registerSensors() {
        val manager = sensorManager ?: return
        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                sensorAccumulators[event.sensor]?.add(event)
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
                sensor?.let { sensorAccumulators[it]?.onAccuracyChanged(accuracy) }
            }
        }
        sensorListener = listener
        runCatching {
            manager.getSensorList(Sensor.TYPE_ALL).forEach { sensor ->
                val accumulator = SensorAccumulator(sensor)
                sensorAccumulators[sensor] = accumulator
                val delay = when (sensor.type) {
                    Sensor.TYPE_ACCELEROMETER,
                    Sensor.TYPE_GYROSCOPE,
                    Sensor.TYPE_GYROSCOPE_UNCALIBRATED,
                    Sensor.TYPE_MAGNETIC_FIELD,
                    Sensor.TYPE_MAGNETIC_FIELD_UNCALIBRATED,
                    Sensor.TYPE_ROTATION_VECTOR,
                    Sensor.TYPE_GAME_ROTATION_VECTOR,
                    Sensor.TYPE_GEOMAGNETIC_ROTATION_VECTOR,
                    Sensor.TYPE_GRAVITY,
                    Sensor.TYPE_LINEAR_ACCELERATION -> SensorManager.SENSOR_DELAY_GAME

                    else -> SensorManager.SENSOR_DELAY_NORMAL
                }
                sensorRegistration[sensor] = runCatching {
                    manager.registerListener(listener, sensor, delay)
                }.getOrDefault(false)
            }
        }
    }

    private fun registerGnss() {
        val manager = locationManager ?: return
        val statusCallback = object : GnssStatus.Callback() {
            override fun onStarted() {
                gnssStatusTransitions.add(JSONObject().put("event", "started").put("elapsedMs", SystemClock.elapsedRealtime()))
            }

            override fun onStopped() {
                gnssStatusTransitions.add(JSONObject().put("event", "stopped").put("elapsedMs", SystemClock.elapsedRealtime()))
            }

            override fun onFirstFix(ttffMillis: Int) {
                gnssStatusTransitions.add(JSONObject().put("event", "first_fix").put("ttffMs", ttffMillis).put("elapsedMs", SystemClock.elapsedRealtime()))
            }

            override fun onSatelliteStatusChanged(status: GnssStatus) {
                if (gnssStatusEvents.size >= 120) return
                val satellites = JSONArray()
                for (i in 0 until status.satelliteCount) {
                    val satellite = JSONObject().apply {
                        put("svid", status.getSvid(i))
                        put("constellation", status.getConstellationType(i))
                        put("cn0DbHz", status.getCn0DbHz(i))
                        put("elevationDeg", status.getElevationDegrees(i))
                        put("azimuthDeg", status.getAzimuthDegrees(i))
                        put("usedInFix", status.usedInFix(i))
                        put("hasAlmanac", status.hasAlmanacData(i))
                        put("hasEphemeris", status.hasEphemerisData(i))
                        if (Build.VERSION.SDK_INT >= 30) {
                            put("hasCarrierFrequency", status.hasCarrierFrequencyHz(i))
                            if (status.hasCarrierFrequencyHz(i)) put("carrierFrequencyHz", status.getCarrierFrequencyHz(i))
                            put("hasBasebandCn0", status.hasBasebandCn0DbHz(i))
                            if (status.hasBasebandCn0DbHz(i)) put("basebandCn0DbHz", status.getBasebandCn0DbHz(i))
                        }
                    }
                    satellites.put(satellite)
                }
                gnssStatusEvents.add(
                    JSONObject().apply {
                        put("elapsedRealtimeNanos", SystemClock.elapsedRealtimeNanos())
                        put("satelliteCount", status.satelliteCount)
                        put("satellites", satellites)
                        put("toString", truncate(status.toString(), 4000))
                    }
                )
            }
        }
        gnssStatusCallback = statusCallback
        runCatching {
            manager.registerGnssStatusCallback(statusCallback, mainHandler)
        }

        val measurementCallback = object : GnssMeasurementsEvent.Callback() {
            override fun onGnssMeasurementsReceived(event: GnssMeasurementsEvent) {
                gnssMeasurementCount.incrementAndGet()
                if (gnssMeasurementSamples.size < 3) {
                    gnssMeasurementSamples.add(measurementsToJson(event))
                }
            }

            override fun onStatusChanged(status: Int) {
                gnssMeasurementStatuses.add(status)
            }
        }
        gnssMeasurementsCallback = measurementCallback
        runCatching {
            manager.registerGnssMeasurementsCallback(measurementCallback, mainHandler)
        }

        val navigationCallback = object : GnssNavigationMessage.Callback() {
            override fun onGnssNavigationMessageReceived(message: GnssNavigationMessage) {
                val key = "${message.type}/${message.status}"
                navMessageCounts.getOrPut(key) { AtomicInteger() }.incrementAndGet()
                if (navMessageSamples.size < 5) {
                    navMessageSamples.add(
                        JSONObject().apply {
                            put("type", message.type)
                            put("svid", message.svid)
                            put("status", message.status)
                            put("messageId", message.messageId)
                            put("submessageId", message.submessageId)
                            put("dataLength", message.data?.size ?: 0)
                            put("toString", truncate(message.toString(), 2000))
                        }
                    )
                }
            }

            override fun onStatusChanged(status: Int) {
                navMessageSamples.add(JSONObject().put("statusCallback", status))
            }
        }
        gnssNavigationCallback = navigationCallback
        runCatching {
            manager.registerGnssNavigationMessageCallback(navigationCallback, mainHandler)
        }

        val nmea = OnNmeaMessageListener { message, timestampNanos ->
            if (nmeaLines.size < 10_000) {
                nmeaLines.add(
                    JSONObject()
                        .put("timestampNanos", timestampNanos)
                        .put("elapsedMs", SystemClock.elapsedRealtime())
                        .put("message", truncate(message, 1000))
                )
            }
        }
        nmeaListener = nmea
        runCatching {
            manager.addNmeaListener(nmea, mainHandler)
        }
    }

    private fun startWifiScan() {
        Thread({
            try {
                val manager = wifiManager ?: return@Thread
                Thread.sleep(800)
                val deadline = startedElapsedMs + durationMs
                var pass = 0
                while (!stopped && SystemClock.elapsedRealtime() < deadline) {
                    runCatching { manager.startScan() }
                    Thread.sleep(2500)
                    val results = manager.scanResults ?: emptyList()
                    results.take(300).forEach { result ->
                        if (wifiScanResults.size >= 1000) return@forEach
                        wifiScanResults.add(
                            JSONObject().apply {
                                put("scanPass", pass)
                                put("collectedElapsedMs", SystemClock.elapsedRealtime() - startedElapsedMs)
                                put("SSID", result.SSID ?: "")
                                put("BSSID", result.BSSID ?: "")
                                put("level", result.level)
                                put("frequency", result.frequency)
                                put("timestamp", result.timestamp)
                                put("capabilities", result.capabilities ?: "")
                                put("centerFreq0", result.centerFreq0)
                                put("centerFreq1", result.centerFreq1)
                                put("channelWidth", result.channelWidth)
                                put("is80211mcResponder", result.is80211mcResponder)
                                if (Build.VERSION.SDK_INT >= 30) put("wifiStandard", result.wifiStandard)
                                put("toString", truncate(result.toString(), 3000))
                            }
                        )
                    }
                    pass++
                    Thread.sleep(12_000)
                }
            } catch (t: Throwable) {
                wifiScanError = t.toString()
            }
        }, "probe-wifi").start()
    }

    private fun startBleScan() {
        try {
            val adapter = bluetoothManager?.adapter ?: return
            bluetoothAdapter = adapter
            if (!adapter.isEnabled) return
            val scanner = adapter.bluetoothLeScanner ?: return
            bleScanner = scanner
            val callback = object : ScanCallback() {
                override fun onScanResult(callbackType: Int, result: ScanResult?) {
                    if (result == null || bleResults.size >= 1000) return
                    bleResults.add(
                        JSONObject().apply {
                            put("callbackType", callbackType)
                            put("address", result.device?.address ?: "")
                            put("name", runCatching { result.device?.name }.getOrNull() ?: "")
                            put("rssi", result.rssi)
                            put("txPower", result.txPower)
                            put("primaryPhy", result.primaryPhy)
                            put("secondaryPhy", result.secondaryPhy)
                            put("timestampNanos", result.timestampNanos)
                            put("isConnectable", result.isConnectable)
                            put("scanRecordHex", result.scanRecord?.bytes?.joinToString("") { "%02x".format(it) } ?: "")
                            put("toString", truncate(result.toString(), 2500))
                        }
                    )
                }

                override fun onBatchScanResults(results: MutableList<ScanResult>?) {
                    results?.forEach { onScanResult(0, it) }
                }

                override fun onScanFailed(errorCode: Int) {
                    bleError = "onScanFailed=$errorCode"
                }
            }
            bleCallback = callback
            scanner.startScan(callback)
        } catch (t: Throwable) {
            bleError = t.toString()
        }
    }

    private fun stopFramework() {
        stopped = true
        val manager = locationManager
        if (manager != null) {
            locationListeners.forEach { runCatching { manager.removeUpdates(it) } }
            locationListeners.clear()
            gnssStatusCallback?.let { runCatching { manager.unregisterGnssStatusCallback(it) } }
            gnssMeasurementsCallback?.let { runCatching { manager.unregisterGnssMeasurementsCallback(it) } }
            gnssNavigationCallback?.let { runCatching { manager.unregisterGnssNavigationMessageCallback(it) } }
            nmeaListener?.let { runCatching { manager.removeNmeaListener(it) } }
        }
        sensorListener?.let { listener ->
            runCatching { sensorManager?.unregisterListener(listener) }
        }
        bleCallback?.let { callback ->
            runCatching { bleScanner?.stopScan(callback) }
        }
    }

    private fun buildResult(system: JSONObject): JSONObject {
        val root = JSONObject()
        root.put("probe", probeMeta())
        root.put("device", deviceInfo())
        root.put("mockLocationPackages", mockLocationPackages())
        root.put("permissions", permissionsInfo())
        root.put("settings", settingsInfo())
        root.put("appOps", appOpsInfo())
        root.put("location", locationInfo())
        root.put("gnss", gnssInfo())
        root.put("sensors", sensorsInfo())
        root.put("wifi", wifiInfo())
        root.put("cell", cellInfo())
        root.put("bluetooth", bluetoothInfo())
        root.put("network", networkInfo())
        root.put("system", system)
        root.put("analysis", ProbeAnalysis.analyze(root))
        return root
    }

    private fun probeMeta(): JSONObject = JSONObject().apply {
        put("package", context.packageName)
        put("startedWallMs", startedWallMs)
        put("startedElapsedMs", startedElapsedMs)
        put("durationMs", durationMs)
        put("finishedWallMs", System.currentTimeMillis())
        put("finishedElapsedMs", SystemClock.elapsedRealtime())
        put("androidSdk", Build.VERSION.SDK_INT)
        put("androidRelease", Build.VERSION.RELEASE)
        put("securityPatch", if (Build.VERSION.SDK_INT >= 23) Build.VERSION.SECURITY_PATCH else "")
    }

    private fun deviceInfo(): JSONObject = JSONObject().apply {
        put("manufacturer", Build.MANUFACTURER)
        put("brand", Build.BRAND)
        put("model", Build.MODEL)
        put("device", Build.DEVICE)
        put("product", Build.PRODUCT)
        put("board", Build.BOARD)
        put("hardware", Build.HARDWARE)
        put("fingerprint", Build.FINGERPRINT)
        put("tags", Build.TAGS)
        put("type", Build.TYPE)
        put("id", Build.ID)
        put("display", Build.DISPLAY)
        put("host", Build.HOST)
        put("user", Build.USER)
        put("abis", JSONArray(Build.SUPPORTED_ABIS.toList()))
        put("isDebuggable", (context.applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) != 0)
        put("isTestOnly", (context.applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_TEST_ONLY) != 0)
        put("targetSdk", context.applicationInfo.targetSdkVersion)
        put("minSdk", if (Build.VERSION.SDK_INT >= 24) context.applicationInfo.minSdkVersion else 0)
        put("debuggerConnected", Debug.isDebuggerConnected())
        val am = context.getSystemService(ActivityManager::class.java)
        put("isLowRamDevice", am?.isLowRamDevice ?: false)
        put("isRunningInTestHarness", ActivityManager.isRunningInTestHarness())
        put("hasGpsFeature", context.packageManager.hasSystemFeature(PackageManager.FEATURE_LOCATION_GPS))
        put("hasNetworkLocationFeature", context.packageManager.hasSystemFeature(PackageManager.FEATURE_LOCATION_NETWORK))
        put("hasGnssFeature", context.packageManager.hasSystemFeature(PackageManager.FEATURE_LOCATION_GPS))
    }

    private fun mockLocationPackages(): JSONArray {
        val result = JSONArray()
        runCatching {
            val packageManager = context.packageManager
            @Suppress("DEPRECATION")
            val packages = packageManager.getInstalledPackages(PackageManager.GET_PERMISSIONS)
            packages.asSequence()
                .filter { info ->
                    info.requestedPermissions?.contains("android.permission.ACCESS_MOCK_LOCATION") == true
                }
                .take(200)
                .forEach { info ->
                    result.put(
                        JSONObject().apply {
                            put("packageName", info.packageName)
                            put("isSystem", (info.applicationInfo?.flags ?: 0) and android.content.pm.ApplicationInfo.FLAG_SYSTEM != 0)
                            put(
                                "granted",
                                packageManager.checkPermission(
                                    "android.permission.ACCESS_MOCK_LOCATION",
                                    info.packageName
                                ) == PackageManager.PERMISSION_GRANTED
                            )
                        }
                    )
                }
        }
        return result
    }

    private fun permissionsInfo(): JSONObject = JSONObject().apply {
        val names = listOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.ACCESS_WIFI_STATE,
            Manifest.permission.CHANGE_WIFI_STATE,
            Manifest.permission.ACTIVITY_RECOGNITION,
            if (Build.VERSION.SDK_INT >= 31) Manifest.permission.BLUETOOTH_SCAN else "",
            if (Build.VERSION.SDK_INT >= 31) Manifest.permission.BLUETOOTH_CONNECT else "",
            if (Build.VERSION.SDK_INT >= 33) Manifest.permission.NEARBY_WIFI_DEVICES else ""
        ).filter { it.isNotBlank() }.distinct()
        val array = JSONArray()
        for (permission in names) {
            val granted = context.checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED
            array.put(JSONObject().put("permission", permission).put("granted", granted))
        }
        put("items", array)
    }

    private fun settingsInfo(): JSONObject = JSONObject().apply {
        put("secure", JSONObject().apply {
            put("mock_location", secureString("mock_location"))
            put("allow_mock_location", secureString("allow_mock_location"))
            put("location_mode", secureString(Settings.Secure.LOCATION_MODE))
            put("location_providers_allowed", secureString(Settings.Secure.LOCATION_PROVIDERS_ALLOWED))
            put("adb_enabled", secureString(Settings.Secure.ADB_ENABLED))
        })
        put("global", JSONObject().apply {
            put("development_settings_enabled", globalString(Settings.Global.DEVELOPMENT_SETTINGS_ENABLED))
            put("adb_enabled", globalString(Settings.Global.ADB_ENABLED))
            put("auto_time", globalString(Settings.Global.AUTO_TIME))
            put("auto_time_zone", globalString(Settings.Global.AUTO_TIME_ZONE))
        })
        put("system", JSONObject().apply {
            put("time_12_24", systemString(Settings.System.TIME_12_24))
        })
    }

    private fun appOpsInfo(): JSONObject = JSONObject().apply {
        val op = "android:mock_location"
        val mode = runCatching {
            if (Build.VERSION.SDK_INT >= 29) {
                appOpsManager?.unsafeCheckOpNoThrow(op, Process.myUid(), context.packageName)
            } else {
                appOpsManager?.checkOpNoThrow(op, Process.myUid(), context.packageName)
            }
        }.getOrNull()
        put("ownPackage", context.packageName)
        put("ownUid", Process.myUid())
        put("mockLocationMode", mode ?: -1)
        put("mockLocationModeName", appOpModeName(mode))
    }

    private fun locationInfo(): JSONObject = JSONObject().apply {
        val manager = locationManager
        put("isLocationEnabled", runCatching { manager?.isLocationEnabled }.getOrNull() ?: false)
        put("providers", JSONArray().apply {
            (runCatching { manager?.allProviders }.getOrNull() ?: emptyList()).sorted().forEach { name ->
                val provider = runCatching { manager?.getProvider(name) }.getOrNull()
                put(
                    JSONObject().apply {
                        put("name", name)
                        put("enabled", runCatching { manager?.isProviderEnabled(name) }.getOrNull() ?: false)
                        put("requiresSatellite", provider?.requiresSatellite() ?: false)
                        put("requiresNetwork", provider?.requiresNetwork() ?: false)
                        put("requiresCell", provider?.requiresCell() ?: false)
                        put("hasMonetaryCost", provider?.hasMonetaryCost() ?: false)
                        put("supportsAltitude", provider?.supportsAltitude() ?: false)
                        put("supportsSpeed", provider?.supportsSpeed() ?: false)
                        put("supportsBearing", provider?.supportsBearing() ?: false)
                        put("powerRequirement", provider?.powerRequirement ?: -1)
                        put("accuracy", provider?.accuracy ?: -1)
                        if (Build.VERSION.SDK_INT >= 31) {
                            put("providerProperties", runCatching {
                                manager?.getProviderProperties(name)?.toString()
                            }.getOrNull() ?: "")
                        }
                    }
                )
            }
        })
        put("lastKnown", JSONObject().apply {
            synchronized(lastKnown) {
                lastKnown.forEach { (name, location) -> put(name, locationToJson(location, "lastKnown")) }
            }
        })
        put("events", JSONArray().apply {
            synchronized(locationEvents) { locationEvents.forEach { put(it) } }
        })
        put("providerEvents", JSONArray().apply {
            synchronized(providerEvents) { providerEvents.forEach { put(it) } }
        })
    }

    private fun gnssInfo(): JSONObject = JSONObject().apply {
        val manager = locationManager
        put("hasGpsFeature", context.packageManager.hasSystemFeature(PackageManager.FEATURE_LOCATION_GPS))
        put("yearOfHardware", if (Build.VERSION.SDK_INT >= 28) runCatching { manager?.gnssYearOfHardware }.getOrNull() ?: -1 else -1)
        put("hardwareModelName", if (Build.VERSION.SDK_INT >= 28) runCatching { manager?.gnssHardwareModelName }.getOrNull() ?: "" else "")
        if (Build.VERSION.SDK_INT >= 31) {
            val caps = runCatching { manager?.gnssCapabilities }.getOrNull()
            put("capabilities", caps?.let { capabilitiesToJson(it) } ?: JSONObject.NULL)
        }
        if (Build.VERSION.SDK_INT >= 30) {
            put("antennaInfos", JSONArray().apply {
                runCatching { manager?.gnssAntennaInfos }.getOrNull()?.forEach { info ->
                    put(JSONObject().put("carrierFrequencyMHz", info.carrierFrequencyMHz).put("toString", truncate(info.toString(), 3000)))
                }
            })
        }
        put("statusEventCount", gnssStatusEvents.size)
        put("statusEvents", JSONArray().apply {
            synchronized(gnssStatusEvents) { gnssStatusEvents.forEach { put(it) } }
        })
        put("statusTransitions", JSONArray().apply {
            synchronized(gnssStatusTransitions) { gnssStatusTransitions.forEach { put(it) } }
        })
        put("measurementEventCount", gnssMeasurementCount.get())
        put("measurementStatuses", JSONArray().apply {
            synchronized(gnssMeasurementStatuses) { gnssMeasurementStatuses.forEach { put(it) } }
        })
        put("measurementSamples", JSONArray().apply {
            synchronized(gnssMeasurementSamples) { gnssMeasurementSamples.forEach { put(it) } }
        })
        put("navigationMessageCounts", JSONObject().apply {
            navMessageCounts.forEach { (key, count) -> put(key, count.get()) }
        })
        put("navigationMessageSamples", JSONArray().apply {
            synchronized(navMessageSamples) { navMessageSamples.forEach { put(it) } }
        })
        put("nmeaCount", nmeaLines.size)
        put("nmeaLines", JSONArray().apply {
            synchronized(nmeaLines) { nmeaLines.take(500).forEach { put(it) } }
        })
    }

    private fun sensorsInfo(): JSONObject = JSONObject().apply {
        val manager = sensorManager
        val accumulators = synchronized(sensorAccumulators) { sensorAccumulators.entries.toList() }
        put("sensorList", JSONArray().apply {
            (runCatching { manager?.getSensorList(Sensor.TYPE_ALL) }.getOrNull() ?: emptyList()).forEach { sensor ->
                put(sensorToJson(sensor))
            }
        })
        put("stats", JSONArray().apply {
            accumulators.forEach { (sensor, accumulator) ->
                put(accumulator.toJson(sensor, sensorRegistration[sensor] ?: false))
            }
        })
    }

    private fun wifiInfo(): JSONObject = JSONObject().apply {
        val manager = wifiManager
        put("isWifiEnabled", runCatching { manager?.isWifiEnabled }.getOrNull() ?: false)
        put("isScanAlwaysAvailable", runCatching { manager?.isScanAlwaysAvailable }.getOrNull() ?: false)
        if (Build.VERSION.SDK_INT >= 28) {
            put("isScanThrottleEnabled", runCatching { manager?.isScanThrottleEnabled }.getOrNull() ?: false)
        }
        put("connectionInfo", runCatching { manager?.connectionInfo?.let { info ->
            JSONObject().apply {
                put("SSID", info.getSSID() ?: "")
                put("BSSID", info.getBSSID() ?: "")
                put("macAddress", info.macAddress ?: "")
                put("rssi", info.rssi)
                put("linkSpeed", info.linkSpeed)
                put("frequency", info.frequency)
                put("networkId", info.networkId)
                put("hiddenSSID", info.hiddenSSID)
                put("supplicantState", info.supplicantState?.toString() ?: "")
                put("ipAddress", intToIp(info.ipAddress))
                if (Build.VERSION.SDK_INT >= 29) {
                    put("rxLinkSpeedMbps", info.rxLinkSpeedMbps)
                    put("txLinkSpeedMbps", info.txLinkSpeedMbps)
                    put("maxSupportedRxLinkSpeedMbps", info.maxSupportedRxLinkSpeedMbps)
                    put("maxSupportedTxLinkSpeedMbps", info.maxSupportedTxLinkSpeedMbps)
                }
                put("toString", truncate(info.toString(), 4000))
            }
        } }.getOrNull() ?: JSONObject.NULL)
        put("dhcpInfo", runCatching { manager?.dhcpInfo?.let { info ->
            JSONObject().apply {
                put("ipAddress", intToIp(info.ipAddress))
                put("gateway", intToIp(info.gateway))
                put("netmask", intToIp(info.netmask))
                put("dns1", intToIp(info.dns1))
                put("dns2", intToIp(info.dns2))
                put("serverAddress", intToIp(info.serverAddress))
                put("leaseDuration", info.leaseDuration)
            }
        } }.getOrNull() ?: JSONObject.NULL)
        put("scanResults", JSONArray().apply {
            synchronized(wifiScanResults) { wifiScanResults.forEach { put(it) } }
        })
        put("scanError", wifiScanError ?: JSONObject.NULL)
    }

    private fun cellInfo(): JSONObject = JSONObject().apply {
        val manager = telephonyManager
        put("dataNetworkType", runCatching { manager?.dataNetworkType }.getOrNull() ?: -1)
        put("voiceNetworkType", runCatching { manager?.voiceNetworkType }.getOrNull() ?: -1)
        put("networkOperatorName", runCatching { manager?.networkOperatorName }.getOrNull() ?: "")
        put("simOperatorName", runCatching { manager?.simOperatorName }.getOrNull() ?: "")
        put("isNetworkRoaming", runCatching { manager?.isNetworkRoaming }.getOrNull() ?: false)
        put("phoneCount", if (Build.VERSION.SDK_INT >= 23) runCatching { manager?.phoneCount }.getOrNull() ?: 0 else 0)
        put("signalStrength", if (Build.VERSION.SDK_INT >= 28) {
            runCatching { manager?.signalStrength?.toString() }.getOrNull() ?: JSONObject.NULL
        } else JSONObject.NULL)
        put("cellLocation", runCatching { manager?.cellLocation?.toString() }.getOrNull() ?: JSONObject.NULL)
        put("allCellInfo", JSONArray().apply {
            runCatching { manager?.allCellInfo }.getOrNull()?.forEach { info ->
                put(
                    JSONObject().apply {
                        put("class", info.javaClass.simpleName)
                        put("registered", info.isRegistered)
                        put("timestamp", info.timeStamp)
                        put("cellIdentity", truncate(info.cellIdentity?.toString(), 3000))
                        put("cellSignalStrength", truncate(info.cellSignalStrength?.toString(), 2000))
                        put("toString", truncate(info.toString(), 4000))
                    }
                )
            }
        })
    }

    private fun bluetoothInfo(): JSONObject = JSONObject().apply {
        val adapter = bluetoothAdapter ?: bluetoothManager?.adapter
        put("available", adapter != null)
        put("enabled", runCatching { adapter?.isEnabled }.getOrNull() ?: false)
        put("state", runCatching { adapter?.state }.getOrNull() ?: -1)
        put("bondedDevices", JSONArray().apply {
            runCatching { adapter?.bondedDevices }.getOrNull()?.forEach { device ->
                put(
                    JSONObject().apply {
                        put("address", device.address ?: "")
                        put("name", runCatching { device.name }.getOrNull() ?: "")
                        put("type", device.type)
                        put("bondState", device.bondState)
                        put("toString", truncate(device.toString(), 2000))
                    }
                )
            }
        })
        put("bleScanResults", JSONArray().apply {
            synchronized(bleResults) { bleResults.forEach { put(it) } }
        })
        put("bleError", bleError ?: JSONObject.NULL)
    }

    private fun networkInfo(): JSONObject = JSONObject().apply {
        val manager = connectivityManager
        val active = runCatching { manager?.activeNetwork }.getOrNull()
        put("activeNetwork", active?.toString() ?: JSONObject.NULL)
        put("isActiveNetworkMetered", runCatching { manager?.isActiveNetworkMetered }.getOrNull() ?: false)
        put("capabilities", runCatching {
            active?.let { manager?.getNetworkCapabilities(it) }?.let { caps ->
                JSONObject().apply {
                    put("toString", truncate(caps.toString(), 4000))
                    put("hasInternet", caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET))
                    put("hasValidated", caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED))
                    put("hasWifi", caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI))
                    put("hasCell", caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR))
                    put("hasBluetooth", caps.hasTransport(NetworkCapabilities.TRANSPORT_BLUETOOTH))
                    put("hasVpn", caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN))
                }
            }
        }.getOrNull() ?: JSONObject.NULL)
        put("linkProperties", runCatching {
            active?.let { manager?.getLinkProperties(it) }?.let { link ->
                JSONObject().apply {
                    put("interfaceName", link.interfaceName ?: "")
                    put("domains", link.domains ?: "")
                    put("privateDnsServerName", if (Build.VERSION.SDK_INT >= 28) link.privateDnsServerName ?: "" else "")
                    put("linkAddresses", JSONArray(link.linkAddresses.map { it.toString() }))
                    put("routes", JSONArray(link.routes.map { it.toString() }))
                    put("dnsServers", JSONArray(link.dnsServers.map { it.hostAddress ?: it.toString() }))
                    put("toString", truncate(link.toString(), 4000))
                }
            }
        }.getOrNull() ?: JSONObject.NULL)
        put("networkInfo", runCatching {
            @Suppress("DEPRECATION")
            manager?.activeNetworkInfo?.let { info ->
                JSONObject().apply {
                    put("typeName", info.typeName ?: "")
                    put("subtypeName", info.subtypeName ?: "")
                    put("state", info.state?.toString() ?: "")
                    put("detailedState", info.detailedState?.toString() ?: "")
                    put("isConnected", info.isConnected)
                    put("isRoaming", info.isRoaming)
                    put("toString", truncate(info.toString(), 3000))
                }
            }
        }.getOrNull() ?: JSONObject.NULL)
    }

    private fun locationToJson(location: Location, source: String): JSONObject = JSONObject().apply {
        put("source", source)
        put("provider", location.provider ?: "")
        put("latitude", location.latitude)
        put("longitude", location.longitude)
        put("accuracyMeters", location.accuracy.toDouble())
        put("altitudeMeters", location.altitude)
        put("verticalAccuracyMeters", if (Build.VERSION.SDK_INT >= 26) location.verticalAccuracyMeters.toDouble() else JSONObject.NULL)
        put("speedMps", location.speed.toDouble())
        put("speedAccuracyMps", if (Build.VERSION.SDK_INT >= 26) location.speedAccuracyMetersPerSecond.toDouble() else JSONObject.NULL)
        put("bearingDeg", location.bearing.toDouble())
        put("bearingAccuracyDeg", if (Build.VERSION.SDK_INT >= 26) location.bearingAccuracyDegrees.toDouble() else JSONObject.NULL)
        put("timeMs", location.time)
        put("elapsedRealtimeNanos", location.elapsedRealtimeNanos)
        put("nowWallMs", System.currentTimeMillis())
        put("nowElapsedMs", SystemClock.elapsedRealtime())
        put("timeSkewMs", location.time - System.currentTimeMillis())
        put("elapsedAgeMs", (SystemClock.elapsedRealtimeNanos() - location.elapsedRealtimeNanos) / 1_000_000.0)
        put("isFromMockProvider", location.isFromMockProvider)
        if (Build.VERSION.SDK_INT >= 31) put("isMock", location.isMock)
        put("extras", location.extras.toJsonObject(48))
    }

    private fun measurementsToJson(event: GnssMeasurementsEvent): JSONObject = JSONObject().apply {
        val clock = event.clock
        put("elapsedRealtimeNanos", SystemClock.elapsedRealtimeNanos())
        put("clock", JSONObject().apply {
            put("timeNanos", clock.timeNanos)
            put("fullBiasNanos", clock.fullBiasNanos)
            put("biasNanos", clock.biasNanos)
            put("biasUncertaintyNanos", clock.biasUncertaintyNanos)
            put("driftNanosPerSecond", clock.driftNanosPerSecond)
            put("driftUncertaintyNanosPerSecond", clock.driftUncertaintyNanosPerSecond)
            put("elapsedRealtimeNanos", clock.elapsedRealtimeNanos)
            put("elapsedRealtimeUncertaintyNanos", clock.elapsedRealtimeUncertaintyNanos)
            put("hardwareClockDiscontinuityCount", clock.hardwareClockDiscontinuityCount)
            put("leapSecond", clock.leapSecond)
            put("timeUncertaintyNanos", clock.timeUncertaintyNanos)
            put("toString", truncate(clock.toString(), 4000))
        })
        // isFullTracking() 是 API 34 新增；SDK 30–33 上不存在，直接调用会 NoSuchMethodError。
        if (Build.VERSION.SDK_INT >= 34) put("isFullTracking", event.isFullTracking)
        val measurements = event.measurements?.take(40) ?: emptyList()
        put("measurementCount", event.measurements?.size ?: 0)
        put("measurements", JSONArray().apply {
            measurements.forEach { m ->
                put(JSONObject().apply {
                    put("svid", m.svid)
                    put("constellation", m.constellationType)
                    put("state", m.state)
                    put("cn0DbHz", m.cn0DbHz)
                    put("pseudorangeRateMps", m.pseudorangeRateMetersPerSecond)
                    put("pseudorangeRateUncertaintyMps", m.pseudorangeRateUncertaintyMetersPerSecond)
                    put("receivedSvTimeNanos", m.receivedSvTimeNanos)
                    put("receivedSvTimeUncertaintyNanos", m.receivedSvTimeUncertaintyNanos)
                    put("timeOffsetNanos", m.timeOffsetNanos)
                    put("carrierPhase", if (m.hasCarrierPhase()) m.carrierPhase else JSONObject.NULL)
                    put("carrierPhaseUncertainty", if (m.hasCarrierPhaseUncertainty()) m.carrierPhaseUncertainty else JSONObject.NULL)
                    put("multipathIndicator", m.multipathIndicator)
                    if (Build.VERSION.SDK_INT >= 30) {
                        put("basebandCn0DbHz", if (m.hasBasebandCn0DbHz()) m.basebandCn0DbHz else JSONObject.NULL)
                        put("carrierFrequencyHz", if (m.hasCarrierFrequencyHz()) m.carrierFrequencyHz else JSONObject.NULL)
                    }
                    put("toString", truncate(m.toString(), 3000))
                })
            }
        })
    }

    private fun sensorToJson(sensor: Sensor): JSONObject = JSONObject().apply {
        put("name", sensor.name ?: "")
        put("vendor", sensor.vendor ?: "")
        put("version", sensor.version)
        put("type", sensor.type)
        put("stringType", sensor.stringType ?: "")
        put("maxRange", sensor.maximumRange)
        put("resolution", sensor.resolution)
        put("power", sensor.power)
        put("minDelayUs", sensor.minDelay)
        put("maxDelayUs", sensor.maxDelay)
        put("fifoMaxEventCount", sensor.fifoMaxEventCount)
        put("fifoReservedEventCount", sensor.fifoReservedEventCount)
        put("isWakeUp", sensor.isWakeUpSensor)
        put("isDynamic", sensor.isDynamicSensor)
        put("reportingMode", sensor.reportingMode)
        if (Build.VERSION.SDK_INT >= 26) {
            put("isAdditionalInfoSupported", sensor.isAdditionalInfoSupported)
            put("highestDirectReportRateLevel", sensor.highestDirectReportRateLevel)
        }
        if (Build.VERSION.SDK_INT >= 28) put("id", sensor.id)
        put("toString", truncate(sensor.toString(), 2000))
    }

    private fun capabilitiesToJson(caps: GnssCapabilities): JSONObject = JSONObject().apply {
        // 只调用 API 31 就存在的方法。hasPower*/hasSingleShotFix/hasScheduling/
        // hasSatellitePvt/hasMeasurementCorrections* 等是 API 34+；在本机 Android 13
        // 上直接调用会 NoSuchMethodError，因此改用 toString 保留厂商扩展信息。
        put("hasMeasurements", caps.hasMeasurements())
        put("hasNavigationMessages", caps.hasNavigationMessages())
        put("hasAntennaInfo", caps.hasAntennaInfo())
        put("toString", truncate(caps.toString(), 4000))
    }

    private fun secureString(key: String): String = runCatching {
        Settings.Secure.getString(context.contentResolver, key) ?: ""
    }.getOrDefault("")

    private fun globalString(key: String): String = runCatching {
        Settings.Global.getString(context.contentResolver, key) ?: ""
    }.getOrDefault("")

    private fun systemString(key: String): String = runCatching {
        Settings.System.getString(context.contentResolver, key) ?: ""
    }.getOrDefault("")

    private fun appOpModeName(mode: Int?): String = when (mode) {
        AppOpsManager.MODE_ALLOWED -> "allowed"
        AppOpsManager.MODE_IGNORED -> "ignored"
        AppOpsManager.MODE_ERRORED -> "errored"
        AppOpsManager.MODE_DEFAULT -> "default"
        else -> "unknown(${mode ?: -1})"
    }

    private fun intToIp(value: Int): String {
        if (value == 0) return "0.0.0.0"
        return String.format(
            Locale.US,
            "%d.%d.%d.%d",
            value and 0xff,
            (value shr 8) and 0xff,
            (value shr 16) and 0xff,
            (value shr 24) and 0xff
        )
    }

    private class AxisStats {
        var count = 0
        var min = Double.POSITIVE_INFINITY
        var max = Double.NEGATIVE_INFINITY
        var sum = 0.0
        var sumSquares = 0.0

        fun add(value: Float) {
            if (!value.isFinite()) return
            val v = value.toDouble()
            count++
            if (v < min) min = v
            if (v > max) max = v
            sum += v
            sumSquares += v * v
        }

        fun json(): JSONObject = JSONObject().apply {
            put("count", count)
            if (count > 0) {
                val mean = sum / count
                put("min", min)
                put("max", max)
                put("mean", mean)
                put("variance", (sumSquares / count) - (mean * mean))
                put("range", max - min)
            }
        }
    }

    private class SensorAccumulator(private val sensor: Sensor) {
        private var count = 0
        private var firstTimestamp = Long.MAX_VALUE
        private var lastTimestamp = 0L
        private var lastValues: FloatArray? = null
        private val axes = Array(8) { AxisStats() }
        private val firstSamples = JSONArray()
        private val lastSamples = ArrayDeque<FloatArray>()
        private val accuracies = ConcurrentHashMap<Int, Int>()

        @Synchronized
        fun add(event: SensorEvent) {
            count++
            if (event.timestamp < firstTimestamp) firstTimestamp = event.timestamp
            if (event.timestamp > lastTimestamp) lastTimestamp = event.timestamp
            val values = event.values.copyOf()
            lastValues = values
            values.forEachIndexed { index, value -> axes.getOrNull(index)?.add(value) }
            if (firstSamples.length() < 3) firstSamples.put(JSONArray(values.toList()))
            lastSamples.addLast(values)
            if (lastSamples.size > 5) lastSamples.removeFirst()
            accuracies[event.accuracy] = (accuracies[event.accuracy] ?: 0) + 1
        }

        @Synchronized
        fun onAccuracyChanged(accuracy: Int) {
            accuracies[accuracy] = (accuracies[accuracy] ?: 0) + 1
        }

        @Synchronized
        fun toJson(sensor: Sensor, registered: Boolean): JSONObject = JSONObject().apply {
            put("name", sensor.name ?: "")
            put("type", sensor.type)
            put("registered", registered)
            put("count", count)
            put("firstTimestampNanos", if (count > 0) firstTimestamp else JSONObject.NULL)
            put("lastTimestampNanos", if (count > 0) lastTimestamp else JSONObject.NULL)
            put("timestampSpanMs", if (count > 0) (lastTimestamp - firstTimestamp) / 1_000_000.0 else 0)
            put("lastValues", lastValues?.let { JSONArray(it.toList()) } ?: JSONArray())
            put("axes", JSONArray().apply { axes.forEach { put(it.json()) } })
            put("firstSamples", firstSamples)
            put("lastSamples", JSONArray().apply { lastSamples.forEach { put(JSONArray(it.toList())) } })
            put("accuracyCounts", JSONObject().apply { accuracies.forEach { (acc, n) -> put(acc.toString(), n) } })
        }
    }
}
