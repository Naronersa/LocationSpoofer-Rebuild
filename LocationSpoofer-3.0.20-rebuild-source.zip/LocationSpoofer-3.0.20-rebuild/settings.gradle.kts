pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\.android.*")
                includeGroupByRegex("com\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        maven { url = uri("https://api.xposed.info/") }
    }
}

rootProject.name = "LocationSpoofer"
include(":app")
include(":app-ui")
include(":service")
include(":xposed")
include(":core-data")
include(":core-geo")
// 独立传感器验证工具（LSPosed 模块 + 自测 Activity），不参与 :app 构建
include(":sensorprobe")
// 独立定位数据验证工具（普通 APK，Root + 框架层采集），不参与 :app 构建
include(":locationprobe")
// global 系统级传感器 native 层（仅 global flavor 依赖，scoped 不打包）
include(":sensor-native")
