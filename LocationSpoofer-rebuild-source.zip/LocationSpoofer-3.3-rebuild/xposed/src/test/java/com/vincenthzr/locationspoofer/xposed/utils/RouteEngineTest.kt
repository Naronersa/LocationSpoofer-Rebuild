package com.vincenthzr.locationspoofer.xposed.utils

import com.vincenthzr.locationspoofer.utils.ConfigKeys

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RouteEngineTest {

    private fun pointsJson(vararg latLng: Pair<Double, Double>): JSONArray {
        val arr = JSONArray()
        latLng.forEach { (lat, lng) ->
            arr.put(JSONObject().apply {
                put(ConfigKeys.LAT, lat)
                put(ConfigKeys.LNG, lng)
            })
        }
        return arr
    }

    @Test
    fun `non route mode falls back to the raw config coordinate`() {
        val config = JSONObject().apply {
            put(ConfigKeys.IS_ROUTE_MODE, false)
            put(ConfigKeys.LAT, 31.5)
            put(ConfigKeys.LNG, 120.5)
            put(ConfigKeys.SIM_BEARING, 88.0)
        }
        val motion = RouteEngine.calculateCurrentPosition(config, now = 0L)
        assertEquals(31.5, motion.lat, 0.0)
        assertEquals(120.5, motion.lng, 0.0)
        assertEquals(88f, motion.bearing)
        assertEquals(0f, motion.speed)
    }

    @Test
    fun `route mode with fewer than two points falls back to the raw config coordinate`() {
        val config = JSONObject().apply {
            put(ConfigKeys.IS_ROUTE_MODE, true)
            put(ConfigKeys.ROUTE_POINTS, pointsJson(1.0 to 2.0))
            put(ConfigKeys.LAT, 31.5)
            put(ConfigKeys.LNG, 120.5)
        }
        val motion = RouteEngine.calculateCurrentPosition(config, now = 0L)
        assertEquals(31.5, motion.lat, 0.0)
        assertEquals(120.5, motion.lng, 0.0)
    }

    @Test
    fun `straight two-point route starts at the first point`() {
        // 用这个测试专属的坐标，避免和其它用例撞上 RouteEngine 内部的路线缓存签名(count+首尾纬度)。
        val start = 10.0 to 100.0
        val end = 10.02 to 100.0 // 正北方向，约 2.2km，明显不是闭环(缺口远大于5米阈值)
        val config = JSONObject().apply {
            put(ConfigKeys.IS_ROUTE_MODE, true)
            put(ConfigKeys.ROUTE_POINTS, pointsJson(start, end))
            put(ConfigKeys.SPEED_M_S, 10.0)
            put(ConfigKeys.START_TIMESTAMP, 0L)
        }
        val motion = RouteEngine.calculateCurrentPosition(config, now = 0L)
        assertEquals(start.first, motion.lat, 1e-6)
        assertEquals(start.second, motion.lng, 1e-6)
    }

    @Test
    fun `straight two-point route with stop_at_destination stops exactly at the last point`() {
        val start = 10.0 to 100.0
        val end = 10.02 to 100.0
        val config = JSONObject().apply {
            put(ConfigKeys.IS_ROUTE_MODE, true)
            put(ConfigKeys.ROUTE_POINTS, pointsJson(start, end))
            put(ConfigKeys.SPEED_M_S, 10.0)
            // start_timestamp 必须是正数——RouteEngine 把 <=0 的值当作"还没设置开始时间"，
            // 会直接拿 now 当起点，导致 elapsedSec 恒为 0，永远走不到终点。
            put(ConfigKeys.START_TIMESTAMP, 1L)
            put(ConfigKeys.STOP_AT_DESTINATION, true)
        }
        // 全程约 2.2km，10m/s 走完要 220s；给 10000s 保证早已到达终点。
        val motion = RouteEngine.calculateCurrentPosition(config, now = 10_000_000L)
        assertEquals(end.first, motion.lat, 1e-6)
        assertEquals(end.second, motion.lng, 1e-6)
        assertEquals(0f, motion.speed)
    }

    @Test
    fun `closed loop route treats the near-identical last point as returning to the start`() {
        // 首尾几乎重合(小于 RouteEngine 5 米的闭环判定阈值)，构成一个三角形闭环。
        val a = 20.0 to 110.0
        val b = 20.01 to 110.0
        val c = 20.01 to 110.01
        val closeToA = 20.0 to 110.0 // 与 a 完全相同，缺口为 0，必然判定为闭环
        val config = JSONObject().apply {
            put(ConfigKeys.IS_ROUTE_MODE, true)
            put(ConfigKeys.ROUTE_POINTS, pointsJson(a, b, c, closeToA))
            put(ConfigKeys.SPEED_M_S, 5.0)
            put(ConfigKeys.START_TIMESTAMP, 0L)
        }
        // t=0 时应该正好在起点 a
        val atStart = RouteEngine.calculateCurrentPosition(config, now = 0L)
        assertEquals(a.first, atStart.lat, 1e-6)
        assertEquals(a.second, atStart.lng, 1e-6)
        assertTrue(atStart.speed > 0f)
    }

    private fun joystickConfig(speed: Double, bearing: Double, startTimestamp: Long) = JSONObject().apply {
        put(ConfigKeys.IS_ROUTE_MODE, false)
        put(ConfigKeys.SIM_MODE, "JOYSTICK")
        put(ConfigKeys.LAT, 31.5)
        put(ConfigKeys.LNG, 120.5)
        put(ConfigKeys.SIM_BEARING, bearing)
        put(ConfigKeys.SPEED_M_S, speed)
        put(ConfigKeys.START_TIMESTAMP, startTimestamp)
    }

    @Test
    fun `joystick mode extrapolates along the bearing between config writes`() {
        val motion = RouteEngine.calculateCurrentPosition(joystickConfig(5.0, 0.0, 1_000L), now = 2_000L)
        // 正北 5 m/s 走 1 秒 ≈ 纬度增加 5 / 111 km
        assertEquals(31.5 + 5.0 / 111_320.0, motion.lat, 1e-6)
        assertEquals(120.5, motion.lng, 1e-9)
        assertEquals(5f, motion.speed)
    }

    @Test
    fun `joystick extrapolation is capped when the app stops writing config`() {
        val capped = RouteEngine.calculateCurrentPosition(joystickConfig(5.0, 90.0, 1_000L), now = 61_000L)
        val atCap = RouteEngine.calculateCurrentPosition(joystickConfig(5.0, 90.0, 1_000L), now = 4_000L)
        assertEquals(atCap.lng, capped.lng, 1e-12)
        assertTrue(capped.lng > 120.5)
    }

    @Test
    fun `released joystick stays at the written coordinate`() {
        val motion = RouteEngine.calculateCurrentPosition(joystickConfig(0.0, 45.0, 1_000L), now = 5_000L)
        assertEquals(31.5, motion.lat, 0.0)
        assertEquals(120.5, motion.lng, 0.0)
        assertEquals(0f, motion.speed)
    }

    @Test
    fun `route resumes from the paused distance offset`() {
        // 一条正北方向约 1113 米的直线路线
        val route = pointsJson(0.0 to 0.0, 0.01 to 0.0)
        fun cfg(offset: Double, start: Long) = JSONObject().apply {
            put(ConfigKeys.IS_ROUTE_MODE, true)
            put(ConfigKeys.ROUTE_POINTS, route)
            put(ConfigKeys.SPEED_M_S, 2.0)
            put(ConfigKeys.START_TIMESTAMP, start)
            put(ConfigKeys.ROUTE_DISTANCE_OFFSET, offset)
        }
        val paused = RouteEngine.calculateCurrentPosition(cfg(0.0, 1_000L), now = 101_000L) // 走了 200 米时暂停
        val resumed = RouteEngine.calculateCurrentPosition(cfg(200.0, 500_000L), now = 500_000L) // 继续的瞬间
        assertEquals(paused.lat, resumed.lat, 1e-9)
        val later = RouteEngine.calculateCurrentPosition(cfg(200.0, 500_000L), now = 510_000L)
        assertEquals(220.0 / 111_320.0, later.lat, 2e-6)
    }

    @Test
    fun `route progress ignores wall clock jumps when monotonic anchor is present`() {
        val start = 0.0 to 0.0
        val config = JSONObject().apply {
            put(ConfigKeys.IS_ROUTE_MODE, true)
            put(ConfigKeys.ROUTE_POINTS, pointsJson(start, 0.01 to 0.0))
            put(ConfigKeys.SPEED_M_S, 2.0)
            put(ConfigKeys.START_TIMESTAMP, 1_000L)
            put(ConfigKeys.ROUTE_START_ELAPSED_MS, 50_000L)
            put(ConfigKeys.ROUTE_BOOT_ID, "")
            put(ConfigKeys.ENABLE_JITTER, false)
            put(ConfigKeys.ROUTE_LATERAL_DEVIATION, false)
        }
        // 单调时钟走过 10 秒：墙钟起点先后无关，应前进 20 米。
        val first = RouteEngine.calculateCurrentPosition(
            config, now = 60_000L, elapsedRealtimeMs = 60_000L
        )
        // 墙钟突然前进 1 小时，单调时钟只前进 1 秒：应只多走 2 米。
        val second = RouteEngine.calculateCurrentPosition(
            config, now = 3_660_000L, elapsedRealtimeMs = 61_000L
        )
        val startLatLng = com.vincenthzr.locationspoofer.utils.CoordinateUtils.LatLng(start.first, start.second)
        assertEquals(
            20.0,
            com.vincenthzr.locationspoofer.utils.GeoMath.distance(
                startLatLng,
                com.vincenthzr.locationspoofer.utils.CoordinateUtils.LatLng(first.lat, first.lng),
            ),
            0.1,
        )
        assertEquals(
            22.0,
            com.vincenthzr.locationspoofer.utils.GeoMath.distance(
                startLatLng,
                com.vincenthzr.locationspoofer.utils.CoordinateUtils.LatLng(second.lat, second.lng),
            ),
            0.1,
        )
    }

    @Test
    fun `route stops at a waitSec traffic light and then continues`() {
        val start = 40.0 to 120.0
        val mid = 40.001 to 120.0
        val end = 40.01 to 120.0
        val midDistance = com.vincenthzr.locationspoofer.utils.GeoMath.distance(
            com.vincenthzr.locationspoofer.utils.CoordinateUtils.LatLng(start.first, start.second),
            com.vincenthzr.locationspoofer.utils.CoordinateUtils.LatLng(mid.first, mid.second),
        )
        val startTimestamp = 1_000_000L
        val config = JSONObject().apply {
            put(ConfigKeys.IS_ROUTE_MODE, true)
            put(ConfigKeys.ROUTE_POINTS, JSONArray().apply {
                put(JSONObject().put(ConfigKeys.LAT, start.first).put(ConfigKeys.LNG, start.second))
                put(JSONObject().put(ConfigKeys.LAT, mid.first).put(ConfigKeys.LNG, mid.second).put(ConfigKeys.WAIT_SEC, 15.0))
                put(JSONObject().put(ConfigKeys.LAT, end.first).put(ConfigKeys.LNG, end.second))
            })
            put(ConfigKeys.SPEED_M_S, 2.0)
            put(ConfigKeys.START_TIMESTAMP, startTimestamp)
        }
        val arrivalMs = startTimestamp + (midDistance / 2.0 * 1000.0).toLong()

        val waiting = RouteEngine.calculateCurrentPosition(config, now = arrivalMs + 1_000L)
        assertEquals(0f, waiting.speed)
        assertEquals(mid.first, waiting.lat, 0.001)
        assertEquals(mid.second, waiting.lng, 0.001)

        val afterWait = RouteEngine.calculateCurrentPosition(config, now = arrivalMs + 16_000L)
        assertTrue(afterWait.speed > 0f)
        assertEquals(mid.second, afterWait.lng, 1e-6)
        assertTrue(afterWait.lat > mid.first)
        assertTrue(
            com.vincenthzr.locationspoofer.utils.GeoMath.distance(
                com.vincenthzr.locationspoofer.utils.CoordinateUtils.LatLng(start.first, start.second),
                com.vincenthzr.locationspoofer.utils.CoordinateUtils.LatLng(afterWait.lat, afterWait.lng),
            ) > midDistance + 1.0
        )
    }

    @Test
    fun `route altitude follows the terrain within the configured range`() {
        fun cfg(variation: Double?) = JSONObject().apply {
            put(ConfigKeys.IS_ROUTE_MODE, true)
            put(ConfigKeys.ROUTE_POINTS, pointsJson(40.0 to 116.0, 40.05 to 116.0))
            put(ConfigKeys.SPEED_M_S, 1.4)
            put(ConfigKeys.START_TIMESTAMP, 1_000_000L)
            put(ConfigKeys.ALTITUDE, 80.0)
            put(ConfigKeys.REALISM_LEVEL, 2)
            variation?.let { put(ConfigKeys.ALTITUDE_VARIATION_M, it) }
        }
        assertEquals(80.0, RouteEngine.realisticAltitude(cfg(0.0), now = 2_000_000L), 0.0)

        val values = (0..3600 step 5).map { RouteEngine.realisticAltitude(cfg(30.0), now = 1_000_000L + it * 1000L) }
        assertTrue(values.all { it in 50.0..110.0 })
        assertTrue(values.max() - values.min() > 5.0)
        // 相邻 5 秒（步行 7 米）的海拔变化不超过坡度上限加漂移
        assertTrue(values.zipWithNext { a, b -> kotlin.math.abs(b - a) }.max() < 7 * 0.08 + 0.5)

        // 旧版配置没有变化范围字段时按随机强度的漂移幅度（中档 ±3 米）处理
        val legacy = (0..600 step 10).map { RouteEngine.realisticAltitude(cfg(null), now = 1_000_000L + it * 1000L) }
        assertTrue(legacy.all { it in 77.0..83.0 })
    }

    @Test
    fun `route bearing is derived from the same jittered trajectory as the coordinate`() {
        // 10 km 正北路线；在开始 3 秒后取前后各 3 秒的真实轨迹点。
        val config = JSONObject().apply {
            put(ConfigKeys.IS_ROUTE_MODE, true)
            put(ConfigKeys.ROUTE_POINTS,
                pointsJson(10.0 to 100.0, 10.1 to 100.0, 10.1 to 100.2)
            )
            put(ConfigKeys.SPEED_M_S, 3.0)
            put(ConfigKeys.START_TIMESTAMP, 1L)
            put(ConfigKeys.ENABLE_JITTER, true)
            put(ConfigKeys.REALISM_LEVEL, 2)
        }
        val now = 1_000_000L
        val current = RouteEngine.calculateCurrentPosition(config, now)
        val behind = RouteEngine.calculateCurrentPosition(config, now - 3_000L)
        val ahead = RouteEngine.calculateCurrentPosition(config, now + 3_000L)
        val chord = com.vincenthzr.locationspoofer.utils.GeoMath.bearing(
            com.vincenthzr.locationspoofer.utils.CoordinateUtils.LatLng(
                behind.lat, behind.lng
            ),
            com.vincenthzr.locationspoofer.utils.CoordinateUtils.LatLng(
                ahead.lat, ahead.lng
            )
        )
        var delta = (current.bearing - chord) % 360f
        if (delta >= 180f) delta -= 360f
        if (delta < -180f) delta += 360f
        // 指南针/Location/NMEA 的 bearing 必须与坐标位移一致，
        // 而不是另一套独立正弦噪声（允许浮点/窗口边界误差）。
        assertTrue(kotlin.math.abs(delta) < 0.5f)
    }

    @Test
    fun `west route bearing is 270 degrees regardless of real device heading`() {
        // 设备真实朝向不参与 RouteEngine：配置只有地图路线。
        // 从东经 100.00 向西到 99.98，约 1.7km；1 秒后仍在该段，bearing 应为正西 270°。
        val config = JSONObject().apply {
            put(ConfigKeys.IS_ROUTE_MODE, true)
            put(ConfigKeys.ROUTE_POINTS, pointsJson(10.0 to 100.00, 10.0 to 99.98))
            put(ConfigKeys.SPEED_M_S, 10.0)
            put(ConfigKeys.START_TIMESTAMP, 1L)
        }
        val motion = RouteEngine.calculateCurrentPosition(config, now = 1_000L)
        assertEquals(270.0, motion.bearing.toDouble(), 0.5)
    }
}
