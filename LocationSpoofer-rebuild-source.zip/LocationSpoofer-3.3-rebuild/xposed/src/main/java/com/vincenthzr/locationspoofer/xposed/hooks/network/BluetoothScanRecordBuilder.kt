@file:Suppress(
    "UNUSED_PARAMETER",
    "UNUSED_VARIABLE",
    "UNNECESSARY_NOT_NULL_ASSERTION",
    "DEPRECATION",
    "NAME_SHADOWING",
    "FunctionName",
    "PrivatePropertyName",
    "SpellCheckingInspection",
    "RedundantUnitReturnType",
    "RemoveRedundantQualifierName",
    "OPT_IN_USAGE",
    "unused",
    "UnusedImport"
)

package com.vincenthzr.locationspoofer.xposed.hooks.network

import com.vincenthzr.locationspoofer.xposed.utils.HookLog

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import com.vincenthzr.locationspoofer.xposed.LocationHooker
import com.vincenthzr.locationspoofer.xposed.utils.*
import org.json.JSONObject
import kotlin.random.Random
import io.github.libxposed.api.*

/**
 * 蓝牙 LE 扫描结果/设备对象构造辅助函数（纯计算，不依赖 LocationHooker 状态）。
 */
internal fun hexStringToByteArray(s: String): ByteArray {
    // 用户可以在“编辑蓝牙设备”里直接粘贴 hex；允许冒号/空格/短横线分隔，
    // 但奇数长度或非 hex 字符必须返回空数组而不是抛
    // StringIndexOutOfBoundsException / 写入 -1 nibble。
    val clean = s.trim()
        .replace(":", "")
        .replace(" ", "")
        .replace("-", "")
    if (clean.isEmpty() || clean.length % 2 != 0) return ByteArray(0)
    val data = ByteArray(clean.length / 2)
    var i = 0
    while (i < clean.length) {
        val hi = Character.digit(clean[i], 16)
        val lo = Character.digit(clean[i + 1], 16)
        if (hi < 0 || lo < 0) return ByteArray(0)
        data[i / 2] = ((hi shl 4) + lo).toByte()
        i += 2
    }
    return data
}

    // 辅助函数：MAC 地址标准化（补齐冒号以防底层抛出 IllegalArgumentException）
internal fun normalizeMacAddress(mac: String): String {
        val clean = mac.replace(":", "").replace("-", "").trim().uppercase()
        if (clean.length == 12 && clean.all { it in "0123456789ABCDEF" }) {
            return clean.chunked(2).joinToString(":")
        }
        return mac.trim().uppercase()
    }

    // 检查字节数组是否为合法的 BLE 广播 AD 结构 (TLV 格式: [Length, Type, Value...])
internal fun isValidAdStructure(bytes: ByteArray): Boolean {
        if (bytes.isEmpty()) return false
        var pos = 0
        var foundValidAd = false
        while (pos < bytes.size) {
            val len = bytes[pos].toInt() and 0xFF
            if (len == 0) {
                // BLE 广播包末尾填充 00 是标准行为
                return foundValidAd
            }
            if (pos + 1 + len > bytes.size) {
                return false
            }
            foundValidAd = true
            pos += 1 + len
        }
        return foundValidAd
    }

    // 辅助函数：智能构造并规范化 BLE 广播包字节数组
internal fun buildScanRecordBytes(name: String, hexRecord: String, address: String = ""): ByteArray {
        val cleanHex = hexRecord.replace("0x", "", ignoreCase = true)
            .replace("0X", "")
            .replace(" ", "")
            .replace(":", "")
            .replace("-", "")
            .replace(",", "")
            .replace(";", "")
            .replace("\n", "")
            .replace("\r", "")
            .trim()
            .uppercase()

        var rawPayload: ByteArray? = null

        if (cleanHex.isNotEmpty() && cleanHex.length >= 2) {
            try {
                val validHex = if (cleanHex.length % 2 != 0) cleanHex.substring(0, cleanHex.length - 1) else cleanHex
                val inputBytes = hexStringToByteArray(validHex)

                if (isValidAdStructure(inputBytes)) {
                    // 格式 1: 完整的标准 TLV 结构广播包（例如从系统/抓包工具导出的 0201061AFF...）
                    rawPayload = inputBytes
                } else if (validHex.startsWith("1AFF4C00") || validHex.startsWith("1EFF4C00")) {
                    // 格式 2: 带有长度的厂商数据段，前面缺少 020106 Flags
                    val flags = byteArrayOf(0x02, 0x01, 0x06)
                    rawPayload = flags + inputBytes
                } else if (validHex.startsWith("FF4C00") || validHex.startsWith("FF")) {
                    // 格式 3: 带有 Type(0xFF) 但缺少 Length 的厂商数据段
                    val flags = byteArrayOf(0x02, 0x01, 0x06)
                    val lenByte = byteArrayOf(inputBytes.size.toByte())
                    rawPayload = flags + lenByte + inputBytes
                } else if (validHex.startsWith("4C000215") || validHex.startsWith("004C0215") || validHex.startsWith("4C00")) {
                    // 格式 4: 纯 Apple iBeacon 厂商数据段（从 nRF Connect 等工具复制的 Manufacturer Data）
                    val flags = byteArrayOf(0x02, 0x01, 0x06)
                    val mfrHeader = byteArrayOf((inputBytes.size + 1).toByte(), 0xFF.toByte())
                    rawPayload = flags + mfrHeader + inputBytes
                } else if (validHex.startsWith("0215") && validHex.length >= 46) {
                    // 格式 5: 缺少 Apple 厂商 ID 的 iBeacon 数据（0215 + UUID + Major + Minor + TxPower）
                    val flags = byteArrayOf(0x02, 0x01, 0x06)
                    val mfrHeader = byteArrayOf(0x1A, 0xFF.toByte(), 0x4C, 0x00)
                    rawPayload = flags + mfrHeader + inputBytes
                } else if (validHex.length == 32) {
                    // 格式 6: 纯 16 字节 UUID
                    val flags = byteArrayOf(0x02, 0x01, 0x06)
                    val mfrData = byteArrayOf(
                        0x1A, 0xFF.toByte(), 0x4C, 0x00, 0x02, 0x15
                    ) + inputBytes + byteArrayOf(0x00, 0x01, 0x00, 0x01, 0xC5.toByte())
                    rawPayload = flags + mfrData
                } else {
                    // 格式 7: 其他厂商自定义数据段，自动封装 Flags + 0xFF 结构
                    val flags = byteArrayOf(0x02, 0x01, 0x06)
                    val mfrHeader = byteArrayOf((inputBytes.size + 1).toByte(), 0xFF.toByte())
                    rawPayload = flags + mfrHeader + inputBytes
                }
            } catch (t: Throwable) { HookLog.swallowed("BluetoothScanRecordBuilder.kt:141", t) }
        }

        if (rawPayload != null && rawPayload.isNotEmpty()) {
            return rawPayload
        }

        // 若用户未填写，自动合成标准的 iBeacon 考勤广播包与名称结构
        val flags = byteArrayOf(0x02, 0x01, 0x06)
        val defaultIBeacon = byteArrayOf(
            0x1A, 0xFF.toByte(), 0x4C, 0x00, 0x02, 0x15,
            0xFD.toByte(), 0xA5.toByte(), 0x06, 0x93.toByte(),
            0xA4.toByte(), 0xE2.toByte(), 0x4F, 0xB1.toByte(),
            0xAF.toByte(), 0xCF.toByte(), 0xC6.toByte(), 0xEB.toByte(),
            0x07, 0x64, 0x78, 0x25,
            0x00, 0x01, 0x00, 0x01, 0xC5.toByte()
        )
        var synthetic = flags + defaultIBeacon
        val nameBytes = name.toByteArray(Charsets.UTF_8)
        if (nameBytes.isNotEmpty() && synthetic.size + nameBytes.size + 2 <= 31) {
            val nameAd = byteArrayOf((nameBytes.size + 1).toByte(), 0x09) + nameBytes
            synthetic = synthetic + nameAd
        }

        return synthetic
    }

    // 辅助函数：安全创建 BluetoothDevice
internal fun createBluetoothDevice(cl: ClassLoader, address: String): Any? {
        val cleanAddress = normalizeMacAddress(address)
        val devClass = XposedHelpers.findClassIfExists("android.bluetooth.BluetoothDevice", cl) ?: return null
        
        // 尝试 1: BluetoothAdapter.getDefaultAdapter().getRemoteDevice(address)
        try {
            val adapterClass = XposedHelpers.findClassIfExists("android.bluetooth.BluetoothAdapter", cl)
            if (adapterClass != null) {
                val adapter = XposedHelpers.callStaticMethod(adapterClass, "getDefaultAdapter")
                if (adapter != null) {
                    val dev = XposedHelpers.callMethod(adapter, "getRemoteDevice", cleanAddress)
                    if (dev != null) return dev
                }
            }
        } catch (t: Throwable) { HookLog.swallowed("BluetoothScanRecordBuilder.kt:183", t) }

        // 尝试 2: 显式构造器 BluetoothDevice(String)
        try {
            val ctor = devClass.getDeclaredConstructor(String::class.java)
            ctor.isAccessible = true
            return ctor.newInstance(cleanAddress)
        } catch (t: Throwable) { HookLog.swallowed("BluetoothScanRecordBuilder.kt:190", t) }

        // 尝试 3: 反射所有构造器兜底
        for (c in devClass.declaredConstructors) {
            try {
                if (c.parameterTypes.size == 1 && c.parameterTypes[0] == String::class.java) {
                    c.isAccessible = true
                    return c.newInstance(cleanAddress)
                }
            } catch (t: Throwable) { HookLog.swallowed("BluetoothScanRecordBuilder.kt:199", t) }
        }
        return null
    }

    // 辅助函数：安全创建 ScanResult
internal fun createScanResult(
        cl: ClassLoader,
        device: Any,
        scanRecord: Any?,
        rssi: Int,
        timestampNanos: Long
    ): Any? {
        val scanResultClass = XposedHelpers.findClassIfExists("android.bluetooth.le.ScanResult", cl) ?: return null
        val devClass = XposedHelpers.findClassIfExists("android.bluetooth.BluetoothDevice", cl) ?: return null
        val recordClass = XposedHelpers.findClassIfExists("android.bluetooth.le.ScanRecord", cl)

        var result: Any? = null

        // 尝试 1: 10 参数扩展构造器 (Android 8.0 ~ Android 17 标准)
        // ScanResult(BluetoothDevice, int eventType, int primaryPhy, int secondaryPhy,
        //            int advertisingSid, int txPower, int rssi, int periodicAdvertisingInterval,
        //            ScanRecord, long timestampNanos)
        if (recordClass != null) {
            try {
                val ctor10 = scanResultClass.getDeclaredConstructor(
                    devClass,
                    Int::class.javaPrimitiveType,
                    Int::class.javaPrimitiveType,
                    Int::class.javaPrimitiveType,
                    Int::class.javaPrimitiveType,
                    Int::class.javaPrimitiveType,
                    Int::class.javaPrimitiveType,
                    Int::class.javaPrimitiveType,
                    recordClass,
                    Long::class.javaPrimitiveType
                )
                result = ctor10.newInstance(
                    device,
                    0x001B /* DATA_COMPLETE | ET_CONNECTABLE | ET_SCANNABLE | ET_LEGACY_ADV */,
                    1 /* PHY_LE_1M */,
                    0 /* PHY_UNUSED */,
                    255 /* SID_NOT_PRESENT */,
                    127 /* TX_POWER_NOT_PRESENT */,
                    rssi,
                    0 /* periodicAdvertisingInterval */,
                    scanRecord,
                    timestampNanos
                )
            } catch (t: Throwable) { HookLog.swallowed("BluetoothScanRecordBuilder.kt:300", t) }
        }

        // 尝试 2: 4 参数标准构造器 (ScanResult(BluetoothDevice, ScanRecord, int, long))
        if (result == null && recordClass != null) {
            try {
                val ctor4 = scanResultClass.getDeclaredConstructor(
                    devClass, recordClass, Int::class.javaPrimitiveType, Long::class.javaPrimitiveType
                )
                ctor4.isAccessible = true
                result = ctor4.newInstance(device, scanRecord, rssi, timestampNanos)
            } catch (t: Throwable) { HookLog.swallowed("BluetoothScanRecordBuilder.kt:311", t) }
        }

        // 尝试 3: 遍历所有可用构造器进行自适应匹配
        if (result == null) {
            for (c in scanResultClass.declaredConstructors) {
                try {
                    c.isAccessible = true
                    val args = arrayOfNulls<Any>(c.parameterCount)
                    for (idx in 0 until c.parameterCount) {
                        val pType = c.parameterTypes[idx]
                        when {
                            devClass.isAssignableFrom(pType) -> args[idx] = device
                            recordClass != null && recordClass.isAssignableFrom(pType) -> args[idx] = scanRecord
                            pType == Int::class.javaPrimitiveType || pType == java.lang.Integer::class.java -> {
                                when (idx) {
                                    1 -> args[idx] = 0x001B
                                    2 -> args[idx] = if (c.parameterCount == 4) rssi else 1
                                    3 -> args[idx] = 0
                                    4 -> args[idx] = 255
                                    5 -> args[idx] = 127
                                    6 -> args[idx] = rssi
                                    else -> args[idx] = if (idx == c.parameterCount - 2) rssi else 0
                                }
                            }
                            pType == Long::class.javaPrimitiveType || pType == java.lang.Long::class.java -> args[idx] = timestampNanos
                            pType == Boolean::class.javaPrimitiveType || pType == java.lang.Boolean::class.java -> args[idx] = false
                            else -> args[idx] = null
                        }
                    }
                    result = c.newInstance(*args)
                    if (result != null) break
                } catch (t: Throwable) { HookLog.swallowed("BluetoothScanRecordBuilder.kt:343", t) }
            }
        }

        // 强制通过反射回填内部关键属性，确保跨各系统版本属性 100% 完整与正确
        if (result != null) {
            try { XposedHelpers.setObjectField(result, "mDevice", device) } catch (t: Throwable) { HookLog.swallowed("BluetoothScanRecordBuilder.kt:349", t) }
            try { XposedHelpers.setObjectField(result, "mScanRecord", scanRecord) } catch (t: Throwable) { HookLog.swallowed("BluetoothScanRecordBuilder.kt:350", t) }
            try { XposedHelpers.setIntField(result, "mRssi", rssi) } catch (t: Throwable) { HookLog.swallowed("BluetoothScanRecordBuilder.kt:351", t) }
            try { XposedHelpers.setLongField(result, "mTimestampNanos", timestampNanos) } catch (t: Throwable) { HookLog.swallowed("BluetoothScanRecordBuilder.kt:352", t) }
            try { XposedHelpers.setIntField(result, "mEventType", 0x001B) } catch (t: Throwable) { HookLog.swallowed("BluetoothScanRecordBuilder.kt:353", t) }
            try { XposedHelpers.setIntField(result, "mPrimaryPhy", 1) } catch (t: Throwable) { HookLog.swallowed("BluetoothScanRecordBuilder.kt:354", t) }
            try { XposedHelpers.setIntField(result, "mTxPower", 127) } catch (t: Throwable) { HookLog.swallowed("BluetoothScanRecordBuilder.kt:355", t) }
        }

        return result
    }
