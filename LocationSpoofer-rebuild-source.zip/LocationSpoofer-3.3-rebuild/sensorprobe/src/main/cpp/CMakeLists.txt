cmake_minimum_required(VERSION 3.22.1)
project(sensorprobe CXX)

add_library(sensorprobe SHARED sensorprobe.cpp)

target_compile_features(sensorprobe PRIVATE cxx_std_17)
target_include_directories(sensorprobe PRIVATE ${CMAKE_CURRENT_SOURCE_DIR})
target_link_options(sensorprobe PRIVATE "-Wl,-z,max-page-size=16384")

# ShadowHook：仅用于链接；打包由 AAR 依赖提供，避免重复 jniLibs
add_library(shadowhook SHARED IMPORTED)
set_target_properties(shadowhook PROPERTIES
    IMPORTED_LOCATION ${CMAKE_CURRENT_SOURCE_DIR}/../../../linkLibs/${ANDROID_ABI}/libshadowhook.so)

find_library(log-lib log)
find_library(dl-lib dl)
target_link_libraries(sensorprobe ${log-lib} ${dl-lib} shadowhook)
