# Location Probe

独立定位与传感器诊断工具，包名 `com.vincenthzr.locationprobe`，不依赖 LocationSpoofer，也不参与主 App 打包。

## 功能

在自有设备上采集定位、GNSS、传感器、Wi-Fi、基站、蓝牙、网络、AppOps 和系统诊断信息，输出本地 JSON 供分析。

- 没有 `INTERNET` 权限，不上传数据。
- 无 Root 时采集框架层数据；有 Root 时补充只读的 `dumpsys`、`/proc`、设置等系统信息。
- `analysis.signals` 只是启发式提示，不是结论，需要结合原始数据判断。

## 输出

```text
/sdcard/Android/data/com.vincenthzr.locationprobe/files/probe/location_probe_<timestamp>.json
```

JSON 包含设备、权限、位置、GNSS、传感器、Wi-Fi、基站、蓝牙、网络和系统诊断数据。

## 构建

需要 JDK 21 和 Android SDK：

```bash
./gradlew :locationprobe:assembleDebug
```

APK：

```text
locationprobe/build/outputs/apk/debug/locationprobe-debug.apk
```

## 安装

```bash
adb install -r locationprobe/build/outputs/apk/debug/locationprobe-debug.apk
adb shell am start -n com.vincenthzr.locationprobe/.MainActivity   --ez auto_start true --el duration_ms 60000
```

默认采集 60 秒，界面可选 30/60/120/300 秒，`--el duration_ms` 可覆盖。

## Root 采集

如果 `su` 可用，App 会自动执行只读系统采集。若返回权限错误，可在界面生成 Root 采集脚本，在 Termux 或 ADB root shell 中执行，然后重新开始采集；没有 Root 时框架层数据仍可用。

## 注意

导出的 JSON 可能包含 Wi-Fi BSSID、基站 ID、蓝牙地址和位置记录，只保存在本机，不要公开上传。工具只做只读诊断，不修改系统设置或定位。部分设备不支持 raw GNSS/NMEA，数据缺失不一定是虚拟定位。
