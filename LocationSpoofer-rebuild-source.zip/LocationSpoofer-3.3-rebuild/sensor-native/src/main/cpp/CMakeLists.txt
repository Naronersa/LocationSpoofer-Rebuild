cmake_minimum_required(VERSION 3.22.1)
project(location_accel CXX)

add_library(location_accel SHARED location_accel.cpp)

target_compile_features(location_accel PRIVATE cxx_std_17)
target_include_directories(location_accel PRIVATE ${CMAKE_CURRENT_SOURCE_DIR})
target_link_options(location_accel PRIVATE "-Wl,-z,max-page-size=16384")

# 构建路径脱敏：不要把本机绝对路径写进 __FILE__ / 调试信息。
target_compile_options(location_accel PRIVATE
    "-ffile-prefix-map=${CMAKE_CURRENT_SOURCE_DIR}=."
    "-fdebug-prefix-map=${CMAKE_CURRENT_SOURCE_DIR}=."
    "-fmacro-prefix-map=${CMAKE_CURRENT_SOURCE_DIR}=.")

# AGP 的 release 变体使用 RelWithDebInfo；除 Debug 外都在链接期剥离符号与 DWARF，
# 避免传播构建机路径。
if(NOT CMAKE_BUILD_TYPE STREQUAL "Debug")
    target_link_options(location_accel PRIVATE "-s")
endif()

# ShadowHook：仅用于链接；打包由 AAR 依赖提供，避免重复 jniLibs
add_library(shadowhook SHARED IMPORTED)
set_target_properties(shadowhook PROPERTIES
    IMPORTED_LOCATION ${CMAKE_CURRENT_SOURCE_DIR}/../../../linkLibs/${ANDROID_ABI}/libshadowhook.so)

find_library(log-lib log)
find_library(dl-lib dl)
target_link_libraries(location_accel ${log-lib} ${dl-lib} shadowhook)
