package com.vincenthzr.locationspoofer.ui

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import javax.xml.parsers.DocumentBuilderFactory
import org.w3c.dom.Element

class StringResourceConsistencyTest {

    private val modules = listOf("app-ui", "service")
    private val cjk = Regex("[\\u4e00-\\u9fff]")
    private val placeholder = Regex("%(\\d+\\$)?[-#+0(]*\\d*(\\.\\d+)?([tT])?[a-zA-Z%]")
    private val stringReference = Regex("R\\.string\\.([A-Za-z0-9_]+)")

    @Test
    fun `default and Chinese resources have identical keys`() {
        for (module in modules) {
            val english = strings(module, "values")
            val chinese = strings(module, "values-zh")
            assertEquals("$module only in English: ${english.keys - chinese.keys}", emptySet<String>(), english.keys - chinese.keys)
            assertEquals("$module only in Chinese: ${chinese.keys - english.keys}", emptySet<String>(), chinese.keys - english.keys)
        }
    }

    @Test
    fun `format placeholders match between languages`() {
        for (module in modules) {
            val english = strings(module, "values")
            val chinese = strings(module, "values-zh")
            for ((key, text) in english) {
                assertEquals(
                    "$module/$key placeholder mismatch",
                    placeholders(text),
                    placeholders(chinese.getValue(key)),
                )
            }
        }
    }

    @Test
    fun `English values contain no Chinese characters`() {
        for (module in modules) {
            for ((key, text) in strings(module, "values")) {
                assertFalse("$module/$key: $text", cjk.containsMatchIn(text))
            }
        }
    }

    @Test
    fun `Chinese values are not empty`() {
        for (module in modules) {
            for ((key, text) in strings(module, "values-zh")) {
                assertTrue("$module/$key is empty", text.isNotBlank())
            }
        }
    }

    @Test
    fun `only English and Chinese locale directories are shipped`() {
        for (module in modules) {
            val res = File(projectRoot(), "$module/src/main/res")
            val locales = res.listFiles()
                ?.filter { it.isDirectory && it.name.startsWith("values-") }
                ?.map { it.name }
                ?.toSet()
                ?: emptySet()
            assertEquals("$module locale resources: $locales", setOf("values-zh"), locales)
        }
    }

    @Test
    fun `all R string references are defined`() {
        val defined = modules.flatMap { strings(it, "values").keys }.toSet()
        for (file in sourceFiles()) {
            stringReference.findAll(file.readText()).forEach { match ->
                val key = match.groupValues[1]
                assertTrue("${file.path} references missing R.string.$key", key in defined)
            }
        }
    }

    @Test
    fun `visible UI text does not hardcode Chinese`() {
        val visibleText = listOf(
            Regex("""Text\s*\(\s*"[^"]*[一-鿿]"""),
            Regex("""Toast\.makeText\([^,]+,\s*"[^"]*[一-鿿]"""),
            Regex("""contentDescription\s*=\s*"[^"]*[一-鿿]"""),
        )
        for (file in sourceFiles()) {
            for ((lineNumber, line) in file.readLines().withIndex()) {
                if (line.trimStart().startsWith("//")) continue
                for (pattern in visibleText) {
                    assertFalse(
                        "${file.path}:${lineNumber + 1} hardcodes Chinese UI text: $line",
                        pattern.containsMatchIn(line),
                    )
                }
            }
        }
    }

    private fun sourceFiles(): List<File> =
        listOf(
            "app-ui/src/main/java",
            "service/src/main/java",
            "app/src/main/java",
        ).flatMap { root ->
            File(projectRoot(), root).walkTopDown()
                .filter { it.isFile && (it.extension == "kt" || it.extension == "java") }
                .toList()
        }

    private fun placeholders(text: String): List<String> =
        placeholder.findAll(text)
            .map { it.value }
            .filter { it != "%%" }
            .map { token ->
                val tail = token.takeLast(2)
                if (tail.first() == 't' || tail.first() == 'T') tail else token.last().toString()
            }
            .sorted()
            .toList()

    private fun strings(module: String, locale: String): Map<String, String> {
        val file = File(projectRoot(), "$module/src/main/res/$locale/strings.xml")
        assertTrue("missing $file", file.isFile)
        val document = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(file)
        val nodes = document.getElementsByTagName("string")
        val result = LinkedHashMap<String, String>()
        for (i in 0 until nodes.length) {
            val element = nodes.item(i) as? Element ?: continue
            val name = element.getAttribute("name")
            assertTrue("$file has a string without a name", name.isNotBlank())
            assertFalse("$file has duplicate $name", result.containsKey(name))
            result[name] = element.textContent
        }
        return result
    }

    private fun projectRoot(): File {
        var current: File? = File(System.getProperty("user.dir") ?: ".").absoluteFile
        repeat(8) {
            val dir = current
            if (dir != null) {
                if (File(dir, "app-ui/src/main/res/values/strings.xml").isFile) return dir
                current = dir.parentFile
            }
        }
        error("Cannot locate project root from ${System.getProperty("user.dir")}")
    }
}
