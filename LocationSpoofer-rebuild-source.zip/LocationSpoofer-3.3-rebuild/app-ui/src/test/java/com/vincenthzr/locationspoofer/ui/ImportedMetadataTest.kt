package com.vincenthzr.locationspoofer.ui

import com.vincenthzr.locationspoofer.ui.util.ImportedMetadata
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ImportedMetadataTest {
    @Test
    fun recognizesWiGleNamesInEveryLanguage() {
        assertTrue(ImportedMetadata.isWiGlePlaceName("WiGLE"))
        assertTrue(ImportedMetadata.isWiGlePlaceName("WiGLE 导入"))
        assertTrue(ImportedMetadata.isWiGlePlaceName("WiGLE Import"))
        assertTrue(ImportedMetadata.isWiGlePlaceName("  WiGLE Import  "))
        assertFalse(ImportedMetadata.isWiGlePlaceName("My WiGLE spot"))
    }

    @Test
    fun recognizesOpenCellIdNamesInEveryLanguage() {
        assertTrue(ImportedMetadata.isOpenCellIdPlaceName("OpenCellID"))
        assertTrue(ImportedMetadata.isOpenCellIdPlaceName("OpenCellID 导入"))
        assertTrue(ImportedMetadata.isOpenCellIdPlaceName("OpenCellID Import"))
        assertFalse(ImportedMetadata.isOpenCellIdPlaceName("OpenCellID nearby"))
    }

    @Test
    fun stripsCoordinatePrefixesFromLegacyRemarks() {
        assertEquals(" (26.0, 119.1)", ImportedMetadata.coordinateRemarkSuffix("经纬度: (26.0, 119.1)"))
        assertEquals(" (26.0, 119.1)", ImportedMetadata.coordinateRemarkSuffix("经纬度： (26.0, 119.1)"))
        assertEquals(" (26.0, 119.1)", ImportedMetadata.coordinateRemarkSuffix("Coordinates: (26.0, 119.1)"))
        assertEquals(" (26.0, 119.1)", ImportedMetadata.coordinateRemarkSuffix("Coordinates： (26.0, 119.1)"))
    }

    @Test
    fun leavesUserRemarksUntouched() {
        assertNull(ImportedMetadata.coordinateRemarkSuffix("Home"))
        assertNull(ImportedMetadata.coordinateRemarkSuffix("坐标: 26,119"))
    }
}
