package com.vincenthzr.locationspoofer.ui

import com.vincenthzr.locationspoofer.utils.defaultLanguageForSystem
import com.vincenthzr.locationspoofer.utils.normalizeLanguage
import org.junit.Assert.assertEquals
import org.junit.Test
import java.util.Locale

class LanguageDefaultsTest {
    @Test
    fun simplifiedChineseUsesChinese() {
        assertEquals("zh", defaultLanguageForSystem(Locale.forLanguageTag("zh")))
        assertEquals("zh", defaultLanguageForSystem(Locale.forLanguageTag("zh-CN")))
        assertEquals("zh", defaultLanguageForSystem(Locale.forLanguageTag("zh-Hans")))
        assertEquals("zh", defaultLanguageForSystem(Locale.forLanguageTag("zh-SG")))
        assertEquals("zh", defaultLanguageForSystem(Locale.forLanguageTag("zh-MY")))
    }

    @Test
    fun traditionalChineseUsesEnglish() {
        assertEquals("en", defaultLanguageForSystem(Locale.forLanguageTag("zh-TW")))
        assertEquals("en", defaultLanguageForSystem(Locale.forLanguageTag("zh-HK")))
        assertEquals("en", defaultLanguageForSystem(Locale.forLanguageTag("zh-MO")))
        assertEquals("en", defaultLanguageForSystem(Locale.forLanguageTag("zh-Hant")))
        assertEquals("en", defaultLanguageForSystem(Locale.forLanguageTag("zh-Hant-TW")))
    }

    @Test
    fun everyOtherSystemUsesEnglish() {
        assertEquals("en", defaultLanguageForSystem(Locale.forLanguageTag("en-US")))
        assertEquals("en", defaultLanguageForSystem(Locale.forLanguageTag("fr")))
        assertEquals("en", defaultLanguageForSystem(Locale.forLanguageTag("ja")))
        assertEquals("en", defaultLanguageForSystem(null))
    }

    @Test
    fun savedTagsAreNormalizedWithTheSameRule() {
        assertEquals("zh", normalizeLanguage("zh-CN"))
        assertEquals("en", normalizeLanguage("zh-TW"))
        assertEquals("en", normalizeLanguage("zh-Hant"))
        assertEquals("en", normalizeLanguage("en-US"))
        assertEquals("en", normalizeLanguage(""))
        assertEquals("en", normalizeLanguage(null))
    }
}
