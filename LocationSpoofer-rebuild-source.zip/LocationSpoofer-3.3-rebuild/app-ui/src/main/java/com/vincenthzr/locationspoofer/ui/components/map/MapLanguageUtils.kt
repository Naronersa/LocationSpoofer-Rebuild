package com.vincenthzr.locationspoofer.ui.components.map

import android.content.Context

/** 地图底图注记跟随 App 当前语言；英文=1，其它=中文。 */
internal fun isEnglishMap(context: Context): Boolean {
    val locales = context.resources.configuration.locales
    val language = if (locales.size() > 0) locales[0].language else java.util.Locale.getDefault().language
    return language.equals("en", ignoreCase = true)
}
