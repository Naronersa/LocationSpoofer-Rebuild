package com.vincenthzr.locationspoofer.ui.screen.settings

import android.content.Context
import android.os.Build
import com.vincenthzr.locationspoofer.data.model.HookStatusReport
import com.vincenthzr.locationspoofer.ui.R
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * 普通用户可触发的诊断日志导出。
 *
 * Native（SysSensorNative）和应用侧（SysSensor）日志都在 logcat 里；普通用户
 * 没有 READ_LOGS 权限，所以这里通过 Root 读取，并把 LSPosed 日志尾部、设备信息
 * 和 Hook 运行状态一起打包成 txt，由 SAF 让用户选择保存位置。
 *
 * 不收集地图 Key、账号、位置历史等业务数据。
 */
internal object DiagnosticLogExporter {

    private const val MAX_OUTPUT_CHARS = 2_000_000

    suspend fun collect(
        context: Context,
        reports: Map<String, HookStatusReport?>
    ): String {
        val now = Date()
        val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(now)
        val sb = StringBuilder()
        sb.appendLine(context.getString(R.string.diag_log_title))
        sb.appendLine("time=$stamp")
        appendAppInfo(context, sb)
        sb.appendLine("device=${Build.MANUFACTURER} ${Build.MODEL}")
        sb.appendLine("android=${Build.VERSION.RELEASE} sdk=${Build.VERSION.SDK_INT}")
        sb.appendLine("fingerprint=${Build.FINGERPRINT}")
        sb.appendLine()
        sb.appendLine(context.getString(R.string.diag_log_hook_status))
        appendHookReports(reports, sb)
        sb.appendLine()
        sb.appendLine(context.getString(R.string.diag_log_sys_sensor))
        sb.appendLine(runRoot("logcat -d -v time -s SysSensor | tail -n 1000"))
        sb.appendLine()
        sb.appendLine(context.getString(R.string.diag_log_sys_sensor_native))
        sb.appendLine(runRoot("logcat -d -v time -s SysSensorNative | tail -n 3000"))
        sb.appendLine()
        sb.appendLine(context.getString(R.string.diag_log_lsposed_modules))
        sb.appendLine(
            runRoot(
                "f=\$(ls -t /data/adb/lspd/log/modules_*.log 2>/dev/null | head -1); " +
                    "if [ -n \"\$f\" ]; then tail -n 500 \"\$f\"; else echo '" +
                    context.getString(R.string.diag_log_no_modules) + "'; fi"
            )
        )
        sb.appendLine()
        sb.appendLine(context.getString(R.string.diag_log_lsposed_verbose))
        sb.appendLine(
            runRoot(
                "f=\$(ls -t /data/adb/lspd/log/verbose_*.log 2>/dev/null | head -1); " +
                    "if [ -n \"\$f\" ]; then tail -n 300 \"\$f\"; else echo '" +
                    context.getString(R.string.diag_log_no_verbose) + "'; fi"
            )
        )
        sb.appendLine()
        sb.appendLine(context.getString(R.string.diag_log_end))
        return sb.toString().take(MAX_OUTPUT_CHARS)
    }

    private fun appendAppInfo(context: Context, sb: StringBuilder) {
        runCatching {
            val info = context.packageManager.getPackageInfo(context.packageName, 0)
            val code = if (Build.VERSION.SDK_INT >= 28) {
                info.longVersionCode
            } else {
                @Suppress("DEPRECATION")
                info.versionCode.toLong()
            }
            sb.appendLine("package=${context.packageName}")
            sb.appendLine("versionName=${info.versionName}")
            sb.appendLine("versionCode=$code")
        }.onFailure {
            sb.appendLine("package=${context.packageName}")
            sb.appendLine("versionInfo=unavailable")
        }
    }

    private fun appendHookReports(
        reports: Map<String, HookStatusReport?>,
        sb: StringBuilder
    ) {
        if (reports.isEmpty()) {
            sb.appendLine("(no reports)")
            return
        }
        val boot = bootTimeMs()
        val bootId = currentBootId()
        reports.forEach { (process, report) ->
            sb.appendLine("[process] $process")
            if (report == null) {
                sb.appendLine("report=null")
                return@forEach
            }
            sb.appendLine("updatedAt=${report.updatedAt} stale=${report.isStale(bootId, boot)}")
            sb.appendLine("vendor=${report.vendorId} manual=${report.manualVendor}")
            sb.appendLine("system=${report.system}")
            sb.appendLine("configPath=${report.configPath} configModified=${report.configModified}")
            sb.appendLine("hooked=${report.hookedCount}/${report.components.size}")
            report.errors.forEach { sb.appendLine("error=$it") }
            report.components.forEach { component ->
                val methods = component.methods.entries.joinToString(", ") { "${it.key}x${it.value}" }
                sb.appendLine(
                    "component=${component.name} state=${component.state} " +
                        "found=${component.found} searched=${component.searched} " +
                        "class=${component.className} source=${component.source} " +
                        "methods=[$methods]"
                )
            }
            sb.appendLine()
        }
    }

    private fun runRoot(command: String): String {
        val candidates = listOf(
            arrayOf("su", "-c", command),
            arrayOf("/system/bin/su", "-c", command)
        )
        var lastError: String? = null
        for (argv in candidates) {
            try {
                val process = ProcessBuilder(*argv)
                    .redirectErrorStream(true)
                    .start()
                // readText() 会阻塞到 EOF；放到独立线程，避免 su 等待授权时
                // 把界面/导出协程永久挂住。20 秒后强制结束并返回部分输出。
                val output = StringBuilder()
                val reader = Thread {
                    runCatching {
                        process.inputStream.bufferedReader().use {
                            output.append(it.readText())
                        }
                    }
                }.apply {
                    isDaemon = true
                    start()
                }
                val finished = process.waitFor(20, TimeUnit.SECONDS)
                if (!finished) {
                    process.destroyForcibly()
                    reader.interrupt()
                    lastError = "timeout"
                    continue
                }
                reader.join(1000)
                val text = output.toString()
                if (process.exitValue() == 0 || text.isNotBlank()) {
                    return text.take(MAX_OUTPUT_CHARS)
                }
                lastError = "exit=${process.exitValue()} output=$text"
            } catch (error: Throwable) {
                lastError = "${error.javaClass.simpleName}: ${error.message}"
            }
        }
        return "root command failed: ${lastError ?: "unknown"}\ncommand=$command"
    }
}