package com.vincenthzr.locationspoofer.ui.util

import android.content.Context
import com.vincenthzr.locationspoofer.ui.R

/** 旧版本把导入来源和坐标前缀按当时语言写进了数据库，显示时重新按当前界面语言渲染。 */
internal object ImportedMetadata {
    private val WIGLE_NAMES = setOf("WiGLE", "WiGLE 导入", "WiGLE Import")
    private val OPEN_CELL_ID_NAMES = setOf("OpenCellID", "OpenCellID 导入", "OpenCellID Import")
    private val COORDINATE_PREFIXES = listOf("经纬度:", "经纬度：", "Coordinates:", "Coordinates：")

    fun isWiGlePlaceName(raw: String): Boolean = raw.trim() in WIGLE_NAMES

    fun isOpenCellIdPlaceName(raw: String): Boolean = raw.trim() in OPEN_CELL_ID_NAMES

    /** 返回坐标备注去掉已知前缀后的内容；不是导入生成的坐标备注时返回 null。 */
    fun coordinateRemarkSuffix(raw: String): String? {
        for (prefix in COORDINATE_PREFIXES) {
            if (raw.startsWith(prefix)) return raw.removePrefix(prefix)
        }
        return null
    }

    fun placeName(context: Context, raw: String): String = when {
        isWiGlePlaceName(raw) -> context.getString(R.string.wigle_import)
        isOpenCellIdPlaceName(raw) -> context.getString(R.string.opencellid_import)
        else -> raw
    }

    fun remark(context: Context, raw: String): String {
        val suffix = coordinateRemarkSuffix(raw) ?: return raw
        return context.getString(R.string.lat_lng_format_prefix) + suffix
    }
}
