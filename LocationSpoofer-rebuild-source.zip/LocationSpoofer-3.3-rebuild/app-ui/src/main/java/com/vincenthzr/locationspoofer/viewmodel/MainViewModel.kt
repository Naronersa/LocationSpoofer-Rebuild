package com.vincenthzr.locationspoofer.viewmodel

import android.content.Context
import android.content.res.Resources
import com.vincenthzr.locationspoofer.utils.defaultLanguageForSystem
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.vincenthzr.locationspoofer.data.db.CompleteLocation
import com.vincenthzr.locationspoofer.data.db.EnvironmentDao
import com.vincenthzr.locationspoofer.data.db.LocationRecord
import com.vincenthzr.locationspoofer.data.model.AppState
import com.vincenthzr.locationspoofer.data.model.AppMapType
import com.vincenthzr.locationspoofer.data.model.MapEngine
import com.vincenthzr.locationspoofer.data.model.RootSolution
import com.vincenthzr.locationspoofer.vendor.VendorScheme
import com.vincenthzr.locationspoofer.utils.GaitTemplate
import com.vincenthzr.locationspoofer.data.motion.MotionController
import com.vincenthzr.locationspoofer.data.recording.PhysicalRouteRecorder
import com.vincenthzr.locationspoofer.data.repository.LocationRepository
import com.vincenthzr.locationspoofer.data.repository.SettingsRepository
import com.vincenthzr.locationspoofer.data.repository.WifiRepository
import com.vincenthzr.locationspoofer.data.state.SpoofingState
import com.vincenthzr.locationspoofer.ui.screen.spoofing.SpoofingUiState
import com.vincenthzr.locationspoofer.utils.EnvironmentScanner
import com.vincenthzr.locationspoofer.utils.LSPosedManager
import com.vincenthzr.locationspoofer.utils.OpenCellIdClient
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.stateIn

sealed interface FavoriteToggleResult {
    data class Added(val name: String) : FavoriteToggleResult
    data class Removed(val name: String) : FavoriteToggleResult
    data object Failed : FavoriteToggleResult
}

class MainViewModel(
    internal val locationRepository: LocationRepository,
    internal val settingsRepository: SettingsRepository,
    internal val lsposedManager: LSPosedManager,
    internal val environmentScanner: EnvironmentScanner,
    internal val environmentDao: EnvironmentDao,
    internal val wifiRepository: WifiRepository,
    internal val opencellidClient: OpenCellIdClient,
    internal val motionController: MotionController,
    internal val physicalRouteRecorder: PhysicalRouteRecorder,
    internal val context: Context
) : ViewModel() {
    internal var lastMapMoveTime = 0L
    internal var mapMoveJob: Job? = null
    /** 地图选点后真正写配置的协程；Stop 时必须取消，避免迟到的 updateConfig 把 active 写回。 */
    internal var mapConfirmJob: Job? = null
    /** 定点模拟启动协程及其代次；Stop 后旧协程不得再发布 active=true。 */
    internal var spoofingStartJob: Job? = null
    internal var spoofingStartGeneration = 0L
    internal var gaitRecordingJob: Job? = null
    internal var mockCapabilitiesJob: Job? = null
    internal var environmentUpdateJob: Job? = null
    internal var routeEnvironmentPrefetchJob: Job? = null
    /** 第一阶段的起点静态模拟；第二阶段开始前 join 它，避免配置被覆盖 */
    internal var routePreviewJob: Job? = null
    /** 第二阶段路线启动；停止时必须取消，避免在途的 startSpoofing 又把 active 写回 */
    internal var routeMotionJob: Job? = null
    internal val routeEnvironmentReplay = RouteEnvironmentReplay()

    val collectionRoutes = environmentDao.observeCollectionRoutes().distinctUntilChanged()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val environmentLocations: StateFlow<List<CompleteLocation>> = environmentDao
        .observeAllCompleteLocations()
        .distinctUntilChanged()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    init {
        // 首次启动按系统语言自动选择：中文系统用中文，其它语言一律英文。
        // 仍可在「信息 → 语言」中手动切换。
        if (settingsRepository.shouldShowLanguageSelection() || settingsRepository.getLanguage().isBlank()) {
            val locales = Resources.getSystem().configuration.locales
            val systemLocale = if (locales.size() > 0) locales[0] else java.util.Locale.getDefault()
            settingsRepository.setLanguage(defaultLanguageForSystem(systemLocale))
            settingsRepository.setLanguageSet(true)
        }
    }

    internal val _uiState = MutableStateFlow(
        AppState(
            mapType = try {
                AppMapType.valueOf(settingsRepository.getMapType())
            } catch (e: Exception) {
                AppMapType.NORMAL
            },
            mapEngine = try {
                MapEngine.valueOf(settingsRepository.getMapEngine())
            } catch (e: Exception) {
                MapEngine.AUTO
            },
            rootSolution = try {
                RootSolution.valueOf(settingsRepository.getRootSolution())
            } catch (e: Exception) {
                RootSolution.AUTO
            },
            vendorScheme = VendorScheme.fromId(settingsRepository.getVendorOverride()),
            debugDumpSystemServices = settingsRepository.debugDumpSystemServices,
            realismLevel = settingsRepository.realismLevel,
            speedFluctuationPct = settingsRepository.speedFluctuationPct,
            barometerFluctuation = settingsRepository.barometerFluctuation,
            compassSimulationEnabled = settingsRepository.compassSimulationEnabled,
            fixedJoystickEnabled = settingsRepository.fixedJoystickEnabled,
            routeLateralDeviation = settingsRepository.routeLateralDeviation,
            gaitTemplateCadence = GaitTemplate.decode(settingsRepository.gaitTemplate)?.cadenceSpm,
            gaitTemplateStrides = GaitTemplate.decode(settingsRepository.gaitTemplate)?.strideCount ?: 0,
            useGaitTemplate = settingsRepository.useGaitTemplate,
            keepLastMapPosition = settingsRepository.keepLastMapPosition,
            savedLocations = settingsRepository.getSavedLocations(),
            savedRoutes = emptyList(), // 将由 Room Flow 填充
            currentLanguage = settingsRepository.getLanguage(),
            isLanguageSet = !settingsRepository.shouldShowLanguageSelection(),
            systemHookPackages = settingsRepository.getSystemHookPackages(),
            isSystemHookGlobalMode = settingsRepository.isSystemHookGlobalMode,
            forceLocationEnabled = settingsRepository.forceLocationEnabled,
            mockWifi = settingsRepository.mockWifi,
            mockCell = settingsRepository.mockCell,
            mockBluetooth = settingsRepository.mockBluetooth,
            enableJitter = settingsRepository.enableJitter,
            restartAppsOnSpoof = settingsRepository.restartAppsOnSpoof,
            altitudeInput = settingsRepository.altitude,
            altitudeVariationM = settingsRepository.altitudeVariationM,
            satelliteCountInput = settingsRepository.satelliteCount,
            wigleToken = settingsRepository.getWigleApiToken(),
            opencellidToken = settingsRepository.getOpencellidApiToken()
        )
    )
    val uiState: StateFlow<AppState> = _uiState.asStateFlow()

    internal val _spoofingUiState =
        MutableStateFlow(SpoofingUiState())
    val spoofingUiState: StateFlow<SpoofingUiState> =
        _spoofingUiState.asStateFlow()

    internal var locationSyncJob: Job? = null
    internal var continuousScanJob: Job? = null

    init {
        initialize()
    }

    data class ClusterData(
        val center: LocationRecord,
        var count: Int,
        var hasWifi: Boolean,
        var hasBluetooth: Boolean,
        var hasCell: Boolean
    )

    internal var pinnedLocationRecordId: Long? = null

    internal val favoriteToggleMutex = kotlinx.coroutines.sync.Mutex()

    internal var lastEnvironmentRouteId: Long? = null
    internal var lastDbQueryLat: Double = 0.0
    internal var lastDbQueryLng: Double = 0.0
}
