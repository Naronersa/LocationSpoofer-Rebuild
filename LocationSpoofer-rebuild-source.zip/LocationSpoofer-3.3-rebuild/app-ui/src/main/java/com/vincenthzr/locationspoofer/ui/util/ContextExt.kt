package com.vincenthzr.locationspoofer.ui.util

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper

/** 解析 Compose 包装过的 Context，用于语言切换后重建 Activity。 */
internal fun Context.findActivity(): Activity? {
    var current: Context = this
    while (current is ContextWrapper) {
        if (current is Activity) return current
        current = current.baseContext
    }
    return null
}
