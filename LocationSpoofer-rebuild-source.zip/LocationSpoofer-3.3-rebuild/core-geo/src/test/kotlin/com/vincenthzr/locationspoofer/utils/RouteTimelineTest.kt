package com.vincenthzr.locationspoofer.utils

import com.vincenthzr.locationspoofer.utils.CoordinateUtils.LatLng
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RouteTimelineTest {

    private val start = LatLng(30.0, 120.0)
    private val mid = GeoMath.destination(start, 0.0, 100.0)
    private val end = GeoMath.destination(start, 0.0, 1000.0)
    private val session = MotionRealism.Session(1L, MotionRealism.Level.OFF, 0)

    private fun timeline(waitSec: Double = 15.0): RouteTimeline =
        RouteTimeline(RoutePath(listOf(start, mid, end)), listOf(0.0, waitSec, 0.0))

    @Test
    fun `route waits at a traffic light before continuing`() {
        val timeline = timeline()

        val before = timeline.progress(49.0, 0.0, 2.0, session)
        assertFalse(before.waiting)
        assertEquals(98.0, before.traveled, 0.05)

        val arrived = timeline.progress(50.0, 0.0, 2.0, session)
        assertTrue(arrived.waiting)
        assertEquals(100.0, arrived.traveled, 0.05)

        val stillWaiting = timeline.progress(60.0, 0.0, 2.0, session)
        assertTrue(stillWaiting.waiting)
        assertEquals(100.0, stillWaiting.traveled, 0.05)

        val departed = timeline.progress(70.0, 0.0, 2.0, session)
        assertFalse(departed.waiting)
        assertEquals(110.0, departed.traveled, 0.05)
    }

    @Test
    fun `wait offset is subtracted from the moving clock`() {
        val timeline = timeline()
        val afterWait = timeline.progress(65.01, 0.0, 2.0, session)
        assertFalse(afterWait.waiting)
        assertEquals(50.0, afterWait.movingSec, 0.05)
        assertEquals(100.0, afterWait.traveled, 0.05)
    }

    @Test
    fun `an open route waits on both the outbound and return pass`() {
        val end200 = GeoMath.destination(start, 0.0, 200.0)
        val timeline = RouteTimeline(RoutePath(listOf(start, mid, end200)), listOf(0.0, 15.0, 0.0))
        // 200m 单程；100m 处在去程 50s 到达并等待，回程再次经过时也要等待。
        val returnArrival = timeline.progress(165.01, 0.0, 2.0, session)
        assertTrue(returnArrival.waiting)
        assertEquals(300.0, returnArrival.traveled, 0.05)

        val afterReturnWait = timeline.progress(180.01, 0.0, 2.0, session)
        assertFalse(afterReturnWait.waiting)
        assertEquals(300.0, afterReturnWait.traveled, 0.05)
        assertEquals(150.0, afterReturnWait.movingSec, 0.05)
    }

    @Test
    fun `a closed loop waits again on the next lap`() {
        val loop = RouteTimeline(
            RoutePath(listOf(start, mid, start)),
            listOf(0.0, 10.0, 0.0),
        )
        // 周长 200m（去 100m 再折回），速度 2m/s：第一次到 100m 是 50s，等 10s；
        // 下一圈到 100m 是 160s。
        assertTrue(loop.progress(55.0, 0.0, 2.0, session).waiting)
        assertEquals(100.0, loop.progress(55.0, 0.0, 2.0, session).traveled, 0.05)
        assertTrue(loop.progress(160.01, 0.0, 2.0, session).waiting)
        assertEquals(300.0, loop.progress(160.01, 0.0, 2.0, session).traveled, 0.05)
    }

    @Test
    fun `an endpoint wait happens at the turnaround`() {
        val end200 = GeoMath.destination(start, 0.0, 200.0)
        val timeline = RouteTimeline(RoutePath(listOf(start, end200)), listOf(0.0, 15.0))
        val waiting = timeline.progress(101.0, 0.0, 2.0, session)
        assertTrue(waiting.waiting)
        assertEquals(200.0, waiting.traveled, 0.05)

        val after = timeline.progress(116.01, 0.0, 2.0, session)
        assertFalse(after.waiting)
        assertEquals(202.02, after.traveled, 0.05)
        assertEquals(101.01, after.movingSec, 0.05)
    }

    @Test
    fun `no waits keeps the old constant-speed path`() {
        val timeline = timeline(0.0)
        val progress = timeline.progress(30.0, 20.0, 2.0, session)
        assertFalse(progress.waiting)
        assertEquals(80.0, progress.traveled, 0.01)
        assertEquals(30.0, progress.movingSec, 0.01)
    }

    @Test
    fun `a wait point already passed at the start is not applied twice`() {
        val timeline = timeline()
        // 从 100m 处继续：起点就是等待点，不应再停一次。
        val progress = timeline.progress(10.0, 100.0, 2.0, session)
        assertFalse(progress.waiting)
        assertEquals(120.0, progress.traveled, 0.05)
    }
}
