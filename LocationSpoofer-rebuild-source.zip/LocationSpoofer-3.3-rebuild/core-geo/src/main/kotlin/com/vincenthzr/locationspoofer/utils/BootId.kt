package com.vincenthzr.locationspoofer.utils

import java.io.File

/** 当前内核启动实例的稳定标识；读不到时返回空串，调用方退回墙钟。 */
object BootId {
    val current: String by lazy {
        runCatching {
            File("/proc/sys/kernel/random/boot_id").readText().trim()
        }.getOrDefault("")
    }
}
