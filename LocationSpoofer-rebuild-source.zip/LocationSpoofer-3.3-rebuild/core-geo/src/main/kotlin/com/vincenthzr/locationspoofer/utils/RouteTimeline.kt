package com.vincenthzr.locationspoofer.utils

/** 把真实时间换算为带 waitSec 红绿灯等待的路线进度，App 与 Xposed 共用。 */
class RouteTimeline(
    val path: RoutePath,
    waits: List<Double>,
) {

    data class Progress(
        val traveled: Double,
        val movingSec: Double,
        val waiting: Boolean,
    )

    private data class Event(val distance: Double, val waitSec: Double)

    private val total = path.totalDistance
    private val cycle = if (path.isClosedLoop) total else total * 2.0
    private val events: List<Event>

    init {
        val cumulative = DoubleArray(path.points.size)
        for (i in 1 until path.points.size) {
            cumulative[i] = cumulative[i - 1] + GeoMath.distance(path.points[i - 1], path.points[i])
        }
        val list = ArrayList<Event>()
        if (path.points.size >= 2 && total > 0.0) {
            for (i in 1 until path.points.size - 1) {
                val wait = waits.getOrElse(i) { 0.0 }.coerceIn(0.0, MAX_WAIT_SEC)
                if (wait <= 0.0) continue
                list += Event(cumulative[i], wait)
                if (!path.isClosedLoop) {
                    list += Event(total * 2.0 - cumulative[i], wait)
                }
            }
            val firstWait = waits.getOrElse(0) { 0.0 }.coerceIn(0.0, MAX_WAIT_SEC)
            val lastWait = waits.getOrElse(path.points.size - 1) { 0.0 }
                .coerceIn(0.0, MAX_WAIT_SEC)
            if (path.isClosedLoop) {
                val seamWait = maxOf(firstWait, lastWait)
                if (seamWait > 0.0) list += Event(0.0, seamWait)
            } else {
                if (firstWait > 0.0) list += Event(0.0, firstWait)
                if (lastWait > 0.0) list += Event(total, lastWait)
            }
        }
        events = list.sortedBy { it.distance }
    }

    fun progress(
        elapsedSec: Double,
        startDistance: Double,
        baseSpeed: Double,
        session: MotionRealism.Session,
    ): Progress {
        val elapsed = elapsedSec.coerceAtLeast(0.0)
        val start = startDistance.coerceAtLeast(0.0)
        if (!path.isValid || cycle <= 0.0 || elapsed <= 0.0 || baseSpeed <= 0.0) {
            return Progress(
                traveled = start,
                movingSec = 0.0,
                waiting = false,
            )
        }

        val startPhase = start % cycle
        var waitBefore = 0.0
        var lap = 0
        var eventIndex = events.indexOfFirst { it.distance > startPhase + EPS }
        if (eventIndex < 0) {
            eventIndex = 0
            lap = 1
        }

        var processed = 0
        while (processed++ < MAX_EVENTS) {
            if (events.isEmpty()) break
            if (eventIndex >= events.size) {
                eventIndex = 0
                lap++
            }
            val event = events[eventIndex++]
            val eventDistance = lap * cycle + (event.distance - startPhase)

            val movingBudget = elapsed - waitBefore
            if (movingBudget <= 0.0) {
                return Progress(start, 0.0, waiting = false)
            }
            val reachable = session.distance(baseSpeed, movingBudget)
            if (eventDistance > reachable + EVENT_EPS) {
                return Progress(
                    traveled = start + reachable,
                    movingSec = movingBudget,
                    waiting = false,
                )
            }

            val arriveSec = inverseDistance(session, baseSpeed, eventDistance, movingBudget)
            val arrival = waitBefore + arriveSec
            if (elapsed < arrival + event.waitSec) {
                return Progress(
                    traveled = start + eventDistance,
                    movingSec = arriveSec,
                    waiting = elapsed >= arrival,
                )
            }
            waitBefore += event.waitSec
        }

        val movingBudget = (elapsed - waitBefore).coerceAtLeast(0.0)
        return Progress(
            traveled = start + session.distance(baseSpeed, movingBudget),
            movingSec = movingBudget,
            waiting = false,
        )
    }

    private fun inverseDistance(
        session: MotionRealism.Session,
        baseSpeed: Double,
        targetDistance: Double,
        maxMovingSec: Double,
    ): Double {
        if (targetDistance <= 0.0) return 0.0
        var lo = 0.0
        var hi = maxMovingSec
        repeat(32) {
            val mid = (lo + hi) / 2.0
            if (session.distance(baseSpeed, mid) < targetDistance) lo = mid else hi = mid
        }
        return hi
    }

    private companion object {
        const val MAX_WAIT_SEC = 600.0
        const val MAX_EVENTS = 20_000
        const val EPS = 1e-9
        const val EVENT_EPS = 1e-6
    }
}
