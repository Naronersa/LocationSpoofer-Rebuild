package com.vincenthzr.locationspoofer.utils

import android.content.Context
import android.content.res.Configuration
import android.os.LocaleList
import java.util.Locale

/** 只有简体中文自动使用中文；繁体中文和其它所有语言一律英文。 */
fun defaultLanguageForSystem(locale: Locale?): String {
    if (locale == null) return "en"
    if (!locale.language.equals("zh", ignoreCase = true)) return "en"
    val script = locale.script
    val country = locale.country
    return when {
        script.equals("Hant", ignoreCase = true) -> "en"
        script.equals("Hans", ignoreCase = true) -> "zh"
        country.equals("TW", ignoreCase = true) ||
            country.equals("HK", ignoreCase = true) ||
            country.equals("MO", ignoreCase = true) -> "en"
        else -> "zh"
    }
}

/** 把保存的语言标签归一到 en/zh；zh-TW、zh-Hant 等繁体标签归一到 en。 */
fun normalizeLanguage(language: String?): String {
    if (language.isNullOrBlank()) return "en"
    return defaultLanguageForSystem(Locale.forLanguageTag(language))
}

class LocaleUtils {
    companion object {
        fun wrap(context: Context, language: String): Context {
            // 应用只支持简体中文和英文：空语言按系统语言判定，
            // 繁体中文（zh-TW/zh-HK/zh-Hant 等）与其它语言统一落到英文。
            val normalized = if (language.isBlank()) {
                val systemLocale = Configuration(context.resources.configuration).locales[0]
                    ?: Locale.getDefault()
                defaultLanguageForSystem(systemLocale)
            } else {
                normalizeLanguage(language)
            }
            val locale = Locale.forLanguageTag(normalized)

            Locale.setDefault(locale)

            val resources = context.resources
            val configuration = Configuration(resources.configuration)

            configuration.setLocale(locale)
            val localeList = LocaleList(locale)
            configuration.setLocales(localeList)
            configuration.setLayoutDirection(locale)

            return context.createConfigurationContext(configuration)
        }
    }
}
