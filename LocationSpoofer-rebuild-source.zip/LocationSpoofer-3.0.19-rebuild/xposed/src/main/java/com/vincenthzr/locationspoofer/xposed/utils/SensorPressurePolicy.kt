package com.vincenthzr.locationspoofer.xposed.utils

import org.json.JSONObject
import kotlin.math.PI
import kotlin.math.pow
import kotlin.math.sin

/**
 * 官方 3.0.12 的气压计策略（从发布版 SensorPressurePolicy 反编译结果移植）：
 * 把 TYPE_PRESSURE 事件的第一个值改写为"模拟海拔对应的标准大气压 + 缓慢小幅波动"。
 * 仅在 config.active && barometer_fluctuation 时生效；事件时间戳离当前过远时不动真实值。
 */
object SensorPressurePolicy {

    fun apply(
        values: FloatArray,
        timestampNanos: Long,
        config: JSONObject?,
        nowMillis: Long,
        nowNanos: Long
    ): Boolean {
        val cfg = config ?: return false
        if (!enabled(cfg) || values.isEmpty()) return false
        val eventNanos = if (timestampNanos > 0L) timestampNanos else nowNanos
        if (eventNanos > nowNanos + 100_000_000L) return false
        if (nowNanos - eventNanos > 1_500_000_000L) return false

        val altitude = RouteEngine.realisticAltitude(
            cfg,
            nowMillis + (eventNanos - nowNanos) / 1_000_000L
        )
        if (altitude.isNaN() || altitude.isInfinite()) return false

        val clamped = altitude.coerceIn(-500.0, 10_000.0)
        val seaLevel = cfg.optDouble("barometer_sea_level_hpa", 1013.25)
            .coerceIn(800.0, 1100.0)
        val pressureHpa =
            (1.0 - clamped / 44330.0).pow(5.2550001983762575) * seaLevel
        val phase = (eventNanos.coerceAtLeast(0L) / 1.0E9) * 2.0 * PI
        val wave =
            (sin(phase / 131.0 + 0.9) * 0.3 + sin(phase / 43.0) * 0.7) * 0.3
        // 与 native pressureNowLocked 对齐的天气/QNH 慢漂移。
        val weather =
            sin(phase / 1200.0 + 0.7) * 0.25 + sin(phase / 420.0 + 1.9) * 0.15
        values[0] = (wave + weather + pressureHpa).toFloat()
        return true
    }

    fun enabled(config: JSONObject?): Boolean =
        config != null &&
            config.optBoolean("active", false) &&
            config.optBoolean("barometer_fluctuation", false)
}
