package com.vincenthzr.locationspoofer.xposed.utils

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * 与 global native 层一致的 6DoF 步态姿态模型（scoped 版本）。
 *
 * 步态只在“屏幕朝上、Z 轴向上”的 canonical 坐标中生成线加速度；
 * 这里再叠加跑步时的俯仰/横滚和轻微航向摆动，并把重力/线加速度旋转到身体坐标。
 * 纯函数，便于单元测试，也不依赖 Android。
 */
data class GaitAttitude(
    val yawMagneticRad: Double = 0.0,
    val pitchRad: Double = 0.0,
    val rollRad: Double = 0.0,
    val pitchRateRad: Double = 0.0,
    val rollRateRad: Double = 0.0,
    val yawRateRad: Double = 0.0,
)

object SensorAccelTypes {
    const val ACCELEROMETER = 1
    const val GRAVITY = 9
    const val LINEAR_ACCELERATION = 10
    const val ACCELEROMETER_UNCALIBRATED = 35

    fun isFamily(type: Int?): Boolean =
        type == ACCELEROMETER || type == GRAVITY ||
            type == LINEAR_ACCELERATION || type == ACCELEROMETER_UNCALIBRATED
}

object SensorAttitudePolicy {

    private const val GRAVITY = 9.80665

    fun compute(
        stepsFloat: Double,
        speedMps: Double,
        cadenceSpm: Int,
        trueHeadingDeg: Double,
        declinationDeg: Double,
        yawRateRad: Double,
        realismLevel: Int,
    ): GaitAttitude {
        val magnetic = wrap360(trueHeadingDeg - declinationDeg) * PI / 180.0
        if (!stepsFloat.isFinite() || !speedMps.isFinite() || speedMps <= 0.05) {
            return GaitAttitude(yawMagneticRad = magnetic)
        }
        val realism = (realismLevel.coerceIn(0, 3)) / 3.0
        val running = if (speedMps >= 2.2) 1.0 else 0.55
        val phase = 2.0 * PI * stepsFloat
        val cadence = cadenceSpm.coerceIn(60, 240)
        val omega = 2.0 * PI * cadence / 60.0

        val pitchAmp = running * (2.2 + 1.0 * realism) * PI / 180.0
        val rollAmp = running * (1.7 + 0.9 * realism) * PI / 180.0
        val yawSwayAmp = running * 0.45 * PI / 180.0
        // 直线段也不能让指南针完全静止：0.5–1° 多频手持扰动。
        val yawJitterAmp = (running * 0.55 + 0.15) * PI / 180.0
        val jitterPhase1 = phase * 0.5 + 1.1
        val jitterPhase2 = phase * 1.7 + 0.4
        val yawJitter = yawJitterAmp * (
            0.6 * sin(jitterPhase1) + 0.4 * sin(jitterPhase2)
        )
        val yawJitterRate = yawJitterAmp * (
            0.6 * 0.5 * omega * cos(jitterPhase1) +
                0.4 * 1.7 * omega * cos(jitterPhase2)
        )
        val pitch = pitchAmp * sin(phase)
        val roll = rollAmp * sin(phase * 0.5 + 0.6)
        return GaitAttitude(
            yawMagneticRad = magnetic + yawSwayAmp * sin(phase * 0.5) + yawJitter,
            pitchRad = pitch,
            rollRad = roll,
            pitchRateRad = pitchAmp * omega * cos(phase),
            rollRateRad = rollAmp * (omega * 0.5) * cos(phase * 0.5 + 0.6),
            yawRateRad = yawRateRad +
                yawSwayAmp * (omega * 0.5) * cos(phase * 0.5) + yawJitterRate,
        )
    }

    /** 世界/导航坐标 -> 身体坐标：Ry(-roll) * Rx(pitch)，与 quaternion 严格对应。 */
    fun rotateTilt(
        x: Double, y: Double, z: Double,
        pitchRad: Double, rollRad: Double,
    ): FloatArray {
        val cp = cos(pitchRad)
        val sp = sin(pitchRad)
        val cr = cos(rollRad)
        val sr = sin(rollRad)
        val y1 = y * cp - z * sp
        val z1 = y * sp + z * cp
        return floatArrayOf(
            (x * cr - z1 * sr).toFloat(),
            y1.toFloat(),
            (x * sr + z1 * cr).toFloat(),
        )
    }

    fun gravityBody(pitchRad: Double, rollRad: Double): FloatArray =
        rotateTilt(0.0, 0.0, GRAVITY, pitchRad, rollRad)

    /**
     * 与 Android SensorManager.getOrientation 的顺序一致：
     * q = qz(-yaw) * qx(-pitch) * qy(roll)。因此 q 反算出的
     * azimuth/pitch/roll 与本函数的参数一致，且 q 的 R^T 与 rotateTilt 一致。
     */
    fun quaternion(yawRad: Double, pitchRad: Double, rollRad: Double): FloatArray {
        // Android rotation vector 的 yaw 符号：heading 增大时 z 为负。
        val cy = cos(-yawRad * 0.5)
        val sy = sin(-yawRad * 0.5)
        val cp = cos(pitchRad * 0.5)
        val sp = sin(-pitchRad * 0.5)
        val cr = cos(rollRad * 0.5)
        val sr = sin(rollRad * 0.5)
        return floatArrayOf(
            (sp * cr * cy - cp * sr * sy).toFloat(),
            (cp * sr * cy + sp * cr * sy).toFloat(),
            (sp * sr * cy + cp * cr * sy).toFloat(),
            (cp * cr * cy - sp * sr * sy).toFloat(),
        )
    }

    /**
     * 由同一姿态在 t 与 t-dt 的四元数差分求身体角速度（rad/s）。
     * 结果与 orientation/gravity/magnetic 使用同一个 q，不再额外叠加独立抖动。
     */
    fun angularVelocity(
        yawRad: Double,
        pitchRad: Double,
        rollRad: Double,
        yawRateRad: Double,
        pitchRateRad: Double,
        rollRateRad: Double,
        dtSec: Double = 0.01,
    ): FloatArray {
        val dt = dtSec.coerceAtLeast(0.0001)
        val q = quaternion(yawRad, pitchRad, rollRad)
        var qPrev = quaternion(
            yawRad - yawRateRad * dt,
            pitchRad - pitchRateRad * dt,
            rollRad - rollRateRad * dt,
        )
        // q 与 -q 等价；跨越 180° 时先对齐符号，避免导数尖峰。
        if (q[0] * qPrev[0] + q[1] * qPrev[1] +
            q[2] * qPrev[2] + q[3] * qPrev[3] < 0f
        ) {
            qPrev = FloatArray(4) { -qPrev[it] }
        }
        val qd = floatArrayOf(
            ((q[0] - qPrev[0]) / dt).toFloat(),
            ((q[1] - qPrev[1]) / dt).toFloat(),
            ((q[2] - qPrev[2]) / dt).toFloat(),
            ((q[3] - qPrev[3]) / dt).toFloat(),
        )
        val qInv = floatArrayOf(-q[0], -q[1], -q[2], q[3])
        val w = qmul(qInv, qd)
        return floatArrayOf(2f * w[0], 2f * w[1], 2f * w[2])
    }

    private fun qmul(a: FloatArray, b: FloatArray): FloatArray = floatArrayOf(
        a[3] * b[0] + a[0] * b[3] + a[1] * b[2] - a[2] * b[1],
        a[3] * b[1] - a[0] * b[2] + a[1] * b[3] + a[2] * b[0],
        a[3] * b[2] + a[0] * b[1] - a[1] * b[0] + a[2] * b[3],
        a[3] * b[3] - a[0] * b[0] - a[1] * b[1] - a[2] * b[2],
    )

    private fun wrap360(deg: Double): Double {
        var v = deg % 360.0
        if (v < 0) v += 360.0
        return v
    }
}
