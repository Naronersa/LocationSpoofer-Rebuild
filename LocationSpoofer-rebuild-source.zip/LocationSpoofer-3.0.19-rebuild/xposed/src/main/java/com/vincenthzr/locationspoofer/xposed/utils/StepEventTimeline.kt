@file:Suppress("unused")

package com.vincenthzr.locationspoofer.xposed.utils

import kotlin.math.floor
import kotlin.math.max

/**
 * 把"累计步数从 prev 到 now"之间的每一个整数步展开成独立的 STEP_DETECTOR 时间戳。
 *
 * 官方 3.0.19 的做法：按步数占比在两次采样之间线性插值，从 max(floor(prev)+1,
 * floor(now)-8) 到 floor(now)（闭区间，最多 9 个），并丢弃早于 2 秒的时间戳。
 * 这样即使轮询间隔抖动，步检测事件也是逐拍、连续的。
 */
class StepEventTimeline {

    private var previousSteps: Double? = null
    private var previousNanos: Long = 0L

    @Synchronized
    fun sample(steps: Double, nowNanos: Long): LongArray {
        val prev = previousSteps
        if (prev != null && nowNanos <= previousNanos) return LongArray(0)

        val prevNanos = previousNanos
        previousSteps = steps
        previousNanos = nowNanos

        if (prev == null || steps <= prev) return LongArray(0)

        val first = floor(prev).toLong() + 1
        val last = floor(steps).toLong()
        val cutoff = nowNanos - 2_000_000_000L
        val out = ArrayList<Long>(8)
        var step = max(first, last - 8)
        while (step <= last) {
            val ratio = (step - prev) / (steps - prev)
            val timestamp = prevNanos + (ratio * (nowNanos - prevNanos)).toLong()
            if (timestamp >= cutoff) out.add(timestamp)
            step++
        }
        return out.toLongArray()
    }
}
