package com.vincenthzr.locationspoofer.xposed.hooks

import org.json.JSONObject

/**
 * 所有被 Hook 的 Location 对象共享的 GNSS 元数据。
 *
 * 之前 SystemHookUtils 固定写 `satellites=20/used=18`，而 NMEA/GnssStatus 已经动态变化；
 * 部分运动 App 会把这种不一致当成“GPS 质量异常”。这里由 system_server 和 App 进程
 * 的配置读取处更新，所有 Location/Bundle 统一使用同一组值。
 */
internal object FakeLocationMetadata {

    @Volatile
    var satellitesInView: Int = 20
        private set

    @Volatile
    var satellitesUsed: Int = 18
        private set

    @Volatile
    var active: Boolean = false
        private set

    /** 运动类 App 更希望看到 GPS provider；统一 provider 也避免 network/gps 两套回调交替。 */
    @Volatile
    var provider: String = "gps"
        private set

    @Volatile
    private var lastUpdateMs: Long = 0L

    fun update(config: JSONObject?, nowMs: Long, force: Boolean = false) {
        if (config == null || !config.optBoolean("active", false)) {
            active = false
            return
        }
        if (!force && nowMs - lastUpdateMs in 0..500L) return
        lastUpdateMs = nowMs
        val count = config.optInt("satellite_count", 20).coerceIn(4, 32)
        satellitesInView = count
        satellitesUsed = GnssFastMockEngine.usedSatelliteCount(
            count,
            nowMs,
            config.optBoolean("enable_jitter", true)
        ).coerceIn(4, count)
        provider = "gps"
        active = true
    }

    /** 给没有配置上下文的 Hook 一个保守但可用的值。 */
    fun usedForView(viewCount: Int): Int =
        if (active) satellitesUsed.coerceIn(0, viewCount)
        else (viewCount - 2).coerceAtLeast(4)
}
