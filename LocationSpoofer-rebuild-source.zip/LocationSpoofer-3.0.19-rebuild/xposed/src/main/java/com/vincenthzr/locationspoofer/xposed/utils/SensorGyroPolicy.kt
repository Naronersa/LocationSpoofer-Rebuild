package com.vincenthzr.locationspoofer.xposed.utils

/**
 * 陀螺仪类型常量（不依赖 android.hardware.Sensor，便于 JVM 测试）。
 */
object SensorGyroTypes {
    const val GYROSCOPE = 4
    const val GYROSCOPE_UNCALIBRATED = 16

    fun isGyro(type: Int?): Boolean =
        type == GYROSCOPE || type == GYROSCOPE_UNCALIBRATED
}

/**
 * 把 [com.vincenthzr.locationspoofer.utils.GyroMotion] 的采样写入传感器值。
 * 纯函数，可重复执行；未校准陀螺仪的 bias 置 0。
 */
object SensorGyroPolicy {

    fun render(type: Int, values: FloatArray, sample: FloatArray): Boolean {
        if (values.size < 3 || sample.size < 3) return false
        if (sample.any { !it.isFinite() }) return false
        values[0] = sample[0]
        values[1] = sample[1]
        values[2] = sample[2]
        if (type == SensorGyroTypes.GYROSCOPE_UNCALIBRATED && values.size >= 6) {
            values[3] = 0.0f
            values[4] = 0.0f
            values[5] = 0.0f
        }
        return true
    }
}
