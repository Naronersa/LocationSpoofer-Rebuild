package com.vincenthzr.locationspoofer.xposed.utils

import com.vincenthzr.locationspoofer.utils.CompassMath
import org.json.JSONObject
import kotlin.math.hypot

/**
 * 指南针相关传感器的类型常量。
 *
 * 不直接依赖 android.hardware.Sensor 常量，方便在 JVM 单元测试里复用，
 * 也避免旧 compileSdk 缺少 TYPE_HEADING。
 */
object SensorCompassTypes {
    const val MAGNETIC_FIELD = 2
    const val ORIENTATION = 3
    const val ROTATION_VECTOR = 11
    const val MAGNETIC_FIELD_UNCALIBRATED = 14
    const val GAME_ROTATION_VECTOR = 15
    const val GEOMAGNETIC_ROTATION_VECTOR = 20
    const val HEADING = 42

    val ALL: Set<Int> = setOf(
        MAGNETIC_FIELD,
        ORIENTATION,
        ROTATION_VECTOR,
        MAGNETIC_FIELD_UNCALIBRATED,
        GAME_ROTATION_VECTOR,
        GEOMAGNETIC_ROTATION_VECTOR,
        HEADING,
    )

    fun isCompass(type: Int?): Boolean = type != null && type in ALL
}

/** 一次采样对应的真北/磁北方位与 6DoF 姿态（pitch/roll 为弧度）。 */
data class CompassHeading(
    val trueDeg: Double,
    val magneticDeg: Double,
    val declinationDeg: Double,
    val accuracyDeg: Double = 5.0,
    val pitchRad: Double = 0.0,
    val rollRad: Double = 0.0,
    val pitchRateRad: Double = 0.0,
    val rollRateRad: Double = 0.0,
    val speedMps: Double = 0.0,
    /** WMM 水平分量（µT）；NaN 表示调用方没有提供，退回真实事件的水平分量。 */
    val horizontalUt: Double = Double.NaN,
    /** WMM 垂直分量（µT，向下为正）；NaN 表示退回真实事件。 */
    val verticalUt: Double = Double.NaN,
)

/**
 * 把真实传感器值改写为模拟方位。
 *
 * 所有改写都是绝对值、幂等的：同一事件在 dispatch 与 listener 两层各执行一次也不会漂移。
 * 不依赖 Android，单元测试可直接调用 [render]。
 */
object SensorCompassPolicy {

    fun enabled(config: JSONObject?): Boolean =
        config != null &&
            config.optBoolean("active", false) &&
            config.optBoolean("enable_compass_simulation", true)

    /**
     * @return true 表示 values 已被改写。
     */
    fun render(type: Int, values: FloatArray, heading: CompassHeading): Boolean {
        if (values.isEmpty() || !heading.trueDeg.isFinite() ||
            !heading.magneticDeg.isFinite() || !heading.declinationDeg.isFinite()
        ) {
            return false
        }
        val magnetic = CompassMath.wrap360(heading.magneticDeg)
        val accuracyRadians = CompassMath.accuracyDegreesToRadians(heading.accuracyDeg)
        val pitch = if (heading.pitchRad.isFinite()) heading.pitchRad else 0.0
        val roll = if (heading.rollRad.isFinite()) heading.rollRad else 0.0

        return when (type) {
            SensorCompassTypes.HEADING -> {
                // TYPE_HEADING 使用真北；API 33+，values[1] 是度单位的精度。
                values[0] = CompassMath.wrap360(heading.trueDeg).toFloat()
                if (values.size >= 2) values[1] = heading.accuracyDeg.toFloat()
                true
            }

            SensorCompassTypes.ORIENTATION -> {
                // azimuth 为磁北；pitch/roll 来自 6DoF 步态姿态。
                values[0] = magnetic.toFloat()
                if (values.size >= 2) values[1] = (pitch * 180.0 / Math.PI).toFloat()
                if (values.size >= 3) values[2] = (roll * 180.0 / Math.PI).toFloat()
                true
            }

            SensorCompassTypes.MAGNETIC_FIELD,
            SensorCompassTypes.MAGNETIC_FIELD_UNCALIBRATED -> {
                if (values.size < 3) return false
                val wmmValid = heading.horizontalUt.isFinite() &&
                    heading.horizontalUt > 1.0 &&
                    heading.verticalUt.isFinite()
                val horizontal: Float
                val z: Float
                if (wmmValid) {
                    // WMM 给出的是当地地磁场的真实量级和磁倾角：传感器 Z 轴
                    // 向上，而 WMM 的垂直分量以向下为正，所以取负号。
                    horizontal = heading.horizontalUt.toFloat().coerceIn(5f, 80f)
                    z = (-heading.verticalUt).toFloat().coerceIn(-80f, 80f)
                } else {
                    // 没有 WMM 时退回真实事件，并做与旧版相同的安全限幅。
                    horizontal = hypot(values[0].toDouble(), values[1].toDouble()).toFloat()
                        .coerceIn(12f, 60f)
                    val rawZ = values[2]
                    z = if (rawZ.isFinite() && rawZ in -70f..70f) {
                        rawZ
                    } else {
                        if (rawZ >= 0f) 45f else -45f
                    }
                }
                val field = CompassMath.flatMagneticFieldUt(
                    magnetic,
                    horizontal,
                    z
                )
                val tilted = SensorAttitudePolicy.rotateTilt(
                    field[0].toDouble(),
                    field[1].toDouble(),
                    field[2].toDouble(),
                    pitch,
                    roll,
                )
                values[0] = tilted[0]
                values[1] = tilted[1]
                values[2] = tilted[2]
                if (type == SensorCompassTypes.MAGNETIC_FIELD_UNCALIBRATED &&
                    values.size >= 6
                ) {
                    // 去掉真实硬铁 bias，保证 App 由 raw - bias 得到的方向与目标一致。
                    values[3] = 0.0f
                    values[4] = 0.0f
                    values[5] = 0.0f
                }
                true
            }

            SensorCompassTypes.ROTATION_VECTOR,
            SensorCompassTypes.GAME_ROTATION_VECTOR,
            SensorCompassTypes.GEOMAGNETIC_ROTATION_VECTOR -> {
                if (values.size < 4) return false
                val q = SensorAttitudePolicy.quaternion(
                    magnetic * Math.PI / 180.0,
                    pitch,
                    roll,
                )
                values[0] = q[0]
                values[1] = q[1]
                values[2] = q[2]
                values[3] = q[3]
                if (type == SensorCompassTypes.ROTATION_VECTOR && values.size >= 5) {
                    values[4] = accuracyRadians
                }
                true
            }

            else -> false
        }
    }
}
