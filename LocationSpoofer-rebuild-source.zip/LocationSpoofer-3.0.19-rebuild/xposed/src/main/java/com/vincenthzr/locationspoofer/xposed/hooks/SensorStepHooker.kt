@file:Suppress(
    "UNUSED_PARAMETER",
    "UNUSED_VARIABLE",
    "UNNECESSARY_NOT_NULL_ASSERTION",
    "DEPRECATION",
    "NAME_SHADOWING",
    "FunctionName",
    "PrivatePropertyName",
    "SpellCheckingInspection",
    "RedundantUnitReturnType",
    "RemoveRedundantQualifierName",
    "OPT_IN_USAGE",
    "unused",
    "UnusedImport"
)

package com.vincenthzr.locationspoofer.xposed.hooks

import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import com.vincenthzr.locationspoofer.utils.CompassMath
import com.vincenthzr.locationspoofer.utils.GaitTemplate
import com.vincenthzr.locationspoofer.xposed.LocationHooker
import com.vincenthzr.locationspoofer.xposed.utils.CompassHeading
import com.vincenthzr.locationspoofer.xposed.utils.CompassHeadingSource
import com.vincenthzr.locationspoofer.xposed.utils.RouteEngine
import com.vincenthzr.locationspoofer.xposed.utils.SensorAccelTypes
import com.vincenthzr.locationspoofer.xposed.utils.SensorAttitudePolicy
import com.vincenthzr.locationspoofer.xposed.utils.SensorCompassPolicy
import com.vincenthzr.locationspoofer.xposed.utils.SensorCompassTypes
import com.vincenthzr.locationspoofer.xposed.utils.SensorGyroPolicy
import com.vincenthzr.locationspoofer.xposed.utils.SensorGyroTypes
import com.vincenthzr.locationspoofer.xposed.utils.SensorPressurePolicy
import com.vincenthzr.locationspoofer.xposed.utils.StepEventTimeline
import com.vincenthzr.locationspoofer.xposed.utils.StepSimulationClock
import com.vincenthzr.locationspoofer.xposed.utils.WeakIdentityCache
import com.vincenthzr.locationspoofer.xposed.utils.XposedHelpers
import org.json.JSONObject
import java.lang.reflect.Constructor
import java.lang.reflect.Field
import java.util.Random
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList

/**
 * scoped 模式的传感器模拟（对照官方 3.0.19 scoped 行为重写）。
 *
 * 3.0.19 相对 3.0.0 的关键改进：
 * - 步数由可续接的 [StepSimulationClock] 计算，改配置不会回退；
 * - STEP_COUNTER 按监听者去重，只在整数步变化时推送；
 * - STEP_DETECTOR 用 [StepEventTimeline] 为每个整数步生成带插值时间戳的事件；
 * - 运动中抑制原生 STEP_DETECTOR，避免与合成事件重复；
 * - 加速度合成只在最近 500ms 没有原生事件时兜底，并用 ThreadLocal 防止重复叠加；
 * - 合成事件投递时设置 syntheticDelivery，listener 层 Hook 看到后不再二次处理。
 */
object SensorStepHooker {

    data class CapturedSensorListener(
        val listener: Any,
        val sensor: Sensor?,
        val handler: Handler?
    )

    val capturedListeners = CopyOnWriteArrayList<CapturedSensorListener>()
    private val hookedListenerClasses = ConcurrentHashMap<Class<*>, Boolean>()

    // 每个 listener 最近一次推送的整数步数 / 步检测时间线
    private val counterValues = ConcurrentHashMap<CapturedSensorListener, Long>()
    private val detectorTimelines = ConcurrentHashMap<CapturedSensorListener, StepEventTimeline>()

    // 每个 listener 最近一次收到原生加速度事件的时间（弱引用，避免持有目标 App 对象）
    private val lastNativeAcceleration = WeakIdentityCache<Long>()

    // dispatchSensorEvent 已经合成过加速度时，listener 层不再重复叠加
    private val nativeVibrationDelivery = ThreadLocal<Boolean>()
    // 模块自己投递的事件，listener 层直接放行
    private val syntheticDelivery = ThreadLocal<Boolean>()

    private val stepClock = StepSimulationClock()
    private val noiseRng = Random()

    @Volatile private var cachedTemplateSource: String? = null
    @Volatile private var cachedTemplate: GaitTemplate? = null

    // 缓存虚拟 Sensor 实例
    private var mockStepCounterSensor: Sensor? = null
    private var mockStepDetectorSensor: Sensor? = null
    private var mockAccelerometerSensor: Sensor? = null

    // 跟踪 handle 到 sensor type 的映射
    private val handleToTypeMap = ConcurrentHashMap<Int, Int>()

    fun hookSensorStepSimulation(classLoader: ClassLoader) {
        val targetClasses = listOf(
            "android.hardware.SensorManager",
            "android.hardware.SystemSensorManager"
        )

        for (className in targetClasses) {
            val managerClass = XposedHelpers.findClassIfExists(className, classLoader) ?: continue

            // 1. 设备无物理计步传感器时注入虚拟 Sensor
            try {
                XposedHelpers.hookAllMethods(managerClass, "getDefaultSensor") { chain, _ ->
                    val result = chain.proceed(chain.args.toTypedArray())
                    val type = (chain.args.firstOrNull() as? Int) ?: return@hookAllMethods result
                    if (result == null && (type == Sensor.TYPE_STEP_COUNTER || type == Sensor.TYPE_STEP_DETECTOR)) {
                        return@hookAllMethods getOrCreateMockSensor(type, classLoader)
                    }
                    result
                }
            } catch (_: Throwable) {
            }

            // 2. getSensorList
            try {
                XposedHelpers.hookAllMethods(managerClass, "getSensorList") { chain, _ ->
                    val result = chain.proceed(chain.args.toTypedArray())
                    val type = (chain.args.firstOrNull() as? Int) ?: return@hookAllMethods result
                    if (type == Sensor.TYPE_STEP_COUNTER || type == Sensor.TYPE_STEP_DETECTOR) {
                        if (result is List<*> && result.isEmpty()) {
                            val mock = getOrCreateMockSensor(type, classLoader)
                            if (mock != null) return@hookAllMethods listOf(mock)
                        }
                    }
                    result
                }
            } catch (_: Throwable) {
            }

            // 3. registerListener / registerListenerImpl
            for (methodName in listOf("registerListener", "registerListenerImpl")) {
                try {
                    XposedHelpers.hookAllMethods(managerClass, methodName) { chain, _ ->
                        val args = chain.args
                        var listener: Any? = null
                        var sensor: Sensor? = null
                        var handler: Handler? = null

                        for (arg in args) {
                            if (arg != null) {
                                if (arg is SensorEventListener ||
                                    LocationHooker.hasTypeByName(arg.javaClass, "android.hardware.SensorEventListener")
                                ) {
                                    listener = arg
                                } else if (arg is Sensor) {
                                    sensor = arg
                                } else if (arg is Handler) {
                                    handler = arg
                                }
                            }
                        }

                        if (listener != null) {
                            val targetSensor = sensor ?: getOrCreateMockSensor(Sensor.TYPE_STEP_COUNTER, classLoader)
                            if (targetSensor != null) {
                                // 所有已注册传感器都记录 handle→type，保证 dispatchSensorEvent
                                // 也能识别没有进入模拟列表的 compass 传感器。
                                getSensorHandle(targetSensor)?.let { handleToTypeMap[it] = targetSensor.type }

                                val simulatable =
                                    targetSensor.type == Sensor.TYPE_STEP_COUNTER ||
                                        targetSensor.type == Sensor.TYPE_STEP_DETECTOR ||
                                        targetSensor.type == Sensor.TYPE_ACCELEROMETER ||
                                        targetSensor.type == Sensor.TYPE_PRESSURE ||
                                        SensorCompassTypes.isCompass(targetSensor.type) ||
                                        SensorGyroTypes.isGyro(targetSensor.type)
                                if (simulatable) {
                                    val entry = CapturedSensorListener(listener, targetSensor, handler)
                                    if (!capturedListeners.any { it.listener === listener && it.sensor?.type == targetSensor.type }) {
                                        capturedListeners.add(entry)
                                    }
                                    hookConcreteListenerClass(listener.javaClass, classLoader)
                                }
                            }
                        }

                        chain.proceed(chain.args.toTypedArray())
                    }
                } catch (_: Throwable) {
                }
            }

            // 4. unregisterListener / unregisterListenerImpl
            for (methodName in listOf("unregisterListener", "unregisterListenerImpl")) {
                try {
                    XposedHelpers.hookAllMethods(managerClass, methodName) { chain, _ ->
                        val listener = chain.args.firstOrNull {
                            it != null && (it is SensorEventListener ||
                                LocationHooker.hasTypeByName(it.javaClass, "android.hardware.SensorEventListener"))
                        }
                        if (listener != null) {
                            capturedListeners.removeAll { it.listener === listener }
                            counterValues.keys.removeAll { it.listener === listener }
                            detectorTimelines.keys.removeAll { it.listener === listener }
                        }
                        chain.proceed(chain.args.toTypedArray())
                    }
                } catch (_: Throwable) {
                }
            }
        }

        // 5. 底层分发接口
        hookSensorEventQueue(classLoader)
    }

    private fun hookSensorEventQueue(classLoader: ClassLoader) {
        try {
            val eventQueueClass =
                XposedHelpers.findClassIfExists("android.hardware.SystemSensorManager\$SensorEventQueue", classLoader)
                    ?: XposedHelpers.findClassIfExists("android.hardware.SystemSensorManager\$BaseEventQueue", classLoader)
                    ?: return

            XposedHelpers.hookAllMethods(eventQueueClass, "dispatchSensorEvent") { chain, _ ->
                val config = readConfig()
                if (config != null && config.optBoolean("active", false)) {
                    val handle = chain.args.getOrNull(0) as? Int
                    val values = chain.args.getOrNull(1) as? FloatArray
                    val timestamp = chain.args.getOrNull(3) as? Long ?: 0L

                    if (handle != null && values != null) {
                        val sensorType = handleToTypeMap[handle]
                        val speed = config.optDouble("speed_m_s", 0.0)
                        val stepSim = config.optBoolean("enable_step_simulation", true)
                        when {
                            sensorType == Sensor.TYPE_PRESSURE -> {
                                SensorPressurePolicy.apply(
                                    values, timestamp, config,
                                    System.currentTimeMillis(), SystemClock.elapsedRealtimeNanos()
                                )
                            }
                            sensorType != null && SensorCompassTypes.isCompass(sensorType) -> {
                                // LSPosed 的 chain.args 可能是不可修改列表，只原地改 values；
                                // 精度由 listener 层的 event.accuracy 设置。
                                CompassHeadingSource.current(config)?.let { heading ->
                                    SensorCompassPolicy.render(
                                        sensorType,
                                        values,
                                        withGaitAttitude(config, heading)
                                    )
                                }
                            }
                            sensorType != null && SensorGyroTypes.isGyro(sensorType) -> {
                                applyGyro(values, sensorType, config, System.currentTimeMillis())
                            }
                            stepSim && sensorType == Sensor.TYPE_STEP_COUNTER -> {
                                if (values.isNotEmpty()) {
                                    values[0] = calculateCurrentSteps(config).toFloat()
                                }
                            }
                            stepSim && sensorType == Sensor.TYPE_STEP_DETECTOR -> {
                                // 运动中由模块按每个整数步投递，抑制原生步检测，避免重复
                                if (speed > 0.05) return@hookAllMethods null
                            }
                            stepSim && SensorAccelTypes.isFamily(sensorType) &&
                                values.size >= 3 && speed > 0.1 -> {
                                applySyntheticMotion(values, sensorType!!, config, speed)
                                nativeVibrationDelivery.set(true)
                                try {
                                    return@hookAllMethods chain.proceed(chain.args.toTypedArray())
                                } finally {
                                    nativeVibrationDelivery.remove()
                                }
                            }
                        }
                    }
                }
                chain.proceed(chain.args.toTypedArray())
            }
        } catch (_: Throwable) {
        }
    }

    private fun hookConcreteListenerClass(clazz: Class<*>, classLoader: ClassLoader) {
        if (hookedListenerClasses.putIfAbsent(clazz, true) != null) return
        try {
            XposedHelpers.hookAllMethods(clazz, "onSensorChanged") { chain, _ ->
                // 模块自己投递的合成事件：不再二次处理
                if (syntheticDelivery.get() == true) {
                    return@hookAllMethods chain.proceed(chain.args.toTypedArray())
                }

                val event = chain.args.firstOrNull() as? SensorEvent
                val sensor = event?.sensor
                if (event != null && sensor != null) {
                    val config = readConfig()
                    if (config != null && config.optBoolean("active", false)) {
                        val speed = config.optDouble("speed_m_s", 0.0)
                        val stepSim = config.optBoolean("enable_step_simulation", true)
                        when {
                            sensor.type == Sensor.TYPE_PRESSURE -> {
                                SensorPressurePolicy.apply(
                                    event.values, event.timestamp, config,
                                    System.currentTimeMillis(), SystemClock.elapsedRealtimeNanos()
                                )
                            }
                            SensorCompassTypes.isCompass(sensor.type) -> {
                                CompassHeadingSource.current(config)?.let { heading ->
                                    if (SensorCompassPolicy.render(
                                            sensor.type,
                                            event.values,
                                            withGaitAttitude(config, heading)
                                        )
                                    ) {
                                        event.accuracy = 3
                                    }
                                }
                            }
                            SensorGyroTypes.isGyro(sensor.type) -> {
                                applyGyro(
                                    event.values,
                                    sensor.type,
                                    config,
                                    System.currentTimeMillis()
                                )
                            }
                            stepSim && sensor.type == Sensor.TYPE_STEP_COUNTER -> {
                                if (event.values.isNotEmpty()) {
                                    event.values[0] = calculateCurrentSteps(config).toFloat()
                                    event.timestamp = SystemClock.elapsedRealtimeNanos()
                                }
                            }
                            stepSim && sensor.type == Sensor.TYPE_STEP_DETECTOR -> {
                                if (speed > 0.05) return@hookAllMethods null
                            }
                            stepSim && SensorAccelTypes.isFamily(sensor.type) &&
                                event.values.size >= 3 && speed > 0.1 -> {
                                val owner = chain.thisObject
                                if (owner != null) {
                                    lastNativeAcceleration.put(owner, SystemClock.elapsedRealtime())
                                }
                                // 底层 dispatch 已经合成过时不再重复叠加
                                if (nativeVibrationDelivery.get() != true) {
                                    applySyntheticMotion(event.values, sensor.type, config, speed)
                                }
                            }
                        }
                    }
                }
                chain.proceed(chain.args.toTypedArray())
            }
        } catch (_: Throwable) {
        }
    }

    /**
     * 由 ConfigPoller 每秒调用：仅在运动路线模拟中主动推送。
     */
    fun dispatchStepEvents(config: JSONObject, classLoader: ClassLoader) {
        if (!config.optBoolean("active", false) ||
            !config.optBoolean("enable_step_simulation", true) ||
            config.optDouble("speed_m_s", 0.0) <= 0.05
        ) {
            detectorTimelines.clear()
            counterValues.clear()
            return
        }

        val now = System.currentTimeMillis()
        val stepsFloat = calculateCurrentStepsFloat(config, now)
        val steps = stepsFloat.toLong()
        val nowNanos = SystemClock.elapsedRealtimeNanos()
        val listeners = capturedListeners.toList()
        if (listeners.isEmpty()) return

        val speed = config.optDouble("speed_m_s", 0.0)
        for (entry in listeners) {
            val listener = entry.listener
            val sensor = entry.sensor ?: continue
            val handler = entry.handler ?: Handler(Looper.getMainLooper())

            when (sensor.type) {
                Sensor.TYPE_STEP_COUNTER -> {
                    val previous = counterValues.put(entry, steps)
                    if (previous == null || previous != steps) {
                        val event = createSensorEvent(sensor, floatArrayOf(steps.toFloat())) ?: continue
                        postSensorEvent(handler, listener, event, config)
                    }
                }
                Sensor.TYPE_STEP_DETECTOR -> {
                    val timeline = detectorTimelines.getOrPut(entry) { StepEventTimeline() }
                    for (timestamp in timeline.sample(stepsFloat, nowNanos)) {
                        val event = createSensorEvent(sensor, floatArrayOf(1.0f)) ?: continue
                        event.timestamp = timestamp
                        postSensorEvent(handler, listener, event, config)
                    }
                }
                Sensor.TYPE_ACCELEROMETER -> {
                    val last = lastNativeAcceleration.get(listener)
                    if ((last == null || SystemClock.elapsedRealtime() - last >= 500) && speed > 0.1) {
                        val values = floatArrayOf(0.0f, 0.0f, 9.8f)
                        applySyntheticMotion(values, Sensor.TYPE_ACCELEROMETER, config, speed)
                        val event = createSensorEvent(sensor, values) ?: continue
                        postSensorEvent(handler, listener, event, config)
                    }
                }
            }
        }
    }

    /**
     * 投递合成 SensorEvent。投递前重新校验配置/会话仍在进行，并设置 syntheticDelivery，
     * 防止 listener 层的 Hook 对同一事件再次改写。
     */
    private fun postSensorEvent(
        handler: Handler,
        listener: Any,
        event: SensorEvent,
        config: JSONObject
    ) {
        val startTimestamp = config.optLong("start_timestamp")
        handler.post {
            try {
                val current = readConfig() ?: return@post
                if (!current.optBoolean("active", false) ||
                    !current.optBoolean("enable_step_simulation", true) ||
                    current.optDouble("speed_m_s", 0.0) <= 0.05 ||
                    current.optLong("start_timestamp") != startTimestamp ||
                    SystemClock.elapsedRealtimeNanos() - event.timestamp > 500_000_000L
                ) {
                    return@post
                }
                if (capturedListeners.none { it.listener === listener && it.sensor === event.sensor }) {
                    return@post
                }
                syntheticDelivery.set(true)
                try {
                    if (listener is SensorEventListener) {
                        listener.onSensorChanged(event)
                    } else {
                        XposedHelpers.callMethod(listener, "onSensorChanged", event)
                    }
                } finally {
                    syntheticDelivery.remove()
                }
            } catch (_: Throwable) {
                syntheticDelivery.remove()
            }
        }
    }

    /** 配置更新时调用：推进时钟；非运动状态清理逐步时间线 */
    fun observeConfig(config: JSONObject) {
        calculateCurrentStepsFloat(config, System.currentTimeMillis())
        if (!config.optBoolean("active", false) ||
            !config.optBoolean("enable_step_simulation", true) ||
            config.optDouble("speed_m_s", 0.0) <= 0.05
        ) {
            detectorTimelines.clear()
        }
        if (!SensorCompassPolicy.enabled(config)) {
            CompassHeadingSource.reset()
        }
    }

    private fun readConfig(): JSONObject? =
        (XposedHelpers.module as? LocationHooker)?.readConfig()

    /**
     * scoped 陀螺仪：路线真北 bearing 的 100ms 差分得到转向角速度，
     * 再由同一姿态四元数的导数生成三轴角速度，与 orientation/gravity 同源。
     */
    private fun applyGyro(
        values: FloatArray,
        type: Int,
        config: JSONObject,
        now: Long
    ): Boolean {
        if (!SensorCompassPolicy.enabled(config)) return false
        val motion = try {
            RouteEngine.calculateCurrentPosition(config, now)
        } catch (_: Throwable) {
            return false
        }
        val speed = motion.speed.toDouble()
        if (speed <= 0.05) return false

        val previous = try {
            RouteEngine.calculateCurrentPosition(config, now - 100L)
        } catch (_: Throwable) {
            motion
        }
        val yawRate = (
            CompassMath.shortestDeltaDegrees(
                previous.bearing.toDouble(),
                motion.bearing.toDouble()
            ) * Math.PI / 180.0 / 0.1
            ).coerceIn(-3.5, 3.5)

        val steps = calculateCurrentStepsFloat(config, now)
        val cadence = if (config.optBoolean("is_auto_cadence", true)) {
            calculateAutoCadence(speed)
        } else {
            config.optInt("step_cadence_spm", 165).coerceIn(60, 240)
        }
        val heading = CompassHeadingSource.current(config, now)
        val attitude = SensorAttitudePolicy.compute(
            stepsFloat = steps,
            speedMps = speed,
            cadenceSpm = cadence,
            trueHeadingDeg = heading?.trueDeg ?: 0.0,
            declinationDeg = heading?.declinationDeg ?: 0.0,
            yawRateRad = yawRate,
            realismLevel = config.optInt("realism_level", 0),
        )
        val gyro = SensorAttitudePolicy.angularVelocity(
            yawRad = attitude.yawMagneticRad,
            pitchRad = attitude.pitchRad,
            rollRad = attitude.rollRad,
            yawRateRad = attitude.yawRateRad,
            pitchRateRad = attitude.pitchRateRad,
            rollRateRad = attitude.rollRateRad,
        )
        return SensorGyroPolicy.render(type, values, gyro)
    }

    private fun applySyntheticMotion(
        values: FloatArray,
        type: Int,
        config: JSONObject,
        speed: Double,
    ) {
        val now = System.currentTimeMillis()
        val stepsFloat = calculateCurrentStepsFloat(config, now)
        val motionSpeed = RouteEngine.calculateCurrentPosition(config, now).speed.toDouble()
            .takeIf { it > 0.0 } ?: speed
        val template = gaitTemplate(config)
        val raw = RouteEngine.realismSession(config).accelerometer(
            stepsFloat, motionSpeed, template, noiseRng
        )
        val mean = template?.meanAcceleration() ?: floatArrayOf(0.0f, 0.0f, 9.80665f)
        val linear = floatArrayOf(raw[0] - mean[0], raw[1] - mean[1], raw[2] - mean[2])
        val attitude = gaitAttitude(config, stepsFloat, motionSpeed, now)
        val gravity = SensorAttitudePolicy.gravityBody(attitude.pitchRad, attitude.rollRad)
        val linearBody = SensorAttitudePolicy.rotateTilt(
            linear[0].toDouble(), linear[1].toDouble(), linear[2].toDouble(),
            attitude.pitchRad, attitude.rollRad,
        )
        val rawBody = floatArrayOf(
            gravity[0] + linearBody[0],
            gravity[1] + linearBody[1],
            gravity[2] + linearBody[2],
        )
        when (type) {
            SensorAccelTypes.GRAVITY -> {
                values[0] = gravity[0]
                values[1] = gravity[1]
                values[2] = gravity[2]
            }
            SensorAccelTypes.LINEAR_ACCELERATION -> {
                values[0] = linearBody[0]
                values[1] = linearBody[1]
                values[2] = linearBody[2]
            }
            SensorAccelTypes.ACCELEROMETER_UNCALIBRATED -> {
                values[0] = rawBody[0]
                values[1] = rawBody[1]
                values[2] = rawBody[2]
                if (values.size >= 6) {
                    values[3] = 0.0f
                    values[4] = 0.0f
                    values[5] = 0.0f
                }
            }
            else -> {
                values[0] = rawBody[0]
                values[1] = rawBody[1]
                values[2] = rawBody[2]
            }
        }
    }

    private fun gaitAttitude(
        config: JSONObject,
        stepsFloat: Double,
        speed: Double,
        now: Long,
        knownHeading: CompassHeading? = null,
    ): com.vincenthzr.locationspoofer.xposed.utils.GaitAttitude {
        val heading = knownHeading ?: CompassHeadingSource.current(config, now)
        return SensorAttitudePolicy.compute(
            stepsFloat = stepsFloat,
            speedMps = speed,
            cadenceSpm = if (config.optBoolean("is_auto_cadence", true)) {
                calculateAutoCadence(speed)
            } else {
                config.optInt("step_cadence_spm", 165).coerceIn(60, 240)
            },
            trueHeadingDeg = heading?.trueDeg ?: 0.0,
            declinationDeg = heading?.declinationDeg ?: 0.0,
            yawRateRad = 0.0,
            realismLevel = config.optInt("realism_level", 0),
        )
    }

    private fun withGaitAttitude(
        config: JSONObject,
        heading: CompassHeading,
        now: Long = System.currentTimeMillis(),
    ): CompassHeading {
        if (heading.speedMps <= 0.05) return heading
        val attitude = gaitAttitude(
            config,
            calculateCurrentStepsFloat(config, now),
            heading.speedMps,
            now,
            heading,
        )
        val yawDelta = CompassMath.shortestDeltaDegrees(
            heading.magneticDeg,
            Math.toDegrees(attitude.yawMagneticRad),
        )
        return heading.copy(
            trueDeg = CompassMath.wrap360(heading.trueDeg + yawDelta),
            magneticDeg = CompassMath.wrap360(heading.magneticDeg + yawDelta),
            pitchRad = attitude.pitchRad,
            rollRad = attitude.rollRad,
            pitchRateRad = attitude.pitchRateRad,
            rollRateRad = attitude.rollRateRad,
        )
    }

    /** 用户录制的步态模板（配置里的编码字符串），按字符串内容缓存解码结果 */
    private fun gaitTemplate(config: JSONObject): GaitTemplate? {
        val source = config.optString("gait_template", "")
        if (source != cachedTemplateSource) {
            cachedTemplate = GaitTemplate.decode(source)
            cachedTemplateSource = source
        }
        return cachedTemplate
    }

    fun calculateCurrentSteps(config: JSONObject, now: Long = System.currentTimeMillis()): Long =
        calculateCurrentStepsFloat(config, now).toLong()

    /** 连续的累计步数：整数部分是步数，小数部分是当前这一步的相位 */
    internal fun calculateCurrentStepsFloat(config: JSONObject, now: Long): Double =
        stepClock.steps(config, now)

    fun calculateAutoCadence(speedMs: Double): Int = StepSimulationClock.autoCadence(speedMs)

    internal fun saveReloadState(): Array<Any?> = arrayOf(
        capturedListeners.map { arrayOf<Any?>(it.listener, it.sensor, it.handler) }.toTypedArray(),
        stepClock.save(),
        mockStepCounterSensor, mockStepDetectorSensor, mockAccelerometerSensor,
        handleToTypeMap.map { arrayOf(it.key, it.value) }.toTypedArray()
    )

    internal fun clearReloadState() {
        capturedListeners.clear()
        hookedListenerClasses.clear()
        counterValues.clear()
        detectorTimelines.clear()
    }

    internal fun restoreReloadState(value: Any?) {
        val state = value as? Array<*> ?: return
        (state.getOrNull(0) as? Array<*>)?.filterIsInstance<Array<*>>()?.forEach {
            val listener = it.getOrNull(0) ?: return@forEach
            capturedListeners.add(CapturedSensorListener(listener, it.getOrNull(1) as? Sensor, it.getOrNull(2) as? Handler))
            hookConcreteListenerClass(listener.javaClass, listener.javaClass.classLoader ?: ClassLoader.getSystemClassLoader())
        }
        val clockState = state.getOrNull(1) as? Array<*>
        stepClock.restore(clockState?.map { it }?.toTypedArray())
        mockStepCounterSensor = state.getOrNull(2) as? Sensor
        mockStepDetectorSensor = state.getOrNull(3) as? Sensor
        mockAccelerometerSensor = state.getOrNull(4) as? Sensor
        (state.getOrNull(5) as? Array<*>)?.filterIsInstance<Array<*>>()?.forEach {
            (it.getOrNull(0) as? Int)?.let { key -> (it.getOrNull(1) as? Int)?.let { v -> handleToTypeMap[key] = v } }
        }
    }

    private fun getSensorHandle(sensor: Sensor): Int? {
        return try {
            val handleField = Sensor::class.java.getDeclaredField("mHandle")
            handleField.isAccessible = true
            handleField.getInt(sensor)
        } catch (_: Throwable) {
            null
        }
    }

    private fun getOrCreateMockSensor(type: Int, classLoader: ClassLoader): Sensor? {
        if (type == Sensor.TYPE_STEP_COUNTER && mockStepCounterSensor != null) return mockStepCounterSensor
        if (type == Sensor.TYPE_STEP_DETECTOR && mockStepDetectorSensor != null) return mockStepDetectorSensor
        if (type == Sensor.TYPE_ACCELEROMETER && mockAccelerometerSensor != null) return mockAccelerometerSensor

        try {
            val sensorClass = Class.forName("android.hardware.Sensor", false, classLoader)
            val constructor: Constructor<*> = sensorClass.getDeclaredConstructor()
            constructor.isAccessible = true
            val sensor = constructor.newInstance() as Sensor

            setSensorField(sensor, "mType", type)
            setSensorField(sensor, "mName", when (type) {
                Sensor.TYPE_STEP_COUNTER -> "Step Counter Sensor"
                Sensor.TYPE_STEP_DETECTOR -> "Step Detector Sensor"
                else -> "Accelerometer Sensor"
            })
            setSensorField(sensor, "mVendor", "Android")
            setSensorField(sensor, "mVersion", 1)
            setSensorField(sensor, "mResolution", 1.0f)
            setSensorField(sensor, "mPower", 0.05f)

            when (type) {
                Sensor.TYPE_STEP_COUNTER -> mockStepCounterSensor = sensor
                Sensor.TYPE_STEP_DETECTOR -> mockStepDetectorSensor = sensor
                Sensor.TYPE_ACCELEROMETER -> mockAccelerometerSensor = sensor
            }
            return sensor
        } catch (_: Throwable) {
            return null
        }
    }

    private fun setSensorField(sensor: Sensor, fieldName: String, value: Any) {
        try {
            val field: Field = Sensor::class.java.getDeclaredField(fieldName)
            field.isAccessible = true
            field.set(sensor, value)
        } catch (_: Throwable) {
        }
    }

    private fun createSensorEvent(sensor: Sensor, values: FloatArray): SensorEvent? {
        try {
            val eventConstructor = SensorEvent::class.java.getDeclaredConstructor(Int::class.javaPrimitiveType)
            eventConstructor.isAccessible = true
            val event = eventConstructor.newInstance(values.size) as SensorEvent
            System.arraycopy(values, 0, event.values, 0, values.size)

            val sensorField = SensorEvent::class.java.getDeclaredField("sensor")
            sensorField.isAccessible = true
            sensorField.set(event, sensor)

            val timestampField = SensorEvent::class.java.getDeclaredField("timestamp")
            timestampField.isAccessible = true
            timestampField.setLong(event, SystemClock.elapsedRealtimeNanos())

            val accuracyField = SensorEvent::class.java.getDeclaredField("accuracy")
            accuracyField.isAccessible = true
            accuracyField.setInt(event, 3)

            return event
        } catch (_: Throwable) {
            try {
                val constructors = SensorEvent::class.java.declaredConstructors
                for (ctor in constructors) {
                    ctor.isAccessible = true
                    val paramTypes = ctor.parameterTypes
                    val args = arrayOfNulls<Any>(paramTypes.size)
                    for (i in args.indices) {
                        if (paramTypes[i] == Int::class.javaPrimitiveType) args[i] = values.size
                    }
                    val event = ctor.newInstance(*args) as SensorEvent
                    System.arraycopy(values, 0, event.values, 0, values.size)
                    try {
                        val sf = SensorEvent::class.java.getDeclaredField("sensor")
                        sf.isAccessible = true
                        sf.set(event, sensor)
                        val tf = SensorEvent::class.java.getDeclaredField("timestamp")
                        tf.isAccessible = true
                        tf.setLong(event, SystemClock.elapsedRealtimeNanos())
                        val af = SensorEvent::class.java.getDeclaredField("accuracy")
                        af.isAccessible = true
                        af.setInt(event, 3)
                    } catch (_: Throwable) {
                    }
                    return event
                }
            } catch (_: Throwable) {
            }

            try {
                val unsafeClass = Class.forName("sun.misc.Unsafe")
                val theUnsafeField = unsafeClass.getDeclaredField("theUnsafe")
                theUnsafeField.isAccessible = true
                val unsafe = theUnsafeField.get(null)
                val allocateMethod = unsafeClass.getMethod("allocateInstance", Class::class.java)
                val event = allocateMethod.invoke(unsafe, SensorEvent::class.java) as SensorEvent

                val valuesField = SensorEvent::class.java.getDeclaredField("values")
                valuesField.isAccessible = true
                val arr = FloatArray(values.size)
                System.arraycopy(values, 0, arr, 0, values.size)
                valuesField.set(event, arr)

                val sf = SensorEvent::class.java.getDeclaredField("sensor")
                sf.isAccessible = true
                sf.set(event, sensor)

                val tf = SensorEvent::class.java.getDeclaredField("timestamp")
                tf.isAccessible = true
                tf.setLong(event, SystemClock.elapsedRealtimeNanos())

                val af = SensorEvent::class.java.getDeclaredField("accuracy")
                af.isAccessible = true
                af.setInt(event, 3)
                return event
            } catch (_: Throwable) {
            }

            return null
        }
    }
}
