package com.vincenthzr.locationspoofer.xposed.utils

import android.hardware.GeomagneticField
import com.vincenthzr.locationspoofer.utils.CompassMath
import com.vincenthzr.locationspoofer.utils.CoordinateUtils
import com.vincenthzr.locationspoofer.utils.CoordinateUtils.LatLng
import com.vincenthzr.locationspoofer.utils.GeoMath
import org.json.JSONObject

/**
 * scoped 模式的方位源：路线/摇杆/固定模式统一走 [RouteEngine]，
 * 真北 bearing 用 WMM (`GeomagneticField`) 按当前位置换算成磁北。
 *
 * GeomagneticField 的计算按坐标/时间缓存；每个传感器事件只做路线 bearing 与缓存查询，
 * 避免磁场/旋转矢量 50–200 Hz 回调里反复做 WMM。GeomagneticField 返回 nT，
 * 这里统一除以 1000 转成 Android 磁力计使用的 µT。
 */
object CompassHeadingSource {

    private const val ACCURACY_DEG = 5.0
    private const val DECLINATION_CACHE_MS = 5 * 60 * 1000L
    private const val DECLINATION_CACHE_DISTANCE_M = 1000.0

    private data class DeclinationCache(
        val lat: Double,
        val lng: Double,
        val altitudeM: Double,
        val atMs: Long,
        val declinationDeg: Double,
        val horizontalUt: Double,
        val verticalUt: Double,
    )

    @Volatile
    private var cache: DeclinationCache? = null

    fun current(
        config: JSONObject,
        now: Long = System.currentTimeMillis()
    ): CompassHeading? {
        if (!SensorCompassPolicy.enabled(config)) return null
        val motion = try {
            RouteEngine.calculateCurrentPosition(config, now)
        } catch (_: Throwable) {
            return null
        }
        if (!motion.lat.isFinite() || !motion.lng.isFinite() ||
            !motion.bearing.isFinite()
        ) {
            return null
        }

        // 路线位置是 GCJ-02；WMM 使用 WGS-84。
        val wgs = try {
            CoordinateUtils.gcj02ToWgs84(motion.lat, motion.lng)
        } catch (_: Throwable) {
            LatLng(motion.lat, motion.lng)
        }
        val wmm = wmmAt(
            wgs.lat,
            wgs.lng,
            config,
            now
        )
        // RouteEngine 的 bearing 是从叠加 GPS 漂移/横向偏移后的轨迹反算的，
        // 指南针、Location.bearing 与 NMEA RMC 共用同一个方向。
        val trueHeading = CompassMath.wrap360(motion.bearing.toDouble())
        return CompassHeading(
            trueDeg = trueHeading,
            magneticDeg = CompassMath.trueToMagnetic(trueHeading, wmm.declinationDeg),
            declinationDeg = wmm.declinationDeg,
            accuracyDeg = ACCURACY_DEG,
            speedMps = motion.speed.toDouble().coerceAtLeast(0.0),
            horizontalUt = wmm.horizontalUt,
            verticalUt = wmm.verticalUt,
        )
    }

    private fun wmmAt(
        lat: Double,
        lng: Double,
        config: JSONObject,
        now: Long
    ): DeclinationCache {
        val cached = cache
        if (cached != null &&
            now - cached.atMs in 0..DECLINATION_CACHE_MS &&
            GeoMath.distance(
                LatLng(cached.lat, cached.lng),
                LatLng(lat, lng)
            ) <= DECLINATION_CACHE_DISTANCE_M
        ) {
            return cached
        }

        val altitude = try {
            RouteEngine.realisticAltitude(config, now)
        } catch (_: Throwable) {
            config.optDouble("altitude", 0.0)
        }
        var declination = 0.0
        var horizontal = Double.NaN
        var vertical = Double.NaN
        try {
            val field = GeomagneticField(
                lat.toFloat(),
                lng.toFloat(),
                altitude.toFloat(),
                now
            )
            declination = field.declination.toDouble()
            // GeomagneticField 的分量单位是 nT；Android 磁力计是 µT。
            horizontal = field.horizontalStrength.toDouble() / 1000.0
            // WMM 的 Z 轴向下为正；传感器 Z 轴向上，消费端会取负。
            vertical = field.z.toDouble() / 1000.0
        } catch (_: Throwable) {
            // 保持 NaN，调用方会退回真实传感器分量
        }
        if (!declination.isFinite()) declination = 0.0
        if (horizontal.isFinite() && horizontal <= 0.0) horizontal = Double.NaN
        if (!vertical.isFinite()) vertical = Double.NaN

        return DeclinationCache(
            lat, lng, altitude, now, declination, horizontal, vertical
        ).also { cache = it }
    }

    fun reset() {
        cache = null
    }
}
