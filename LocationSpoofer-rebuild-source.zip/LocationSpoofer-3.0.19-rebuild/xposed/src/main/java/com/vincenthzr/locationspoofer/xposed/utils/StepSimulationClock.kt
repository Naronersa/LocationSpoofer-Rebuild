@file:Suppress("unused")

package com.vincenthzr.locationspoofer.xposed.utils

import com.vincenthzr.locationspoofer.utils.MotionRealism
import org.json.JSONObject
import kotlin.math.max

/**
 * 可续接的步数时钟（对照官方 3.0.19 scoped 的 StepSimulationClock 行为重写）。
 *
 * 与 3.0.0 的线性公式相比，这里把模拟拆成"段"：
 * - 配置里的 start_timestamp / 速度 / 步频 / 真实度变化时，先把上一段累计到当前时刻，
 *   再把累计值作为新段的起点，因此改配置不会让步数回退；
 * - 累计步数仍由 [MotionRealism.Session] 计算，保留本地噪声/波动，不依赖云端策略。
 */
class StepSimulationClock {

    private data class Program(
        val start: Long,
        val speed: Double,
        val cadence: Int,
        val autoCadence: Boolean,
        val realismLevel: Int,
        val fluctuationPct: Int,
        val stationarySim: Boolean,
        val session: MotionRealism.Session
    ) {
        fun sameAs(other: Program): Boolean =
            start == other.start &&
                speed == other.speed &&
                cadence == other.cadence &&
                autoCadence == other.autoCadence &&
                realismLevel == other.realismLevel &&
                fluctuationPct == other.fluctuationPct &&
                stationarySim == other.stationarySim
    }

    private var program: Program? = null
    private var base: Double = INITIAL_BOOT_STEPS
    private var steps: Double = INITIAL_BOOT_STEPS
    private var anchor: Long = 0L
    private var lastNow: Long = 0L

    @Synchronized
    fun steps(config: JSONObject, now: Long = System.currentTimeMillis()): Double {
        val start = config.optLong("start_timestamp", 0L)
        if (start <= 0L || now < lastNow) return steps

        val speed = config.optDouble("speed_m_s", 0.0)
        val autoCadence = config.optBoolean("is_auto_cadence", true)
        val cadence = if (autoCadence) {
            autoCadence(speed)
        } else {
            config.optInt("step_cadence_spm", 165).coerceIn(60, 240)
        }
        val level = config.optInt("realism_level", 0)
        val fluctuation = config.optInt("speed_fluctuation_pct", 0)
        val stationarySim = speed <= 0.05 &&
            config.optBoolean("active", true) &&
            config.optBoolean("enable_step_simulation", true)
        val session = RouteEngine.realismSession(config, start)
        val next = Program(start, speed, cadence, autoCadence, level, fluctuation, stationarySim, session)

        val current = program
        if (current == null) {
            program = next
            anchor = start
            base = steps
        } else if (!next.sameAs(current)) {
            val cut = now
            base += segmentSteps(current, anchor, cut)
            steps = base
            anchor = cut
            program = next
        }

        if (next.speed > 0.05) {
            steps = base + segmentSteps(next, anchor, now)
        } else {
            // 静止且未开启原地模拟：冻结步数；恢复运动时从当前时刻继续
            anchor = now
        }
        lastNow = now
        return steps
    }

    private fun segmentSteps(p: Program, from: Long, to: Long): Double {
        val t0 = (max(from, p.start) - p.start) / 1000.0
        val t1 = (max(to, p.start) - p.start) / 1000.0
        if (t1 <= t0) return 0.0
        return p.session.steps(p.cadence.toDouble(), t1) -
            p.session.steps(p.cadence.toDouble(), t0)
    }

    @Synchronized
    fun save(): Array<Any?> = arrayOf(
        base, steps, anchor, lastNow,
        program?.start, program?.speed, program?.cadence, program?.autoCadence,
        program?.realismLevel, program?.fluctuationPct, program?.stationarySim
    )

    @Synchronized
    fun restore(state: Array<Any?>?) {
        if (state == null || state.size < 11) return
        base = (state[0] as? Double) ?: return
        steps = (state[1] as? Double) ?: return
        anchor = (state[2] as? Long) ?: 0L
        lastNow = (state[3] as? Long) ?: 0L
        val start = state[4] as? Long ?: return
        val speed = state[5] as? Double ?: 0.0
        val cadence = state[6] as? Int ?: 165
        val auto = state[7] as? Boolean ?: true
        val level = state[8] as? Int ?: 0
        val fluctuation = state[9] as? Int ?: 0
        val stationary = state[10] as? Boolean ?: false
        val session = MotionRealism.session(start, level, fluctuation)
        program = Program(start, speed, cadence, auto, level, fluctuation, stationary, session)
    }

    companion object {
        /** 与 3.0.0 保持一致的初始基数（真实计步器自开机以来的步数） */
        private const val INITIAL_BOOT_STEPS = 2350.0

        /** 按速度估算生理步频（SPM），与 3.0.0 的阈值一致 */
        fun autoCadence(speedMs: Double): Int = when {
            speedMs <= 0.8 -> 95
            speedMs <= 1.5 -> (100 + (speedMs - 0.8) / 0.7 * 25).toInt()
            speedMs <= 2.8 -> (135 + (speedMs - 1.5) / 1.3 * 25).toInt()
            speedMs <= 4.0 -> (160 + (speedMs - 2.8) / 1.2 * 20).toInt()
            speedMs <= 5.5 -> (180 + (speedMs - 4.0) / 1.5 * 15).toInt()
            else -> 200
        }
    }
}
