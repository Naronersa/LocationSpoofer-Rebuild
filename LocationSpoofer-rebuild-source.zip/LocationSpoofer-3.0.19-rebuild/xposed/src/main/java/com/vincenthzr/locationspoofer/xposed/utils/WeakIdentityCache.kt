@file:Suppress("unused")

package com.vincenthzr.locationspoofer.xposed.utils

import java.lang.ref.ReferenceQueue
import java.lang.ref.WeakReference

/**
 * 按对象身份（而不是 equals）索引的弱引用缓存。
 * 用于记录每个 SensorEventListener 最近一次收到原生加速度事件的时间，
 * 避免模块强引用目标 App 的 listener 造成泄漏。
 */
class WeakIdentityCache<T> {

    private class Key(referent: Any, queue: ReferenceQueue<Any>?) :
        WeakReference<Any>(referent, queue) {
        private val hash = System.identityHashCode(referent)
        override fun hashCode(): Int = hash
        override fun equals(other: Any?): Boolean =
            other is Key && other.get() === get()
    }

    private val queue = ReferenceQueue<Any>()
    private val values = HashMap<Key, T>()

    @Synchronized
    fun put(key: Any, value: T) {
        clean()
        values[Key(key, queue)] = value
    }

    @Synchronized
    fun get(key: Any): T? {
        clean()
        return values[Key(key, null)]
    }

    private fun clean() {
        while (true) {
            val key = queue.poll() as? Key ?: break
            values.remove(key)
        }
    }
}
