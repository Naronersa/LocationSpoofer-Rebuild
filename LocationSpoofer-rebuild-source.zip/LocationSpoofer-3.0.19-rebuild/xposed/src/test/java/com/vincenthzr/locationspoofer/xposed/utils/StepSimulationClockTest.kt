package com.vincenthzr.locationspoofer.xposed.utils

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class StepSimulationClockTest {

    private fun config(
        speed: Double,
        start: Long,
        cadence: Int = 120,
        active: Boolean = true,
        stepSim: Boolean = true
    ) = JSONObject().apply {
        put("start_timestamp", start)
        put("speed_m_s", speed)
        put("is_auto_cadence", false)
        put("step_cadence_spm", cadence)
        put("active", active)
        put("enable_step_simulation", stepSim)
        put("realism_level", 0)
        put("speed_fluctuation_pct", 0)
        put("altitude_variation_m", 0.0)
    }

    @Test
    fun accumulatesStepsOverTime() {
        val clock = StepSimulationClock()
        val t0 = 1_700_000_000_000L
        val cfg = config(1.4, t0)
        val first = clock.steps(cfg, t0)
        val after10s = clock.steps(cfg, t0 + 10_000)
        assertEquals(20.0, after10s - first, 0.2)
    }

    @Test
    fun configChangeKeepsAccumulatedSteps() {
        val clock = StepSimulationClock()
        val t0 = 1_700_000_000_000L
        val slow = config(1.4, t0)
        clock.steps(slow, t0 + 10_000)
        val atChange = clock.steps(slow, t0 + 20_000)
        val fast = config(3.0, t0)
        val afterChange = clock.steps(fast, t0 + 20_000)
        assertEquals(atChange, afterChange, 0.2)
        val later = clock.steps(fast, t0 + 30_000)
        assertTrue(later > afterChange)
    }

    @Test
    fun stationaryFreezesSteps() {
        val clock = StepSimulationClock()
        val t0 = 1_700_000_000_000L
        val moving = config(1.4, t0)
        clock.steps(moving, t0 + 5_000)
        val still = config(0.0, t0)
        val frozen = clock.steps(still, t0 + 6_000)
        val stillLater = clock.steps(still, t0 + 16_000)
        assertEquals(frozen, stillLater, 0.0)
        val resumed = clock.steps(moving, t0 + 20_000)
        assertTrue(resumed > stillLater)
    }
}
