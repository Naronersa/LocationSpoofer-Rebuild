package com.vincenthzr.locationspoofer.xposed.utils

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class StepEventTimelineTest {

    @Test
    fun expandsIntegerStepsWithInterpolatedTimestamps() {
        val timeline = StepEventTimeline()
        val t0 = 1_000_000_000L
        assertTrue(timeline.sample(10.2, t0).isEmpty())
        val result = timeline.sample(12.2, t0 + 1_000_000_000L)
        assertEquals(2, result.size)
        assertTrue(result[0] in (t0 + 1)..(t0 + 1_000_000_000L))
        assertTrue(result[1] in (t0 + 1)..(t0 + 1_000_000_000L))
        assertTrue(result[0] <= result[1])
    }

    @Test
    fun capsAtNineStepsPerSample() {
        val timeline = StepEventTimeline()
        val t0 = 2_000_000_000L
        timeline.sample(0.0, t0)
        val result = timeline.sample(20.0, t0 + 2_000_000_000L)
        // 官方为 floor(now)-8 .. floor(now) 闭区间，共 9 个
        assertEquals(9, result.size)
    }

    @Test
    fun dropsTimestampsOlderThanTwoSeconds() {
        val timeline = StepEventTimeline()
        val t0 = 3_000_000_000L
        timeline.sample(0.0, t0)
        val result = timeline.sample(2.0, t0 + 5_000_000_000L)
        assertEquals(1, result.size)
        assertTrue(result[0] >= t0 + 3_000_000_000L)
    }

    @Test
    fun noDuplicateWhenStepsDoNotAdvance() {
        val timeline = StepEventTimeline()
        val t0 = 4_000_000_000L
        timeline.sample(5.0, t0)
        assertTrue(timeline.sample(5.0, t0 + 1_000_000_000L).isEmpty())
        assertTrue(timeline.sample(5.0, t0 + 2_000_000_000L).isEmpty())
    }
}
