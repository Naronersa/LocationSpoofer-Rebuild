package com.vincenthzr.locationspoofer.xposed.utils

import com.vincenthzr.locationspoofer.utils.CompassMath
import org.json.JSONObject
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SensorCompassPolicyTest {

    private val heading90 = CompassHeading(
        trueDeg = 90.0,
        magneticDeg = 83.0,
        declinationDeg = 7.0,
        accuracyDeg = 5.0,
    )

    @Test
    fun enabledRequiresActiveAndDefaultTrue() {
        assertFalse(SensorCompassPolicy.enabled(null))
        assertFalse(SensorCompassPolicy.enabled(JSONObject().put("active", false)))

        assertTrue(SensorCompassPolicy.enabled(JSONObject().put("active", true)))
        assertTrue(
            SensorCompassPolicy.enabled(
                JSONObject()
                    .put("active", true)
                    .put("enable_compass_simulation", true)
            )
        )
        assertFalse(
            SensorCompassPolicy.enabled(
                JSONObject()
                    .put("active", true)
                    .put("enable_compass_simulation", false)
            )
        )
    }

    @Test
    fun headingUsesTrueNorthAndAccuracyDegrees() {
        val values = floatArrayOf(0.0f, 0.0f)
        assertTrue(SensorCompassPolicy.render(SensorCompassTypes.HEADING, values, heading90))
        assertArrayEquals(floatArrayOf(90.0f, 5.0f), values, 1e-5f)
    }

    @Test
    fun orientationUsesMagneticNorthAndFlatTilt() {
        val values = floatArrayOf(1.0f, 2.0f, 3.0f)
        assertTrue(SensorCompassPolicy.render(SensorCompassTypes.ORIENTATION, values, heading90))
        assertArrayEquals(floatArrayOf(83.0f, 0.0f, 0.0f), values, 1e-5f)
    }

    @Test
    fun calibratedMagneticFieldKeepsMagnitudeAndVerticalComponent() {
        val north = floatArrayOf(30.0f, 40.0f, -40.0f)
        assertTrue(
            SensorCompassPolicy.render(
                SensorCompassTypes.MAGNETIC_FIELD,
                north,
                CompassHeading(trueDeg = 0.0, magneticDeg = 0.0, declinationDeg = 0.0)
            )
        )
        assertArrayEquals(floatArrayOf(0.0f, 50.0f, -40.0f), north, 1e-4f)

        val east = floatArrayOf(50.0f, 0.0f, -40.0f)
        assertTrue(
            SensorCompassPolicy.render(
                SensorCompassTypes.MAGNETIC_FIELD,
                east,
                CompassHeading(trueDeg = 90.0, magneticDeg = 90.0, declinationDeg = 0.0)
            )
        )
        assertArrayEquals(floatArrayOf(-50.0f, 0.0f, -40.0f), east, 1e-4f)
    }

    @Test
    fun uncalibratedMagneticFieldZeroesHardIronBias() {
        val values = floatArrayOf(30.0f, 40.0f, -40.0f, 1.0f, 2.0f, 3.0f)
        assertTrue(
            SensorCompassPolicy.render(
                SensorCompassTypes.MAGNETIC_FIELD_UNCALIBRATED,
                values,
                CompassHeading(trueDeg = 0.0, magneticDeg = 0.0, declinationDeg = 0.0)
            )
        )
        assertArrayEquals(
            floatArrayOf(0.0f, 50.0f, -40.0f, 0.0f, 0.0f, 0.0f),
            values,
            1e-4f
        )
    }

    @Test
    fun wmmHorizontalAndVerticalStrengthReplaceRawCompassMagnitude() {
        // 中纬度地区典型量级：H≈35µT、WMM Z（向下）≈30µT → 传感器 Z 轴为 -30µT。
        val heading = CompassHeading(
            trueDeg = 90.0,
            magneticDeg = 90.0,
            declinationDeg = 0.0,
            horizontalUt = 35.0,
            verticalUt = 30.0,
        )
        val values = floatArrayOf(1.0f, 2.0f, 3.0f)
        assertTrue(
            SensorCompassPolicy.render(
                SensorCompassTypes.MAGNETIC_FIELD,
                values,
                heading
            )
        )
        assertArrayEquals(floatArrayOf(-35.0f, 0.0f, -30.0f), values, 1e-4f)
    }

    @Test
    fun rotationVectorsUseMagneticYawAndAccuracyRadians() {
        val values = floatArrayOf(0.0f, 0.0f, 0.0f, 1.0f, 0.0f)
        assertTrue(
            SensorCompassPolicy.render(
                SensorCompassTypes.ROTATION_VECTOR,
                values,
                CompassHeading(trueDeg = 90.0, magneticDeg = 90.0, declinationDeg = 0.0)
            )
        )
        assertArrayEquals(
            floatArrayOf(0.0f, 0.0f, -0.7071068f, 0.7071068f, 0.08726646f),
            values,
            1e-5f
        )

        val game = floatArrayOf(0.0f, 0.0f, 0.0f, 1.0f)
        assertTrue(
            SensorCompassPolicy.render(
                SensorCompassTypes.GAME_ROTATION_VECTOR,
                game,
                CompassHeading(trueDeg = 90.0, magneticDeg = 90.0, declinationDeg = 0.0)
            )
        )
        assertArrayEquals(
            floatArrayOf(0.0f, 0.0f, -0.7071068f, 0.7071068f),
            game,
            1e-5f
        )

        val geomagnetic = floatArrayOf(0.0f, 0.0f, 0.0f, 1.0f, 0.3f)
        assertTrue(
            SensorCompassPolicy.render(
                SensorCompassTypes.GEOMAGNETIC_ROTATION_VECTOR,
                geomagnetic,
                CompassHeading(trueDeg = 90.0, magneticDeg = 90.0, declinationDeg = 0.0)
            )
        )
        // 只改写前 4 个；非 TYPE_ROTATION_VECTOR 的第 5 个值保持原样。
        assertArrayEquals(
            floatArrayOf(0.0f, 0.0f, -0.7071068f, 0.7071068f, 0.3f),
            geomagnetic,
            1e-5f
        )
    }

    @Test
    fun rewriteIsIdempotent() {
        val values = floatArrayOf(30.0f, 40.0f, -40.0f)
        assertTrue(SensorCompassPolicy.render(SensorCompassTypes.MAGNETIC_FIELD, values, heading90))
        val first = values.copyOf()
        assertTrue(SensorCompassPolicy.render(SensorCompassTypes.MAGNETIC_FIELD, values, heading90))
        assertArrayEquals(first, values, 1e-6f)
    }

    @Test
    fun invalidHeadingOrShortValuesAreIgnored() {
        val values = floatArrayOf(1.0f, 2.0f)
        assertFalse(
            SensorCompassPolicy.render(
                SensorCompassTypes.ORIENTATION,
                values,
                CompassHeading(Double.NaN, 0.0, 0.0)
            )
        )
        assertFalse(
            SensorCompassPolicy.render(
                SensorCompassTypes.ORIENTATION,
                FloatArray(0),
                heading90
            )
        )
        assertFalse(
            SensorCompassPolicy.render(
                SensorCompassTypes.MAGNETIC_FIELD,
                floatArrayOf(1.0f, 2.0f),
                heading90
            )
        )
    }

    @Test
    fun `west route heading overrides a real device pointing north`() {
        // 真北 270°（正西），WMM 磁偏角 -7.9° → 磁北 277.9°。
        // 这里没有“真实设备朝向”输入，证明指南针完全由模拟路线 bearing 决定。
        val heading = CompassHeading(
            trueDeg = 270.0,
            magneticDeg = 277.9,
            declinationDeg = -7.9,
            accuracyDeg = 5.0,
        )
        val orientation = floatArrayOf(0.0f, 0.0f, 0.0f)
        assertTrue(
            SensorCompassPolicy.render(
                SensorCompassTypes.ORIENTATION,
                orientation,
                heading
            )
        )
        assertEquals(277.9, orientation[0].toDouble(), 1e-4)

        val field = floatArrayOf(30.0f, 40.0f, -40.0f)
        assertTrue(
            SensorCompassPolicy.render(
                SensorCompassTypes.MAGNETIC_FIELD,
                field,
                heading
            )
        )
        val fieldHeading = CompassMath.wrap360(
            Math.toDegrees(kotlin.math.atan2(-field[0].toDouble(), field[1].toDouble()))
        )
        assertEquals(277.9, fieldHeading, 1e-3)
    }
}
