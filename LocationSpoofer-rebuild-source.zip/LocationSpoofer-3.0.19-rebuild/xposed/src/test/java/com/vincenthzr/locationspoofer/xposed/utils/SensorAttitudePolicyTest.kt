package com.vincenthzr.locationspoofer.xposed.utils

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Test
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

/**
 * 验证 6DoF 的 quaternion、orientation、gravity 和磁场使用同一套 Android 约定。
 * 参考 AOSP SensorManager.getRotationMatrixFromVector()/getOrientation()。
 */
class SensorAttitudePolicyTest {

    private data class Quat(val x: Double, val y: Double, val z: Double, val w: Double)

    private fun qz(a: Double) = Quat(0.0, 0.0, sin(a / 2), cos(a / 2))
    private fun qx(a: Double) = Quat(sin(a / 2), 0.0, 0.0, cos(a / 2))
    private fun qy(a: Double) = Quat(0.0, sin(a / 2), 0.0, cos(a / 2))

    private fun mul(a: Quat, b: Quat) = Quat(
        a.w * b.x + a.x * b.w + a.y * b.z - a.z * b.y,
        a.w * b.y - a.x * b.z + a.y * b.w + a.z * b.x,
        a.w * b.z + a.x * b.y - a.y * b.x + a.z * b.w,
        a.w * b.w - a.x * b.x - a.y * b.y - a.z * b.z,
    )

    private fun conjugate(q: Quat) = Quat(-q.x, -q.y, -q.z, q.w)

    private fun rotate(v: FloatArray, q: Quat): FloatArray {
        val p = Quat(v[0].toDouble(), v[1].toDouble(), v[2].toDouble(), 0.0)
        val r = mul(mul(q, p), conjugate(q))
        return floatArrayOf(r.x.toFloat(), r.y.toFloat(), r.z.toFloat())
    }

    /** AOSP getRotationMatrixFromVector + getOrientation. */
    private fun orientation(q: FloatArray): DoubleArray {
        val x = q[0].toDouble()
        val y = q[1].toDouble()
        val z = q[2].toDouble()
        val w = q[3].toDouble()
        val r1 = 2 * (x * y - z * w)
        val r4 = 1 - 2 * (x * x + z * z)
        val r6 = 2 * (x * z - y * w)
        val r7 = 2 * (y * z + x * w)
        val r8 = 1 - 2 * (x * x + y * y)
        return doubleArrayOf(
            Math.toDegrees(atan2(r1, r4)).let { if (it < 0) it + 360 else it },
            Math.toDegrees(asin((-r7).coerceIn(-1.0, 1.0))),
            Math.toDegrees(atan2(-r6, r8)),
        )
    }

    private fun assertNear(expected: Double, actual: Double, tolerance: Double = 0.25) {
        assertEquals(expected, actual, tolerance)
    }

    @Test
    fun quaternionMatchesAndroidOrientationConvention() {
        val cases = listOf(
            Triple(0.0, 0.0, 0.0),
            Triple(90.0, 0.0, 0.0),
            Triple(30.0, 3.0, -2.0),
            Triple(180.0, 5.0, 4.0),
            Triple(270.0, -10.0, 10.0),
        )
        for ((yaw, pitch, roll) in cases) {
            val q = SensorAttitudePolicy.quaternion(
                Math.toRadians(yaw),
                Math.toRadians(pitch),
                Math.toRadians(roll),
            )
            val o = orientation(q)
            assertNear(yaw, o[0])
            assertNear(pitch, o[1])
            assertNear(roll, o[2])
        }
    }

    @Test
    fun quaternionGravityMatchesTiltModel() {
        val pitch = Math.toRadians(4.0)
        val roll = Math.toRadians(-3.0)
        val q = SensorAttitudePolicy.quaternion(0.4, pitch, roll)
        val fromQ = rotate(floatArrayOf(0f, 0f, 9.80665f), conjugate(Quat(
            q[0].toDouble(), q[1].toDouble(), q[2].toDouble(), q[3].toDouble()
        )))
        assertArrayEquals(
            SensorAttitudePolicy.gravityBody(pitch, roll),
            fromQ,
            0.002f,
        )
    }

    @Test
    fun magneticTiltMatchesQuaternion() {
        val yaw = Math.toRadians(35.0)
        val pitch = Math.toRadians(5.0)
        val roll = Math.toRadians(-2.0)
        val q = SensorAttitudePolicy.quaternion(yaw, pitch, roll)
        val world = floatArrayOf(0f, 25f, -30f)
        val fromQ = rotate(world, conjugate(Quat(
            q[0].toDouble(), q[1].toDouble(), q[2].toDouble(), q[3].toDouble()
        )))
        val base = floatArrayOf(
            (-25.0 * sin(yaw)).toFloat(),
            (25.0 * cos(yaw)).toFloat(),
            -30f,
        )
        val fromTilt = SensorAttitudePolicy.rotateTilt(
            base[0].toDouble(), base[1].toDouble(), base[2].toDouble(),
            pitch, roll,
        )
        assertArrayEquals(fromQ, fromTilt, 0.002f)
    }

    @Test
    fun angularVelocityUsesSameQuaternionDerivative() {
        val yawOnly = SensorAttitudePolicy.angularVelocity(
            yawRad = 0.4, pitchRad = 0.0, rollRad = 0.0,
            yawRateRad = 1.0, pitchRateRad = 0.0, rollRateRad = 0.0,
        )
        assertNear(0.0, yawOnly[0].toDouble(), 0.002)
        assertNear(0.0, yawOnly[1].toDouble(), 0.002)
        assertNear(-1.0, yawOnly[2].toDouble(), 0.01)

        val pitchOnly = SensorAttitudePolicy.angularVelocity(
            yawRad = 0.4, pitchRad = 0.05, rollRad = 0.0,
            yawRateRad = 0.0, pitchRateRad = 1.0, rollRateRad = 0.0,
        )
        assertNear(-1.0, pitchOnly[0].toDouble(), 0.01)

        val rollOnly = SensorAttitudePolicy.angularVelocity(
            yawRad = 0.4, pitchRad = 0.0, rollRad = 0.03,
            yawRateRad = 0.0, pitchRateRad = 0.0, rollRateRad = 1.0,
        )
        assertNear(1.0, rollOnly[1].toDouble(), 0.01)

        // 180° 附近 q 与 -q 的符号对齐不能产生角速度尖峰。
        val nearPi = SensorAttitudePolicy.angularVelocity(
            yawRad = Math.PI, pitchRad = 0.0, rollRad = 0.0,
            yawRateRad = 1.0, pitchRateRad = 0.0, rollRateRad = 0.0,
        )
        assertNear(-1.0, nearPi[2].toDouble(), 0.02)
    }

    @Test
    fun orientationSensorUsesPositivePitchAndRoll() {
        val values = FloatArray(3)
        val heading = CompassHeading(
            trueDeg = 40.0,
            magneticDeg = 30.0,
            declinationDeg = 10.0,
            accuracyDeg = 5.0,
            pitchRad = Math.toRadians(4.0),
            rollRad = Math.toRadians(-3.0),
        )
        SensorCompassPolicy.render(SensorCompassTypes.ORIENTATION, values, heading)
        assertNear(30.0, values[0].toDouble())
        assertNear(4.0, values[1].toDouble())
        assertNear(-3.0, values[2].toDouble())
    }
}
