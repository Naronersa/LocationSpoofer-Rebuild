package com.vincenthzr.locationspoofer.xposed.utils

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SensorGyroPolicyTest {

    @Test
    fun writesThreeAxisGyroscope() {
        val values = floatArrayOf(0.0f, 0.0f, 0.0f)
        assertTrue(
            SensorGyroPolicy.render(
                SensorGyroTypes.GYROSCOPE,
                values,
                floatArrayOf(1.2f, -0.4f, 2.5f)
            )
        )
        assertArrayEquals(floatArrayOf(1.2f, -0.4f, 2.5f), values, 0.0f)
    }

    @Test
    fun uncalibratedGyroscopeZeroesBias() {
        val values = floatArrayOf(0.0f, 0.0f, 0.0f, 9.0f, 9.0f, 9.0f)
        assertTrue(
            SensorGyroPolicy.render(
                SensorGyroTypes.GYROSCOPE_UNCALIBRATED,
                values,
                floatArrayOf(0.3f, -0.2f, 1.1f)
            )
        )
        assertArrayEquals(
            floatArrayOf(0.3f, -0.2f, 1.1f, 0.0f, 0.0f, 0.0f),
            values,
            0.0f
        )
    }

    @Test
    fun rejectsShortOrNonFiniteSamples() {
        assertFalse(
            SensorGyroPolicy.render(
                SensorGyroTypes.GYROSCOPE,
                floatArrayOf(0.0f, 0.0f),
                floatArrayOf(1.0f, 2.0f, 3.0f)
            )
        )
        assertFalse(
            SensorGyroPolicy.render(
                SensorGyroTypes.GYROSCOPE,
                floatArrayOf(0.0f, 0.0f, 0.0f),
                floatArrayOf(1.0f, Float.NaN, 3.0f)
            )
        )
    }
}
