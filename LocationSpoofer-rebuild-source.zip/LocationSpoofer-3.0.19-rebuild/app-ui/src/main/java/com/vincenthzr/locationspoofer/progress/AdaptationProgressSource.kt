package com.vincenthzr.locationspoofer.progress

import android.content.Context

/**
 * 适配进度文档来源。
 *
 * 本重建版只使用安装包内置的 ADAPTATION_PROGRESS.md：
 * - 该文档描述本重建版的实际验证状态，不能再用作者仓库 main 分支的官方文档覆盖；
 * - 同时也避免 App 为了显示进度而自动联网。
 */
class AdaptationProgressSource(context: Context) {

    enum class Origin { BUNDLED }

    data class Document(val markdown: String, val origin: Origin)

    private val appContext = context.applicationContext

    fun local(): Document {
        val bundled = runCatching {
            appContext.assets.open(FILE_NAME).bufferedReader().use { it.readText() }
        }.getOrDefault("")
        return Document(bundled, Origin.BUNDLED)
    }

    private companion object {
        const val FILE_NAME = "ADAPTATION_PROGRESS.md"
    }
}
