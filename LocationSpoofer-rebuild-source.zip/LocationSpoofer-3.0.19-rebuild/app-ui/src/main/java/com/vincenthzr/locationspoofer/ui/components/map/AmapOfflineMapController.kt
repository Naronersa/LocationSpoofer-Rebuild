package com.vincenthzr.locationspoofer.ui.components.map

import android.content.Context
import android.os.SystemClock
import com.amap.api.location.AMapLocationClient
import com.amap.api.maps.MapsInitializer
import com.amap.api.maps.offlinemap.OfflineMapCity
import com.amap.api.maps.offlinemap.OfflineMapManager
import com.amap.api.maps.offlinemap.OfflineMapStatus
import com.amap.api.services.core.ServiceSettings
import java.security.MessageDigest
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

enum class AmapOfflineError {
    INIT,
    DOWNLOAD,
    NETWORK,
    STORAGE,
    AMAP,
    REMOVE,
    UNKNOWN
}

data class AmapOfflineCity(
    val name: String,
    val code: String,
    val province: String,
    val pinyin: String,
    val jianpin: String,
    val sizeBytes: Long,
    val state: Int,
    val progress: Int
) {
    val isDownloaded: Boolean
        get() = state == OfflineMapStatus.SUCCESS || state == OfflineMapStatus.NEW_VERSION

    val hasUpdate: Boolean
        get() = state == OfflineMapStatus.NEW_VERSION

    val isBusy: Boolean
        get() = state == OfflineMapStatus.LOADING ||
            state == OfflineMapStatus.UNZIP ||
            state == OfflineMapStatus.WAITING
    // AMap's OfflineMapCity defaults to state CHECKUPDATES (6) for cities that are
    // merely not downloaded; treating it as "busy" hid every Download button and
    // made the whole list look like it was auto-downloading. Only the explicit
    // LOADING/WAITING/UNZIP states mean work is actually in flight.

    val isPaused: Boolean
        get() = state == OfflineMapStatus.PAUSE || state == OfflineMapStatus.STOP

    val isFailed: Boolean
        get() = state == OfflineMapStatus.ERROR ||
            state == OfflineMapStatus.EXCEPTION_NETWORK_LOADING ||
            state == OfflineMapStatus.EXCEPTION_AMAP ||
            state == OfflineMapStatus.EXCEPTION_SDCARD ||
            state == OfflineMapStatus.START_DOWNLOAD_FAILD
}

data class AmapOfflineState(
    val initialized: Boolean = false,
    val loading: Boolean = true,
    val cities: List<AmapOfflineCity> = emptyList(),
    val downloadingCount: Int = 0,
    val error: AmapOfflineError? = null
)

/**
 * 高德官方离线地图（OfflineMapManager）的应用级控制器。
 *
 * - 只持有 applicationContext，管理器在进程存活期间复用，离开页面后下载仍可继续；
 * - Key 只在本类内存中传给高德 SDK，并用 SHA-256 指纹判断是否变化，不写日志、不进入 UI；
 * - 构造失败通常表示 Key 未绑定当前包名/签名；对外只暴露错误类型，不暴露异常文本。
 */
object AmapOfflineMapController {

    private val _state = MutableStateFlow(AmapOfflineState())
    val state: StateFlow<AmapOfflineState> = _state.asStateFlow()

    private var manager: OfflineMapManager? = null
    private var keyFingerprint: String? = null
    private var appContext: Context? = null
    private var lastRefreshAt = 0L

    private val listener = object : OfflineMapManager.OfflineMapDownloadListener {
        override fun onDownload(status: Int, progress: Int, name: String) {
            when (status) {
                OfflineMapStatus.SUCCESS, OfflineMapStatus.NEW_VERSION -> {
                    _state.update { it.copy(error = null) }
                    refresh(force = true)
                }

                OfflineMapStatus.EXCEPTION_NETWORK_LOADING -> {
                    updateCity(name, status, progress)
                    _state.update { it.copy(error = AmapOfflineError.NETWORK) }
                }

                OfflineMapStatus.EXCEPTION_AMAP -> {
                    updateCity(name, status, progress)
                    _state.update { it.copy(error = AmapOfflineError.AMAP) }
                }

                OfflineMapStatus.EXCEPTION_SDCARD -> {
                    updateCity(name, status, progress)
                    _state.update { it.copy(error = AmapOfflineError.STORAGE) }
                }

                OfflineMapStatus.ERROR, OfflineMapStatus.START_DOWNLOAD_FAILD -> {
                    updateCity(name, status, progress)
                    _state.update { it.copy(error = AmapOfflineError.DOWNLOAD) }
                }

                else -> updateCity(name, status, progress)
            }
        }

        override fun onCheckUpdate(success: Boolean, name: String) {
            refresh(force = true)
        }

        override fun onRemove(success: Boolean, name: String, message: String?) {
            if (!success) {
                _state.update { it.copy(error = AmapOfflineError.REMOVE) }
            }
            refresh(force = true)
        }
    }

    /**
     * 用当前运行时 Key 初始化/复用离线管理器。
     * 必须在主线程调用；高德内部会使用应用主 Looper。
     */
    @Synchronized
    fun ensureStarted(context: Context, apiKey: String): Boolean {
        if (apiKey.isBlank()) {
            _state.update {
                it.copy(initialized = false, loading = false, error = AmapOfflineError.INIT)
            }
            return false
        }

        val applicationContext = context.applicationContext
        appContext = applicationContext
        val fingerprint = fingerprint(apiKey)

        if (manager != null && keyFingerprint == fingerprint) {
            refresh(force = true)
            return true
        }

        if (manager != null) {
            runCatching { manager?.destroy() }
            manager = null
        }

        // 认证/刷新城市列表需要网络；若用户启用了“仅离线”，页面会在没有下载任务时再关闭网络。
        runCatching { MapsInitializer.setNetWorkEnable(true) }
        runCatching { MapsInitializer.setApiKey(apiKey) }
        runCatching { AMapLocationClient.setApiKey(apiKey) }
        runCatching { ServiceSettings.getInstance().setApiKey(apiKey) }

        return try {
            val created = OfflineMapManager(applicationContext, listener)
            created.setOnOfflineLoadedListener {
                refresh(force = true)
            }
            manager = created
            keyFingerprint = fingerprint
            _state.update { it.copy(error = null) }
            refresh(force = true)
            // 城市列表可能由高德内部线程稍后填充；补一次延迟刷新。
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(
                { refresh(force = true) },
                1200L
            )
            true
        } catch (t: Throwable) {
            // 不记录异常文本：高德鉴权失败信息可能携带调用上下文，且这里不需要诊断 Key 值。
            manager = null
            _state.update {
                it.copy(initialized = false, loading = false, error = AmapOfflineError.INIT)
            }
            false
        }
    }

    fun refresh(force: Boolean = false) {
        val currentManager = manager ?: return
        val now = SystemClock.elapsedRealtime()
        if (!force && now - lastRefreshAt < 350L) return
        lastRefreshAt = now

        val provinceByCity = HashMap<String, String>()
        runCatching {
            currentManager.offlineMapProvinceList?.forEach { province ->
                val provinceName = province.provinceName ?: ""
                province.cityList?.forEach { city ->
                    provinceByCity[cityKey(city.city, city.code)] = provinceName
                }
            }
        }

        val cities = runCatching {
            currentManager.offlineMapCityList.orEmpty()
                .asSequence()
                .filter { !it.city.isNullOrBlank() }
                .map { city ->
                    AmapOfflineCity(
                        name = city.city,
                        code = city.code ?: "",
                        province = provinceByCity[cityKey(city.city, city.code)] ?: "",
                        pinyin = city.pinyin ?: "",
                        jianpin = city.jianpin ?: "",
                        sizeBytes = city.size,
                        state = city.state,
                        progress = city.getcompleteCode().coerceIn(0, 100)
                    )
                }
                .distinctBy { cityKey(it.name, it.code) }
                .toList()
        }.getOrElse {
            emptyList()
        }

        // Do not trust downloadingCityList for the idle/offline decision: AMap puts
        // not-downloaded cities in CHECKUPDATES and some SDK versions report them as
        // "downloading". Use the normalized city states instead.
        val downloadingCount = cities.count { it.isBusy }

        _state.update {
            it.copy(
                initialized = true,
                loading = false,
                cities = cities,
                downloadingCount = downloadingCount
            )
        }
    }

    fun download(name: String): Boolean {
        val currentManager = manager ?: return false
        // 用户可能刚开启“仅离线”；下载必须先临时恢复网络。
        runCatching { MapsInitializer.setNetWorkEnable(true) }
        return runCatching {
            currentManager.downloadByCityName(name)
            refresh(force = true)
            // 高德回调可能稍后才到；先标记为有下载任务，避免“仅离线”在启动窗口内关闭网络。
            _state.update { it.copy(downloadingCount = maxOf(it.downloadingCount, 1)) }
            true
        }.getOrElse {
            _state.update { state -> state.copy(error = AmapOfflineError.DOWNLOAD) }
            false
        }
    }

    fun update(name: String): Boolean {
        val currentManager = manager ?: return false
        runCatching { MapsInitializer.setNetWorkEnable(true) }
        return runCatching {
            currentManager.updateOfflineCityByName(name)
            refresh(force = true)
            _state.update { it.copy(downloadingCount = maxOf(it.downloadingCount, 1)) }
            true
        }.getOrElse {
            _state.update { state -> state.copy(error = AmapOfflineError.DOWNLOAD) }
            false
        }
    }

    fun pause(name: String) {
        runCatching { manager?.pauseByName(name) }
        refresh(force = true)
    }

    /** “仅离线”页面退出时用：暂停所有进行中的下载，随后可安全断开地图网络。 */
    fun pauseAll() {
        runCatching { manager?.pause() }
        refresh(force = true)
    }

    fun remove(name: String) {
        runCatching { manager?.remove(name) }
        refresh(force = true)
    }

    fun hasActiveDownloads(): Boolean = runCatching {
        manager?.downloadingCityList?.isNotEmpty() == true
    }.getOrDefault(false)

    fun clearError() {
        _state.update { it.copy(error = null) }
    }

    private fun updateCity(name: String, state: Int, progress: Int) {
        _state.update { current ->
            val cities = current.cities.map { city ->
                if (city.name == name) {
                    city.copy(state = state, progress = progress.coerceIn(0, 100))
                } else {
                    city
                }
            }
            current.copy(
                cities = cities,
                downloadingCount = maxOf(
                    cities.count { it.isBusy },
                    if (state == OfflineMapStatus.LOADING ||
                        state == OfflineMapStatus.WAITING ||
                        state == OfflineMapStatus.UNZIP
                    ) 1 else 0
                )
            )
        }
    }

    private fun cityKey(name: String?, code: String?): String {
        val normalizedCode = code?.trim().orEmpty()
        return if (normalizedCode.isNotEmpty()) normalizedCode else name?.trim().orEmpty()
    }

    private fun fingerprint(value: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(value.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }
}
