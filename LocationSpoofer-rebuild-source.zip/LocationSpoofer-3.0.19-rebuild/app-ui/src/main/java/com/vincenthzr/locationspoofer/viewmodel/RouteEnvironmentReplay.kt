package com.vincenthzr.locationspoofer.viewmodel

import android.util.Log
import com.vincenthzr.locationspoofer.data.db.CompleteLocation
import com.vincenthzr.locationspoofer.data.model.RoutePoint
import com.vincenthzr.locationspoofer.data.repository.WifiRepository
import com.vincenthzr.locationspoofer.utils.CoordinateUtils
import com.vincenthzr.locationspoofer.utils.GeoMath
import com.vincenthzr.locationspoofer.utils.MacVendorHelper
import com.vincenthzr.locationspoofer.utils.OpenCellIdClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.log10
import kotlin.math.max

/**
 * 路线环境重放：把本地点位/路线采集数据与 WiGLE/OpenCellID 查询结果合并成
 * 一个按模拟位置变化的 Wi-Fi / 基站快照。
 *
 * 关键点：
 * - 不再把一份 wifi_json 从头用到尾；
 * - 每个 AP/基站记录带一个观测位置和参考信号；
 * - 每次按当前位置计算距离衰减、扫描噪声和 AP 进出；
 * - 没有完整 AP 位置时，用查询点/采集点作为观测位置（保守但一致）。
 */
internal class RouteEnvironmentReplay {

    private data class ApObs(
        val bssid: String,
        val ssid: String,
        val frequency: Int,
        val capabilities: String,
        val vendor: String,
        val lat: Double,
        val lng: Double,
        val refLevel: Int?,
        val local: Boolean
    )

    private data class ConnectedObs(
        val bssid: String,
        val ssid: String,
        val frequency: Int,
        val capabilities: String,
        val vendor: String,
        val macAddress: String,
        val linkSpeed: Int,
        val level: Int,
        val networkId: Int,
        val wifiStandard: Int,
        val lat: Double,
        val lng: Double
    )

    private data class CellObs(
        val type: String,
        val mcc: Int,
        val mnc: Int,
        val tac: Int,
        val lac: Int,
        val ci: Int,
        val cid: Int,
        val pci: Int,
        val psc: Int,
        val nci: Long,
        val networkId: Int,
        val systemId: Int,
        val basestationId: Int,
        val refDbm: Int,
        val lat: Double,
        val lng: Double,
        val local: Boolean
    )

    private val wifi = ArrayList<ApObs>()
    private val connected = ArrayList<ConnectedObs>()
    private val cells = ArrayList<CellObs>()

    fun reset() {
        wifi.clear()
        connected.clear()
        cells.clear()
    }

    fun summary(): String =
        "wifi=${wifi.size} connected=${connected.size} cells=${cells.size}"

    /** 加入点位/路线采集数据。AP/基站观测位置使用采集点，参考信号使用采集到的 level/dbm。 */
    fun addLocal(records: List<CompleteLocation>) {
        for (rec in records) {
            // 点位/路线记录的经纬度来自地图坐标（国内通常为 GCJ-02）；
            // WiGLE/OpenCellID 都是 WGS-84，统一后再做距离衰减。
            val wgs = CoordinateUtils.gcj02ToWgs84(rec.location.lat, rec.location.lng)
            val lat = wgs.lat
            val lng = wgs.lng
            rec.wifis.forEach { lw ->
                val d = lw.device
                wifi.add(
                    ApObs(
                        bssid = d.bssid,
                        ssid = d.ssid.ifBlank { "WIFI_${d.bssid.takeLast(5).replace(":", "")}" },
                        frequency = d.frequency,
                        capabilities = d.capabilities,
                        vendor = d.vendor,
                        lat = lat,
                        lng = lng,
                        refLevel = lw.locationWifi.level,
                        local = true
                    )
                )
            }
            rec.connectedWifi?.let { cw ->
                connected.add(
                    ConnectedObs(
                        bssid = cw.bssid,
                        ssid = cw.ssid,
                        frequency = cw.frequency,
                        capabilities = cw.capabilities,
                        vendor = cw.vendor,
                        macAddress = cw.macAddress,
                        linkSpeed = cw.linkSpeed,
                        level = cw.level,
                        networkId = cw.networkId,
                        wifiStandard = cw.wifiStandard,
                        lat = lat,
                        lng = lng
                    )
                )
            }
            rec.cells.forEach { lc ->
                val d = lc.device
                cells.add(
                    CellObs(
                        type = d.type,
                        mcc = d.mcc,
                        mnc = d.mnc,
                        tac = d.tac,
                        lac = d.lac,
                        ci = d.ci,
                        cid = d.cid,
                        pci = d.pci,
                        psc = d.psc,
                        nci = d.nci,
                        networkId = d.networkId,
                        systemId = d.systemId,
                        basestationId = d.basestationId,
                        refDbm = lc.locationCell.dbm,
                        lat = lat,
                        lng = lng,
                        local = true
                    )
                )
            }
        }
    }

    /**
     * 加入 WiGLE 结果。优先使用 trilat/trilong 作为 AP 观测位置；
     * 缺失时才退回查询点（调用方已把查询点转换为 WGS-84）。
     */
    fun addWigleJson(raw: String, queryLat: Double, queryLng: Double): Int {
        var added = 0
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val item = arr.optJSONObject(i) ?: continue
                val bssid = item.optString("bssid").trim()
                if (bssid.isBlank()) continue
                val ssid = item.optString("ssid").ifBlank {
                    "WIFI_${bssid.takeLast(5).replace(":", "")}"
                }
                val freq = item.optInt("frequency", 2412)
                val apLat = item.optDouble("lat", Double.NaN)
                    .takeIf { it.isFinite() && it in -90.0..90.0 } ?: queryLat
                val apLng = item.optDouble("lng", Double.NaN)
                    .takeIf { it.isFinite() && it in -180.0..180.0 } ?: queryLng
                wifi.add(
                    ApObs(
                        bssid = bssid,
                        ssid = ssid,
                        frequency = freq,
                        capabilities = item.optString("capabilities", "[WPA2-PSK-CCMP][ESS]"),
                        vendor = MacVendorHelper.getVendor(bssid),
                        lat = apLat,
                        lng = apLng,
                        refLevel = null,
                        local = false
                    )
                )
                added++
            }
        } catch (_: Throwable) {}
        return added
    }

    /** 加入 OpenCellID 结果；只保留可构造 CellInfo 的身份字段。 */
    fun addOpenCellIdJson(raw: String, queryLat: Double, queryLng: Double): Int {
        var added = 0
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val item = arr.optJSONObject(i) ?: continue
                val area = item.optInt("tac", item.optInt("lac", 0))
                val cid = item.optInt("ci", item.optInt("cid", 0))
                if (area <= 0 || cid <= 0) continue
                val cellLat = item.optDouble("lat", Double.NaN)
                    .takeIf { it.isFinite() && it in -90.0..90.0 } ?: queryLat
                val cellLng = item.optDouble("lon", item.optDouble("lng", Double.NaN))
                    .takeIf { it.isFinite() && it in -180.0..180.0 } ?: queryLng
                cells.add(
                    CellObs(
                        type = item.optString("type", "LTE"),
                        mcc = item.optInt("mcc", 460),
                        mnc = item.optInt("mnc", 0),
                        tac = item.optInt("tac", area),
                        lac = item.optInt("lac", area),
                        ci = item.optInt("ci", cid),
                        cid = item.optInt("cid", cid),
                        pci = item.optInt("pci", 0),
                        psc = item.optInt("psc", 0),
                        nci = item.optLong("nci", 0),
                        networkId = item.optInt("networkId", 0),
                        systemId = item.optInt("systemId", 0),
                        basestationId = item.optInt("basestationId", 0),
                        refDbm = item.optInt("dbm", -85),
                        lat = cellLat,
                        lng = cellLng,
                        local = false
                    )
                )
                added++
            }
        } catch (_: Throwable) {}
        return added
    }

    /** 路线起点的本地环境准备；可同步调用，让模拟不必等网络。 */
    fun prepareLocal(points: List<RoutePoint>, localRecords: List<CompleteLocation>) {
        reset()
        addLocal(filterLocalToRoute(localRecords, points))
        Log.i(
            TAG,
            "local prepared: points=${points.size} local=${localRecords.size} " +
                "localWifi=${wifi.size} localCells=${cells.size}"
        )
    }

    /**
     * 路线预取：本地记录立即生效，WiGLE/OpenCellID 在后台逐点补充。
     * 数组只在调用方（主线程）修改，网络请求单独切到 IO，避免与路线刷新并发读写。
     */
    suspend fun prefetch(
        points: List<RoutePoint>,
        localRecords: List<CompleteLocation>,
        wifiRepository: WifiRepository,
        openCellIdClient: OpenCellIdClient,
        wigleToken: String,
        openCellIdToken: String
    ) {
        prepareLocal(points, localRecords)
        if (points.isEmpty()) return

        val samples = sampleRoute(points, 120.0, maxSamples = 6)
        var wigleAdded = 0
        var cellAdded = 0
        var wigleUsable = wigleToken.isNotBlank()
        var cellUsable = openCellIdToken.isNotBlank()
        Log.i(
            TAG,
            "prefetch start: samples=${samples.size} " +
                "wigle=$wigleUsable opencellid=$cellUsable"
        )
        for (p in samples) {
            // WiGLE/OpenCellID 使用 WGS-84；地图路线点通常是 GCJ-02。
            val wgs = CoordinateUtils.gcj02ToWgs84(p.lat, p.lng)
            if (wigleUsable) {
                val raw = withContext(Dispatchers.IO) {
                    try {
                        wifiRepository.fetchWifiData(wgs.lat, wgs.lng, wigleToken)
                    } catch (e: Throwable) {
                        Log.w(TAG, "WiGLE sample failed: ${e.javaClass.simpleName}")
                        ""
                    }
                }
                if (raw.isBlank() || raw == "[]") {
                    // 网络不可达/无数据时不继续为每个采样点重复等待超时。
                    wigleUsable = false
                } else {
                    wigleAdded += addWigleJson(raw, wgs.lat, wgs.lng)
                }
            }
            if (cellUsable) {
                val raw = withContext(Dispatchers.IO) {
                    try {
                        openCellIdClient.fetchCellData(wgs.lat, wgs.lng, openCellIdToken)
                    } catch (e: Throwable) {
                        Log.w(TAG, "OpenCellID sample failed: ${e.javaClass.simpleName}")
                        ""
                    }
                }
                if (raw.isBlank() || raw == "[]") {
                    cellUsable = false
                } else {
                    cellAdded += addOpenCellIdJson(raw, wgs.lat, wgs.lng)
                }
            }
            if (!wigleUsable && !cellUsable) break
        }
        Log.i(
            TAG,
            "prefetch done: wigleAdded=$wigleAdded cellAdded=$cellAdded " +
                "totalWifi=${wifi.size} totalCells=${cells.size}"
        )
    }

    /** 按当前模拟位置生成 Wi-Fi JSON；每次调用 RSSI 都会随位置/时间轻微变化。 */
    fun buildWifiJson(lat: Double, lng: Double, timeMs: Long = System.currentTimeMillis()): String {
        val wgs = CoordinateUtils.gcj02ToWgs84(lat, lng)
        val current = CoordinateUtils.LatLng(wgs.lat, wgs.lng)
        val best = LinkedHashMap<String, JSONObject>()
        for (obs in wifi) {
            val d = max(1.0, GeoMath.distance(
                current,
                com.vincenthzr.locationspoofer.utils.CoordinateUtils.LatLng(obs.lat, obs.lng)
            ))
            val base = obs.refLevel ?: -38
            val refDist = if (obs.refLevel != null) 10.0 else 1.0
            val pathLoss = 10.0 * 2.4 * log10(max(d, 1.0) / refDist)
            val slowFade = 1.6 * kotlin.math.sin(timeMs / 7000.0 + obs.bssid.hashCode() * 0.001)
            val scanNoise = ((obs.bssid.hashCode() + (timeMs / 1000).toInt()) % 5 - 2) * 0.8
            val level = (base - pathLoss + slowFade + scanNoise).toInt().coerceIn(-92, -28)
            if (level < -92) continue
            val obj = JSONObject().apply {
                put("bssid", obs.bssid)
                put("ssid", obs.ssid)
                put("vendor", obs.vendor)
                put("frequency", obs.frequency)
                put("channel", MacVendorHelper.frequencyToChannel(obs.frequency))
                put("capabilities", obs.capabilities)
                put("level", level)
            }
            val previous = best[obs.bssid]
            if (previous == null || level > previous.optInt("level", -999)) {
                best[obs.bssid] = obj
            }
        }

        val nearby = JSONArray()
        best.values.sortedByDescending { it.optInt("level", -999) }
            .take(10)
            .forEach { nearby.put(it) }

        var connectedObj: JSONObject? = null
        val nearConnected = connected
            .map { c ->
                c to GeoMath.distance(
                    current,
                    com.vincenthzr.locationspoofer.utils.CoordinateUtils.LatLng(c.lat, c.lng)
                )
            }
            .filter { it.second <= 60.0 }
            .minByOrNull { it.second }
            ?.first
        if (nearConnected != null) {
            val level = (nearConnected.level - 8.0 * log10(max(1.0, GeoMath.distance(
                current,
                com.vincenthzr.locationspoofer.utils.CoordinateUtils.LatLng(nearConnected.lat, nearConnected.lng)
            )) / 10.0)).toInt().coerceIn(-90, -30)
            connectedObj = JSONObject().apply {
                put("bssid", nearConnected.bssid)
                put("ssid", nearConnected.ssid)
                put("vendor", nearConnected.vendor)
                put("macAddress", nearConnected.macAddress)
                put("frequency", nearConnected.frequency)
                put("channel", MacVendorHelper.frequencyToChannel(nearConnected.frequency))
                put("linkSpeed", nearConnected.linkSpeed)
                put("level", level)
                put("capabilities", nearConnected.capabilities)
                put("networkId", nearConnected.networkId)
                put("wifiStandard", nearConnected.wifiStandard)
            }
            // 连接 AP 必须出现在扫描列表中。
            if (nearby.length() == 0 || (0 until nearby.length()).none {
                    nearby.optJSONObject(it)?.optString("bssid")
                        ?.equals(nearConnected.bssid, ignoreCase = true) == true
                }
            ) {
                nearby.put(JSONObject().apply {
                    put("bssid", nearConnected.bssid)
                    put("ssid", nearConnected.ssid)
                    put("vendor", nearConnected.vendor)
                    put("frequency", nearConnected.frequency)
                    put("channel", MacVendorHelper.frequencyToChannel(nearConnected.frequency))
                    put("capabilities", nearConnected.capabilities)
                    put("level", level)
                })
            }
        }

        if (nearby.length() == 0 && connectedObj == null) return "{}"
        return JSONObject().apply {
            put("isConnected", connectedObj != null)
            put("connectedWifi", connectedObj ?: JSONObject.NULL)
            put("nearbyWifi", nearby)
        }.toString()
    }

    /** 按当前模拟位置生成基站 JSON。 */
    fun buildCellJson(lat: Double, lng: Double, timeMs: Long = System.currentTimeMillis()): String {
        val wgs = CoordinateUtils.gcj02ToWgs84(lat, lng)
        val current = CoordinateUtils.LatLng(wgs.lat, wgs.lng)
        val best = LinkedHashMap<String, JSONObject>()
        for (obs in cells) {
            val d = max(1.0, GeoMath.distance(
                current,
                com.vincenthzr.locationspoofer.utils.CoordinateUtils.LatLng(obs.lat, obs.lng)
            ))
            if (d > 800.0) continue
            val refDist = if (obs.local) 10.0 else 1.0
            val pathLoss = 10.0 * 2.8 * log10(d / refDist)
            val fade = 1.2 * kotlin.math.sin(timeMs / 9000.0 + obs.ci * 0.01)
            val dbm = (obs.refDbm - pathLoss + fade).toInt().coerceIn(-125, -40)
            val key = "${obs.mcc}-${obs.mnc}-${obs.tac}-${obs.ci}-${obs.type}"
            val obj = JSONObject().apply {
                put("type", obs.type)
                put("mcc", obs.mcc)
                put("mnc", obs.mnc)
                put("tac", obs.tac)
                put("lac", obs.lac)
                put("ci", obs.ci)
                put("cid", obs.cid)
                put("pci", obs.pci)
                put("psc", obs.psc)
                put("nci", obs.nci)
                put("networkId", obs.networkId)
                put("systemId", obs.systemId)
                put("basestationId", obs.basestationId)
                put("dbm", dbm)
                put("isRegistered", false)
            }
            val previous = best[key]
            if (previous == null || dbm > previous.optInt("dbm", -999)) best[key] = obj
        }

        val arr = JSONArray()
        best.values.sortedByDescending { it.optInt("dbm", -999) }
            .take(6)
            .forEachIndexed { index, obj ->
                obj.put("isRegistered", index == 0)
                arr.put(obj)
            }
        return arr.toString()
    }

    private fun filterLocalToRoute(
        records: List<CompleteLocation>,
        points: List<RoutePoint>
    ): List<CompleteLocation> {
        if (records.isEmpty() || points.isEmpty()) return emptyList()
        val minLat = points.minOf { it.lat } - 0.01
        val maxLat = points.maxOf { it.lat } + 0.01
        val minLng = points.minOf { it.lng } - 0.01
        val maxLng = points.maxOf { it.lng } + 0.01
        return records.filter {
            it.location.lat in minLat..maxLat && it.location.lng in minLng..maxLng
        }
    }

    private fun sampleRoute(
        points: List<RoutePoint>,
        spacingMeters: Double,
        maxSamples: Int
    ): List<RoutePoint> {
        if (points.isEmpty()) return emptyList()
        val out = ArrayList<RoutePoint>()
        out.add(points.first())
        var travelled = 0.0
        for (i in 1 until points.size) {
            val a = points[i - 1]
            val b = points[i]
            travelled += GeoMath.distance(
                com.vincenthzr.locationspoofer.utils.CoordinateUtils.LatLng(a.lat, a.lng),
                com.vincenthzr.locationspoofer.utils.CoordinateUtils.LatLng(b.lat, b.lng)
            )
            if (travelled >= spacingMeters) {
                if (out.size < maxSamples) out.add(b)
                travelled = 0.0
            }
        }
        if (out.last().lat != points.last().lat || out.last().lng != points.last().lng) {
            if (out.size < maxSamples) out.add(points.last())
        }
        return out
    }

    private companion object {
        const val TAG = "EnvReplay"
    }
}
