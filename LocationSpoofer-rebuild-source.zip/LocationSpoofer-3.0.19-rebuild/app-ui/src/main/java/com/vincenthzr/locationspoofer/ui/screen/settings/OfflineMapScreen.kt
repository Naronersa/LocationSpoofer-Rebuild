package com.vincenthzr.locationspoofer.ui.screen.settings

import android.content.Context
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Clear
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.amap.api.maps.MapsInitializer
import com.amap.api.maps.offlinemap.OfflineMapStatus
import com.vincenthzr.locationspoofer.data.model.AppState
import com.vincenthzr.locationspoofer.ui.R
import com.vincenthzr.locationspoofer.ui.components.map.AmapOfflineCity
import com.vincenthzr.locationspoofer.ui.components.map.AmapOfflineError
import com.vincenthzr.locationspoofer.ui.components.map.AmapOfflineMapController
import com.vincenthzr.locationspoofer.ui.theme.AccentBlue
import com.vincenthzr.locationspoofer.ui.theme.AccentGreen
import com.vincenthzr.locationspoofer.ui.theme.AccentOrange
import com.vincenthzr.locationspoofer.ui.theme.AppColors
import com.vincenthzr.locationspoofer.ui.theme.noRippleClickable
import com.vincenthzr.locationspoofer.viewmodel.MainViewModel
import com.vincenthzr.locationspoofer.viewmodel.setAmapOfflineOnly
import java.util.Locale

@Composable
fun OfflineMapScreen(
    viewModel: MainViewModel,
    uiState: AppState,
    isDark: Boolean = isSystemInDarkTheme(),
    onClose: () -> Unit,
    onOpenMapSettings: () -> Unit
) {
    val context = LocalContext.current
    val offlineState by AmapOfflineMapController.state.collectAsState()
    val hasKey = uiState.amapApiKey.isNotBlank()
    var query by rememberSaveable { mutableStateOf("") }
    var retryToken by remember { mutableIntStateOf(0) }
    var pendingDelete by remember { mutableStateOf<AmapOfflineCity?>(null) }
    val latestOfflineOnly by rememberUpdatedState(uiState.amapOfflineOnly)

    BackHandler(onBack = onClose)

    // 进入页面先允许认证/刷新城市列表；仅离线模式在没有下载任务时再关闭网络。
    DisposableEffect(Unit) {
        runCatching { MapsInitializer.setNetWorkEnable(true) }
        onDispose {
            runCatching {
                if (latestOfflineOnly) {
                    if (AmapOfflineMapController.hasActiveDownloads()) {
                        AmapOfflineMapController.pauseAll()
                    }
                    MapsInitializer.setNetWorkEnable(false)
                } else {
                    MapsInitializer.setNetWorkEnable(true)
                }
            }
        }
    }

    LaunchedEffect(uiState.amapApiKey, retryToken) {
        if (uiState.amapApiKey.isNotBlank()) {
            AmapOfflineMapController.ensureStarted(context.applicationContext, uiState.amapApiKey)
        }
    }

    // 仅离线时，页面空闲就关掉地图 SDK 的网络，避免它在后台自动下载在线底图/资源。
    // 手动点“下载/更新”时 AmapOfflineMapController.download() 会临时恢复网络，
    // 并把 downloadingCount 置为非 0；下载结束后这里再关掉。
    // 首次进入或城市列表尚未加载时先保持联网，否则新设备永远拿不到城市列表。
    LaunchedEffect(
        uiState.amapOfflineOnly,
        offlineState.downloadingCount,
        offlineState.initialized,
        offlineState.cities.size
    ) {
        runCatching {
            val needNetwork = !uiState.amapOfflineOnly ||
                offlineState.downloadingCount > 0 ||
                !offlineState.initialized ||
                offlineState.cities.isEmpty()
            MapsInitializer.setNetWorkEnable(needNetwork)
        }
    }

    LaunchedEffect(offlineState.error) {
        val error = offlineState.error ?: return@LaunchedEffect
        Toast.makeText(context, offlineErrorMessage(context, error), Toast.LENGTH_LONG).show()
        // 初始化失败要在页面上保留错误卡片；其他临时错误弹一次后清除。
        if (error != AmapOfflineError.INIT) {
            AmapOfflineMapController.clearError()
        }
    }

    pendingDelete?.let { city ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text(stringResource(R.string.offline_map_delete_title)) },
            text = {
                Text(stringResource(R.string.offline_map_delete_confirm, city.name))
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        AmapOfflineMapController.remove(city.name)
                        pendingDelete = null
                    }
                ) {
                    Text(stringResource(R.string.offline_map_delete), color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingDelete = null }) {
                    Text(stringResource(R.string.offline_map_cancel))
                }
            }
        )
    }

    val filteredCities = remember(offlineState.cities, query) {
        val normalized = query.trim().lowercase(Locale.ROOT)
        val filtered = if (normalized.isEmpty()) {
            offlineState.cities
        } else {
            offlineState.cities.filter { city ->
                city.name.lowercase(Locale.ROOT).contains(normalized) ||
                    city.pinyin.lowercase(Locale.ROOT).contains(normalized) ||
                    city.jianpin.lowercase(Locale.ROOT).contains(normalized) ||
                    city.province.lowercase(Locale.ROOT).contains(normalized)
            }
        }
        filtered.sortedWith(
            compareBy<AmapOfflineCity>(
                { if (it.isDownloaded || it.isBusy || it.isPaused || it.isFailed) 0 else 1 },
                { it.pinyin.ifBlank { it.name } }
            )
        )
    }

    val downloadedCount = remember(offlineState.cities) {
        offlineState.cities.count { it.isDownloaded }
    }
    val downloadedBytes = remember(offlineState.cities) {
        offlineState.cities.filter { it.isDownloaded }.sumOf { it.sizeBytes }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(AppColors.background(isDark))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .shadow(elevation = 6.dp, shape = CircleShape, clip = false)
                        .clip(CircleShape)
                        .background(if (isDark) Color(0xFF22272E) else Color.White)
                        .border(
                            width = 1.dp,
                            color = if (isDark) {
                                Color.White.copy(alpha = 0.14f)
                            } else {
                                Color(0xFFE5E8EC)
                            },
                            shape = CircleShape
                        )
                        .noRippleClickable(onClick = onClose),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                        contentDescription = stringResource(R.string.back),
                        tint = if (isDark) Color.White else Color(0xFF1A1D20),
                        modifier = Modifier.size(21.dp)
                    )
                }

                Spacer(Modifier.width(14.dp))

                Column {
                    Text(
                        text = stringResource(R.string.offline_map_title),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = stringResource(R.string.offline_map_subtitle),
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                    )
                }
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (!hasKey) {
                    item {
                        SettingsCard(isDark) {
                            Text(
                                text = stringResource(R.string.offline_map_key_missing_title),
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(Modifier.height(6.dp))
                            Text(
                                text = stringResource(R.string.offline_map_key_missing_desc),
                                fontSize = 12.sp,
                                lineHeight = 17.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                            Spacer(Modifier.height(8.dp))
                            Text(
                                text = stringResource(
                                    R.string.offline_map_key_binding_desc,
                                    context.packageName
                                ),
                                fontSize = 11.5.sp,
                                lineHeight = 16.sp,
                                color = AccentOrange
                            )
                            Spacer(Modifier.height(10.dp))
                            TextButton(onClick = onOpenMapSettings) {
                                Text(stringResource(R.string.offline_map_open_settings))
                            }
                        }
                    }
                }

                item {
                    SettingsCard(isDark) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = stringResource(R.string.offline_map_only_title),
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(Modifier.height(3.dp))
                                Text(
                                    text = stringResource(R.string.offline_map_only_desc),
                                    fontSize = 11.5.sp,
                                    lineHeight = 16.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f)
                                )
                            }
                            Spacer(Modifier.width(12.dp))
                            Switch(
                                checked = uiState.amapOfflineOnly,
                                onCheckedChange = { viewModel.setAmapOfflineOnly(it) }
                            )
                        }
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = stringResource(
                                    R.string.offline_map_summary,
                                    offlineState.cities.size,
                                    downloadedCount,
                                    formatSize(downloadedBytes)
                                ),
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.55f)
                            )
                            if (hasKey) {
                                Text(
                                    text = stringResource(R.string.offline_map_key_ready),
                                    fontSize = 11.sp,
                                    color = AccentGreen
                                )
                            }
                        }
                        IconButton(
                            onClick = {
                                AmapOfflineMapController.refresh(force = true)
                            },
                            enabled = hasKey
                        ) {
                            Icon(
                                Icons.Rounded.Refresh,
                                contentDescription = stringResource(R.string.offline_map_refresh),
                                tint = AccentBlue
                            )
                        }
                        TextButton(
                            onClick = { retryToken++ },
                            enabled = hasKey
                        ) {
                            Text(stringResource(R.string.offline_map_refresh))
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text(stringResource(R.string.offline_map_search_hint)) },
                        leadingIcon = {
                            Icon(Icons.Rounded.Search, contentDescription = null)
                        },
                        trailingIcon = {
                            if (query.isNotEmpty()) {
                                IconButton(onClick = { query = "" }) {
                                    Icon(
                                        Icons.Rounded.Clear,
                                        contentDescription = stringResource(R.string.offline_map_clear_search)
                                    )
                                }
                            }
                        },
                        singleLine = true,
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                            imeAction = ImeAction.Search
                        ),
                        shape = RoundedCornerShape(14.dp)
                    )
                }

                if (hasKey && offlineState.error == AmapOfflineError.INIT) {
                    item {
                        SettingsCard(isDark) {
                            Text(
                                text = stringResource(R.string.offline_map_auth_failed),
                                fontSize = 12.5.sp,
                                lineHeight = 18.sp,
                                color = MaterialTheme.colorScheme.error
                            )
                            Spacer(Modifier.height(6.dp))
                            Text(
                                text = stringResource(
                                    R.string.offline_map_key_binding_desc,
                                    context.packageName
                                ),
                                fontSize = 11.5.sp,
                                lineHeight = 16.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f)
                            )
                            Spacer(Modifier.height(8.dp))
                            TextButton(onClick = { retryToken++ }) {
                                Text(stringResource(R.string.offline_map_retry))
                            }
                        }
                    }
                }

                if (hasKey && offlineState.loading && offlineState.cities.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 40.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                CircularProgressIndicator(color = AccentBlue)
                                Spacer(Modifier.height(12.dp))
                                Text(
                                    text = stringResource(R.string.offline_map_loading),
                                    fontSize = 12.5.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f)
                                )
                            }
                        }
                    }
                } else if (hasKey && filteredCities.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 32.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = stringResource(R.string.offline_map_empty),
                                fontSize = 12.5.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f)
                            )
                        }
                    }
                }

                items(filteredCities, key = { "${it.code}|${it.name}" }) { city ->
                    OfflineCityCard(
                        city = city,
                        isDark = isDark,
                        onDownload = { AmapOfflineMapController.download(city.name) },
                        onPause = { AmapOfflineMapController.pause(city.name) },
                        onUpdate = { AmapOfflineMapController.update(city.name) },
                        onDelete = { pendingDelete = city }
                    )
                }

                item {
                    Spacer(Modifier.height(20.dp))
                }
            }
        }
    }
}

@Composable
private fun SettingsCard(
    isDark: Boolean,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isDark) Color(0xFF1C2026) else Color.White
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            content = content
        )
    }
}

@Composable
private fun OfflineCityCard(
    city: AmapOfflineCity,
    isDark: Boolean,
    onDownload: () -> Unit,
    onPause: () -> Unit,
    onUpdate: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(15.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isDark) Color(0xFF1C2026) else Color.White
        )
    ) {
        Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = city.name,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        text = listOfNotNull(
                            city.province.takeIf { it.isNotBlank() },
                            city.sizeBytes.takeIf { it > 0 }?.let { formatSize(it) }
                        ).joinToString(" · "),
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                    )
                }
                Spacer(Modifier.width(10.dp))
                CityStatusChip(city)
            }

            if (city.isBusy) {
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { (city.progress.coerceIn(0, 100)) / 100f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(5.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = AccentBlue,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                )
            }

            Spacer(Modifier.height(2.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                when {
                    city.isBusy -> {
                        TextButton(onClick = onPause) {
                            Text(stringResource(R.string.offline_map_pause))
                        }
                    }

                    city.hasUpdate -> {
                        TextButton(onClick = onUpdate) {
                            Text(stringResource(R.string.offline_map_update))
                        }
                        TextButton(onClick = onDelete) {
                            Text(
                                stringResource(R.string.offline_map_delete),
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }

                    city.isDownloaded -> {
                        TextButton(onClick = onDelete) {
                            Text(
                                stringResource(R.string.offline_map_delete),
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }

                    city.isPaused -> {
                        TextButton(onClick = onDownload) {
                            Text(stringResource(R.string.offline_map_resume))
                        }
                        TextButton(onClick = onDelete) {
                            Text(
                                stringResource(R.string.offline_map_delete),
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }

                    city.isFailed -> {
                        TextButton(onClick = onDownload) {
                            Text(stringResource(R.string.offline_map_retry))
                        }
                        TextButton(onClick = onDelete) {
                            Text(
                                stringResource(R.string.offline_map_delete),
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }

                    else -> {
                        TextButton(onClick = onDownload) {
                            Text(
                                stringResource(R.string.offline_map_download),
                                color = AccentBlue,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CityStatusChip(city: AmapOfflineCity) {
    val (label, color) = when {
        city.state == OfflineMapStatus.SUCCESS -> {
            stringResource(R.string.offline_map_downloaded) to AccentGreen
        }

        city.state == OfflineMapStatus.NEW_VERSION -> {
            stringResource(R.string.offline_map_update_available) to AccentOrange
        }

        city.state == OfflineMapStatus.LOADING -> {
            stringResource(R.string.offline_map_downloading, city.progress) to AccentBlue
        }

        city.state == OfflineMapStatus.WAITING -> {
            stringResource(R.string.offline_map_waiting) to AccentBlue
        }

        city.state == OfflineMapStatus.UNZIP -> {
            stringResource(R.string.offline_map_unzipping) to AccentBlue
        }

        city.state == OfflineMapStatus.PAUSE || city.state == OfflineMapStatus.STOP -> {
            stringResource(R.string.offline_map_paused) to MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
        }

        city.isFailed -> {
            stringResource(R.string.offline_map_failed) to MaterialTheme.colorScheme.error
        }

        else -> {
            stringResource(R.string.offline_map_not_downloaded) to MaterialTheme.colorScheme.onSurface.copy(alpha = 0.45f)
        }
    }

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(7.dp))
            .background(color.copy(alpha = 0.12f))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(
            text = label,
            fontSize = 10.5.sp,
            fontWeight = FontWeight.SemiBold,
            color = color
        )
    }
}

private fun formatSize(bytes: Long): String {
    if (bytes <= 0L) return "0 MB"
    val mb = bytes / (1024.0 * 1024.0)
    return String.format(Locale.US, "%.1f MB", mb)
}

private fun offlineErrorMessage(context: Context, error: AmapOfflineError): String = when (error) {
    AmapOfflineError.INIT -> context.getString(R.string.offline_map_auth_failed)
    AmapOfflineError.NETWORK -> context.getString(R.string.offline_map_error_network)
    AmapOfflineError.STORAGE -> context.getString(R.string.offline_map_error_storage)
    AmapOfflineError.AMAP, AmapOfflineError.DOWNLOAD -> context.getString(R.string.offline_map_error_request)
    AmapOfflineError.REMOVE -> context.getString(R.string.offline_map_error_remove)
    AmapOfflineError.UNKNOWN -> context.getString(R.string.offline_map_error_generic)
}
