package com.vincenthzr.locationprobe

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 独立定位/反虚拟定位探针。
 *
 * 使用方式：
 *  1. 授予位置、电话、WiFi、蓝牙、活动识别权限；
 *  2. 点“开始采集”，允许 KernelSU/Magisk 的 su 授权；
 *  3. 采集完成后 JSON 自动保存到应用外部目录，也可再次点“导出 JSON”。
 *
 * adb 测试：
 *  adb shell am start -n com.vincenthzr.locationprobe/.MainActivity \
 *      --ez auto_start true --el 30000 duration_ms 8000
 */
class MainActivity : Activity() {

    private lateinit var statusView: TextView
    private lateinit var startButton: Button
    private lateinit var exportButton: Button
    private var collector: ProbeCollector? = null
    private var collecting = false
    private var pendingStartAfterPermission = false
    private var lastJson: String? = null
    private var selectedDurationMs = 60_000L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 32, 40, 32)
        }
        root.addView(TextView(this).apply {
            text = "Location Probe"
            textSize = 24f
            gravity = Gravity.START
        })
        root.addView(TextView(this).apply {
            text = "框架层：位置/GNSS原始测量/NMEA/传感器/WiFi/基站/蓝牙/网络。\n" +
                "系统层：自动 su + dumpsys/appops/proc/sysfs/getprop。\n" +
                "结果只保存在本机，APK 没有 INTERNET 权限。"
            textSize = 13f
            setPadding(0, 10, 0, 10)
        })

        val durationRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, 12)
        }
        durationRow.addView(TextView(this).apply {
            text = "采集时长："
            textSize = 14f
        })
        val durationOptions = listOf(30L to "30 秒", 60L to "60 秒", 120L to "120 秒", 300L to "300 秒")
        val durationSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                durationOptions.map { it.second }
            )
            setSelection(1)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                    selectedDurationMs = durationOptions[position].first * 1000L
                }

                override fun onNothingSelected(parent: AdapterView<*>?) = Unit
            }
        }
        durationRow.addView(durationSpinner, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        durationRow.addView(TextView(this).apply {
            text = "默认 60 秒；Root 系统层命令会自动执行"
            textSize = 11f
        })
        root.addView(durationRow, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        startButton = Button(this).apply {
            text = "开始采集"
            setOnClickListener { startProbe() }
        }
        root.addView(startButton, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        exportButton = Button(this).apply {
            text = "导出 JSON"
            isEnabled = false
            setOnClickListener { exportJson() }
        }
        root.addView(exportButton, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        val permissionButton = Button(this).apply {
            text = "请求权限"
            setOnClickListener { requestProbePermissions() }
        }
        root.addView(permissionButton, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        val rootScriptButton = Button(this).apply {
            text = "生成 Root 采集脚本"
            setOnClickListener { writeRootScript() }
        }
        root.addView(rootScriptButton, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        statusView = TextView(this).apply {
            textSize = 12f
            setTextIsSelectable(true)
            setPadding(0, 16, 0, 16)
            text = "等待开始。\n首次采集会触发 su 授权；拒绝 root 时仍会采集框架层数据。"
        }
        val scroll = ScrollView(this).apply {
            addView(statusView, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        val autoStart = intent?.getBooleanExtra("auto_start", false) == true
        if (autoStart) {
            statusView.postDelayed({ startProbe() }, 800)
        }
    }

    private fun startProbe() {
        if (collecting) return
        val missing = probePermissions().filter {
            checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            pendingStartAfterPermission = true
            requestPermissions(missing.toTypedArray(), REQUEST_PERMISSIONS)
            statusView.text = "请授予权限；拒绝的权限会在 JSON 中记录为未授权。"
            return
        }
        runCollector()
    }

    private fun runCollector() {
        if (collecting) return
        collecting = true
        startButton.isEnabled = false
        exportButton.isEnabled = false
        val extraDuration = intent?.getLongExtra("duration_ms", -1L) ?: -1L
        val durationMs = (if (extraDuration > 0) extraDuration else selectedDurationMs)
            .coerceIn(10_000L, 300_000L)
        statusView.text = "采集中（${durationMs / 1000} 秒）...\n" +
            "正在注册位置/GNSS/传感器回调，并执行只读系统命令。\n" +
            "如果 KernelSU/Magisk 弹出授权，请允许。"

        val probe = ProbeCollector(applicationContext, durationMs)
        collector = probe
        probe.start { json ->
            runOnUiThread {
                collecting = false
                startButton.isEnabled = true
                val text = json.toString(2)
                lastJson = text
                val path = runCatching { writeJson(text) }
                    .getOrElse { "写入失败: ${it.message ?: it.javaClass.simpleName}" }
                exportButton.isEnabled = true
                statusView.text = summaryText(json, path)
            }
        }
    }

    private fun exportJson() {
        val text = lastJson ?: return
        val path = writeJson(text)
        Toast.makeText(this, "已写入：$path", Toast.LENGTH_LONG).show()
        statusView.append("\n\n已导出：$path")
    }

    private fun writeJson(text: String): String {
        val dir = getExternalFilesDir("probe") ?: File(filesDir, "probe")
        if (!dir.exists()) dir.mkdirs()
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val file = File(dir, "location_probe_$stamp.json")
        file.writeText(text)
        return file.absolutePath
    }

    private fun summaryText(json: JSONObject, path: String): String {
        val analysis = json.optJSONObject("analysis")
        val summary = analysis?.optJSONObject("summary")
        val signals = analysis?.optJSONArray("signals")
        val sb = StringBuilder()
        sb.append("采集完成\n")
        val rootAvailable = json.optJSONObject("system")?.optBoolean("rootAvailable", false) == true
        val durationMs = json.optJSONObject("probe")?.optLong("durationMs", 0L) ?: 0L
        sb.append("系统层 Root：").append(if (rootAvailable) "已启用" else "未启用（可生成 Root 脚本）")
            .append(" · 采集时长：").append(durationMs / 1000).append(" 秒\n")
        if (summary != null) {
            sb.append("信号评分：").append(summary.optInt("score", 0)).append("/100\n")
            sb.append("critical=").append(summary.optInt("critical", 0))
                .append(" high=").append(summary.optInt("high", 0))
                .append(" medium=").append(summary.optInt("medium", 0))
                .append(" low=").append(summary.optInt("low", 0))
                .append(" info=").append(summary.optInt("info", 0)).append("\n\n")
        }
        if (signals != null && signals.length() > 0) {
            val limit = minOf(signals.length(), 30)
            for (i in 0 until limit) {
                val s = signals.optJSONObject(i) ?: continue
                sb.append("[").append(s.optString("severity")).append("] ")
                    .append(s.optString("id")).append(": ")
                    .append(s.optString("detail")).append("\n")
            }
            if (signals.length() > limit) sb.append("... 其余 ").append(signals.length() - limit).append(" 条见 JSON\n")
        } else {
            sb.append("未生成检测信号；请查看 JSON 原始数据。\n")
        }
        sb.append("\n完整 JSON：").append(path)
        return sb.toString()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_PERMISSIONS && pendingStartAfterPermission) {
            pendingStartAfterPermission = false
            runCollector()
        }
    }

    private fun writeRootScript() {
        runCatching {
            val dir = getExternalFilesDir("probe") ?: File(filesDir, "probe")
            if (!dir.exists()) dir.mkdirs()
            val script = File(dir, "root_probe.sh")
            assets.open("root_probe.sh").bufferedReader().use { reader ->
                script.writeText(reader.readText())
            }
            script.setReadable(true, false)
            script.setExecutable(true, false)
            val output = File(dir, "root_probe.txt")
            val command = "su -c 'sh ${script.absolutePath} ${output.absolutePath}'"
            statusView.text = "Root 脚本已生成：\n${script.absolutePath}\n\n" +
                "在 Termux/ADB 的 root shell 中执行：\n$command\n\n" +
                "执行后再点一次“开始采集”，app 会把 root_probe.txt 合并到 system.rootScriptOutput。\n" +
                "如果 KernelSU/Magisk 允许本应用直接 su，则可不执行脚本，采集时会自动尝试。"
            Toast.makeText(this, "已生成 Root 脚本", Toast.LENGTH_LONG).show()
        }.onFailure {
            statusView.text = "生成 Root 脚本失败：${it.message ?: it.javaClass.simpleName}"
        }
    }

    private fun requestProbePermissions() {
        val missing = probePermissions().filter {
            checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) {
            Toast.makeText(this, "权限已齐全", Toast.LENGTH_SHORT).show()
        } else {
            requestPermissions(missing.toTypedArray(), REQUEST_PERMISSIONS)
        }
    }

    private fun probePermissions(): List<String> {
        val list = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.READ_PHONE_STATE
        )
        if (Build.VERSION.SDK_INT >= 29) list.add(Manifest.permission.ACTIVITY_RECOGNITION)
        if (Build.VERSION.SDK_INT >= 31) {
            list.add(Manifest.permission.BLUETOOTH_SCAN)
            list.add(Manifest.permission.BLUETOOTH_CONNECT)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            list.add(Manifest.permission.NEARBY_WIFI_DEVICES)
        }
        return list
    }

    companion object {
        private const val REQUEST_PERMISSIONS = 42
    }
}
