package com.vincenthzr.locationprobe

import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs

/**
 * 保守的“检测信号”汇总，不下结论。信号只表示值得进一步核对的数据组合。
 */
internal object ProbeAnalysis {

    fun analyze(root: JSONObject): JSONObject {
        val signals = JSONArray()
        fun signal(id: String, severity: String, detail: String) {
            signals.put(JSONObject().put("id", id).put("severity", severity).put("detail", detail))
        }

        val location = root.optJSONObject("location") ?: JSONObject()
        val events = location.optJSONArray("events") ?: JSONArray()
        val lastEvents = mutableListOf<JSONObject>()
        for (i in 0 until events.length()) {
            events.optJSONObject(i)?.let { lastEvents.add(it) }
        }
        val collectionWindowMs = root.optJSONObject("probe")?.optLong("durationMs", 60_000L) ?: 60_000L
        // 只把本次采集窗口内的事件用于“位移/速度/海拔”指标；缓存的上一次 network/fused 位置
        // 可能已经过去几十分钟，混入会制造假位移。
        val movementEvents = lastEvents.filter {
            val age = it.optDouble("elapsedAgeMs", 0.0)
            age >= 0.0 && age <= collectionWindowMs + 5_000.0
        }
        val maxSpeed = movementEvents.mapNotNull { it.optDouble("speedMps", Double.NaN).takeIf { v -> !v.isNaN() } }.maxOrNull() ?: 0.0
        val minAltitude = movementEvents.mapNotNull { it.optDouble("altitudeMeters", Double.NaN).takeIf { v -> !v.isNaN() } }.minOrNull()
        val maxAltitude = movementEvents.mapNotNull { it.optDouble("altitudeMeters", Double.NaN).takeIf { v -> !v.isNaN() } }.maxOrNull()
        val altitudeRange = if (minAltitude != null && maxAltitude != null) maxAltitude - minAltitude else 0.0
        val hasFreshGpsEvent = movementEvents.any { it.optString("provider") == "gps" }
        val hasGpsEvent = hasFreshGpsEvent
        if (movementEvents.isNotEmpty() && !hasFreshGpsEvent) {
            signal("location.no_fresh_gps_fix", "info", "采集窗口内没有新的 GPS provider 定位，只有 network/fused 或缓存位置")
        }
        val firstEvent = movementEvents.firstOrNull()
        val lastEvent = movementEvents.lastOrNull()
        val firstLat = firstEvent?.optDouble("latitude", Double.NaN)
        val firstLng = firstEvent?.optDouble("longitude", Double.NaN)
        val lastLat = lastEvent?.optDouble("latitude", Double.NaN)
        val lastLng = lastEvent?.optDouble("longitude", Double.NaN)
        val movementDistanceM = if (firstLat != null && firstLng != null && lastLat != null && lastLng != null &&
            !firstLat.isNaN() && !firstLng.isNaN() && !lastLat.isNaN() && !lastLng.isNaN()
        ) haversineMeters(firstLat, firstLng, lastLat, lastLng) else 0.0
        val movementDurationS = if (firstEvent != null && lastEvent != null) {
            abs(lastEvent.optLong("elapsedRealtimeNanos", 0L) - firstEvent.optLong("elapsedRealtimeNanos", 0L)) / 1_000_000_000.0
        } else 0.0
        val computedSpeedMps = if (movementDurationS > 0.1) movementDistanceM / movementDurationS else 0.0
        // 首尾净位移 / 净速度：环形或折返路线会显著小于实际路程，保留用于兼容旧报告。
        // 另外计算累计路径长度与路径平均速度，这才是判断 3m/s 路线是否准确的指标。
        var pathLengthM = 0.0
        val ordered = movementEvents.sortedBy { it.optLong("elapsedRealtimeNanos", 0L) }
        for (i in 1 until ordered.size) {
            val a = ordered[i - 1]
            val b = ordered[i]
            val latA = a.optDouble("latitude", Double.NaN)
            val lngA = a.optDouble("longitude", Double.NaN)
            val latB = b.optDouble("latitude", Double.NaN)
            val lngB = b.optDouble("longitude", Double.NaN)
            if (!latA.isNaN() && !lngA.isNaN() && !latB.isNaN() && !lngB.isNaN()) {
                pathLengthM += haversineMeters(latA, lngA, latB, lngB)
            }
        }
        val pathSpeedMps = if (movementDurationS > 0.1) pathLengthM / movementDurationS else 0.0
        val accuracyValues = movementEvents.map { it.optDouble("accuracyMeters", -1.0) }.filter { it > 0 }.distinct().size
        val providerCounts = movementEvents.groupingBy { it.optString("provider") }.eachCount()
        val movementMetrics = JSONObject().apply {
            put("eventCount", movementEvents.size)
            put("firstProvider", firstEvent?.optString("provider") ?: "")
            put("lastProvider", lastEvent?.optString("provider") ?: "")
            put("distanceMeters", movementDistanceM)
            put("netDisplacementMeters", movementDistanceM)
            put("pathLengthMeters", pathLengthM)
            put("durationSeconds", movementDurationS)
            put("computedSpeedMps", computedSpeedMps)
            put("pathSpeedMps", pathSpeedMps)
            put("reportedMaxSpeedMps", maxSpeed)
            put("altitudeRangeMeters", altitudeRange)
            put("distinctAccuracyValues", accuracyValues)
            put("providerCounts", JSONObject().apply { providerCounts.forEach { (p, n) -> put(p, n) } })
        }

        if (lastEvents.any { it.optBoolean("isMock", false) || it.optBoolean("isFromMockProvider", false) }) {
            signal("location.mock_flag", "critical", "Location.isMock/isFromMockProvider 为 true")
        }
        if (lastEvents.any { it.optString("provider").lowercase().let { p -> p.contains("mock") || p.contains("fake") || p.contains("test") || p.contains("virtual") } }) {
            signal("location.mock_provider_name", "critical", "位置 provider 名称包含 mock/fake/test/virtual")
        }
        for (event in lastEvents) {
            val extras = event.optJSONObject("extras")?.toString()?.lowercase().orEmpty()
            if (extras.contains("mock") || extras.contains("fake") || extras.contains("virtual")) {
                signal("location.mock_extras", "high", "Location.extras 包含 mock/fake/virtual 字段")
                break
            }
        }
        if (lastEvents.any {
                abs(it.optDouble("timeSkewMs", 0.0)) > 10_000.0 &&
                    it.optDouble("elapsedAgeMs", 0.0) < 10_000.0
            }
        ) {
            signal("location.time_skew", "high", "新鲜位置事件的 Location.time 与系统墙钟相差超过 10 秒")
        }
        if (lastEvents.any { it.optDouble("elapsedAgeMs", 0.0) > 10_000.0 }) {
            signal("location.stale_elapsed", "info", "存在 elapsedRealtime 超过 10 秒的位置事件")
        }
        if (lastEvents.any { it.optDouble("accuracyMeters", -1.0) <= 0.0 }) {
            signal("location.accuracy_invalid", "high", "存在 accuracy <= 0 的位置")
        }

        val gnss = root.optJSONObject("gnss") ?: JSONObject()
        val statusEvents = gnss.optJSONArray("statusEvents") ?: JSONArray()
        val lastStatus = if (statusEvents.length() > 0) statusEvents.optJSONObject(statusEvents.length() - 1) else null
        val lastSatCount = lastStatus?.optInt("satelliteCount", -1) ?: -1
        val lastUsed = lastStatus?.optJSONArray("satellites")?.let { arr ->
            (0 until arr.length()).count { arr.optJSONObject(it)?.optBoolean("usedInFix", false) == true }
        } ?: -1
        val maxCn0 = lastStatus?.optJSONArray("satellites")?.let { arr ->
            (0 until arr.length()).mapNotNull { arr.optJSONObject(it)?.optDouble("cn0DbHz", Double.NaN)?.takeIf { v -> !v.isNaN() } }.maxOrNull()
        } ?: null
        val gnssMetrics = JSONObject().apply {
            put("lastSatelliteCount", lastSatCount)
            put("lastUsedInFix", lastUsed)
            put("maxCn0DbHz", maxCn0 ?: JSONObject.NULL)
            put("statusEventCount", gnss.optInt("statusEventCount", 0))
            put("measurementEventCount", gnss.optInt("measurementEventCount", 0))
            put("nmeaCount", gnss.optInt("nmeaCount", 0))
            put("yearOfHardware", gnss.optInt("yearOfHardware", -1))
            put("hardwareModelName", gnss.optString("hardwareModelName"))
        }
        if (hasGpsEvent && lastSatCount > 0 && maxCn0 != null && maxCn0 < 10.0) {
            signal("gnss.low_cn0", "medium", "卫星存在但最大 C/N0 <10 dB-Hz，信号质量异常低")
        }
        if (hasGpsEvent && (lastStatus == null || lastSatCount <= 0)) {
            signal("gnss.gps_without_satellites", "high", "收到 GPS 位置，但没有卫星状态或卫星数为 0")
        } else if (hasGpsEvent && lastUsed == 0) {
            signal("gnss.no_used_in_fix", "high", "GPS 位置存在，但没有任何卫星 usedInFix")
        }
        if (hasGpsEvent && gnss.optInt("measurementEventCount", 0) == 0) {
            signal("gnss.no_raw_measurements", "medium", "GPS 位置存在，但没有 GNSS 原始测量（部分机型/权限本身不支持）")
        }
        if (hasGpsEvent && gnss.optInt("nmeaCount", 0) == 0) {
            signal("gnss.no_nmea", "medium", "GPS 位置存在，但没有 NMEA 输出（部分机型/权限本身不支持）")
        }
        val nmea = gnss.optJSONArray("nmeaLines") ?: JSONArray()
        if (hasGpsEvent) {
            for (i in 0 until nmea.length()) {
                val line = nmea.optJSONObject(i)?.optString("message").orEmpty()
                if (line.startsWith("\$GPGGA") || line.startsWith("\$GNGGA")) {
                    val parts = line.split(",")
                    if (parts.size > 6 && parts[6].toIntOrNull() == 0) {
                        signal("gnss.nmea_fix_quality_zero", "high", "GPS/fused 位置存在，但 NMEA GGA fix quality 为 0")
                        break
                    }
                }
            }
        }

        val appOps = root.optJSONObject("appOps") ?: JSONObject()
        if (appOps.optString("mockLocationModeName") == "allowed") {
            signal("appops.mock_location_allowed", "high", "本应用 android:mock_location AppOps 为 allowed")
        }
        val mockPkgs = root.optJSONArray("mockLocationPackages") ?: JSONArray()
        val grantedMockPkgs = (0 until mockPkgs.length()).count {
            mockPkgs.optJSONObject(it)?.optBoolean("granted", false) == true
        }
        if (grantedMockPkgs > 0) {
            signal(
                "system.mock_location_permission",
                "info",
                "存在 $grantedMockPkgs 个持有 ACCESS_MOCK_LOCATION 权限的已安装包（系统/测试应用，不代表正在模拟）"
            )
        }
        val settings = root.optJSONObject("settings") ?: JSONObject()
        val secure = settings.optJSONObject("secure") ?: JSONObject()
        val global = settings.optJSONObject("global") ?: JSONObject()
        if (secure.optString("mock_location") == "1" || secure.optString("allow_mock_location") == "1") {
            signal("settings.mock_location", "medium", "Secure settings 中 mock_location/allow_mock_location 为 1")
        }
        if (global.optString("development_settings_enabled") == "1") {
            signal("settings.developer_options", "info", "开发者选项已开启")
        }

        val sensors = root.optJSONObject("sensors") ?: JSONObject()
        val stats = sensors.optJSONArray("stats") ?: JSONArray()
        fun sensorStat(type: Int): JSONObject? {
            var best: JSONObject? = null
            var bestCount = -1
            for (i in 0 until stats.length()) {
                val s = stats.optJSONObject(i) ?: continue
                if (s.optInt("type", -1) != type) continue
                val count = s.optInt("count", 0)
                if (count > bestCount) {
                    best = s
                    bestCount = count
                }
            }
            return best
        }
        fun axisRange(stat: JSONObject?): Double {
            val axes = stat?.optJSONArray("axes") ?: return 0.0
            var max = 0.0
            for (i in 0 until axes.length()) {
                max = maxOf(max, axes.optJSONObject(i)?.optDouble("range", 0.0) ?: 0.0)
            }
            return max
        }
        val accel = sensorStat(1)
        val accelRange = axisRange(accel)
        if ((accel?.optInt("count", 0) ?: 0) > 20 && accelRange < 0.05 && maxSpeed > 1.0) {
            signal("sensor.accel_static_while_moving", "high", "位置速度 >1m/s，但加速度计几乎完全静止")
        }
        val gyro = sensorStat(4)
        val gyroRange = axisRange(gyro)
        if ((gyro?.optInt("count", 0) ?: 0) > 20 && gyroRange < 0.02 && maxSpeed > 1.0) {
            signal("sensor.gyro_static_while_moving", "medium", "位置速度 >1m/s，但陀螺仪几乎无角速度")
        }
        val pressure = sensorStat(6)
        val pressureRange = axisRange(pressure)
        if ((pressure?.optInt("count", 0) ?: 0) > 5 && pressureRange < 0.2 && altitudeRange > 2.0) {
            signal("sensor.pressure_flat_altitude_change", "medium", "气压几乎不变，但位置海拔变化 >2m")
        }
        val step = sensorStat(19)
        val stepFirst = step?.optJSONArray("firstSamples")?.optJSONArray(0)?.optDouble(0, Double.NaN)
        val stepLast = step?.optJSONArray("lastValues")?.optDouble(0, Double.NaN)
        val stepDelta = if (stepFirst != null && stepLast != null && !stepFirst.isNaN() && !stepLast.isNaN()) stepLast - stepFirst else 0.0
        if (step != null && step.optInt("count", 0) > 0 && maxSpeed > 1.0 && stepDelta < 1.0) {
            signal("sensor.no_steps_while_moving", "medium", "位置速度 >1m/s，但计步器累计值没有增加")
        }
        if (movementDistanceM < 10.0 && accelRange > 0.8 && stepDelta > 10.0) {
            signal("sensor.motion_without_location", "medium", "计步/加速度显示在运动，但位置几乎没有位移")
        }
        if (movementDistanceM > 30.0 && computedSpeedMps > 1.0 &&
            (maxSpeed < 0.3 || maxSpeed > computedSpeedMps * 3.0 || maxSpeed < computedSpeedMps / 3.0)
        ) {
            signal("location.movement_vs_reported_speed", "medium", "位置位移/时间算出的速度与 Location.speed 明显不一致")
        }
        if (movementDistanceM > 100.0 && accuracyValues == 1) {
            signal("location.constant_accuracy_while_moving", "low", "位置移动 >100m，但 accuracy 只有一个固定值")
        }
        val sensorMetrics = JSONObject().apply {
            put("accelRange", accelRange)
            put("gyroRange", gyroRange)
            put("pressureRange", pressureRange)
            put("stepDelta", stepDelta)
            put("accelCount", accel?.optInt("count", 0) ?: 0)
            put("gyroCount", gyro?.optInt("count", 0) ?: 0)
            put("pressureCount", pressure?.optInt("count", 0) ?: 0)
        }
        val orientation = sensorStat(3)
        val bearing = movementEvents.lastOrNull()?.optDouble("bearingDeg", Double.NaN)
        val azimuth = orientation?.optJSONArray("lastValues")?.optDouble(0, Double.NaN)
        if (maxSpeed > 1.0 && bearing != null && !bearing.isNaN() && azimuth != null && !azimuth.isNaN()) {
            val delta = abs((((bearing - azimuth) % 360.0 + 540.0) % 360.0) - 180.0)
            if (delta > 60.0) {
                signal("sensor.compass_bearing_mismatch", "low", "罗盘方位与位置 bearing 相差 >60°（磁北/安装角可能造成差异）")
            }
        }

        val system = root.optJSONObject("system") ?: JSONObject()
        if (system.optBoolean("rootAvailable", false)) {
            signal("system.root", "info", "检测到 root（su id=0）；root 本身不等同于虚拟定位")
        }
        val props = system.optString("props").lowercase()
        if (props.contains("ro.debuggable=1") || props.contains("ro.build.tags=test-keys") || props.contains("ro.secure=0")) {
            signal("system.build_debuggable", "medium", "系统属性显示 debuggable/test-keys/secure=0")
        }
        val hookMaps = (system.optString("systemServerMapsFindings") + "\n" + system.optString("selfMapsFindings")).lowercase()
        if (hookMaps.contains("xposed") || hookMaps.contains("magisk") || hookMaps.contains("zygisk") ||
            hookMaps.contains("shamiko") || hookMaps.contains("riru") || hookMaps.contains("shadowhook") ||
            hookMaps.contains("location_accel") || hookMaps.contains("lspd")
        ) {
            signal("system.hook_libraries", "high", "进程 maps 发现 Xposed/Magisk/Zygisk/ShadowHook/本工程注入库")
        }
        val appOpsXml = system.optString("appOpsXmlFindings").lowercase()
        if (appOpsXml.contains("mock_location") && appOpsXml.contains("allow")) {
            signal("system.appops_xml_mock_allow", "high", "appops.xml 中存在 mock_location allow 记录")
        }
        val rootScript = system.optString("rootScriptOutput")
        if (rootScript.isNotBlank()) {
            signal("system.root_script_present", "info", "已读取 root_probe.txt；系统层数据在 system.rootScriptOutput")
            val lower = rootScript.lowercase()
            if (lower.contains("uid=0(root)")) {
                signal("system.root_script_ran_as_root", "info", "Root 脚本以 uid=0 执行")
            }
            val mockAllowPattern = Regex(
                "(mock_location|android:mock_location)[^\\n]{0,80}(allow|allowed|allowed=1|: 1|=1)",
                RegexOption.IGNORE_CASE
            )
            if (mockAllowPattern.containsMatchIn(rootScript)) {
                signal("system.root_script_mock_allow", "high", "Root 输出中发现 mock_location 被允许的记录")
            }
            if (lower.contains("invalid_user_scode") || lower.contains("mock provider")) {
                signal("system.root_script_mock_provider", "medium", "Root 输出提及 mock provider/INVALID_USER_SCODE")
            }
        }

        val wifi = root.optJSONObject("wifi") ?: JSONObject()
        val scan = wifi.optJSONArray("scanResults") ?: JSONArray()
        val uniqueBssids = (0 until scan.length()).mapNotNull {
            scan.optJSONObject(it)?.optString("BSSID")?.takeIf { b -> b.isNotBlank() }
        }.distinct().size
        if (scan.length() == 0) {
            signal("wifi.no_scan_results", "info", "没有 WiFi 扫描结果（权限/定位开关/扫描节流均可能导致）")
        }
        if (movementDistanceM > 200.0 && scan.length() > 0 && uniqueBssids <= 1) {
            signal("environment.static_wifi_while_moving", "low", "位置移动 >200m，但 WiFi BSSID 集合几乎没有变化")
        }
        val cell = root.optJSONObject("cell") ?: JSONObject()
        val cells = cell.optJSONArray("allCellInfo") ?: JSONArray()
        val uniqueCells = (0 until cells.length()).mapNotNull {
            cells.optJSONObject(it)?.optString("cellIdentity")?.takeIf { c -> c.isNotBlank() }
        }.distinct().size
        if (cells.length() == 0) {
            signal("cell.no_cell_info", "info", "没有基站信息（可能无 SIM/权限/飞行模式）")
        }
        if (movementDistanceM > 500.0 && cells.length() > 0 && uniqueCells <= 1) {
            signal("environment.static_cell_while_moving", "low", "位置移动 >500m，但基站 identity 集合没有变化")
        }
        val environmentMetrics = JSONObject().apply {
            put("wifiScanRows", scan.length())
            put("wifiUniqueBssids", uniqueBssids)
            put("cellRows", cells.length())
            put("cellUniqueIdentities", uniqueCells)
        }

        val counts = JSONObject()
        val weights = mapOf("critical" to 40, "high" to 20, "medium" to 8, "low" to 3, "info" to 0)
        var score = 0
        for (severity in listOf("critical", "high", "medium", "low", "info")) {
            var n = 0
            for (i in 0 until signals.length()) {
                if (signals.optJSONObject(i)?.optString("severity") == severity) n++
            }
            counts.put(severity, n)
            score += n * (weights[severity] ?: 0)
        }
        counts.put("score", minOf(score, 100))
        val metrics = JSONObject()
            .put("location", movementMetrics)
            .put("sensors", sensorMetrics)
            .put("gnss", gnssMetrics)
            .put("environment", environmentMetrics)
        return JSONObject().put("signals", signals).put("summary", counts).put("metrics", metrics)
    }

    private fun haversineMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val earthRadius = 6_371_000.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = kotlin.math.sin(dLat / 2) * kotlin.math.sin(dLat / 2) +
            kotlin.math.cos(Math.toRadians(lat1)) * kotlin.math.cos(Math.toRadians(lat2)) *
            kotlin.math.sin(dLon / 2) * kotlin.math.sin(dLon / 2)
        return earthRadius * 2 * kotlin.math.atan2(kotlin.math.sqrt(a), kotlin.math.sqrt(1 - a))
    }
}
