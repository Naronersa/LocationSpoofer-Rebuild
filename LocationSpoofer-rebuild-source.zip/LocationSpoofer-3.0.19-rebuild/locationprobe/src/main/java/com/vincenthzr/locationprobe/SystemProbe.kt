package com.vincenthzr.locationprobe

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Root/系统层采集。所有命令都是固定的只读诊断命令，不接受外部输入。
 * 输出只保存在本机导出的 JSON 中；APK 没有 INTERNET 权限。
 */
internal class SystemProbe(private val context: Context) {

    private data class CmdResult(
        val args: List<String>,
        val exitCode: Int,
        val output: String,
        val timedOut: Boolean,
        val error: String?
    )

    fun collect(): JSONObject {
        val result = JSONObject()
        val rootScriptFile = context.getExternalFilesDir("probe")?.resolve("root_probe.txt")
        val rootScriptOutput = if (rootScriptFile?.exists() == true) {
            runCatching { rootScriptFile.readText() }.getOrNull().orEmpty()
        } else ""
        val id = run(listOf("su", "-c", "id"), 12_000L)
        val rootAvailable = !id.timedOut && id.output.contains("uid=0")
        val props = exec(rootAvailable, "getprop | grep -iE 'gps|gnss|location|mock|debuggable|secure|build.type|build.tags|magisk|kernel|zygisk|lsposed|selinux'", 6000L)
        val selinux = exec(rootAvailable, "getenforce", 4000L)
        val uname = exec(rootAvailable, "uname -a", 4000L)

        val commands = JSONArray()
        fun command(id: String, cmd: String, timeoutMs: Long = 8000L): CmdResult {
            val r = exec(rootAvailable, cmd, timeoutMs)
            commands.put(JSONObject().apply {
                put("id", id)
                put("root", rootAvailable)
                put("command", cmd)
                put("exitCode", r.exitCode)
                put("timedOut", r.timedOut)
                put("error", r.error ?: JSONObject.NULL)
                put("output", truncate(r.output, 300_000))
            })
            return r
        }

        command("service_list", "service list | grep -iE 'location|gnss|sensor|wifi|telephony|bluetooth|connectivity'")
        command("dumpsys_location", "dumpsys location", 12_000L)
        command("cmd_location_help", "cmd location help", 6000L)
        command("gnss_hal_dumpsys", "dumpsys android.hardware.gnss.IGnss/default", 6000L)
        command("gnss_hal_lshal", "lshal | grep -iE 'gnss|location'", 8000L)
        command("gnss_devices", "ls -l /dev | grep -iE 'gnss|gps|location'", 4000L)
        command("gnss_sysfs", "find /sys -maxdepth 5 \\( -iname '*gnss*' -o -iname '*gps*' \\) 2>/dev/null | head -200", 8000L)
        command("gnss_dmesg", "dmesg | grep -iE 'gnss|gps|location' | tail -200", 8000L)
        command("settings_location", "settings list secure | grep -iE 'location|mock'; settings list global | grep -iE 'location|mock'", 6000L)
        command("dumpsys_sensorservice", "dumpsys sensorservice", 12_000L)
        command(
            "dumpsys_wifi",
            "dumpsys wifi | grep -iE 'SSID|BSSID|RSSI|frequency|linkSpeed|mWifiInfo|mScanResult|mNetworkInfo|mLinkProperties|mDhcpInfo|Gateway|DNS|ARP'",
            12_000L
        )
        command(
            "dumpsys_telephony",
            "dumpsys telephony.registry | grep -iE 'CellInfo|SignalStrength|mServiceState|mDataConnectionState|mNetworkType|mOperator|mCellIdentity|mRegistered|mRoaming|mNrState'",
            12_000L
        )
        command(
            "dumpsys_bluetooth",
            "dumpsys bluetooth_manager | grep -iE 'BleScan|ScanResult|mScanResults|mConnectedDevices|mBluetoothAddress|mDevice|mRssi|mLeScan'",
            12_000L
        )
        command("dumpsys_appops_mock", "dumpsys appops | grep -iE -C 2 'MOCK_LOCATION|mock_location'", 12_000L)
        command("dumpsys_package_probe", "dumpsys package ${context.packageName}")
        command("ip_addr", "ip addr", 6000L)
        command("ip_route", "ip route", 6000L)
        command("ip_neigh", "ip neigh", 6000L)
        command("proc_net_arp", "cat /proc/net/arp", 6000L)
        command("proc_net_route", "cat /proc/net/route", 6000L)
        command(
            "root_paths",
            "ls -ld /system/bin/su /system/xbin/su /sbin/su /system/sbin/su /vendor/bin/su /data/adb/ksu /data/adb/magisk /data/adb/modules /data/adb/lspd 2>/dev/null",
            6000L
        )
        command("mount_findings", "mount | grep -iE 'magisk|zygisk|shamiko|riru|overlay|data'", 6000L)
        val selfMaps = command(
            "self_maps_findings",
            "cat /proc/self/maps | grep -iE 'xposed|magisk|zygisk|shamiko|riru|shadowhook|location_accel|lspd'",
            6000L
        )

        val pidResult = exec(rootAvailable, "pidof system_server", 5000L)
        val systemServerPid = pidResult.output.lineSequence().firstOrNull()?.trim()?.takeIf { it.matches(Regex("[0-9]+")) }
        val systemServerMaps = if (systemServerPid != null) {
            exec(
                rootAvailable,
                "cat /proc/$systemServerPid/maps | grep -iE 'xposed|magisk|zygisk|shamiko|riru|shadowhook|location_accel|lspd'",
                8000L
            )
        } else CmdResult(emptyList(), -1, "", false, "system_server pid not found")
        val systemServerStatus = if (systemServerPid != null) {
            exec(
                rootAvailable,
                "cat /proc/$systemServerPid/status | grep -E 'Name|TracerPid|Seccomp|NoNewPrivs|CapEff'",
                6000L
            )
        } else CmdResult(emptyList(), -1, "", false, "system_server pid not found")

        val settingsFindings = exec(
            rootAvailable,
            "grep -iE 'mock_location|location_mode|location_providers_allowed|allow_mock_location|adb_enabled|development_settings_enabled' /data/system/users/0/settings_secure.xml /data/system/users/0/settings_global.xml 2>/dev/null",
            6000L
        )
        val appOpsXml = exec(
            rootAvailable,
            "grep -iE -C 2 'mock_location' /data/system/appops.xml 2>/dev/null",
            6000L
        )
        val locationData = exec(
            rootAvailable,
            "ls -la /data/system/location /data/misc/location 2>/dev/null",
            6000L
        )

        result.put("rootAvailable", rootAvailable)
        result.put("rootScriptPath", rootScriptFile?.absolutePath ?: JSONObject.NULL)
        result.put("rootScriptModifiedMs", rootScriptFile?.lastModified() ?: 0L)
        result.put("rootScriptOutput", truncate(rootScriptOutput, 1_200_000))
        result.put("suCheck", commandResultJson(id))
        result.put("selinux", truncate(selinux.output, 1000))
        result.put("uname", truncate(uname.output, 2000))
        result.put("props", truncate(props.output, 30_000))
        result.put("systemServerPid", systemServerPid ?: JSONObject.NULL)
        result.put("selfMapsFindings", truncate(selfMaps.output, 30_000))
        result.put("systemServerMapsFindings", truncate(systemServerMaps.output, 30_000))
        result.put("systemServerStatus", truncate(systemServerStatus.output, 6000))
        result.put("settingsFindings", truncate(settingsFindings.output, 30_000))
        result.put("appOpsXmlFindings", truncate(appOpsXml.output, 60_000))
        result.put("locationDataFiles", truncate(locationData.output, 10_000))
        result.put("commands", commands)
        return result
    }

    private fun commandResultJson(r: CmdResult): JSONObject = JSONObject().apply {
        put("args", JSONArray(r.args))
        put("exitCode", r.exitCode)
        put("timedOut", r.timedOut)
        put("error", r.error ?: JSONObject.NULL)
        put("output", truncate(r.output, 4000))
    }

    private fun exec(rootAvailable: Boolean, command: String, timeoutMs: Long): CmdResult {
        return if (rootAvailable) {
            run(listOf("su", "-c", command), timeoutMs)
        } else {
            run(listOf("sh", "-c", command), timeoutMs)
        }
    }

    /**
     * 读取 stdout/stderr 的线程会持续排空管道，避免 dumpsys 输出超过管道缓冲区时进程阻塞。
     * 只保留前 maxChars 个字符；后续输出丢弃但仍读取。
     */
    private fun run(args: List<String>, timeoutMs: Long): CmdResult {
        val output = StringBuilder()
        var timedOut = false
        var error: String? = null
        try {
            val process = ProcessBuilder(args)
                .redirectErrorStream(true)
                .start()
            val reader = Thread({
                try {
                    process.inputStream.bufferedReader().use { reader ->
                        val buffer = CharArray(8192)
                        var kept = 0
                        val maxChars = 400_000
                        while (true) {
                            val n = reader.read(buffer)
                            if (n < 0) break
                            if (kept < maxChars) {
                                val take = minOf(n, maxChars - kept)
                                output.append(buffer, 0, take)
                                kept += take
                            }
                        }
                    }
                } catch (t: Throwable) {
                    error = t.toString()
                }
            }, "probe-reader")
            reader.start()
            val finished = process.waitFor(timeoutMs, TimeUnit.MILLISECONDS)
            if (!finished) {
                timedOut = true
                process.destroyForcibly()
                process.waitFor(2, TimeUnit.SECONDS)
            }
            reader.join(1500)
            val exit = runCatching { process.exitValue() }.getOrDefault(-1)
            return CmdResult(args, exit, output.toString(), timedOut, error)
        } catch (t: Throwable) {
            return CmdResult(args, -1, output.toString(), timedOut, t.toString())
        }
    }
}
