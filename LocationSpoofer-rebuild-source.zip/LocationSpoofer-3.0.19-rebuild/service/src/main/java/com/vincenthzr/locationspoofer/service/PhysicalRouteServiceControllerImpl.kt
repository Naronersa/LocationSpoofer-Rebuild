package com.vincenthzr.locationspoofer.service

import android.content.Context
import android.content.Intent
import com.vincenthzr.locationspoofer.data.recording.PhysicalRouteCommand
import com.vincenthzr.locationspoofer.data.recording.PhysicalRouteServiceController

class PhysicalRouteServiceControllerImpl : PhysicalRouteServiceController {

    override fun send(context: Context, command: PhysicalRouteCommand) {
        val intent = Intent(context, PhysicalRouteRecordingService::class.java)
            .setAction(command.name)
        when (command) {
            PhysicalRouteCommand.START,
            PhysicalRouteCommand.RESUME -> context.startForegroundService(intent)

            PhysicalRouteCommand.PAUSE,
            PhysicalRouteCommand.FINISH -> context.startService(intent)
        }
    }
}
