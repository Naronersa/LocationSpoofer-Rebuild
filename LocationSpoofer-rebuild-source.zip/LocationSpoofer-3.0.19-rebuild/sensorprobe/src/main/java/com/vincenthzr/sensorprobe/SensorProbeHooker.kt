package com.vincenthzr.sensorprobe

import android.util.Log
import io.github.libxposed.api.XposedModule
import io.github.libxposed.api.XposedModuleInterface
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicBoolean

/**
 * 独立传感器探针的 system_server 入口。
 *
 * 加载 native 库后：
 *  - 把本探针 App 的 UID 传给 native，native 只改写/注入该 UID 的连接；
 *  - 从 LSPosed 远程 prefs（group=sensorprobe_config, key=config）轮询 JSON 配置，
 *    通过 nativeConfigure 下发速度、步频、传感器句柄、真实度和步态模板；
 *  - 配置缺失时使用与 scoped 侧一致的默认值（1.4 m/s、自动步频、本机句柄）。
 */
class SensorProbeHooker : XposedModule() {

    private val initialized = AtomicBoolean(false)

    override fun onSystemServerStarting(param: XposedModuleInterface.SystemServerStartingParam) {
        Log.i(TAG, "onSystemServerStarting")
        if (!initialized.compareAndSet(false, true)) return

        // onSystemServerStarting 时 PackageManagerService 往往还没就绪，
        // 放到后台线程轮询 UID，成功后再交给 native（native 继续轮询 libsensorservice）。
        Thread({
            try {
                // ShadowHook 的 JNI_OnLoad 会 FindClass/RegisterNatives 这个类，
                // 必须先确保它在模块 classloader 中可见。
                Class.forName("com.bytedance.shadowhook.ShadowHook", true, javaClass.classLoader)
                System.loadLibrary("shadowhook")
                System.loadLibrary("sensorprobe")

                var uid = -1
                for (attempt in 1..240) {
                    uid = resolveUid(PROBE_PACKAGE)
                    if (uid > 0) {
                        Log.i(TAG, "probe uid=$uid (attempt $attempt)")
                        break
                    }
                    Thread.sleep(500)
                }
                if (uid <= 0) {
                    uid = FALLBACK_UID
                    Log.w(TAG, "resolveUid unavailable, fallback to uid=$uid")
                }

                val ok = nativeInit(uid)
                Log.i(TAG, "nativeInit=$ok status=${nativeStatus()}")
                applyConfig(uid, null, source = "defaults")
                startConfigPoller(uid)
            } catch (t: Throwable) {
                Log.e(TAG, "native init failed", t)
            }
        }, "SensorProbeInit").start()
    }

    /**
     * LSPosed remote prefs 里的配置 JSON。探针阶段由调试脚本/宿主写入；
     * 正式 global 模块将由应用配置直接调用 nativeConfigure。
     */
    private fun startConfigPoller(uid: Int) {
        Thread({
            var lastApplied: String? = null
            var remoteSeen = false
            var missingLogged = false
            while (true) {
                val raw = runCatching {
                    getRemotePreferences(CONFIG_GROUP)
                        ?.getString(CONFIG_KEY, null)
                }.getOrNull()
                if (raw != null && raw != lastApplied) {
                    remoteSeen = true
                    lastApplied = raw
                    applyConfig(uid, raw, source = "remote")
                } else if (raw == null && !remoteSeen && !missingLogged) {
                    // 远程 prefs 尚未发布时保持默认配置，只提示一次，继续等待
                    missingLogged = true
                    Log.i(TAG, "sensorprobe_config not published yet, keep defaults")
                }
                Thread.sleep(1000)
            }
        }, "SensorProbeConfig").start()
    }

    /**
     * 解析并下发配置。字段全部可选，缺省值与 scoped 侧默认行为一致。
     */
    private fun applyConfig(uid: Int, raw: String?, source: String) {
        try {
            val obj = if (raw.isNullOrBlank()) JSONObject() else JSONObject(raw)
            val speed = obj.optDouble("speed_m_s", DEFAULT_SPEED)
                .coerceIn(0.0, 10.0)
            val cadenceRaw = obj.optInt("step_cadence_spm", 0)
            val cadence = if (cadenceRaw in 60..240) cadenceRaw else 0
            val stepDetector = obj.optInt("step_detector_handle", DEFAULT_STEP_DETECTOR)
            val stepCounter = obj.optInt("step_counter_handle", DEFAULT_STEP_COUNTER)
            val accelerometer = obj.optInt("accelerometer_handle", DEFAULT_ACCELEROMETER)
            val realism = obj.optInt("realism_level", 0).coerceIn(0, 3)
            val fluctuation = obj.optInt("speed_fluctuation_pct", 0).coerceIn(0, 100)
            val active = obj.optBoolean("active", true)
            val stepSim = obj.optBoolean("enable_step_simulation", true)
            val accelSim = obj.optBoolean("enable_accel_simulation", true)
            val gait = obj.optString("gait_template", "")

            val ok = nativeConfigure(
                uid, speed, cadence,
                stepDetector, stepCounter, accelerometer,
                realism, fluctuation,
                active, stepSim, accelSim, gait
            )
            Log.i(
                TAG,
                "config source=$source ok=$ok speed=$speed cadence=$cadence " +
                    "handles=$stepDetector/$stepCounter/0x${accelerometer.toString(16)} " +
                    "realism=$realism active=$active step=$stepSim accel=$accelSim " +
                    "gaitLen=${gait.length} status=${nativeStatus()}"
            )
        } catch (t: Throwable) {
            Log.e(TAG, "applyConfig failed: $raw", t)
        }
    }

    /**
     * API 33: IPackageManager.getPackageUid(String, long flags, int userId)。
     * 在 system_server 中通过 AppGlobals 取 PackageManager，避免依赖 Context。
     * PMS 未就绪时静默返回 -1，由调用方重试。
     */
    private fun resolveUid(packageName: String): Int {
        return try {
            val appGlobals = Class.forName("android.app.AppGlobals")
            val pm = appGlobals.getMethod("getPackageManager").invoke(null) ?: return -1
            val method = pm.javaClass.getMethod(
                "getPackageUid",
                String::class.java,
                Long::class.javaPrimitiveType,
                Int::class.javaPrimitiveType
            )
            (method.invoke(pm, packageName, 0L, 0) as? Int) ?: -1
        } catch (t: Throwable) {
            -1
        }
    }

    private external fun nativeInit(targetUid: Int): Boolean

    private external fun nativeConfigure(
        targetUid: Int,
        speedMps: Double,
        cadenceSpm: Int,
        stepDetectorHandle: Int,
        stepCounterHandle: Int,
        accelerometerHandle: Int,
        realismLevel: Int,
        fluctuationPct: Int,
        active: Boolean,
        stepSimulation: Boolean,
        accelerometerSimulation: Boolean,
        gaitTemplate: String
    ): Boolean

    private external fun nativeStatus(): String

    private companion object {
        const val TAG = "SensorProbe"
        const val PROBE_PACKAGE = "com.vincenthzr.sensorprobe"
        const val CONFIG_GROUP = "sensorprobe_config"
        const val CONFIG_KEY = "config"

        const val DEFAULT_SPEED = 1.4
        const val DEFAULT_STEP_DETECTOR = 3
        const val DEFAULT_STEP_COUNTER = 5
        const val DEFAULT_ACCELEROMETER = 0x37

        // 本机首次安装实测 UID；仅在 PMS 长时间不可用时兜底
        const val FALLBACK_UID = 10251
    }
}
