// SensorProbe: LSPosed system_server 传感器探针（native 传感器层 MVP）
//
// 目标设备：Xiaomi 10S (thyme), Android 13 (SDK 33), HyperOS 1.0.4.0
//
// 拦截点：libc __sendto 的 svc 指令（本 ROM 0xe1918）。本 ROM 上
// SensorEventQueue::write / SensorEventConnection::sendEvents 的函数入口 hook
// 不可靠，但事件最终都经过 __sendto。
//
// 能力：
//   - 按目标 UID 过滤：Hook SensorEventConnection 构造函数，建立 fd -> uid；
//   - 改写目标 UID 的 STEP_COUNTER / STEP_DETECTOR；
//   - 按配置速度/步频/步态模板改写加速度计（程序化步态或录制模板）；
//   - 静止时按目标步频注入合成步数（每个 tick 只注入一条连接，防重复）。

#include <jni.h>
#include <android/log.h>
#include <dlfcn.h>
#include <link.h>
#include <shadowhook.h>
#include <sys/socket.h>
#include <sys/syscall.h>
#include <sys/uio.h>
#include <unistd.h>

#include <algorithm>
#include <array>
#include <atomic>
#include <cerrno>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <functional>
#include <memory>
#include <mutex>
#include <pthread.h>
#include <random>
#include <string>
#include <vector>

#define LOG_TAG "SensorProbe"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace {

constexpr double kPi = 3.14159265358979323846;

constexpr const char* kLibcName = "libc.so";
constexpr const char* kLibSensorservice = "libsensorservice.so";

// libc __sendto: bti c; mov x8,#0xce; svc #0
constexpr uintptr_t kLibcSvcOffset = 0xe1918;
constexpr uint8_t kLibcSvcBytes[4] = {0x01, 0x00, 0x00, 0xd4};

// libsensorservice SensorEventConnection::SensorEventConnection(C1)
constexpr uintptr_t kConnectionCtorOffset = 0x58160;
constexpr uint8_t kConnectionCtorPrologue[16] = {
    0x3f, 0x23, 0x03, 0xd5, 0xfd, 0x7b, 0xbb, 0xa9,
    0xfa, 0x67, 0x01, 0xa9, 0xfd, 0x03, 0x00, 0x91,
};
// this+0x30 = sp<BitTube>；BitTube+0x10 = 发送 fd；this+0x38 = uid
constexpr size_t kConnectionBitTubeOffset = 0x30;

// Android 13 / arm64 sensors_event_t
struct SensorsEvent {
  int32_t version;
  int32_t sensor;
  int32_t type;
  int32_t reserved0;
  int64_t timestamp;
  union {
    float data[16];
    uint64_t step_counter;
  } u;
  uint32_t flags;
  int32_t reserved1[3];
};
static_assert(sizeof(SensorsEvent) == 0x68, "unexpected sensors_event_t size");
static_assert(offsetof(SensorsEvent, sensor) == 0x04, "sensor offset");
static_assert(offsetof(SensorsEvent, type) == 0x08, "type offset");
static_assert(offsetof(SensorsEvent, timestamp) == 0x10, "timestamp offset");
static_assert(offsetof(SensorsEvent, u) == 0x18, "data offset");

constexpr int32_t kTypeAccelerometer = 1;
constexpr int32_t kTypeStepDetector = 18;
constexpr int32_t kTypeStepCounter = 19;

constexpr size_t kMaxTargetFds = 8;
constexpr size_t kFdMapSize = 256;
constexpr uint64_t kStepSalt = 0x57E9057EULL;

// ---------------------------------------------------------------- 步态波形
// 与 core-geo MotionRealism 的程序化波形一致：256 点查表、去均值。

using ShapeTable = std::array<double, 256>;

double bump(double p, double center, double width) {
  double d = std::fabs(p - center);
  if (d > 0.5) d = 1.0 - d;
  return std::exp(-0.5 * (d / width) * (d / width));
}

ShapeTable zeroMeanTable(const std::function<double(double)>& shape) {
  ShapeTable table{};
  double sum = 0.0;
  for (size_t i = 0; i < table.size(); ++i) {
    table[i] = shape(static_cast<double>(i) / table.size());
    sum += table[i];
  }
  const double mean = sum / table.size();
  for (auto& v : table) v -= mean;
  return table;
}

const ShapeTable kWalkVertical = zeroMeanTable([](double p) {
  return 1.0 * bump(p, 0.00, 0.045) - 0.45 * bump(p, 0.13, 0.07) +
         0.55 * bump(p, 0.42, 0.09) - 0.65 * bump(p, 0.72, 0.13);
});
const ShapeTable kWalkForward = zeroMeanTable([](double p) {
  return -0.5 * bump(p, 0.03, 0.05) + 0.45 * bump(p, 0.40, 0.09) -
         0.15 * bump(p, 0.75, 0.15);
});
const ShapeTable kRunVertical = zeroMeanTable([](double p) {
  return 1.0 * bump(p, 0.00, 0.035) + 0.55 * bump(p, 0.16, 0.09) -
         0.85 * bump(p, 0.62, 0.18);
});
const ShapeTable kRunForward = zeroMeanTable([](double p) {
  return -0.6 * bump(p, 0.02, 0.04) + 0.5 * bump(p, 0.25, 0.08);
});

double lookup(const ShapeTable& table, double phase) {
  const double pos = (phase - std::floor(phase)) * table.size();
  const int i = static_cast<int>(pos) % static_cast<int>(table.size());
  const double frac = pos - std::floor(pos);
  return table[i] * (1.0 - frac) +
         table[(i + 1) % table.size()] * frac;
}

// 与 MotionRealism.hashUnit 一致的 64 位混合
double hashUnit(uint64_t seed, int64_t n) {
  uint64_t x = seed ^ (static_cast<uint64_t>(n) * 0x9E3779B97F4A7C15ULL);
  x = (x ^ (x >> 33)) * 0xFF51AFD7ED558CCDULL;
  x = (x ^ (x >> 33)) * 0xC4CEB9FE1A85EC53ULL;
  x ^= (x >> 33);
  return static_cast<double>(x >> 11) / static_cast<double>(1ULL << 53) * 2.0 - 1.0;
}

void proceduralGait(double stepPhase, double stepsFloat, int64_t stepIndex,
                    double speed, double strength, float out[3]) {
  const bool running = speed >= 2.2;
  const double amplitude = running ? 6.0 + 1.5 * speed : 2.0 + 1.0 * speed;
  const double vertical = lookup(running ? kRunVertical : kWalkVertical, stepPhase);
  const double forward = lookup(running ? kRunForward : kWalkForward, stepPhase);
  const double side = (stepIndex % 2 == 0) ? 1.0 : -1.0;
  const double lateral =
      0.12 * amplitude * std::sin(kPi * stepsFloat) +
      0.1 * amplitude * side * bump(stepPhase, 0.02, 0.05);
  const double z = std::max(0.0, 9.80665 + strength * amplitude * vertical);
  out[0] = static_cast<float>(strength * lateral);
  out[1] = static_cast<float>(strength * 0.35 * amplitude * forward);
  out[2] = static_cast<float>(z);
}

// 录制的个人步态模板：v1;cadence;strides;x0..x63;y...;z...
struct GaitTemplate {
  std::array<float, 64> x{};
  std::array<float, 64> y{};
  std::array<float, 64> z{};
  float meanX = 0.0f;
  float meanY = 0.0f;
  float meanZ = 0.0f;
};

std::vector<std::string> split(const std::string& s, char sep) {
  std::vector<std::string> out;
  size_t start = 0;
  while (true) {
    const size_t pos = s.find(sep, start);
    if (pos == std::string::npos) {
      out.push_back(s.substr(start));
      break;
    }
    out.push_back(s.substr(start, pos - start));
    start = pos + 1;
  }
  return out;
}

bool parseAxis(const std::string& text, std::array<float, 64>& axis) {
  const auto parts = split(text, ',');
  if (parts.size() != axis.size()) return false;
  for (size_t i = 0; i < axis.size(); ++i) {
    char* end = nullptr;
    const float v = std::strtof(parts[i].c_str(), &end);
    if (end == parts[i].c_str() || !std::isfinite(v)) return false;
    axis[i] = v;
  }
  return true;
}

std::shared_ptr<const GaitTemplate> parseGait(const std::string& encoded) {
  if (encoded.empty()) return nullptr;
  const auto parts = split(encoded, ';');
  if (parts.size() != 6 || parts[0] != "v1") return nullptr;
  auto t = std::make_shared<GaitTemplate>();
  if (!parseAxis(parts[3], t->x) || !parseAxis(parts[4], t->y) ||
      !parseAxis(parts[5], t->z)) {
    return nullptr;
  }
  double sx = 0.0, sy = 0.0, sz = 0.0;
  for (size_t i = 0; i < t->x.size(); ++i) {
    sx += t->x[i];
    sy += t->y[i];
    sz += t->z[i];
  }
  t->meanX = static_cast<float>(sx / t->x.size());
  t->meanY = static_cast<float>(sy / t->y.size());
  t->meanZ = static_cast<float>(sz / t->z.size());
  return t;
}

void sampleGait(const GaitTemplate& t, double stridePhase, double strength,
                float out[3]) {
  const double pos = (stridePhase - std::floor(stridePhase)) * t.x.size();
  const int i = static_cast<int>(pos) % static_cast<int>(t.x.size());
  const int j = (i + 1) % static_cast<int>(t.x.size());
  const float frac = static_cast<float>(pos - std::floor(pos));
  const std::array<float, 64>* axes[3] = {&t.x, &t.y, &t.z};
  const float means[3] = {t.meanX, t.meanY, t.meanZ};
  for (int a = 0; a < 3; ++a) {
    const float v = (*axes[a])[i] * (1.0f - frac) + (*axes[a])[j] * frac;
    out[a] = means[a] + (v - means[a]) * static_cast<float>(strength);
  }
}

struct LevelParams {
  double stepAmplitudeVariation;
  double sensorNoise;
};
constexpr LevelParams kLevels[4] = {
    {0.0, 0.0}, {0.05, 0.03}, {0.10, 0.06}, {0.18, 0.10}};

// ---------------------------------------------------------------- 配置与时钟

struct Config {
  int32_t targetUid = -1;
  double speedMps = 1.4;
  int32_t cadenceSpm = 0;  // 0 = 按速度自动
  int32_t stepDetectorHandle = 3;
  int32_t stepCounterHandle = 5;
  int32_t accelerometerHandle = 0x37;
  int32_t realismLevel = 0;
  int32_t fluctuationPct = 0;
  bool active = true;
  bool stepSimulation = true;
  bool accelerometerSimulation = true;
  std::string gaitEncoded;
};

std::mutex g_config_mutex;
Config g_config;
int64_t g_clock_origin_ns = 0;
double g_clock_base_steps = 0.0;
bool g_counter_base_captured = false;
std::shared_ptr<const GaitTemplate> g_gait;

std::atomic<bool> g_installed{false};
std::atomic<int> g_target_fds[kMaxTargetFds];
std::atomic<int> g_fd_map[kFdMapSize];
std::atomic<int> g_fd_uid_map[kFdMapSize];
std::atomic<uint64_t> g_rewritten_events{0};
std::atomic<uint64_t> g_accel_rewritten_events{0};
std::atomic<uint64_t> g_injected_events{0};

thread_local std::mt19937 g_rng(0x5EED);

int64_t nowNanos() {
  timespec ts{};
  clock_gettime(CLOCK_BOOTTIME, &ts);
  return static_cast<int64_t>(ts.tv_sec) * 1000000000LL + ts.tv_nsec;
}

uintptr_t untagPtr(uint64_t p) { return p & 0x00FFFFFFFFFFFFULL; }

int autoCadence(double speedMs) {
  if (speedMs <= 0.8) return 95;
  if (speedMs <= 1.5) return static_cast<int>(100 + (speedMs - 0.8) / 0.7 * 25);
  if (speedMs <= 2.8) return static_cast<int>(135 + (speedMs - 1.5) / 1.3 * 25);
  if (speedMs <= 4.0) return static_cast<int>(160 + (speedMs - 2.8) / 1.2 * 20);
  if (speedMs <= 5.5) return static_cast<int>(180 + (speedMs - 4.0) / 1.5 * 15);
  return 200;
}

int effectiveCadenceLocked() {
  if (g_config.cadenceSpm > 0) return std::clamp(g_config.cadenceSpm, 60, 240);
  return autoCadence(g_config.speedMps);
}

double currentStepsLocked(int64_t now) {
  if (g_clock_origin_ns <= 0) return g_clock_base_steps;
  const double elapsed = static_cast<double>(now - g_clock_origin_ns) / 1e9;
  return g_clock_base_steps + elapsed * effectiveCadenceLocked() / 60.0;
}

bool rewriteStepEvent(SensorsEvent& e, int64_t now, uint64_t stepValue) {
  if (e.type == kTypeStepDetector) {
    e.u.data[0] = 1.0f;
    e.timestamp = now;
    return true;
  }
  if (e.type == kTypeStepCounter) {
    e.u.step_counter = stepValue;
    e.timestamp = now;
    return true;
  }
  return false;
}

void applyGait(SensorsEvent& e, int64_t now, const Config& cfg,
               const GaitTemplate* tmpl, double stepsFloat, uint64_t seed) {
  const int64_t stepIndex = static_cast<int64_t>(std::floor(stepsFloat));
  const double stepPhase = stepsFloat - static_cast<double>(stepIndex);
  const auto& level = kLevels[std::clamp(cfg.realismLevel, 0, 3)];
  const double strength =
      1.0 + level.stepAmplitudeVariation * hashUnit(seed ^ kStepSalt, stepIndex);
  float out[3];
  if (tmpl != nullptr) {
    sampleGait(*tmpl, stepsFloat / 2.0, strength, out);
  } else {
    proceduralGait(stepPhase, stepsFloat, stepIndex, cfg.speedMps, strength, out);
  }
  if (level.sensorNoise > 0.0) {
    std::normal_distribution<double> dist(0.0, level.sensorNoise);
    for (int i = 0; i < 3; ++i) out[i] += static_cast<float>(dist(g_rng));
  }
  e.u.data[0] = out[0];
  e.u.data[1] = out[1];
  e.u.data[2] = out[2];
  e.timestamp = now;
}

// ---------------------------------------------------------------- 目标 fd 管理

void recordTargetFd(int fd) {
  if (fd < 0) return;
  for (size_t i = 0; i < kMaxTargetFds; ++i) {
    const int cur = g_target_fds[i].load(std::memory_order_relaxed);
    if (cur == fd) return;
    if (cur == -1) {
      int expected = -1;
      if (g_target_fds[i].compare_exchange_strong(expected, fd)) {
        LOGI("track sensor fd=%d", fd);
        return;
      }
    }
  }
}

void recordFdUid(int fd, int uid) {
  if (fd < 0) return;
  for (size_t i = 0; i < kFdMapSize; ++i) {
    if (g_fd_map[i].load(std::memory_order_relaxed) == fd) {
      g_fd_uid_map[i].store(uid, std::memory_order_relaxed);
      return;
    }
  }
  for (size_t i = 0; i < kFdMapSize; ++i) {
    int expected = -1;
    if (g_fd_map[i].compare_exchange_strong(expected, fd,
                                             std::memory_order_relaxed)) {
      g_fd_uid_map[i].store(uid, std::memory_order_relaxed);
      LOGI("conn fd=%d uid=%d", fd, uid);
      return;
    }
  }
  LOGE("fd map full, drop fd=%d uid=%d", fd, uid);
}

int uidForFd(int fd) {
  if (fd < 0) return -1;
  for (size_t i = 0; i < kFdMapSize; ++i) {
    const int cur = g_fd_map[i].load(std::memory_order_relaxed);
    if (cur == fd) return g_fd_uid_map[i].load(std::memory_order_relaxed);
    if (cur == -1) return -1;
  }
  return -1;
}

// ---------------------------------------------------------------- 合成步数注入

void* stepInjectThread(void*) {
  uint64_t tick = 0;
  int64_t lastInject = 0;
  int64_t lastDetectorStep = -1;
  while (true) {
    usleep(100 * 1000);
    const int64_t now = nowNanos();
    std::lock_guard<std::mutex> lock(g_config_mutex);
    if (!g_config.active || !g_config.stepSimulation) continue;

    const int cadence = effectiveCadenceLocked();
    if (cadence < 1) continue;
    int64_t interval = static_cast<int64_t>(60000000000.0 / cadence);
    interval = std::max<int64_t>(interval, 100000000LL);
    if (now - lastInject < interval) continue;
    lastInject = now;

    const double stepsFloat = currentStepsLocked(now);
    const uint64_t value = static_cast<uint64_t>(std::floor(stepsFloat));
    for (size_t i = 0; i < kMaxTargetFds; ++i) {
      const int fd = g_target_fds[i].load(std::memory_order_relaxed);
      if (fd < 0) continue;

      SensorsEvent counter{};
      counter.version = static_cast<int32_t>(sizeof(SensorsEvent));
      counter.sensor = g_config.stepCounterHandle;
      counter.type = kTypeStepCounter;
      counter.timestamp = now;
      counter.u.step_counter = value;

      const ssize_t rc = syscall(__NR_sendto, fd, &counter, sizeof(counter),
                                 MSG_DONTWAIT | MSG_NOSIGNAL, nullptr, 0);
      if (rc < 0) {
        const int err = errno;
        if (err == EAGAIN || err == EWOULDBLOCK || err == ENOBUFS) break;
        g_target_fds[i].store(-1, std::memory_order_relaxed);
        LOGI("drop sensor fd=%d errno=%d", fd, err);
        continue;
      }
      g_injected_events.fetch_add(1, std::memory_order_relaxed);

      if (static_cast<int64_t>(value) > lastDetectorStep &&
          g_config.stepDetectorHandle >= 0) {
        SensorsEvent detector{};
        detector.version = static_cast<int32_t>(sizeof(SensorsEvent));
        detector.sensor = g_config.stepDetectorHandle;
        detector.type = kTypeStepDetector;
        detector.timestamp = now;
        detector.u.data[0] = 1.0f;
        if (syscall(__NR_sendto, fd, &detector, sizeof(detector),
                    MSG_DONTWAIT | MSG_NOSIGNAL, nullptr, 0) >= 0) {
          g_injected_events.fetch_add(1, std::memory_order_relaxed);
        }
        lastDetectorStep = static_cast<int64_t>(value);
      }
      // 每个 tick 只注入一条有效连接，避免同一进程多连接重复
      break;
    }

    if ((++tick % 25) == 0) {
      LOGI("inject tick=%llu value=%llu cadence=%d total=%llu",
           static_cast<unsigned long long>(tick),
           static_cast<unsigned long long>(value), cadence,
           static_cast<unsigned long long>(g_injected_events.load()));
    }
  }
  return nullptr;
}

// ---------------------------------------------------------------- Hook

using ConnectionCtorFn = void (*)(void* thiz, const void* service, uint32_t uid,
                                  const void* name, bool wakeup, const void* opPkg,
                                  const void* attribution);
ConnectionCtorFn g_orig_connection_ctor = nullptr;

void probeConnectionCtor(void* thiz, const void* service, uint32_t uid,
                         const void* name, bool wakeup, const void* opPkg,
                         const void* attribution) {
  if (g_orig_connection_ctor != nullptr) {
    g_orig_connection_ctor(thiz, service, uid, name, wakeup, opPkg, attribution);
  }
  if (thiz == nullptr) return;
  void* tube = *reinterpret_cast<void**>(
      reinterpret_cast<char*>(thiz) + kConnectionBitTubeOffset);
  if (tube == nullptr) return;
  const int fd = *reinterpret_cast<int*>(reinterpret_cast<char*>(tube) + 0x10);
  if (fd < 0) return;
  recordFdUid(fd, static_cast<int>(uid));
  int32_t targetUid;
  {
    std::lock_guard<std::mutex> lock(g_config_mutex);
    targetUid = g_config.targetUid;
  }
  if (static_cast<int32_t>(uid) == targetUid) {
    recordTargetFd(fd);
  }
}

// __sendto svc 拦截器：在 syscall 执行前改写目标 UID 的事件
void sendtoPreInterceptor(shadowhook_cpu_context_t* ctx, void*) {
  if (ctx == nullptr) return;
  if (ctx->regs[8] != 0xce) return;  // __NR_sendto

  const uint64_t rawLen = ctx->regs[2];
  if (rawLen < sizeof(SensorsEvent) || rawLen % sizeof(SensorsEvent) != 0 ||
      rawLen > sizeof(SensorsEvent) * 256) {
    return;
  }

  auto* events = reinterpret_cast<SensorsEvent*>(untagPtr(ctx->regs[1]));
  const size_t count = rawLen / sizeof(SensorsEvent);

  bool hasStep = false;
  bool hasAccel = false;
  for (size_t i = 0; i < count; ++i) {
    if (events[i].type == kTypeStepDetector || events[i].type == kTypeStepCounter) {
      hasStep = true;
    } else if (events[i].type == kTypeAccelerometer) {
      hasAccel = true;
    }
  }
  if (!hasStep && !hasAccel) return;

  const uintptr_t tube = untagPtr(ctx->regs[24]);
  int fd = -1;
  if (tube > 0x1000) {
    int32_t candidate = -1;
    iovec local{&candidate, sizeof(candidate)};
    iovec remote{reinterpret_cast<void*>(tube + 0x10), sizeof(candidate)};
    if (process_vm_readv(getpid(), &local, 1, &remote, 1, 0) ==
        static_cast<ssize_t>(sizeof(candidate))) {
      int domain = 0;
      int sockType = 0;
      socklen_t optLen = sizeof(domain);
      if (candidate >= 0 &&
          getsockopt(candidate, SOL_SOCKET, SO_DOMAIN, &domain, &optLen) == 0 &&
          domain == AF_UNIX) {
        optLen = sizeof(sockType);
        if (getsockopt(candidate, SOL_SOCKET, SO_TYPE, &sockType, &optLen) == 0 &&
            sockType == SOCK_SEQPACKET) {
          fd = candidate;
        }
      }
    }
  }
  if (fd < 0) return;

  const int32_t uid = uidForFd(fd);
  int rewritten = 0;
  {
    std::lock_guard<std::mutex> lock(g_config_mutex);
    if (!g_config.active) return;
    if (uid != g_config.targetUid) {
      if (hasStep) {
        static std::atomic<int64_t> lastSkipLog{0};
        const int64_t now = nowNanos();
        const int64_t prev = lastSkipLog.load(std::memory_order_relaxed);
        if (now - prev > 2000000000LL) {
          lastSkipLog.store(now, std::memory_order_relaxed);
          LOGI("skip step fd=%d uid=%d target=%d", fd, uid,
               g_config.targetUid);
        }
      }
      return;
    }

    const int64_t now = nowNanos();
    // 第一次看到目标 App 的真实计步事件时，以它的累计值为起点续接，
    // 避免合成计数器从 0 开始导致用户看到步数回退。
    if (!g_counter_base_captured && g_config.stepSimulation) {
      for (size_t i = 0; i < count; ++i) {
        if (events[i].type == kTypeStepCounter) {
          g_clock_base_steps = static_cast<double>(events[i].u.step_counter);
          g_clock_origin_ns = now;
          g_counter_base_captured = true;
          LOGI("counter base captured value=%llu",
               static_cast<unsigned long long>(events[i].u.step_counter));
          break;
        }
      }
    }
    const double stepsFloat = currentStepsLocked(now);
    const uint64_t stepValue = static_cast<uint64_t>(std::floor(stepsFloat));
    const GaitTemplate* tmpl = g_gait.get();
    for (size_t i = 0; i < count; ++i) {
      if (g_config.stepSimulation &&
          (events[i].type == kTypeStepDetector ||
           events[i].type == kTypeStepCounter)) {
        if (rewriteStepEvent(events[i], now, stepValue)) ++rewritten;
      } else if (g_config.accelerometerSimulation &&
                 g_config.speedMps > 0.1 &&
                 events[i].type == kTypeAccelerometer &&
                 events[i].sensor == g_config.accelerometerHandle) {
        applyGait(events[i], now, g_config, tmpl, stepsFloat,
                  static_cast<uint64_t>(g_clock_origin_ns));
        g_accel_rewritten_events.fetch_add(1, std::memory_order_relaxed);
      }
    }
    if (hasStep) {
      g_rewritten_events.fetch_add(static_cast<uint64_t>(rewritten),
                                   std::memory_order_relaxed);
      LOGI("svc step fd=%d uid=%d count=%zu rewritten=%d speed=%.2f cadence=%d",
           fd, uid, count, rewritten, g_config.speedMps,
           effectiveCadenceLocked());
    }
  }
  recordTargetFd(fd);
}

// ---------------------------------------------------------------- 安装

struct LibBase {
  const char* name;
  uintptr_t base;
};

int findLibCallback(struct dl_phdr_info* info, size_t, void* data) {
  auto* target = static_cast<LibBase*>(data);
  if (info->dlpi_name != nullptr && strstr(info->dlpi_name, target->name) != nullptr) {
    target->base = static_cast<uintptr_t>(info->dlpi_addr);
    return 1;
  }
  return 0;
}

// onSystemServerStarting 时 libsensorservice 尚未加载，轮询到它出现后再 Hook 构造函数
void* ctorPollThread(void*) {
  for (int i = 0; i < 1200; ++i) {
    LibBase sensors{kLibSensorservice, 0};
    dl_iterate_phdr(findLibCallback, &sensors);
    if (sensors.base != 0) {
      auto* ctorAddr = reinterpret_cast<void*>(sensors.base + kConnectionCtorOffset);
      if (memcmp(ctorAddr, kConnectionCtorPrologue,
                 sizeof(kConnectionCtorPrologue)) != 0) {
        LOGE("SensorEventConnection ctor prologue mismatch at %p (base=%p)",
             ctorAddr, reinterpret_cast<void*>(sensors.base));
        return nullptr;
      }
      void* stub = shadowhook_hook_func_addr(
          ctorAddr, reinterpret_cast<void*>(&probeConnectionCtor),
          reinterpret_cast<void**>(&g_orig_connection_ctor));
      if (stub == nullptr || g_orig_connection_ctor == nullptr) {
        LOGE("ctor hook failed: %d (%s)", shadowhook_get_errno(),
             shadowhook_to_errmsg(shadowhook_get_errno()));
        return nullptr;
      }
      LOGI("SensorEventConnection ctor hook installed at %p (base=%p)", ctorAddr,
           reinterpret_cast<void*>(sensors.base));

      pthread_t injectTid{};
      if (pthread_create(&injectTid, nullptr, stepInjectThread, nullptr) == 0) {
        pthread_detach(injectTid);
        LOGI("step inject thread started");
      } else {
        LOGE("step inject thread create failed");
      }
      return nullptr;
    }
    usleep(100 * 1000);
  }
  LOGE("timeout waiting for libsensorservice.so");
  return nullptr;
}

bool install() {
  // global native 层已加载时拒绝安装第二套 Hook，避免重复改写/注入。
  LibBase globalLibrary{"liblocation_accel.so", 0};
  dl_iterate_phdr(findLibCallback, &globalLibrary);
  if (globalLibrary.base != 0) {
    LOGE("location_accel native library already loaded; refusing double sensor hooks");
    return false;
  }

  const int init = shadowhook_init(SHADOWHOOK_MODE_SHARED, false);
  if (init != 0) {
    LOGE("shadowhook_init failed: %d", init);
    return false;
  }

  LibBase libc{kLibcName, 0};
  dl_iterate_phdr(findLibCallback, &libc);
  if (libc.base == 0) {
    LOGE("libc.so not found via dl_iterate_phdr");
    return false;
  }

  auto* svcAddr = reinterpret_cast<void*>(libc.base + kLibcSvcOffset);
  if (memcmp(svcAddr, kLibcSvcBytes, sizeof(kLibcSvcBytes)) != 0) {
    LOGE("__sendto svc instruction mismatch at %p (libc base=%p)", svcAddr,
         reinterpret_cast<void*>(libc.base));
    return false;
  }

  void* stub = shadowhook_intercept_instr_addr(svcAddr, sendtoPreInterceptor,
                                               nullptr, 0);
  if (stub == nullptr) {
    LOGE("svc intercept failed: %d (%s)", shadowhook_get_errno(),
         shadowhook_to_errmsg(shadowhook_get_errno()));
    return false;
  }

  g_installed.store(true, std::memory_order_relaxed);
  LOGI("__sendto intercept installed at %p (libc base=%p)", svcAddr,
       reinterpret_cast<void*>(libc.base));

  pthread_t ctorTid{};
  if (pthread_create(&ctorTid, nullptr, ctorPollThread, nullptr) == 0) {
    pthread_detach(ctorTid);
    LOGI("ctor poll thread started");
  } else {
    LOGE("ctor poll thread create failed");
  }
  return true;
}

// ---------------------------------------------------------------- JNI

std::string jstringToStd(JNIEnv* env, jstring value) {
  if (value == nullptr) return {};
  const char* utf = env->GetStringUTFChars(value, nullptr);
  std::string out = utf != nullptr ? utf : "";
  if (utf != nullptr) env->ReleaseStringUTFChars(value, utf);
  return out;
}

bool configure(int32_t targetUid, double speedMps, int32_t cadenceSpm,
               int32_t stepDetectorHandle, int32_t stepCounterHandle,
               int32_t accelerometerHandle, int32_t realismLevel,
               int32_t fluctuationPct, bool active, bool stepSimulation,
               bool accelerometerSimulation, const std::string& gait) {
  std::lock_guard<std::mutex> lock(g_config_mutex);
  const int64_t now = nowNanos();
  const double current = currentStepsLocked(now);
  g_clock_base_steps = current;
  g_clock_origin_ns = now;

  g_config.targetUid = targetUid;
  g_config.speedMps = speedMps;
  g_config.cadenceSpm = cadenceSpm;
  g_config.stepDetectorHandle = stepDetectorHandle;
  g_config.stepCounterHandle = stepCounterHandle;
  g_config.accelerometerHandle = accelerometerHandle;
  g_config.realismLevel = realismLevel;
  g_config.fluctuationPct = fluctuationPct;
  g_config.active = active;
  g_config.stepSimulation = stepSimulation;
  g_config.accelerometerSimulation = accelerometerSimulation;
  g_config.gaitEncoded = gait;
  g_gait = parseGait(gait);

  LOGI("configure uid=%d speed=%.2f cadence=%d handles=%d/%d/0x%x realism=%d "
       "pct=%d active=%d step=%d accel=%d gait=%zu steps=%.1f",
       targetUid, speedMps, cadenceSpm, stepDetectorHandle, stepCounterHandle,
       accelerometerHandle, realismLevel, fluctuationPct, active ? 1 : 0,
       stepSimulation ? 1 : 0, accelerometerSimulation ? 1 : 0, gait.size(),
       current);
  return true;
}

}  // namespace

extern "C" JNIEXPORT jboolean JNICALL
Java_com_vincenthzr_sensorprobe_SensorProbeHooker_nativeInit(JNIEnv*, jclass,
                                                             jint targetUid) {
  {
    std::lock_guard<std::mutex> lock(g_config_mutex);
    g_config.targetUid = targetUid;
    g_clock_origin_ns = nowNanos();
    g_clock_base_steps = 0.0;
    g_counter_base_captured = false;
  }
  for (auto& fd : g_target_fds) fd.store(-1, std::memory_order_relaxed);
  for (auto& fd : g_fd_map) fd.store(-1, std::memory_order_relaxed);
  for (auto& uid : g_fd_uid_map) uid.store(-1, std::memory_order_relaxed);
  LOGI("nativeInit targetUid=%d", targetUid);
  if (g_installed.load(std::memory_order_relaxed)) return JNI_TRUE;
  return install() ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_vincenthzr_sensorprobe_SensorProbeHooker_nativeConfigure(
    JNIEnv* env, jclass, jint targetUid, jdouble speedMps, jint cadenceSpm,
    jint stepDetectorHandle, jint stepCounterHandle, jint accelerometerHandle,
    jint realismLevel, jint fluctuationPct, jboolean active,
    jboolean stepSimulation, jboolean accelerometerSimulation, jstring gait) {
  const bool ok = configure(
      targetUid, speedMps, cadenceSpm, stepDetectorHandle, stepCounterHandle,
      accelerometerHandle, realismLevel, fluctuationPct, active == JNI_TRUE,
      stepSimulation == JNI_TRUE, accelerometerSimulation == JNI_TRUE,
      jstringToStd(env, gait));
  return ok ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_vincenthzr_sensorprobe_SensorProbeHooker_nativeStatus(JNIEnv* env, jclass) {
  int fdCount = 0;
  for (auto& fd : g_target_fds) {
    if (fd.load(std::memory_order_relaxed) >= 0) ++fdCount;
  }
  char out[640];
  {
    std::lock_guard<std::mutex> lock(g_config_mutex);
    snprintf(out, sizeof(out),
             "{\"installed\":%s,\"targetUid\":%d,\"speed\":%.2f,\"cadence\":%d,"
             "\"active\":%s,\"step\":%s,\"accel\":%s,\"gait\":%zu,"
             "\"fds\":%d,\"rewritten\":%llu,\"accelRewritten\":%llu,"
             "\"injected\":%llu,\"errno\":%d,\"errmsg\":\"%s\"}",
             g_installed.load() ? "true" : "false", g_config.targetUid,
             g_config.speedMps, effectiveCadenceLocked(),
             g_config.active ? "true" : "false",
             g_config.stepSimulation ? "true" : "false",
             g_config.accelerometerSimulation ? "true" : "false",
             g_config.gaitEncoded.size(), fdCount,
             static_cast<unsigned long long>(g_rewritten_events.load()),
             static_cast<unsigned long long>(g_accel_rewritten_events.load()),
             static_cast<unsigned long long>(g_injected_events.load()),
             shadowhook_get_errno(),
             shadowhook_to_errmsg(shadowhook_get_errno()));
  }
  return env->NewStringUTF(out);
}
