import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.jetbrains.kotlin.android)
}

android {
    namespace = "com.vincenthzr.sensorprobe"
    compileSdk = 37
    ndkVersion = "27.2.12479018"

    defaultConfig {
        applicationId = "com.vincenthzr.sensorprobe"
        minSdk = 26
        targetSdk = 37
        versionCode = 1
        versionName = "0.1"

        // 首版只做 arm64；官方 native 也明确只支持 64 位进程
        ndk {
            abiFilters += listOf("arm64-v8a")
        }
        externalNativeBuild {
            cmake {
                cppFlags += listOf("-std=c++17", "-fno-exceptions", "-fno-rtti")
            }
        }
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    buildFeatures {
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

dependencies {
    // LSPosed 运行时提供；与现有 xposed 模块一致
    compileOnly(libs.xposed.api)
    // ShadowHook 的 Java 类与 native 库（Apache-2.0）；JNI_OnLoad 需要注册其 Java 类
    implementation("com.bytedance.android:shadowhook:2.0.1")
}
