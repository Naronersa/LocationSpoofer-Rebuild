# 适配进度（本重建版）

本文件记录 **本重建版** 的实机验证结果，不是作者官方完整适配声明，也不代表作者已验证的系统版本。

只登记本重建版在真实设备上实际测过的内容；没测过的一律写“未验证”，不要凭推测填写。

- 设备：arm64 测试机（型号与 ROM 信息已隐去），Android 13。
- Root / 框架：KernelSU + Zygisk Next + LSPosed（libxposed API 102）。
- 当前安装：global full-mode `.rebuild` 包（`com.vincenthzr.locationspoofer.rebuild`）。
- 验证日期：2026-10-19 / 2026-10-20。

**状态说明**：✅ 实测通过 · ⚠️ 部分可用（见备注） · ❌ 实测不可用 · ❔ 未验证

---

## 全局方案（global）

### 按系统

| 系统 | 适配器 | 状态 | 已验证的系统版本 | 备注 |
|---|---|---|---|---|
| 小米 HyperOS / MIUI | `HyperOsVendor` | ⚠️ | 厂商 ROM / Android 13（测试机） | 本重建版实测：system_server 七个系统组件均找到，电话与蓝牙进程组件找到，三份 Hook 报告均可读取，汇总 8/9（唯一未挂上方法的是本 ROM 缺少 `getSingleScanResults` 的 Wi-Fi 扫描服务）。定位、Wi-Fi、基站、AppOps、网络可用；蓝牙已能正常开启，普通扫描与虚拟信标待完整验证。HyperOS 4/3 等其它版本未由本重建版验证。 |
| OPPO ColorOS / 一加 OxygenOS | `ColorOs16Vendor` / `ColorOsVendor` | ❔ | — | 本重建版未验证；官方文档中的 ColorOS 结果不代表本重建版。 |
| 三星 One UI | `OneUiVendor` | ❔ | — | 本重建版未验证。 |
| vivo OriginOS、荣耀 MagicOS、魅族 Flyme 等 | 无专用适配器（回退 `AospVendor`） | ❔ | — | 本重建版未验证。 |
| 原生 AOSP / 类原生 | `AospVendor` | ❔ | — | 本重建版未验证。 |

### 按组件（Android 13 / 测试机）

| 组件 | 所在进程 | 状态 | 备注 |
|---|---|---|---|
| Hook 状态报告 | system_server / phone / bluetooth | ✅ | 三份报告均可读取，汇总 8/9。 |
| 定位（GPS / 网络 / 被动 / fused） | system_server | ✅ | `LocationManagerService`、`LocationProviderManager` 均找到；真机启停与配置下发通过。 |
| Wi-Fi 扫描与连接信息 | system_server | ⚠️ | `WifiServiceImpl.getScanResults/getConnectionInfo` 已挂载；`WifiScanningServiceImpl` 类找到，但本 ROM 没有 `getSingleScanResults`，因此“Wi-Fi 扫描服务”灰色显示“本 ROM 无此接口”。 |
| 网络状态脱敏 | system_server | ✅ | `ConnectivityService` 相关方法挂载。 |
| AppOps 模拟定位记录 | system_server | ✅ | `AppOpsService` / OP_MOCK_LOCATION 挂载。 |
| 基站信息 | com.android.phone | ✅ | `PhoneInterfaceManager.getAllCellInfo` / `getCellLocation` / `requestCellInfoUpdate` 挂载。 |
| 蓝牙扫描 / 虚拟信标 | com.android.bluetooth | ⚠️ | 本机蓝牙已开启，蓝牙进程报告已生成，`GattService` 的 `registerScanner` / `startScan` 已挂载。HyperOS 另有 `com.xiaomi.bluetooth` 扩展进程，但系统蓝牙适配器进程仍是 `com.android.bluetooth`。普通扫描与虚拟信标尚未端到端验证。若蓝牙无法开启并报 `BLE_START_TIMEOUT`，先检查 `com.android.bluetooth` 的“附近设备”运行时权限（`BLUETOOTH_CONNECT` / `BLUETOOTH_SCAN` / `BLUETOOTH_ADVERTISE`）是否被撤销。 |
| 原生传感器 / 气压 / 指南针 | system_server | ✅ | 本重建版 native 层在测试机上完成过步数、加速度、气压、指南针/陀螺仪注入测试；本文件只登记当前版本仍保留该能力，未重新做全量长测。 |

### 实测设备

| 设备 | 系统版本 | 验证日期 | 备注 |
|---|---|---|---|
| arm64 测试机 | 厂商 ROM / Android 13 | 2026-10-19、2026-10-20 | KernelSU + Zygisk Next + LSPosed；global `.rebuild` 包；8/9 Hook 组件汇总。 |

---

## 非全局方案（scoped）

| 设备 | 系统版本 | Root / LSPosed | 验证内容 | 状态 |
|---|---|---|---|---|
| arm64 测试机 | 厂商 ROM / Android 13 | KernelSU + LSPosed | scoped 包可安装；传感器/指南针/步数策略通过探针与对比包验证；未覆盖所有目标 App | ⚠️ |

> scoped 只 Hook 目标 App，不依赖系统适配。不同 App 的检测强度不同，不能把探针结果等同于所有目标 App 都可用。

---

## 功能验证

| 功能 | 状态 | 说明 |
|---|---|---|
| global 定位启停 | ✅ | 广播/界面启动、STOP、AppOps 恢复均已在本机验证。 |
| 路线 / 定点 / 摇杆 | ✅ | 既有功能保留；本轮未重新做长路线测试。 |
| 指南针 / 陀螺仪模拟 | ✅ | 本机 type 42 未暴露；orientation / magnetic / rotation vector / game / geomagnetic 已用探针验证。 |
| 步数 / 加速度 / 气压 native | ✅ | 本重建版 native 探针在测试机上验证；当前交付包保留该层。 |
| 导入 / 导出与 API Key 计数 | ✅ | 3 个非空 Key 显示“3 条”；dummy 测试后已清理，未使用真实 Key。 |
| 高德离线地图手动下载 | ✅ | 城市列表与手动“下载”按钮已修复；本机成功下载城市离线包。Key 由用户在运行时导入，不写入构建产物。 |
| 系统适配页状态 | ⚠️ | 本机显示 HyperOS 1.0 / Android 13、部分可用、8/9 Hook；不再引用官方 HyperOS 4/3 的验证声明。 |

---

## 未验证 / 限制

- HyperOS 4 / HyperOS 3、ColorOS 16、One UI、OriginOS、MagicOS、Flyme、Android 14+ 均未由本重建版验证。
- 蓝牙虚拟信标与部分厂商 BLE 派发路径未完成本机端到端验证。
- GNSS 芯片寄存器、厂商 HAL 私有 IOCTL、TEE/云端/会员功能不在本重建版范围内。
- 系统级 Hook 依赖 LSPosed/libxposed 与当前 ROM 实现；其它 ROM 需重新验证。
- 高德离线地图下载依赖高德控制台对 `.rebuild` 包名、签名 SHA-1 和离线地图服务的授权。

---

## 如何更新本文件

完成一次真机验证后：

1. 在对应表格里新增或修改一行；
2. 写清设备、系统版本、Root/LSPosed 版本、验证日期；
3. 未测的保持 ❔，不要因为“应该没问题”就标 ✅；
4. 标 ⚠️ / ❌ 时写明现象和关键日志。

本文件仍会打包进 App，但界面只读取本机顶部状态卡，不再展示完整进度页。
