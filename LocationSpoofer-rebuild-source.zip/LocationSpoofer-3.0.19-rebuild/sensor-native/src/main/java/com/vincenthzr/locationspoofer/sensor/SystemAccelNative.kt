package com.vincenthzr.locationspoofer.sensor

/**
 * global 系统级传感器 native 桥。
 *
 * 只在 system_server 中由 [GlobalSensorIntegration] 调用；native 侧通过
 * ShadowHook 拦截 libc `__sendto` 的 `svc` 指令，按目标 UID 改写
 * STEP_COUNTER / STEP_DETECTOR / ACCELEROMETER。
 */
internal object SystemAccelNative {

    external fun nativeSetProfile(
        svcOffset: Int,
        ctorOffset: Int,
        pltOffset: Int,
        bitTubeOffset: Int,
        bitTubeFdOffset: Int,
        force: Boolean
    ): Boolean

    external fun nativeInit(targetUids: IntArray, allApps: Boolean): Boolean

    external fun nativeConfigure(
        targetUids: IntArray,
        allApps: Boolean,
        speedMps: Double,
        cadenceSpm: Int,
        stepDetectorHandle: Int,
        stepCounterHandle: Int,
        accelerometerHandle: Int,
        realismLevel: Int,
        fluctuationPct: Int,
        active: Boolean,
        stepSimulation: Boolean,
        accelerometerSimulation: Boolean,
        gaitTemplate: String
    ): Boolean

    external fun nativeSetClockStart(startTimestampMs: Long): Boolean

    external fun nativeSetCompassHeading(
        trueHeadingDeg: Double,
        declinationDeg: Double,
        accuracyDeg: Double,
        horizontalUt: Double,
        verticalUt: Double,
        enabled: Boolean
    ): Boolean

    external fun nativeConfigurePressure(
        altitudeM: Double,
        altitudeVariationM: Double,
        latitude: Double,
        longitude: Double,
        driftM: Double,
        seaLevelHpa: Double,
        enabled: Boolean
    ): Boolean

    external fun nativeStatus(): String
}
