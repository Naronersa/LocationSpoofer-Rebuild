# LocationHooker 通过 Class.forName 反射调用该类，R8 无法静态发现引用
-keep class com.vincenthzr.locationspoofer.sensor.GlobalSensorIntegration { *; }
# JNI 方法按类名/方法名查找，不能被混淆或裁剪
-keep class com.vincenthzr.locationspoofer.sensor.SystemAccelNative { *; }
# JNI_OnLoad 通过类名注册 ShadowHook 的 native 方法
-keep class com.bytedance.shadowhook.ShadowHook { *; }
