package com.vincenthzr.locationspoofer.utils

import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.pow
import kotlin.math.sin

/**
 * 手持手机跑步时的陀螺仪角速度模型（设备坐标系，单位 rad/s）。
 *
 * 设备视为水平：X 右（滚转）、Y 上（俯仰）、Z 屏幕外（偏航）。
 * 角速度由四部分叠加：
 *
 *   ω(t) = ω_gait(t) + ω_impact(t) + ω_noise(t) + ω_turn(t)
 *
 * - 步态基频：p = frac(stepsFloat)，φ = 2πp；步频 f = cadence/60。
 * - 步态主振动（滚转/俯仰/偏航分别有不同幅度）：
 *     g_x = A_r [0.72 sin(φ+φ1) + 0.20 sin(2φ+φ2) + 0.08 sin(3φ+φ3)]
 *     g_y = A_p [0.68 sin(φ+ψ1) + 0.24 sin(2φ+ψ2)]
 *     g_z = A_y [0.75 sin(φ+χ1) + 0.25 sin(3φ+χ2)]
 * - 脚跟着地冲击：s(p) = exp(-0.5*((p-0.02)/0.075)^2)，
 *   左右脚交替 (+/-)；x/y 各叠加 0.35/0.25 倍冲击。
 * - 带限手持抖动（低频正弦叠加，周期 1.7s/0.63s/0.27s，确定性相位）：
 *     n_i = A_n [0.55 sin(2πt/1.7+...) + 0.30 sin(2πt/0.63+...) + 0.15 sin(2πt/0.27+...)]
 * - 路线转向：ω_turn 由真北 bearing 的短时差分得到（rad/s），只加在 Z（偏航）上。
 *
 * 幅度：
 *   A_r = (0.10 + 0.045v) * (0.65 + 0.35r) * (1.65 if running)
 *   A_p = (0.08 + 0.038v) * (0.65 + 0.35r) * (1.60 if running)
 *   A_y = (0.06 + 0.028v) * (0.65 + 0.35r) * (1.45 if running)
 *   A_n = (0.02 + 0.012v) * (0.5 + 0.5r) * (1 + 0.5F)
 * 其中 v 为速度 m/s、r = realism/3、F = fluctuation/100、running 为 v>=2.2。
 *
 * 所有相位由 startTimestamp 与步号 hash 得到，因此同一会话可复现；输出限幅 ±6 rad/s，
 * 转向角速度单独限幅 ±3.5 rad/s。该模型不模拟真实倾斜，只模拟“手持跑步”的角速度抖动。
 */
object GyroMotion {

    private const val TWO_PI = 2.0 * PI
    private const val RUN_SPEED_MPS = 2.2
    private const val MAX_GYRO_RAD = 6.0
    private const val MAX_TURN_RATE_RAD = 3.5

    private const val SALT_X = 0x4759524F58L
    private const val SALT_Y = 0x4759524F59L
    private const val SALT_Z = 0x4759524F5AL
    private const val SALT_NOISE_X = 0x4E4F49534558L
    private const val SALT_NOISE_Y = 0x4E4F49534559L
    private const val SALT_NOISE_Z = 0x4E4F4953455AL
    private const val SALT_STEP = 0x53544550L

    /**
     * @param stepsFloat 连续累计步数（整数部分步号，小数部分步相）
     * @param cadenceSpm 当前步频（60..240）
     * @param speedMps 当前模拟速度
     * @param elapsedSec 从 start_timestamp 起经过的秒数
     * @param yawRateRad 路线转向角速度（rad/s，绕 Z）
     */
    fun sample(
        stepsFloat: Double,
        cadenceSpm: Int,
        speedMps: Double,
        realismLevel: Int,
        fluctuationPct: Int,
        startTimestampMs: Long,
        yawRateRad: Double,
        elapsedSec: Double,
    ): FloatArray {
        if (!stepsFloat.isFinite() || !speedMps.isFinite() ||
            !elapsedSec.isFinite() || speedMps <= 0.05
        ) {
            return floatArrayOf(0.0f, 0.0f, 0.0f)
        }

        val speed = speedMps.coerceAtLeast(0.0)
        val realism = realismLevel.coerceIn(0, 3) / 3.0
        val fluctuation = fluctuationPct.coerceIn(0, 30) / 100.0
        val running = speed >= RUN_SPEED_MPS
        val runningScale = when {
            !running -> 1.0
            realism >= 0.9 -> 1.75
            else -> 1.60
        }
        val baseScale = (0.65 + 0.35 * realism) * runningScale
        val rollAmp = (0.10 + 0.045 * speed).coerceAtLeast(0.03) * baseScale
        val pitchAmp = (0.08 + 0.038 * speed).coerceAtLeast(0.025) * baseScale
        val yawAmp = (0.06 + 0.028 * speed).coerceAtLeast(0.02) * baseScale
        val noiseAmp = (0.02 + 0.012 * speed) *
            (0.5 + 0.5 * realism) *
            (1.0 + 0.5 * fluctuation) *
            (if (running) 1.25 else 1.0)

        val cadence = cadenceSpm.coerceIn(60, 240)
        // 步频越高，脚跟着地冲击越短促。
        val strikeWidth = (0.075 * 120.0 / cadence).coerceIn(0.055, 0.110)
        val step = floor(stepsFloat)
        val stepIndex = step.toLong()
        val phase = TWO_PI * (stepsFloat - step)
        val strike = exp(-0.5 * ((stepsFloat - step - 0.02) / strikeWidth).pow(2))
        val stepStrength = unit(startTimestampMs xor SALT_STEP, stepIndex)
        val alternating = if (stepIndex % 2L == 0L) 1.0 else -1.0

        val x1 = TWO_PI * unit(startTimestampMs xor SALT_X, 1)
        val x2 = TWO_PI * unit(startTimestampMs xor SALT_X, 2)
        val x3 = TWO_PI * unit(startTimestampMs xor SALT_X, 3)
        val y1 = TWO_PI * unit(startTimestampMs xor SALT_Y, 1)
        val y2 = TWO_PI * unit(startTimestampMs xor SALT_Y, 2)
        val z1 = TWO_PI * unit(startTimestampMs xor SALT_Z, 1)
        val z2 = TWO_PI * unit(startTimestampMs xor SALT_Z, 2)

        val gaitX = rollAmp * (
            0.72 * sin(phase + x1) +
                0.20 * sin(2.0 * phase + x2) +
                0.08 * sin(3.0 * phase + x3)
            ) + rollAmp * 0.35 * stepStrength * strike
        val gaitY = pitchAmp * (
            0.68 * sin(phase + y1) +
                0.24 * sin(2.0 * phase + y2)
            ) + pitchAmp * 0.25 * alternating * strike
        val gaitZ = yawAmp * (
            0.75 * sin(phase + z1) +
                0.25 * sin(3.0 * phase + z2)
            ) + yawAmp * 0.20 * alternating * strike

        val turn = yawRateRad.coerceIn(-MAX_TURN_RATE_RAD, MAX_TURN_RATE_RAD)
        val noiseX = noise(noiseAmp, elapsedSec, startTimestampMs xor SALT_NOISE_X)
        val noiseY = noise(noiseAmp, elapsedSec, startTimestampMs xor SALT_NOISE_Y)
        val noiseZ = noise(noiseAmp, elapsedSec, startTimestampMs xor SALT_NOISE_Z)

        return floatArrayOf(
            clampGyro(gaitX + noiseX),
            clampGyro(gaitY + noiseY),
            clampGyro(gaitZ + turn + noiseZ)
        )
    }

    private fun noise(amplitude: Double, tSec: Double, seed: Long): Double {
        if (amplitude <= 0.0) return 0.0
        val p1 = TWO_PI * unit(seed, 1)
        val p2 = TWO_PI * unit(seed, 2)
        val p3 = TWO_PI * unit(seed, 3)
        return amplitude * (
            0.55 * sin(TWO_PI * tSec / 1.7 + p1) +
                0.30 * sin(TWO_PI * tSec / 0.63 + p2) +
                0.15 * sin(TWO_PI * tSec / 0.27 + p3)
            )
    }

    private fun clampGyro(value: Double): Float {
        val finite = if (value.isFinite()) value else 0.0
        return finite.coerceIn(-MAX_GYRO_RAD, MAX_GYRO_RAD).toFloat()
    }

    /** 确定性 [-1,1] 伪随机数；与 MotionRealism.hashUnit 的混合方式一致。 */
    private fun unit(seed: Long, n: Long): Double {
        var x = seed xor (n * -0x61c8864680b583ebL)
        x = (x xor (x ushr 33)) * -0xae502812aa7333L
        x = (x xor (x ushr 33)) * -0x3b314601e57a13adL
        x = x xor (x ushr 33)
        return (x ushr 11).toDouble() / (1L shl 53).toDouble() * 2.0 - 1.0
    }
}
