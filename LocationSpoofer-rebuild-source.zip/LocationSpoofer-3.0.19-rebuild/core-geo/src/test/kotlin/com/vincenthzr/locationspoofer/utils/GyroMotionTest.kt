package com.vincenthzr.locationspoofer.utils

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.sqrt

class GyroMotionTest {

    private fun sample(
        steps: Double,
        speed: Double,
        cadence: Int,
        yawRate: Double = 0.0,
        realism: Int = 2,
    ): FloatArray = GyroMotion.sample(
        stepsFloat = steps,
        cadenceSpm = cadence,
        speedMps = speed,
        realismLevel = realism,
        fluctuationPct = 10,
        startTimestampMs = 1_700_000_000_000L,
        yawRateRad = yawRate,
        elapsedSec = steps / (cadence / 60.0),
    )

    @Test
    fun deterministicForSameSession() {
        val a = sample(12.35, 2.4, 150)
        val b = sample(12.35, 2.4, 150)
        assertEquals(a[0], b[0], 0.0f)
        assertEquals(a[1], b[1], 0.0f)
        assertEquals(a[2], b[2], 0.0f)
    }

    @Test
    fun runningJitterIsStrongerThanWalking() {
        val walking = (0 until 30).map { sample(it * 0.37, 1.2, 110) }
        val running = (0 until 30).map { sample(it * 0.37, 3.2, 180) }
        fun rms(values: List<FloatArray>): Double {
            val sums = values.sumOf { v -> v[0].toDouble() * v[0] + v[1].toDouble() * v[1] + v[2].toDouble() * v[2] }
            return sqrt(sums / values.size)
        }
        assertTrue(rms(running) > rms(walking) * 1.5)
    }

    @Test
    fun yawRateIsAddedToZAxis() {
        val withoutTurn = (0 until 20).map { sample(it * 0.21, 2.5, 150, yawRate = 0.0) }
        val withTurn = (0 until 20).map { sample(it * 0.21, 2.5, 150, yawRate = 2.0) }
        val zDelta = withTurn.indices.map { withTurn[it][2].toDouble() - withoutTurn[it][2].toDouble() }
        assertTrue(zDelta.average() > 1.5)
        assertTrue(zDelta.all { it in 1.0..3.0 })
    }

    @Test
    fun stationaryReturnsZero() {
        val values = sample(42.0, 0.0, 120)
        assertEquals(0.0, values[0].toDouble(), 0.0)
        assertEquals(0.0, values[1].toDouble(), 0.0)
        assertEquals(0.0, values[2].toDouble(), 0.0)
    }

    @Test
    fun outputIsFiniteAndClamped() {
        for (i in 0 until 500) {
            val values = sample(i * 0.17, 8.0, 240, yawRate = 99.0, realism = 3)
            values.forEach {
                assertTrue(it.isFinite())
                assertTrue(it in -6.0f..6.0f)
            }
        }
    }

    @Test
    fun realismIncreasesJitter() {
        val low = (0 until 30).map { sample(it * 0.31, 2.5, 150, realism = 0) }
        val high = (0 until 30).map { sample(it * 0.31, 2.5, 150, realism = 3) }
        val lowRms = sqrt(low.sumOf { it[0].toDouble() * it[0] + it[1].toDouble() * it[1] }.div(low.size))
        val highRms = sqrt(high.sumOf { it[0].toDouble() * it[0] + it[1].toDouble() * it[1] }.div(high.size))
        assertTrue(highRms > lowRms)
    }
}
