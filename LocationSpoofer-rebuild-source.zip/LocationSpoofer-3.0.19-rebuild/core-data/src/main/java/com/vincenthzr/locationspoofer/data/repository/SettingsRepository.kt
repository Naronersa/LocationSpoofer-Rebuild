package com.vincenthzr.locationspoofer.data.repository

import com.vincenthzr.locationspoofer.data.model.RoutePoint
import com.vincenthzr.locationspoofer.data.model.SavedLocation
import com.vincenthzr.locationspoofer.data.model.SavedRoute
import com.vincenthzr.locationspoofer.utils.SettingsManager
import org.json.JSONArray
import org.json.JSONObject

class SettingsRepository(private val settingsManager: SettingsManager) {

    fun getSavedLocations(): List<SavedLocation> = settingsManager.getSavedLocations()

    fun setSavedLocations(locations: List<SavedLocation>) = settingsManager.saveLocationList(locations)

    fun addSavedLocation(location: SavedLocation) = settingsManager.addSavedLocation(location)

    fun removeSavedLocation(location: SavedLocation) = settingsManager.removeSavedLocation(location)

    fun getSavedRoutes(): List<SavedRoute> = settingsManager.getSavedRoutes()

    fun addSavedRoute(route: SavedRoute) = settingsManager.addSavedRoute(route)

    fun removeSavedRoute(route: SavedRoute) = settingsManager.removeSavedRoute(route)

    fun isLanguageSet(): Boolean = settingsManager.isLanguageSet

    fun shouldShowLanguageSelection(): Boolean = settingsManager.shouldShowLanguageSelection()

    fun setLanguageSet(value: Boolean) {
        settingsManager.isLanguageSet = value
    }

    fun getLanguage(): String = settingsManager.language

    fun setLanguage(value: String) {
        settingsManager.language = value
    }

    fun getAmapApiKey(): String = settingsManager.amapApiKey

    fun setAmapApiKey(value: String) {
        settingsManager.amapApiKey = value
    }

    fun getBaiduApiKey(): String = settingsManager.baiduApiKey

    fun setBaiduApiKey(value: String) {
        settingsManager.baiduApiKey = value
    }

    fun getGoogleApiKey(): String = settingsManager.googleApiKey

    fun setGoogleApiKey(value: String) {
        settingsManager.googleApiKey = value
    }

    fun getWigleApiToken(): String = settingsManager.wigleApiToken

    fun setWigleApiToken(value: String) {
        settingsManager.wigleApiToken = value
    }

    fun getOpencellidApiToken(): String = settingsManager.opencellidApiToken

    fun setOpencellidApiToken(value: String) {
        settingsManager.opencellidApiToken = value
    }

    fun getMapType(): String = settingsManager.mapType

    fun setMapType(value: String) {
        settingsManager.mapType = value
    }

    fun getMapEngine(): String = settingsManager.mapEngine

    fun setMapEngine(value: String) {
        settingsManager.mapEngine = value
    }

    fun getRootSolution(): String = settingsManager.rootSolution

    fun setRootSolution(value: String) {
        settingsManager.rootSolution = value
    }

    fun getVendorOverride(): String = settingsManager.vendorOverride

    fun setVendorOverride(value: String) {
        settingsManager.vendorOverride = value
    }

    var debugDumpSystemServices: Boolean
        get() = settingsManager.debugDumpSystemServices
        set(value) {
            settingsManager.debugDumpSystemServices = value
        }

    fun getIgnoredVersion(): String = settingsManager.ignoredVersion

    fun setIgnoredVersion(value: String) {
        settingsManager.ignoredVersion = value
    }

    fun getAppCoordinateSystems(): Map<String, String> = settingsManager.getAppCoordinateSystems()

    fun setAppCoordinateSystems(map: Map<String, String>) =
        settingsManager.setAppCoordinateSystems(map)

    fun getSystemHookPackages(): Set<String> = settingsManager.getSystemHookPackages()

    fun setSystemHookPackages(packages: Set<String>) =
        settingsManager.setSystemHookPackages(packages)

    var isSystemHookGlobalMode: Boolean
        get() = settingsManager.isSystemHookGlobalMode
        set(value) {
            settingsManager.isSystemHookGlobalMode = value
        }

    var forceLocationEnabled: Boolean
        get() = settingsManager.forceLocationEnabled
        set(value) { settingsManager.forceLocationEnabled = value }

    var isSpoofingActive: Boolean
        get() = settingsManager.isSpoofingActive
        set(value) {
            settingsManager.isSpoofingActive = value
        }

    var lastSpoofedLat: String
        get() = settingsManager.lastSpoofedLat
        set(value) {
            settingsManager.lastSpoofedLat = value
        }

    var lastSpoofedLng: String
        get() = settingsManager.lastSpoofedLng
        set(value) {
            settingsManager.lastSpoofedLng = value
        }

    var mockWifi: Boolean
        get() = settingsManager.mockWifi
        set(value) {
            settingsManager.mockWifi = value
        }

    var mockCell: Boolean
        get() = settingsManager.mockCell
        set(value) {
            settingsManager.mockCell = value
        }

    var mockBluetooth: Boolean
        get() = settingsManager.mockBluetooth
        set(value) {
            settingsManager.mockBluetooth = value
        }

    var enableJitter: Boolean
        get() = settingsManager.enableJitter
        set(value) {
            settingsManager.enableJitter = value
        }

    var restartAppsOnSpoof: Boolean
        get() = settingsManager.restartAppsOnSpoof
        set(value) {
            settingsManager.restartAppsOnSpoof = value
        }

    var altitude: String
        get() = settingsManager.altitude
        set(value) {
            settingsManager.altitude = value
        }

    var altitudeVariationM: Int
        get() = settingsManager.altitudeVariationM
        set(value) {
            settingsManager.altitudeVariationM = value
        }

    var realismLevel: Int
        get() = settingsManager.realismLevel
        set(value) {
            settingsManager.realismLevel = value
        }

    var speedFluctuationPct: Int
        get() = settingsManager.speedFluctuationPct
        set(value) {
            settingsManager.speedFluctuationPct = value
        }

    var barometerFluctuation: Boolean
        get() = settingsManager.barometerFluctuation
        set(value) {
            settingsManager.barometerFluctuation = value
        }

    var compassSimulationEnabled: Boolean
        get() = settingsManager.compassSimulationEnabled
        set(value) {
            settingsManager.compassSimulationEnabled = value
        }

    var fixedJoystickEnabled: Boolean
        get() = settingsManager.fixedJoystickEnabled
        set(value) {
            settingsManager.fixedJoystickEnabled = value
        }

    var routeLateralDeviation: Boolean
        get() = settingsManager.routeLateralDeviation
        set(value) {
            settingsManager.routeLateralDeviation = value
        }

    fun isRouteWaitingToStart(): Boolean = settingsManager.routeWaitingToStart

    fun getRouteWaitingPoints(): List<RoutePoint> {
        val raw = settingsManager.routeWaitingPoints
        if (raw.isBlank()) return emptyList()
        return try {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val obj = array.optJSONObject(i) ?: continue
                    add(
                        RoutePoint(
                            obj.optDouble("lat", Double.NaN),
                            obj.optDouble("lng", Double.NaN),
                            obj.optDouble("waitSec", 0.0)
                        )
                    )
                }
            }.filter { it.lat.isFinite() && it.lng.isFinite() }
        } catch (_: Throwable) {
            emptyList()
        }
    }

    fun getRouteWaitingSimMode(): String = settingsManager.routeWaitingSimMode

    fun getRouteWaitingCustomSpeed(): Double = settingsManager.routeWaitingCustomSpeed.toDouble()

    fun getRouteWaitingRunMode(): String = settingsManager.routeWaitingRunMode

    fun clearRouteWaitingState() {
        settingsManager.routeWaitingToStart = false
        settingsManager.routeWaitingPoints = "[]"
    }

    fun setRouteWaitingState(
        points: List<RoutePoint>,
        simMode: String,
        customSpeed: Double,
        runMode: String
    ) {
        val array = JSONArray()
        points.forEach { p ->
            array.put(JSONObject().apply {
                put("lat", p.lat)
                put("lng", p.lng)
                put("waitSec", p.waitSec)
            })
        }
        settingsManager.routeWaitingPoints = array.toString()
        settingsManager.routeWaitingSimMode = simMode
        settingsManager.routeWaitingCustomSpeed = customSpeed.toFloat()
        settingsManager.routeWaitingRunMode = runMode
        settingsManager.routeWaitingToStart = points.size >= 2
    }

    var gaitTemplate: String
        get() = settingsManager.gaitTemplate
        set(value) {
            settingsManager.gaitTemplate = value
        }

    var useGaitTemplate: Boolean
        get() = settingsManager.useGaitTemplate
        set(value) {
            settingsManager.useGaitTemplate = value
        }

    var keepLastMapPosition: Boolean
        get() = settingsManager.keepLastMapPosition
        set(value) {
            settingsManager.keepLastMapPosition = value
        }

    /** 仅使用高德离线瓦片，禁止地图 SDK 联网 */
    var amapOfflineOnly: Boolean
        get() = settingsManager.amapOfflineOnly
        set(value) {
            settingsManager.amapOfflineOnly = value
        }

    /** 最后一次选定的地图位置（GCJ-02），未保存过时返回 null */
    fun getLastMapPosition(): Pair<String, String>? {
        val lat = settingsManager.lastMapLat
        val lng = settingsManager.lastMapLng
        return if (lat.isNotBlank() && lng.isNotBlank()) lat to lng else null
    }

    fun setLastMapPosition(lat: String, lng: String) {
        settingsManager.lastMapLat = lat
        settingsManager.lastMapLng = lng
    }

    var satelliteCount: String
        get() = settingsManager.satelliteCount
        set(value) {
            settingsManager.satelliteCount = value
        }

    var checkBetaUpdates: Boolean
        get() = settingsManager.checkBetaUpdates
        set(value) {
            settingsManager.checkBetaUpdates = value
        }
}
