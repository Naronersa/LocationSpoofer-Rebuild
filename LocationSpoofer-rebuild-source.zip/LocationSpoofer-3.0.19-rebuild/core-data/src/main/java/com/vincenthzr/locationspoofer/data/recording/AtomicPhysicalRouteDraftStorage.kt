package com.vincenthzr.locationspoofer.data.recording

import android.content.Context
import android.util.AtomicFile
import java.io.File

/**
 * 将录制草稿写入 noBackupFilesDir/physical-route-draft.json（AtomicFile，崩溃安全）。
 * 文件名与官方 3.0.19 保持一致。
 */
class AtomicPhysicalRouteDraftStorage(context: Context) : PhysicalRouteDraftStorage {

    private val file = AtomicFile(File(context.noBackupFilesDir, "physical-route-draft.json"))

    override fun load(): PhysicalRouteDraft? {
        val base = file.baseFile
        if (!base.exists() && !File(base.path + ".bak").exists()) return null
        return try {
            file.openRead().use { input ->
                if (input.channel.size() > PhysicalRouteDraft.MAX_BYTES) {
                    throw IllegalArgumentException("draft file too large")
                }
                val text = input.bufferedReader(Charsets.UTF_8).readText()
                PhysicalRouteDraft.decode(text)
            }
        } catch (_: Exception) {
            // 损坏/超限/无法解析的草稿直接丢弃，避免录制器永久停在 STORAGE 状态
            file.delete()
            null
        }
    }

    override fun save(draft: PhysicalRouteDraft) {
        val output = file.startWrite()
        try {
            output.write(draft.encode().toByteArray(Charsets.UTF_8))
            file.finishWrite(output)
        } catch (e: Exception) {
            file.failWrite(output)
            throw e
        }
    }

    override fun clear() {
        file.delete()
        val base = file.baseFile
        check(!base.exists() && !File(base.path + ".bak").exists()) { "draft file still present" }
    }
}
