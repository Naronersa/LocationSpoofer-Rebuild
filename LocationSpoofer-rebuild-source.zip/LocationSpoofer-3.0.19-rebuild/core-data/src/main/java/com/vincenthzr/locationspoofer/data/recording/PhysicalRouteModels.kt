package com.vincenthzr.locationspoofer.data.recording

import com.vincenthzr.locationspoofer.data.model.RoutePoint
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** 录制控制命令，服务与录制器共用的稳定标识（也是 Intent action 名）。 */
enum class PhysicalRouteCommand { START, RESUME, PAUSE, FINISH }

/** 录制阶段。 */
enum class PhysicalRoutePhase { IDLE, RECORDING, PAUSED, FINISHED }

/** 录制过程中的问题/提示。 */
enum class PhysicalRouteIssue {
    NONE,
    WAITING,
    GPS_OFF,
    POOR_ACCURACY,
    STALE,
    MOCK_LOCATION,
    JUMP,
    GAP,
    LIMIT,
    PERMISSION,
    SIMULATION_ACTIVE,
    STORAGE,
    INTERRUPTED,
}

/** 一条真实定位采样（WGS-84）。 */
data class PhysicalRouteFix(
    val lat: Double,
    val lng: Double,
    val accuracyM: Float,
    val elapsedNanos: Long,
    val mock: Boolean = false,
)

/** 对外暴露的录制状态。 */
data class PhysicalRouteRecordingState(
    val ready: Boolean = true,
    val id: String? = null,
    val phase: PhysicalRoutePhase = PhysicalRoutePhase.IDLE,
    val points: List<RoutePoint> = emptyList(),
    val distanceM: Double = 0.0,
    val durationMillis: Long = 0L,
    val accuracyM: Float? = null,
    val issue: PhysicalRouteIssue = PhysicalRouteIssue.NONE,
    val saving: Boolean = false,
) {
    val recording: Boolean get() = phase == PhysicalRoutePhase.RECORDING

    /** 是否有可保存/恢复的草稿（完成后仍为 true，保存或丢弃后归零）。 */
    val hasDraft: Boolean get() = id != null && phase != PhysicalRoutePhase.IDLE
}

/**
 * 录制草稿。落盘格式与官方 3.0.19 保持一致：
 * {"version":1,"coordinateSystem":"WGS84","id":"<uuid>","durationMillis":..,"finished":..,"points":[[lat,lng],...]}
 */
data class PhysicalRouteDraft(
    val id: String,
    val pointsWgs84: List<RoutePoint>,
    val durationMillis: Long,
    val finished: Boolean,
) {
    fun encode(): String {
        val root = JSONObject()
            .put("version", VERSION)
            .put("coordinateSystem", COORDINATE_SYSTEM)
            .put("id", id)
            .put("durationMillis", durationMillis)
            .put("finished", finished)
        val array = JSONArray()
        for (point in pointsWgs84) {
            array.put(JSONArray().put(point.lat).put(point.lng))
        }
        return root.put("points", array).toString()
    }

    companion object {
        const val VERSION = 1
        const val COORDINATE_SYSTEM = "WGS84"
        const val MAX_BYTES = 2_000_000
        const val MAX_POINTS = 10_000
        const val MAX_DURATION_MILLIS = 604_800_000L

        /** 解析并校验草稿；任何不一致返回 null（调用方按“无草稿”处理）。 */
        fun decode(text: String): PhysicalRouteDraft? {
            if (text.length > MAX_BYTES) return null
            val root = JSONObject(text)
            if (root.getInt("version") != VERSION) return null
            if (root.getString("coordinateSystem") != COORDINATE_SYSTEM) return null
            val id = root.getString("id")
            if (UUID.fromString(id).toString() != id) return null
            val array = root.getJSONArray("points")
            if (array.length() > MAX_POINTS) return null
            val points = ArrayList<RoutePoint>(array.length())
            for (index in 0 until array.length()) {
                val pair = array.getJSONArray(index)
                if (pair.length() != 2) return null
                val lat = pair.getDouble(0)
                val lng = pair.getDouble(1)
                if (lat.isNaN() || lng.isNaN()) return null
                if (lat !in -90.0..90.0 || lng !in -180.0..180.0) return null
                points.add(RoutePoint(lat, lng))
            }
            val duration = root.getLong("durationMillis")
            if (duration < 0L || duration >= MAX_DURATION_MILLIS + 1) return null
            return PhysicalRouteDraft(id, points, duration, root.getBoolean("finished"))
        }
    }
}

/** 草稿持久化。 */
interface PhysicalRouteDraftStorage {
    fun load(): PhysicalRouteDraft?
    fun save(draft: PhysicalRouteDraft)
    fun clear()
}
