package com.vincenthzr.locationspoofer.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface SavedRouteDao {
    @Query("SELECT * FROM saved_routes ORDER BY timestamp DESC")
    fun getAllSavedRoutes(): Flow<List<SavedRouteEntity>>

    @Query("SELECT * FROM saved_routes ORDER BY timestamp DESC")
    suspend fun getAllSavedRoutesList(): List<SavedRouteEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSavedRoute(route: SavedRouteEntity)

    @Delete
    suspend fun deleteSavedRoute(route: SavedRouteEntity)

    /** 官方 3.0.17 起按唯一标识查找/删除，避免同名路线误删。 */
    @Query("SELECT * FROM saved_routes WHERE syncId = :syncId LIMIT 1")
    suspend fun findBySyncId(syncId: String): SavedRouteEntity?

    @Query("DELETE FROM saved_routes WHERE syncId = :syncId")
    suspend fun deleteBySyncId(syncId: String)
}
