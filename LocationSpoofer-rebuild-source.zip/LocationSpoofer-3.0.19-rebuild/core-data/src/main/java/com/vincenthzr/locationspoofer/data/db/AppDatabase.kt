package com.vincenthzr.locationspoofer.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        LocationRecord::class,
        LocationConnectedWifi::class,
        WifiDevice::class, LocationWifi::class,
        BluetoothDevice::class, LocationBluetooth::class,
        CellDevice::class, LocationCell::class,
        SavedRouteEntity::class, CollectionRouteRecord::class
    ],
    version = 12,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun environmentDao(): EnvironmentDao
    abstract fun savedRouteDao(): SavedRouteDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        private val MIGRATION_3_4 = object : androidx.room.migration.Migration(3, 4) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE location_records ADD COLUMN placeName TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE location_records ADD COLUMN remark TEXT NOT NULL DEFAULT ''")
            }
        }

        private val MIGRATION_6_7 = object : androidx.room.migration.Migration(6, 7) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE location_records ADD COLUMN selectedWifiBssid TEXT")
                db.execSQL("ALTER TABLE location_records ADD COLUMN selectedBluetoothAddress TEXT")
                db.execSQL("ALTER TABLE location_records ADD COLUMN selectedCellKey TEXT")
            }
        }

        private val MIGRATION_7_8 = object : androidx.room.migration.Migration(7, 8) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("CREATE INDEX IF NOT EXISTS index_location_records_lat_lng ON location_records(lat, lng)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_location_records_timestamp ON location_records(timestamp)")
            }
        }

        private val MIGRATION_8_9 = object : androidx.room.migration.Migration(8, 9) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS collection_routes (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, name TEXT NOT NULL, remark TEXT NOT NULL, pointsJson TEXT NOT NULL, halfWidthM REAL NOT NULL, timestamp INTEGER NOT NULL)")
                db.execSQL("ALTER TABLE location_records ADD COLUMN collectionRouteId INTEGER REFERENCES collection_routes(id) ON DELETE CASCADE")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_location_records_collectionRouteId ON location_records(collectionRouteId)")
            }
        }

        /** 官方 3.0.12+：位置、采集路线、保存路线增加跨设备同步唯一标识。 */
        private val MIGRATION_9_10 = object : androidx.room.migration.Migration(9, 10) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                for (table in listOf("location_records", "collection_routes", "saved_routes")) {
                    db.execSQL("ALTER TABLE $table ADD COLUMN syncId TEXT NOT NULL DEFAULT ''")
                    val ids = ArrayList<Long>()
                    db.query("SELECT id FROM $table").use { cursor ->
                        while (cursor.moveToNext()) ids.add(cursor.getLong(0))
                    }
                    for (id in ids) {
                        db.execSQL(
                            "UPDATE $table SET syncId=? WHERE id=?",
                            arrayOf<Any>(java.util.UUID.randomUUID().toString(), id)
                        )
                    }
                }
            }
        }

        /** 官方 3.0.17：保存路线增加"录制来源"标记。 */
        private val MIGRATION_10_11 = object : androidx.room.migration.Migration(10, 11) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE saved_routes ADD COLUMN recorded INTEGER NOT NULL DEFAULT 0")
            }
        }

        /**
         * 官方 3.0.18：三类记录增加坐标参考系，并把原始坐标备份到 coordinate_backup_v11。
         * 迁移只补列与备份，不修改已保存的坐标值（与官方"不自动修改原始坐标"一致）。
         */
        private val MIGRATION_11_12 = object : androidx.room.migration.Migration(11, 12) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS coordinate_backup_v11(" +
                        "kind TEXT NOT NULL,record_id INTEGER NOT NULL,payload TEXT NOT NULL," +
                        "PRIMARY KEY(kind,record_id))"
                )
                // location_records 存的是单点
                db.execSQL("ALTER TABLE location_records ADD COLUMN coordinateSystem TEXT NOT NULL DEFAULT 'WGS84'")
                db.query("SELECT id,lat,lng FROM location_records").use { cursor ->
                    while (cursor.moveToNext()) {
                        val payload = org.json.JSONObject()
                            .put("lat", cursor.getDouble(1))
                            .put("lng", cursor.getDouble(2))
                            .toString()
                        db.execSQL(
                            "INSERT OR IGNORE INTO coordinate_backup_v11 VALUES(?,?,?)",
                            arrayOf<Any>("location_records", cursor.getLong(0), payload)
                        )
                    }
                }
                // 两类路线存的是 pointsJson
                for (table in listOf("saved_routes", "collection_routes")) {
                    db.execSQL("ALTER TABLE $table ADD COLUMN coordinateSystem TEXT NOT NULL DEFAULT 'WGS84'")
                    val rows = ArrayList<Pair<Long, String>>()
                    db.query("SELECT id,pointsJson FROM $table").use { cursor ->
                        while (cursor.moveToNext()) rows.add(cursor.getLong(0) to cursor.getString(1))
                    }
                    for ((id, pointsJson) in rows) {
                        val payload = org.json.JSONObject().put("pointsJson", pointsJson).toString()
                        db.execSQL(
                            "INSERT OR IGNORE INTO coordinate_backup_v11 VALUES(?,?,?)",
                            arrayOf<Any>(table, id, payload)
                        )
                    }
                }
            }
        }

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "environment_database"
                )
                    .addMigrations(
                        MIGRATION_3_4, MIGRATION_6_7, MIGRATION_7_8, MIGRATION_8_9,
                        MIGRATION_9_10, MIGRATION_10_11, MIGRATION_11_12
                    )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
