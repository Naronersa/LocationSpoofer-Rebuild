package com.vincenthzr.locationspoofer

import com.vincenthzr.locationspoofer.utils.ConfigKeys

import android.app.Application
import android.content.Context
import com.amap.api.location.AMapLocationClient
import com.amap.api.maps.MapsInitializer
import com.amap.api.services.core.ServiceSettings
import com.google.android.libraries.places.api.Places
import com.vincenthzr.locationspoofer.di.appModules
import com.vincenthzr.locationspoofer.utils.XposedModuleStatus
import org.koin.android.ext.koin.androidContext
import org.koin.android.ext.koin.androidLogger
import org.koin.core.context.startKoin
import io.github.libxposed.service.XposedService
import io.github.libxposed.service.XposedServiceHelper

class LocationApp : Application(), XposedServiceHelper.OnServiceListener {

    override fun onCreate() {
        super.onCreate()

        val prefs = getSharedPreferences("app_settings", MODE_PRIVATE)
        // 地图/定位 SDK 的隐私同意不能在用户确认前硬编码为 true；
        // MainActivity 首次启动会显示同意对话框，确认后调用 initializeMapSdks。
        if (prefs.getBoolean(ConfigKeys.PRIVACY_ACCEPTED, false)) {
            initializeMapSdks(this)
        }

        startKoin {
            androidLogger()
            androidContext(this@LocationApp)
            modules(appModules)
        }

        // Create the config publisher before registering; it observes the current service and rebinds.
        org.koin.java.KoinJavaComponent.get<com.vincenthzr.locationspoofer.utils.ConfigManager>(
            com.vincenthzr.locationspoofer.utils.ConfigManager::class.java
        )
        Thread {
            try {
                XposedServiceHelper.registerListener(this@LocationApp)
            } catch (e: Throwable) {
                e.printStackTrace()
            }
        }.start()
    }

    override fun onServiceBind(service: XposedService) {
        XposedModuleStatus.update(service)
    }

    override fun onServiceDied(service: XposedService) {
        XposedModuleStatus.clear(service)
    }

    companion object {
        /**
         * 在用户明确同意地图/定位 SDK 隐私条款后初始化。重复调用安全：
         * 高德/百度 SDK 自身会保持已初始化状态。
         */
        fun initializeMapSdks(context: Context) {
            val prefs = context.getSharedPreferences("app_settings", Context.MODE_PRIVATE)
            MapsInitializer.updatePrivacyShow(context, true, true)
            MapsInitializer.updatePrivacyAgree(context, true)
            ServiceSettings.updatePrivacyShow(context, true, true)
            ServiceSettings.updatePrivacyAgree(context, true)
            AMapLocationClient.updatePrivacyShow(context, true, true)
            AMapLocationClient.updatePrivacyAgree(context, true)

            val customApiKey = prefs.getString(ConfigKeys.AMAP_API_KEY, "")
            if (!customApiKey.isNullOrEmpty()) {
                MapsInitializer.setApiKey(customApiKey)
                AMapLocationClient.setApiKey(customApiKey)
                ServiceSettings.getInstance().setApiKey(customApiKey)
            }

            runCatching {
                MapsInitializer.setNetWorkEnable(
                    !prefs.getBoolean(ConfigKeys.AMAP_OFFLINE_ONLY, false)
                )
            }

            val baiduApiKey = prefs.getString(ConfigKeys.BAIDU_API_KEY, "")
            if (!baiduApiKey.isNullOrEmpty()) {
                com.baidu.mapapi.SDKInitializer.setApiKey(baiduApiKey)
            }

            try {
                com.baidu.mapapi.SDKInitializer.setAgreePrivacy(context, true)
                com.baidu.mapapi.SDKInitializer.setCoordType(com.baidu.mapapi.CoordType.GCJ02)
                com.baidu.mapapi.SDKInitializer.initialize(context)
            } catch (e: Exception) {
                e.printStackTrace()
            }

            val googleApiKey = prefs.getString(ConfigKeys.GOOGLE_API_KEY, "")
            if (!Places.isInitialized() && !googleApiKey.isNullOrBlank()) {
                try {
                    Places.initialize(context, googleApiKey)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }
}
