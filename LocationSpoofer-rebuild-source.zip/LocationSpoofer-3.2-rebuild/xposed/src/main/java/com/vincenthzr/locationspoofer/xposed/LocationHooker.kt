@file:Suppress(
    "UNUSED_PARAMETER",
    "UNUSED_VARIABLE",
    "UNNECESSARY_NOT_NULL_ASSERTION",
    "DEPRECATION",
    "NAME_SHADOWING",
    "FunctionName",
    "PrivatePropertyName",
    "SpellCheckingInspection",
    "RedundantUnitReturnType",
    "RemoveRedundantQualifierName",
    "OPT_IN_USAGE",
    "unused",
    "UnusedImport"
)

package com.vincenthzr.locationspoofer.xposed

import com.vincenthzr.locationspoofer.xposed.utils.HookLog

import com.vincenthzr.locationspoofer.utils.ConfigKeys

import com.vincenthzr.locationspoofer.xposed.utils.*
import com.vincenthzr.locationspoofer.xposed.hooks.*
import com.vincenthzr.locationspoofer.xposed.hooks.network.*
import com.vincenthzr.locationspoofer.xposed.hooks.vendor.VendorRegistry
import com.vincenthzr.locationspoofer.xposed.hooks.vendor.SystemComponent
import com.vincenthzr.locationspoofer.xposed.hooks.vendor.SystemProcess
import com.vincenthzr.locationspoofer.xposed.diagnostics.HookStatus

import io.github.libxposed.api.XposedInterface
import io.github.libxposed.api.XposedModule
import io.github.libxposed.api.XposedModuleInterface
import org.json.JSONObject
import java.io.File
import android.content.SharedPreferences
import android.os.ParcelFileDescriptor
import com.vincenthzr.locationspoofer.utils.FrameworkConfigChannel
import java.util.Random
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import java.lang.reflect.*
import java.util.concurrent.CopyOnWriteArrayList

class LocationHooker : XposedModule() {
    init {
        XposedHelpers.module = this
    }

    internal val nmeaTimers = ConcurrentHashMap<Any, java.util.Timer>()
    internal val bleScanTimers = ConcurrentHashMap<Any, java.util.Timer>()
    internal val hookedCallbackClasses = ConcurrentHashMap<Class<*>, Boolean>()

    // 标记本进程内是否已经安装过一次环境级 Hook（WiFi/基站/连接层/蓝牙/位置/环境兼容等）。
    // 这些 Hook 针对的是 ConnectivityManager/TelephonyManager/WifiManager/Location 等系统共享类，
    // 同一个类在整个进程里只有一份，不需要也不能按 classloader 重复 Hook——
    // WebView/MultiDex 等场景会让 handleLoadPackage 在同一进程内被多次调用（不同的"包名"），
    // 如果重复安装，会在同一个方法上叠加两层拦截链，libxposed 在处理带基本类型参数的方法
    // (如 ConnectivityManager.getNetworkInfo(int)) 时，叠加后的拦截链会抛出
    // IllegalArgumentException: argument N has type int, got java.lang.Integer，导致目标 App 崩溃。
    @Volatile
    internal var environmentHooksInstalled = false

    @Volatile
    internal var systemHooksInstalled = false

    @Volatile
    internal var isSystemServerProcess = false

    @Volatile
    internal var isPhoneProcessInstance = false

    @Volatile
    internal var isBluetoothProcessInstance = false

    // 用于跟踪活动的 Android LocationListener，实现动态主动欺骗
    // 使用 CopyOnWriteArrayList 和强引用，防止 GC 移除监听器
    internal val capturedLocationListeners = CopyOnWriteArrayList<Any>()
    internal val capturedAMapListeners = CopyOnWriteArrayList<Any>()
    internal val capturedBaiduListeners = CopyOnWriteArrayList<Any>()
    internal val capturedTencentListeners = CopyOnWriteArrayList<Any>()
    internal val capturedFusedLocationCallbacks = CopyOnWriteArrayList<Any>()

    @Volatile
    internal var currentPackageName: String = ""

    @Volatile
    internal var currentClassLoader: ClassLoader? = null

    @Volatile
    internal var lastSpoofedLat = 0.0

    @Volatile
    internal var lastSpoofedLng = 0.0

    @Volatile
    internal var cachedProvince = ""

    @Volatile
    internal var cachedCity = ""

    @Volatile
    internal var cachedDistrict = ""

    @Volatile
    internal var cachedStreet = ""

    @Volatile
    internal var cachedStreetNum = ""

    @Volatile
    internal var cachedAddress = ""

    @Volatile
    internal var cachedCountry = ""

    @Volatile
    internal var cachedPoiName = ""

    @Volatile
    internal var lastGeocodedLat = -999.0

    @Volatile
    internal var lastGeocodedLng = -999.0

    override fun onModuleLoaded(param: XposedModuleInterface.ModuleLoadedParam) {
        android.util.Log.i(
            "LocationSpoofer",
            "[Config] onModuleLoaded modulePackage=${getModuleApplicationInfo()?.packageName}"
        )
        startFrameworkConfigReceiver()
    }

    override fun onPackageLoaded(param: XposedModuleInterface.PackageLoadedParam) {
        // 目前这里没有内容
    }

    override fun onPackageReady(param: XposedModuleInterface.PackageReadyParam) {
        val pkg = param.packageName
        val classLoader = param.classLoader
        handleLoadPackage(pkg, classLoader)
    }

    // LibXposed API 101/102: 系统服务专属入口
    override fun onSystemServerStarting(param: XposedModuleInterface.SystemServerStartingParam) {
        android.util.Log.e(
            "LocationSpoofer",
            "[SysHook] onSystemServerStarting invoked! system_server classLoader=${param.classLoader}"
        )
        handleLoadPackage("android", param.classLoader)
    }

    // LibXposed API 102: 热重载请求前置确认与资源清理
    internal val vendorExtraHooks = mutableListOf<AutoCloseable>()

    @Volatile internal var retiringGeneration = false
    private val ownedReloadTimers = java.util.Collections.synchronizedSet(mutableSetOf<java.util.Timer>())

    internal fun ownReloadTimer(timer: java.util.Timer): java.util.Timer {
        synchronized(ownedReloadTimers) {
            if (retiringGeneration) timer.cancel() else ownedReloadTimers.add(timer)
        }
        return timer
    }

    internal fun releaseReloadTimer(timer: java.util.Timer) { ownedReloadTimers.remove(timer) }

    override fun onHotReloading(param: XposedModuleInterface.HotReloadingParam): Boolean {
        val loader = currentClassLoader ?: return false
        if (currentPackageName.isBlank()) return false
        // A new module instance receives this bootstrap-owned state. Never pass this module or
        // module-defined registration records across the classloader boundary.
        param.setSavedInstanceState(hashMapOf<String, Any>(
            "host" to HotReloadHost(currentPackageName, loader).save(),
            "callbacks" to arrayOf(
                capturedLocationListeners.toTypedArray(), capturedAMapListeners.toTypedArray(),
                capturedBaiduListeners.toTypedArray(), capturedTencentListeners.toTypedArray(),
                capturedFusedLocationCallbacks.toTypedArray(), bleScanTimers.keys.toTypedArray()
            ),
            "system_location" to saveSystemLocationReloadState(),
            "system_ble" to saveSystemBleReloadState()
        ))
        retiringGeneration = true
        val worker = synchronized(pollingLock) {
            val previous = configWorker
            configWorker = null
            isConfigWorkerStarted = false
            previous?.interrupt()
            previous
        }
        worker?.join(2_000)
        if (worker?.isAlive == true) {
            retiringGeneration = false
            startConfigWorker()
            return false
        }
        // 指南针 worker 也持有旧实例的类加载器和 native 状态。热重载时必须
        // 主动停掉并清空引用，否则旧线程会继续跑，新实例再启动一条。
        val compass = synchronized(this) {
            val previous = compassWorker
            compassWorker = null
            previous?.interrupt()
            previous
        }
        compass?.join(1_000)
        configReceiver?.close()
        configReceiver = null
        lastConfig = null
        synchronized(ownedReloadTimers) {
            ownedReloadTimers.forEach { it.cancel() }
            ownedReloadTimers.clear()
        }
        vendorExtraHooks.asReversed().forEach { runCatching { it.close() } }
        vendorExtraHooks.clear()
        ModuleBinderDeaths.close()
        HookStatus.close()
        nmeaTimers.values.forEach { it.cancel() }
        nmeaTimers.clear()
        bleScanTimers.values.forEach { it.cancel() }
        bleScanTimers.clear()
        clearSystemLocationReloadState()
        clearSystemBleReloadState()
        capturedLocationListeners.clear()
        capturedAMapListeners.clear()
        capturedBaiduListeners.clear()
        capturedTencentListeners.clear()
        capturedFusedLocationCallbacks.clear()
        return true
    }

    override fun onHotReloaded(param: XposedModuleInterface.HotReloadedParam) {
        val state = param.savedInstanceState as? Map<*, *>
        reinstallAfterHotReload(
            state = state?.get("host"),
            // First upgrade from older versions has no saved state. Recover the already-running
            // host through its Application / system service, not module-instance fields.
            resolveHost = { resolveRunningHost(param) },
            removeOldHooks = { super.onHotReloaded(param) },
            install = { host ->
                currentPackageName = host.packageName
                currentClassLoader = host.classLoader
                HookStatus.markHotReload()
                startFrameworkConfigReceiver()
                handleLoadPackage(host.packageName, host.classLoader)
                val callbacks = state?.get("callbacks") as? Array<*>
                val lists = listOf(capturedLocationListeners, capturedAMapListeners,
                    capturedBaiduListeners, capturedTencentListeners, capturedFusedLocationCallbacks)
                lists.forEachIndexed { index, list ->
                    (callbacks?.getOrNull(index) as? Array<*>)?.filterNotNull()?.let { list.addAll(it) }
                }
                restoreSystemLocationReloadState(state?.get("system_location"))
                restoreSystemBleReloadState(state?.get("system_ble"))
                (callbacks?.getOrNull(5) as? Array<*>)?.filterNotNull()?.forEach { callback ->
                    if (hasTypeByName(callback.javaClass, "android.bluetooth.BluetoothAdapter\$LeScanCallback")) {
                        startOldLeScanTimer(callback, host.classLoader)
                    } else startBleTimer(callback, host.classLoader)
                }
                android.util.Log.i("LocationSpoofer", "[HotReload] Reinstalled hooks in ${param.processName}; generation=${HookStatus.generationId}")
            }
        )
    }

    private fun resolveRunningHost(param: XposedModuleInterface.HotReloadedParam): HotReloadHost? {
        val app = runCatching {
            Class.forName("android.app.ActivityThread").getDeclaredMethod("currentApplication")
                .invoke(null) as? android.app.Application
        }.getOrNull()
        if (!param.isSystemServer && app != null) return HotReloadHost(app.packageName, app.classLoader)
        if (param.isSystemServer) {
            // Hook handles belong to the framework; their declaring classes retain the real
            // system-service loader even when an older module did not save lifecycle state.
            param.oldHookHandles.forEach { handle ->
                val clazz = handle.executable.declaringClass
                if (clazz.name.startsWith("com.android.server.")) {
                    val loader = clazz.classLoader
                    if (loader != null) return HotReloadHost("android", loader)
                }
            }
            val serviceLoader = runCatching {
                val serviceManager = Class.forName("android.os.ServiceManager")
                serviceManager.getDeclaredMethod("getService", String::class.java).invoke(null, "location")
                    ?.javaClass?.classLoader
            }.getOrNull()
            val candidates = listOfNotNull(serviceLoader, Thread.currentThread().contextClassLoader,
                ClassLoader.getSystemClassLoader(), javaClass.classLoader?.parent)
            candidates.forEach { candidate ->
                val hostLoader = runCatching { candidate.loadClass("com.android.server.SystemServer").classLoader }.getOrNull()
                if (hostLoader != null) return HotReloadHost("android", hostLoader)
            }
        }
        return null
    }


    companion object {

        // 系统进程同样需要覆盖（android进程持有LocationManagerService）
        val SYSTEM_PACKAGES = setOf("android", "system", "com.android.phone")
        internal const val VERBOSE_CELL_BUILD_LOGS = false

        fun hasTypeByName(clazz: Class<*>?, typeName: String): Boolean {
            if (clazz == null) return false
            if (clazz.name == typeName) return true
            for (iface in clazz.interfaces) {
                if (hasTypeByName(iface, typeName)) return true
            }
            return hasTypeByName(clazz.superclass, typeName)
        }
    }

    fun handleLoadPackage(pkg: String, classLoader: ClassLoader) {
        val processName = try {
            File("/proc/self/cmdline").readText().trim('\u0000', ' ', '\n')
        } catch (e: Exception) {
            pkg
        }
        val actualHostPkg = processName.substringBefore(":")
        if (actualHostPkg.isNotBlank() && !actualHostPkg.startsWith("android") && actualHostPkg != "system_server" && actualHostPkg != "system") {
            currentPackageName = actualHostPkg
        } else if (currentPackageName.isEmpty()) {
            currentPackageName = pkg
        }
        if (currentClassLoader == null || (pkg == currentPackageName)) {
            currentClassLoader = classLoader
        }

        startConfigWorker()
        if (handleSystemProcessGlobal(pkg, processName, classLoader)) return
        // global 方案只 Hook 系统进程；非目标进程不安装 App 内 Hook。
        readConfig()
    }

    internal fun hookAllMapSdks(cl: ClassLoader) {
        try { hookAMapSDK(cl) } catch (t: Throwable) { HookLog.swallowed("LocationHooker.kt:326", t) }
        try { hookTencentSDK(cl) } catch (t: Throwable) { HookLog.swallowed("LocationHooker.kt:327", t) }
        try { hookBaiduSDK(cl) } catch (t: Throwable) { HookLog.swallowed("LocationHooker.kt:328", t) }
        try { hookGoogleFusedLocation(cl) } catch (t: Throwable) { HookLog.swallowed("LocationHooker.kt:329", t) }
    }

    /**
     * 全局（global）方案下对系统进程的处理：在 system_server / com.android.phone / com.android.bluetooth
     * 里安装系统服务级 Hook，一次性对全设备生效。
     * @return true 表示该进程已处理完毕（或应当跳过），调用方不再继续安装 App 内 Hook。
     */
    private fun handleSystemProcessGlobal(pkg: String, processName: String, classLoader: ClassLoader): Boolean {
        // 防止注入到 SystemUI 导致崩溃或无意义占用
        if (pkg == "com.android.systemui" || processName == "com.android.systemui") {
            return true
        }

        val isSystemServer =
            (processName == "system_server") || (processName == "system")
        if (!isSystemServer && (pkg == "android" || pkg == "system")) return true
        val isPhoneProcess =
            (pkg == "com.android.phone") || (processName == "com.android.phone")
        val isBluetoothProcess =
            (pkg == "com.android.bluetooth") || (processName.startsWith("com.android.bluetooth"))

        if (isSystemServer) isSystemServerProcess = true
        if (isPhoneProcess) isPhoneProcessInstance = true
        if (isBluetoothProcess) isBluetoothProcessInstance = true

        val isCoreSystemProcess = isSystemServer || isPhoneProcess || isBluetoothProcess
        if (!isCoreSystemProcess) return false

        android.util.Log.e(
            "LocationSpoofer",
            "[SysHook] Core system process detected: pkg=$pkg, process=$processName, myUid=${android.os.Process.myUid()}"
        )
        if (systemHooksInstalled) {
            readConfig()
            return true
        }
        systemHooksInstalled = true
        XposedBridge.log("[SysHook] Deploying system framework hooks in $processName...")

        // 厂商适配方案的手动覆盖（VendorRegistry.applyManualOverride）必须在下面任何一个
        // hookSystemXxxService 之前生效——它们会通过 SystemClassLocator 查询 VendorRegistry，从而触发
        // VendorRegistry.active 这个 by lazy 属性首次求值，晚了就再也覆盖不了。这里提前读一次
        // 配置：readConfig() 可重复调用，后续调用只返回内存里已缓存的 lastConfig，只读内存。
        val earlyCfg = readConfig()
        VendorRegistry.applyManualOverride(earlyCfg?.optString(ConfigKeys.VENDOR_OVERRIDE, "auto"))

        // Hook 运行状态报告（App 的"系统适配 → Hook 运行状态"页读取），每个系统进程各写一份
        HookStatus.begin(
            when {
                isSystemServer -> SystemProcess.SYSTEM_SERVER
                isPhoneProcess -> SystemProcess.PHONE
                else -> SystemProcess.BLUETOOTH
            }
        )
        fun deploy(name: String, block: () -> Unit) {
            try {
                block()
            } catch (t: Throwable) {
                XposedBridge.log("[SysHook] $name error: $t")
                HookStatus.error(name, t)
            }
        }

        if (isSystemServer) {
            // 只读侦察：把各组件候选类的方法 / 字段列表打进日志，适配新系统时才需要，由配置里的调试开关控制
            if (earlyCfg?.optBoolean(ConfigKeys.DEBUG_DUMP_SYSTEM_SERVICES, false) == true) {
                deploy("dumpSystemServiceInternals") { dumpSystemServiceInternals(classLoader) }
            }
            deploy("hookSystemLocationService") { hookSystemLocationService(classLoader) }
            deploy("hookSystemWifiService") { hookSystemWifiService(classLoader) }
            deploy("hookSystemConnectivityService") { hookSystemConnectivityService(classLoader) }
            deploy("hookSystemTelephonyRegistry") { hookSystemTelephonyRegistry(classLoader) }
            deploy("hookSystemAppOpsService") { hookSystemAppOpsService(classLoader) }
            // 系统级传感器层：与上游 global 一致，由 system_server 统一改写/注入所有目标应用
            deploy("installGlobalNativeSensor") { installGlobalNativeSensor() }
        }

        if (isPhoneProcess) {
            deploy("hookSystemTelephonyService") { hookSystemTelephonyService(classLoader) }
        }

        if (isBluetoothProcess) {
            deploy("hookSystemBluetoothService") { hookSystemBluetoothService(classLoader) }
        }

        // 机型/系统适配层：先打印一次命中的适配器画像，再执行该机型专属的额外 Hook（默认空实现，
        // 各厂商在 vendor/profiles/ 下按需覆写）。基线 Hook 已在上面装完，这里是纯追加，不影响任何机型。
        VendorRegistry.logSelectionOnce()
        deploy("installExtraHooks") { VendorRegistry.installExtraHooks(this, classLoader) }

        val cfg = readConfig()
        android.util.Log.e(
            "LocationSpoofer",
            "[SysHook] System framework hooks deployed in $processName. Config active=${cfg?.optBoolean(ConfigKeys.ACTIVE)}, globalMode=${cfg?.optBoolean(ConfigKeys.SYSTEM_HOOK_GLOBAL_MODE)}, targetPkgs=${cfg?.optJSONArray(ConfigKeys.SYSTEM_HOOK_PACKAGES)?.length() ?: 0}"
        )
        return true
    }

    /**
     * 只读侦察，不装任何会改变行为的 Hook：探索"直接改 system_server 内部服务实现，
     * 一次性对全设备生效"这个方向时，第一步必须先摸清楚这台设备/这个安卓版本实际的
     * 内部类结构长什么样——LocationManagerService/WifiServiceImpl 这些类不是公开 API，
     * 字段和方法名在不同安卓版本、不同 OEM 定制 ROM 之间差异很大，且没有公开文档，
     * 瞎猜字段名直接上 Hook 是 system_server 崩溃、设备进重启循环最常见的原因。
     * 这里只用反射枚举候选类的方法名/字段名打进日志，不拦截、不修改任何返回值，
     * 单个类枚举失败也只是记一条日志，不会影响 system_server 本身的运行。
     */
    internal fun dumpSystemServiceInternals(classLoader: ClassLoader) {
        // 各组件的候选类名（含当前适配器给出的定制候选），再加上两个只用于排查的 GNSS 内部类
        val candidateClassNames = SystemComponent.entries
            .filter { it.process == SystemProcess.SYSTEM_SERVER }
            .flatMap { VendorRegistry.classCandidates(it) } + listOf(
            "com.android.server.location.gnss.GnssLocationProvider",
            "com.android.server.location.gnss.GnssManagerService",
        )
        for (className in candidateClassNames) {
            try {
                val clazz = classLoader.loadClass(className)
                val methodNames = clazz.declaredMethods.map { it.name }.distinct().sorted()
                val fieldInfo = clazz.declaredFields.map { "${it.type.simpleName} ${it.name}" }.sorted()
                XposedBridge.log(
                    "[LocationSpoofer][SysDump] FOUND $className (superclass=${clazz.superclass?.name})\n" +
                        "  methods(${methodNames.size})=${methodNames.joinToString(",")}\n" +
                        "  fields(${fieldInfo.size})=${fieldInfo.joinToString(",")}"
                )
            } catch (e: ClassNotFoundException) {
                XposedBridge.log("[LocationSpoofer][SysDump] not found: $className")
            } catch (e: Throwable) {
                XposedBridge.log("[LocationSpoofer][SysDump] error dumping $className: $e")
            }
        }
    }

    /**
     * ★ 环境兼容: 保持 Hook 环境一致性
     *
     * 设计原则:
     * 1. 只使用精确匹配,绝不使用宽泛的contains/startsWith,避免误杀正常类
     * 2. 不Hook ClassLoader.loadClass的宽泛模式(会导致App卡死)
     * 3. 不Hook BufferedReader.readLine(开销巨大)
     * 4. 不Hook File.exists/Runtime.exec(干扰正常功能)
     */
    internal var startTimestamp = System.currentTimeMillis()

    internal val rng = Random()
    internal var hookDriftLat = 0.0
    internal var hookDriftLng = 0.0
    internal var hookAccuracyDrift = 0.0
    internal var hookLastCallTime = 0L

    /** Complete normalized snapshots are swapped atomically by the framework receiver. */
    @Volatile
    internal var lastConfig: JSONObject? = null

    @Volatile
    internal var lastOpenCellConfigLogKey: String? = null

    @Volatile
    private var configReceiver: FrameworkConfigReceiver? = null
    @Volatile private var configWorker: Thread? = null
    @Volatile private var isConfigWorkerStarted = false
    private val pollingLock = Any()

    private fun startFrameworkConfigReceiver() {
        if (configReceiver != null) return
        configReceiver = FrameworkConfigReceiver(
            getPreferences = {
                val group = FrameworkConfigChannel.GROUP
                val remote = runCatching { getRemotePreferences(group) }.getOrNull()
                val remoteValue = runCatching {
                    remote?.getString(FrameworkConfigChannel.SNAPSHOT_KEY, null)
                }.getOrNull()
                if (remoteValue != null) {
                    android.util.Log.i("LocationSpoofer", "[Config] libxposed remote prefs snapshot found")
                    remote!!
                } else {
                    android.util.Log.w(
                        "LocationSpoofer",
                        "[Config] libxposed remote prefs empty; trying legacy XSharedPreferences"
                    )
                    val legacy = legacyRemotePreferences(group)
                    legacy ?: remote
                }
            },
            readFile = { name ->
                ParcelFileDescriptor.AutoCloseInputStream(openRemoteFile(name))
                    .bufferedReader(Charsets.UTF_8).use { it.readText() }
            },
            onConfig = { snapshot ->
                val config = normalizeConfig(snapshot.config)
                lastConfig = config
                HookStatus.configLoaded(snapshot.source, snapshot.publishedAt)
                logOpenCellConfigLoaded(snapshot.source, config)
                notifyGlobalNativeSensor(config)
            },
            onError = { error ->
                XposedBridge.log("[Config] Framework receive failed: ${error.javaClass.simpleName}: ${error.message}")
            },
            fallbackConfigText = { null }
        ).also { it.start() }
    }

    /** libxposed 远程 prefs 不可用时的回退：直接走 LSPosed 的旧版 XSharedPreferences */
    private fun legacyRemotePreferences(group: String): SharedPreferences? {
        return try {
            val pkg = getModuleApplicationInfo()?.packageName ?: return null
            val cls = Class.forName("de.robv.android.xposed.XSharedPreferences")
            val ctor = cls.getConstructor(String::class.java, String::class.java)
            val prefs = ctor.newInstance(pkg, group) as SharedPreferences
            runCatching { cls.getMethod("reload").invoke(prefs) }
            android.util.Log.i(
                "LocationSpoofer",
                "[Config] legacy XSharedPreferences pkg=$pkg group=$group"
            )
            prefs
        } catch (t: Throwable) {
            android.util.Log.w("LocationSpoofer", "[Config] legacy XSharedPreferences failed: $t")
            null
        }
    }

    internal fun logOpenCellConfigLoaded(source: String, config: JSONObject) {
        val cellArray = config.optJSONArray(ConfigKeys.CELL_JSON_2)
        val cellCount = cellArray?.length() ?: 0
        val btArray = config.optJSONArray(ConfigKeys.BLUETOOTH_JSON_2)
        val btCount = btArray?.length() ?: 0
        val active = config.optBoolean(ConfigKeys.ACTIVE, false)
        val mockBt = config.optBoolean(ConfigKeys.MOCK_BLUETOOTH, true)
        val lat = config.optDouble(ConfigKeys.LAT, 0.0)
        val lng = config.optDouble(ConfigKeys.LNG, 0.0)
        val isGlobal = config.optBoolean(ConfigKeys.SYSTEM_HOOK_GLOBAL_MODE, false)
        val sysPkgs = config.optJSONArray(ConfigKeys.SYSTEM_HOOK_PACKAGES)?.length() ?: 0
        val logKey = "$active|$mockBt|$lat|$lng|$cellCount|$btCount|$isGlobal|$sysPkgs"
        if (logKey != lastOpenCellConfigLogKey) {
            lastOpenCellConfigLogKey = logKey
            val msg = "[SysHook] 配置已加载[$source]: active=$active, globalMode=$isGlobal, 目标应用数=$sysPkgs, lat=$lat, lng=$lng, 蓝牙数=$btCount, 基站数=$cellCount"
            android.util.Log.i("LocationSpoofer", msg)
            XposedBridge.log(msg)
        }
    }

    internal fun normalizeConfig(config: JSONObject): JSONObject {
        if (!config.has(ConfigKeys.WIFI_JSON_2)) config.put(ConfigKeys.WIFI_JSON_2, org.json.JSONArray())
        // UI 使用高德地图(AMapSDK)，cameraPosition.target 返回的是 GCJ-02 坐标系。
        // 因此 config["lat"/"lng"] 已经是 GCJ-02，不需要再做 BD-09 → GCJ-02 转换。
        val gcj02Lat = config.optDouble(ConfigKeys.LAT, 0.0)
        val gcj02Lng = config.optDouble(ConfigKeys.LNG, 0.0)

        // 派生出 BD-09（百度定位 SDK 需要）
        val bd09 = gcj02ToBd09(gcj02Lat, gcj02Lng)
        config.put(ConfigKeys.BD09_LAT, bd09.first)
        config.put(ConfigKeys.BD09_LNG, bd09.second)

        // 派生出 WGS-84（标准 Android Location 对象的理论坐标系）
        val wgs84 = gcj02ToWgs84(gcj02Lat, gcj02Lng)
        config.put(ConfigKeys.WGS84_LAT, wgs84.first)
        config.put(ConfigKeys.WGS84_LNG, wgs84.second)

        // lat/lng 保持 GCJ-02 不变，作为默认坐标（高德、腾讯等直接使用）
        return config
    }

    /** The hook call path performs no framework calls, parsing, or file IO. */
    internal fun readConfig(): JSONObject? = lastConfig

    // ---------------------------------------------------------------- global native sensor
    // 系统级传感器层位于 :sensor-native。主源码通过反射调用，避免直接依赖其类。

    private val isSystemServerProcessByCmdline: Boolean by lazy {
        try {
            File("/proc/self/cmdline").readText().trim('\u0000', ' ', '\n') == "system_server"
        } catch (_: Throwable) {
            false
        }
    }

    @Volatile private var globalNativeSensorClass: Class<*>? = null
    @Volatile private var globalNativeSensorErrorLogged = false
    @Volatile private var globalCompassErrorLogged = false
    @Volatile private var globalCompassMethod: java.lang.reflect.Method? = null
    @Volatile private var compassWorker: Thread? = null

    private fun globalNativeSensorClass(): Class<*>? {
        globalNativeSensorClass?.let { return it }
        return try {
            Class.forName(
                "com.vincenthzr.locationspoofer.sensor.GlobalSensorIntegration",
                true,
                javaClass.classLoader
            ).also { globalNativeSensorClass = it }
        } catch (t: Throwable) {
            if (!globalNativeSensorErrorLogged) {
                globalNativeSensorErrorLogged = true
                android.util.Log.w(
                    "LocationSpoofer",
                    "[SysSensor] native bridge unavailable: ${t.javaClass.simpleName}: ${t.message}"
                )
            }
            null
        }
    }

    private fun installGlobalNativeSensor() {
        if (!isSystemServerProcessByCmdline) return
        try {
            globalNativeSensorClass()?.getMethod("install")?.invoke(null)
        } catch (t: Throwable) {
            android.util.Log.e("LocationSpoofer", "[SysSensor] install failed", t)
        }
        startCompassWorker()
    }

    /**
     * 指南针专用高频 worker：模拟中 50 Hz 更新方位，静止/关闭时 4 Hz 轮询。
     *
     * 现有 1 Hz 定位 worker 负责位置/步数；指南针若等到 1 Hz 才更新，路线急转时
     * 会有明显滞后。这里只做 RouteEngine bearing + 缓存的 WMM 磁偏角，开销很小。
     */
    private fun startCompassWorker() {
        if (!isSystemServerProcessByCmdline) return
        synchronized(this) {
            if (compassWorker != null) return
            val thread = Thread({
                var lastEnabled = false
                while (compassWorker === Thread.currentThread() &&
                    !Thread.currentThread().isInterrupted
                ) {
                    try {
                        val config = readConfig()
                        val active = config != null &&
                            config.optBoolean(ConfigKeys.ACTIVE, false) &&
                            config.optBoolean(ConfigKeys.ENABLE_COMPASS_SIMULATION, true)
                        if (active) {
                            val heading = try {
                                CompassHeadingSource.current(
                                    config!!,
                                    System.currentTimeMillis()
                                )
                            } catch (_: Throwable) {
                                null
                            }
                            if (heading != null) {
                                notifyGlobalNativeCompass(
                                    heading.trueDeg,
                                    heading.declinationDeg,
                                    heading.accuracyDeg,
                                    heading.horizontalUt,
                                    heading.verticalUt,
                                    true
                                )
                                lastEnabled = true
                            } else if (lastEnabled) {
                                notifyGlobalNativeCompass(
                                    0.0, 0.0, 0.0, Double.NaN, Double.NaN, false
                                )
                                lastEnabled = false
                            }
                            Thread.sleep(20L) // 50 Hz：弯道方向更跟手
                        } else {
                            if (lastEnabled) {
                                notifyGlobalNativeCompass(
                                    0.0, 0.0, 0.0, Double.NaN, Double.NaN, false
                                )
                                lastEnabled = false
                            }
                            Thread.sleep(250L) // 4 Hz idle
                        }
                    } catch (_: InterruptedException) {
                        break
                    } catch (_: Throwable) {
                        try {
                            Thread.sleep(250L)
                        } catch (_: InterruptedException) {
                            break
                        }
                    }
                }
            }, "SysSensorCompass")
            compassWorker = thread
            thread.start()
            android.util.Log.i(
                "LocationSpoofer",
                "[SysSensor] compass worker started (50 Hz active, 4 Hz idle)"
            )
        }
    }

    private fun notifyGlobalNativeSensor(config: JSONObject?) {
        if (!isSystemServerProcessByCmdline) return
        try {
            val cls = globalNativeSensorClass() ?: return
            cls.getMethod("onConfig", String::class.java)
                .invoke(null, config?.toString() ?: "")
        } catch (t: Throwable) {
            if (!globalNativeSensorErrorLogged) {
                globalNativeSensorErrorLogged = true
                android.util.Log.e("LocationSpoofer", "[SysSensor] onConfig failed", t)
            }
        }
    }

    /**
     * system_server 1 Hz worker 的指南针桥：路线真北 bearing + WMM 磁偏角 -> native。
     */
    private fun notifyGlobalCompass(
        config: JSONObject,
        motion: SpoofedMotion,
        now: Long
    ) {
        if (!isSystemServerProcessByCmdline) return
        val enabled = config.optBoolean(ConfigKeys.ENABLE_COMPASS_SIMULATION, true)
        if (!enabled) {
            notifyGlobalNativeCompass(
                0.0, 0.0, 0.0, Double.NaN, Double.NaN, false
            )
            return
        }

        val altitude = try {
            RouteEngine.realisticAltitude(config, now)
        } catch (_: Throwable) {
            config.optDouble(ConfigKeys.ALTITUDE, 0.0)
        }
        val wgs = try {
            com.vincenthzr.locationspoofer.utils.CoordinateUtils
                .gcj02ToWgs84(motion.lat, motion.lng)
        } catch (_: Throwable) {
            com.vincenthzr.locationspoofer.utils.CoordinateUtils
                .LatLng(motion.lat, motion.lng)
        }
        var declination = 0.0
        var horizontal = Double.NaN
        var vertical = Double.NaN
        try {
            val field = android.hardware.GeomagneticField(
                wgs.lat.toFloat(),
                wgs.lng.toFloat(),
                altitude.toFloat(),
                now
            )
            declination = field.declination.toDouble()
            // GeomagneticField 的分量单位是 nT；Android 磁力计是 µT。
            horizontal = field.horizontalStrength.toDouble() / 1000.0
            // WMM 的 Z 轴向下为正；native 传感器 Z 轴向上，取负后使用。
            vertical = field.z.toDouble() / 1000.0
        } catch (_: Throwable) {
            // native 会退回真实事件的分量
        }
        if (!declination.isFinite()) declination = 0.0
        if (!horizontal.isFinite() || horizontal <= 0.0) horizontal = Double.NaN
        if (!vertical.isFinite()) vertical = Double.NaN

        notifyGlobalNativeCompass(
            motion.bearing.toDouble(),
            declination,
            5.0,
            horizontal,
            vertical,
            true
        )
    }

    private fun notifyGlobalNativeCompass(
        trueHeadingDeg: Double,
        declinationDeg: Double,
        accuracyDeg: Double,
        horizontalUt: Double,
        verticalUt: Double,
        enabled: Boolean
    ) {
        if (!isSystemServerProcessByCmdline) return
        try {
            val cls = globalNativeSensorClass() ?: return
            val method = globalCompassMethod ?: cls.getMethod(
                "onCompassHeading",
                java.lang.Double.TYPE,
                java.lang.Double.TYPE,
                java.lang.Double.TYPE,
                java.lang.Double.TYPE,
                java.lang.Double.TYPE,
                java.lang.Boolean.TYPE
            ).also { globalCompassMethod = it }
            method.invoke(
                null,
                trueHeadingDeg,
                declinationDeg,
                accuracyDeg,
                horizontalUt,
                verticalUt,
                enabled
            )
        } catch (t: Throwable) {
            if (!globalCompassErrorLogged) {
                globalCompassErrorLogged = true
                android.util.Log.e(
                    "LocationSpoofer",
                    "[SysSensor] onCompassHeading failed",
                    t
                )
            }
        }
    }

    /** Motion delivery and service discovery need a timer independently of config reception. */
    private fun startConfigWorker() {
        if (!isConfigWorkerStarted) {
            synchronized(pollingLock) {
                if (!isConfigWorkerStarted) {
                    isConfigWorkerStarted = true

                    // 后台定时器只读内存中的配置，不轮询配置文件
                    val worker = Thread {
                        val workerThread = Thread.currentThread()
                        while (configWorker === workerThread && !workerThread.isInterrupted) {
                            try {
                                Thread.sleep(1_000L)
                                val newConfig = readConfig()

                                // 若系统核心服务在初次加载时尚未初始化完成，在后台轮询线程中重试挂载，直至成功
                                // isXxxProcess 标记只在全局方案的系统进程分支里被置位，非全局方案下这三个条件恒为 false
                                if (isSystemServerProcess && !isWifiServiceHooked && currentClassLoader != null) {
                                    try { hookSystemWifiService(currentClassLoader!!) } catch (t: Throwable) { XposedBridge.log("[SysWifi] Poller hookSystemWifiService error: $t") }
                                }
                                if (isPhoneProcessInstance && !isTelephonyServiceHooked && currentClassLoader != null) {
                                    try { hookSystemTelephonyService(currentClassLoader!!) } catch (t: Throwable) { XposedBridge.log("[SysCell] Poller hookSystemTelephonyService error: $t") }
                                }
                                if (isBluetoothProcessInstance && !isBluetoothServiceHooked && currentClassLoader != null) {
                                    try { hookSystemBluetoothService(currentClassLoader!!) } catch (t: Throwable) { XposedBridge.log("[SysBle] Poller hookSystemBluetoothService error: $t") }
                                }

                                if (newConfig != null && newConfig.optBoolean(ConfigKeys.ACTIVE, false)) {
                                    val currentLat = newConfig.optDouble(ConfigKeys.LAT, 0.0)
                                    val currentLng = newConfig.optDouble(ConfigKeys.LNG, 0.0)
                                    lastSpoofedLat = currentLat
                                    lastSpoofedLng = currentLng

                                    // 直接从前端控制台下发的 JSON 配置中读取逆地理编码信息，0网络延迟，0硬编码
                                    cachedProvince = newConfig.optString(ConfigKeys.PROVINCE, "")
                                    cachedCity = newConfig.optString(ConfigKeys.CITY, "")
                                    cachedDistrict = newConfig.optString(ConfigKeys.DISTRICT, "")
                                    cachedStreet = newConfig.optString(ConfigKeys.STREET, "")
                                    cachedStreetNum = newConfig.optString(ConfigKeys.STREET_NUM, "")
                                    cachedAddress = newConfig.optString(ConfigKeys.ADDRESS, "")
                                    cachedCountry = newConfig.optString(ConfigKeys.COUNTRY, "")
                                    cachedPoiName = newConfig.optString(ConfigKeys.POI_NAME, "")

                                    val timeNow = System.currentTimeMillis()
                                    FakeLocationMetadata.update(newConfig, timeNow)
                                    val elapsedNanos = android.os.SystemClock.elapsedRealtimeNanos()
                                    val motion = RouteEngine.calculateCurrentPosition(newConfig, timeNow)
                                    lastSpoofedLat = motion.lat
                                    lastSpoofedLng = motion.lng
                                    notifyGlobalCompass(newConfig, motion, timeNow)

                                    val basePkg = currentPackageName.substringBefore(":")
                                    if (SystemHookUtils.isSelfPackage(basePkg)) {
                                        continue
                                    }

                                    val cl = currentClassLoader
                                    val nCount = capturedLocationListeners.size
                                    val aCount = capturedAMapListeners.size
                                    val bCount = capturedBaiduListeners.size
                                    val tCount = capturedTencentListeners.size
                                    val fCount = capturedFusedLocationCallbacks.size

                                    val isStationary = motion.speed <= 0.05
                                    // 标准 android.location.Location 按规范是 WGS-84，高德等 App 会自行转 GCJ-02；
                                    // 这里若直接给 GCJ-02 会被二次加密、偏移数百米（issue #62）
                                    val (targetLat, targetLng) = getAppTargetCoordinate(motion.lat, motion.lng, newConfig, "WGS-84")
                                    val pushLat = if (isStationary) targetLat else getJitteredLocation(targetLat, targetLng).first
                                    val pushLng = if (isStationary) targetLng else getJitteredLocation(targetLat, targetLng).second
                                    val pushSpeed = motion.speed
                                    val pushBearing = motion.bearing
                                    val pushAccuracy = if (isStationary) 2.5f else getJitteredAccuracy()
                                    val pushAltitude = RouteEngine.realisticAltitude(newConfig)

                                    val mainHandler = try {
                                        android.os.Handler(android.os.Looper.getMainLooper())
                                    } catch (_: Throwable) {
                                        null
                                    }

                                    val dispatchBlock = Runnable {
                                        if (configWorker !== workerThread) return@Runnable
                                        // 1. Android Native LocationListener & Consumer
                                        if (nCount > 0 && cl != null) {
                                            val listenersToNotify = capturedLocationListeners.toList()
                                            for (listener in listenersToNotify) {
                                                try {
                                                    val listenerCl = listener.javaClass.classLoader ?: cl
                                                    val locationClass = Class.forName(
                                                        "android.location.Location",
                                                        false,
                                                        listenerCl
                                                    )
                                                    val mockLoc =
                                                        locationClass.getConstructor(String::class.java)
                                                            .newInstance(android.location.LocationManager.GPS_PROVIDER)
                                                    XposedHelpers.callMethod(mockLoc, "setLatitude", pushLat)
                                                    XposedHelpers.callMethod(mockLoc, "setLongitude", pushLng)
                                                    XposedHelpers.callMethod(mockLoc, "setAccuracy", pushAccuracy)
                                                    XposedHelpers.callMethod(mockLoc, "setSpeed", pushSpeed)
                                                    XposedHelpers.callMethod(mockLoc, "setBearing", pushBearing)
                                                    XposedHelpers.callMethod(mockLoc, "setAltitude", pushAltitude)
                                                    XposedHelpers.callMethod(mockLoc, "setTime", timeNow)
                                                    XposedHelpers.callMethod(
                                                        mockLoc,
                                                        "setElapsedRealtimeNanos",
                                                        elapsedNanos
                                                    )
                                                    try {
                                                        val extras = android.os.Bundle().apply {
                                                            val satCount = newConfig.optInt(ConfigKeys.SATELLITE_COUNT, 20)
                                                            putInt("satellites", FakeLocationMetadata.satellitesInView)
                                                            putInt("satellites_in_view", FakeLocationMetadata.satellitesInView)
                                                            putInt("satellites_used_in_fix", FakeLocationMetadata.satellitesUsed)
                                                            putInt("satellites_visible", satCount)
                                                            putBoolean("mockLocation", false)
                                                        }
                                                        XposedHelpers.callMethod(mockLoc, "setExtras", extras)
                                                    } catch (t: Throwable) { HookLog.swallowed("LocationHooker.kt:951", t) }
                                                    try {
                                                        XposedHelpers.callMethod(
                                                            mockLoc,
                                                            "setIsFromMockProvider",
                                                            false
                                                        )
                                                    } catch (t: Throwable) { HookLog.swallowed("LocationHooker.kt:958", t) }
                                                    var called = false
                                                    try {
                                                        XposedHelpers.callMethod(
                                                            listener,
                                                            "onLocationChanged",
                                                            mockLoc
                                                        )
                                                        called = true
                                                    } catch (t: Throwable) { HookLog.swallowed("LocationHooker.kt:968", t) }
                                                    if (!called) {
                                                        try {
                                                            XposedHelpers.callMethod(
                                                                listener,
                                                                "accept",
                                                                mockLoc
                                                            )
                                                            called = true
                                                        } catch (t: Throwable) { HookLog.swallowed("LocationHooker.kt:977", t) }
                                                    }
                                                    if (!called) {
                                                        try {
                                                            XposedHelpers.callMethod(
                                                                listener,
                                                                "onLocationChanged",
                                                                listOf(mockLoc)
                                                            )
                                                            called = true
                                                        } catch (t: Throwable) { HookLog.swallowed("LocationHooker.kt:987", t) }
                                                    }
                                                } catch (t: Throwable) { HookLog.swallowed("LocationHooker.kt:989", t) }
                                            }
                                        }

                                        // 1.5 Google FusedLocationProviderClient 的 LocationCallback
                                        if (fCount > 0 && cl != null) {
                                            val callbacksToNotify = capturedFusedLocationCallbacks.toList()
                                            for (callback in callbacksToNotify) {
                                                try {
                                                    val callbackCl = callback.javaClass.classLoader ?: cl
                                                    val locationClass = Class.forName(
                                                        "android.location.Location",
                                                        false,
                                                        callbackCl
                                                    )
                                                    val mockLoc =
                                                        locationClass.getConstructor(String::class.java)
                                                            .newInstance(android.location.LocationManager.GPS_PROVIDER)
                                                    XposedHelpers.callMethod(mockLoc, "setLatitude", pushLat)
                                                    XposedHelpers.callMethod(mockLoc, "setLongitude", pushLng)
                                                    XposedHelpers.callMethod(mockLoc, "setAccuracy", pushAccuracy)
                                                    XposedHelpers.callMethod(mockLoc, "setSpeed", pushSpeed)
                                                    XposedHelpers.callMethod(mockLoc, "setBearing", pushBearing)
                                                    XposedHelpers.callMethod(mockLoc, "setAltitude", pushAltitude)
                                                    XposedHelpers.callMethod(mockLoc, "setTime", timeNow)
                                                    XposedHelpers.callMethod(
                                                        mockLoc,
                                                        "setElapsedRealtimeNanos",
                                                        elapsedNanos
                                                    )
                                                    try {
                                                        XposedHelpers.callMethod(
                                                            mockLoc,
                                                            "setIsFromMockProvider",
                                                            false
                                                        )
                                                    } catch (t: Throwable) { HookLog.swallowed("LocationHooker.kt:1026", t) }

                                                    val locationResultClass = Class.forName(
                                                        "com.google.android.gms.location.LocationResult",
                                                        false,
                                                        callbackCl
                                                    )
                                                    val locationsList = java.util.Collections.singletonList(mockLoc)
                                                    val result = XposedHelpers.callStaticMethod(
                                                        locationResultClass,
                                                        "create",
                                                        locationsList
                                                    )
                                                    XposedHelpers.callMethod(callback, "onLocationResult", result)
                                                } catch (t: Throwable) { HookLog.swallowed("LocationHooker.kt:1040", t) }
                                            }
                                        }

                                        // 2. AMapLocationListener
                                        if (aCount > 0 && cl != null) {
                                            val (aMapLat, aMapLng) = getAppTargetCoordinate(motion.lat, motion.lng, newConfig, "GCJ-02")
                                            val aMapPushLat = if (isStationary) aMapLat else getJitteredLocation(aMapLat, aMapLng).first
                                            val aMapPushLng = if (isStationary) aMapLng else getJitteredLocation(aMapLat, aMapLng).second
                                            val listenersToNotify = capturedAMapListeners.toList()
                                            for (listener in listenersToNotify) {
                                                try {
                                                    val listenerCl = listener.javaClass.classLoader ?: cl
                                                    val amapLocationClass = Class.forName(
                                                        "com.amap.api.location.AMapLocation",
                                                        false,
                                                        listenerCl
                                                    )
                                                    val mockAMapLoc =
                                                        amapLocationClass.getConstructor(String::class.java)
                                                            .newInstance("gps")
                                                    XposedHelpers.callMethod(
                                                        mockAMapLoc,
                                                        "setLatitude",
                                                        aMapPushLat
                                                    )
                                                    XposedHelpers.callMethod(
                                                        mockAMapLoc,
                                                        "setLongitude",
                                                        aMapPushLng
                                                    )
                                                    XposedHelpers.callMethod(
                                                        mockAMapLoc,
                                                        "setAccuracy",
                                                        pushAccuracy
                                                    )
                                                    XposedHelpers.callMethod(
                                                        mockAMapLoc,
                                                        "setSpeed",
                                                        pushSpeed
                                                    )
                                                    XposedHelpers.callMethod(
                                                        mockAMapLoc,
                                                        "setBearing",
                                                        pushBearing
                                                    )
                                                    XposedHelpers.callMethod(
                                                        mockAMapLoc,
                                                        "setAltitude",
                                                        pushAltitude
                                                    )
                                                    XposedHelpers.callMethod(
                                                        mockAMapLoc,
                                                        "setTime",
                                                        timeNow
                                                    )
                                                    try {
                                                        XposedHelpers.callMethod(mockAMapLoc, "setSatellites", newConfig.optInt(ConfigKeys.SATELLITE_COUNT, 20))
                                                        XposedHelpers.callMethod(mockAMapLoc, "setGpsAccuracyStatus", 1)
                                                        XposedHelpers.callMethod(mockAMapLoc, "setLocationType", 1)
                                                    } catch (t: Throwable) { HookLog.swallowed("LocationHooker.kt:1101", t) }
                                                    try {
                                                        val extras = android.os.Bundle().apply {
                                                            val satCount = newConfig.optInt(ConfigKeys.SATELLITE_COUNT, 20)
                                                            putInt("satellites", FakeLocationMetadata.satellitesInView)
                                                            putInt("satellites_in_view", FakeLocationMetadata.satellitesInView)
                                                            putInt("satellites_used_in_fix", FakeLocationMetadata.satellitesUsed)
                                                            putInt("satellites_visible", satCount)
                                                            putBoolean("mockLocation", false)
                                                        }
                                                        XposedHelpers.callMethod(mockAMapLoc, "setExtras", extras)
                                                    } catch (t: Throwable) { HookLog.swallowed("LocationHooker.kt:1112", t) }
                                                    try {
                                                        XposedHelpers.callMethod(
                                                            mockAMapLoc,
                                                            "setElapsedRealtimeNanos",
                                                            elapsedNanos
                                                        )
                                                    } catch (t: Throwable) { HookLog.swallowed("LocationHooker.kt:1119", t) }
                                                    try {
                                                        XposedHelpers.callMethod(
                                                            mockAMapLoc,
                                                            "setIsFromMockProvider",
                                                            false
                                                        )
                                                    } catch (t: Throwable) { HookLog.swallowed("LocationHooker.kt:1127", t) }
                                                    XposedHelpers.callMethod(
                                                        listener,
                                                        "onLocationChanged",
                                                        mockAMapLoc
                                                    )
                                                } catch (t: Throwable) { HookLog.swallowed("LocationHooker.kt:1134", t) }
                                            }
                                        }

                                        // 3. BDLocationListener / BDAbstractLocationListener
                                        if (bCount > 0 && cl != null) {
                                            val (baiduLat, baiduLng) = getAppTargetCoordinate(motion.lat, motion.lng, newConfig, "BD-09")
                                            val baiduPushLat = if (isStationary) baiduLat else getJitteredLocation(baiduLat, baiduLng).first
                                            val baiduPushLng = if (isStationary) baiduLng else getJitteredLocation(baiduLat, baiduLng).second
                                            val listenersToNotify = capturedBaiduListeners.toList()
                                            for (listener in listenersToNotify) {
                                                try {
                                                    val listenerCl = listener.javaClass.classLoader ?: cl
                                                    val bdLocationClass = Class.forName(
                                                        "com.baidu.location.BDLocation",
                                                        false,
                                                        listenerCl
                                                    )
                                                    val mockBDLoc =
                                                        bdLocationClass.getConstructor().newInstance()
                                                    XposedHelpers.callMethod(
                                                        mockBDLoc,
                                                        "setLatitude",
                                                        baiduPushLat
                                                    )
                                                    XposedHelpers.callMethod(
                                                        mockBDLoc,
                                                        "setLongitude",
                                                        baiduPushLng
                                                    )
                                                    try { XposedHelpers.setDoubleField(mockBDLoc, "mLatitude", baiduPushLat) } catch (t: Throwable) { HookLog.swallowed("LocationHooker.kt:1165", t) }
                                                    try { XposedHelpers.setDoubleField(mockBDLoc, "mLongitude", baiduPushLng) } catch (t: Throwable) { HookLog.swallowed("LocationHooker.kt:1166", t) }
                                                    try { XposedHelpers.callMethod(mockBDLoc, "setCoorType", "bd09ll") } catch (t: Throwable) { HookLog.swallowed("LocationHooker.kt:1167", t) }
                                                    try { XposedHelpers.setObjectField(mockBDLoc, "mCoorType", "bd09ll") } catch (t: Throwable) { HookLog.swallowed("LocationHooker.kt:1168", t) }
                                                    XposedHelpers.callMethod(mockBDLoc, "setRadius", pushAccuracy)
                                                    XposedHelpers.callMethod(mockBDLoc, "setSpeed", pushSpeed * 3.6f)
                                                    XposedHelpers.callMethod(mockBDLoc, "setDirection", pushBearing)
                                                    XposedHelpers.callMethod(mockBDLoc, "setLocType", 61)
                                                    XposedHelpers.callMethod(mockBDLoc, "setSatelliteNumber", 20)
                                                    XposedHelpers.callMethod(mockBDLoc, "setGpsCheckStatus", 1)
                                                    try { XposedHelpers.callMethod(mockBDLoc, "setMockGps", 0) } catch (t: Throwable) { HookLog.swallowed("LocationHooker.kt:1175", t) }
                                                    try { XposedHelpers.callMethod(mockBDLoc, "setTime", java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US).format(java.util.Date())) } catch (t: Throwable) { HookLog.swallowed("LocationHooker.kt:1176", t) }
                                                    XposedHelpers.callMethod(
                                                        listener,
                                                        "onReceiveLocation",
                                                        mockBDLoc
                                                    )
                                                } catch (t: Throwable) { HookLog.swallowed("LocationHooker.kt:1182", t) }
                                            }
                                        }

                                        // 4. TencentLocationListener
                                        if (tCount > 0 && cl != null) {
                                            try {
                                                val (tencentLat, tencentLng) = getAppTargetCoordinate(motion.lat, motion.lng, newConfig, "GCJ-02")
                                                val tencentPushLat = if (isStationary) tencentLat else getJitteredLocation(tencentLat, tencentLng).first
                                                val tencentPushLng = if (isStationary) tencentLng else getJitteredLocation(tencentLat, tencentLng).second
                                                val tencentLocInterface = Class.forName(
                                                    "com.tencent.map.geolocation.TencentLocation",
                                                    false,
                                                    cl
                                                )
                                                val proxyLoc = Proxy.newProxyInstance(
                                                    cl, arrayOf(tencentLocInterface)
                                                ) { _, method, _ ->
                                                    when (method.name) {
                                                        "getLatitude" -> tencentPushLat
                                                        "getLongitude" -> tencentPushLng
                                                        "getProvider" -> "gps"
                                                        "getAccuracy" -> pushAccuracy
                                                        "getSpeed" -> pushSpeed
                                                        "getBearing" -> pushBearing
                                                        "getTime" -> timeNow
                                                        else -> null
                                                    }
                                                }
                                                val listenersToNotify = capturedTencentListeners.toList()
                                                for (listener in listenersToNotify) {
                                                    try {
                                                        XposedHelpers.callMethod(
                                                            listener,
                                                            "onLocationChanged",
                                                            proxyLoc,
                                                            0,
                                                            "ok"
                                                        )
                                                    } catch (t: Throwable) { HookLog.swallowed("LocationHooker.kt:1222", t) }
                                                }
                                            } catch (t: Throwable) { HookLog.swallowed("LocationHooker.kt:1225", t) }
                                        }

                                        // 5. 传感器步数注入由 global 系统级 native 层处理。
                                    }

                                    if (mainHandler != null) {
                                        mainHandler.post(dispatchBlock)
                                    } else {
                                        dispatchBlock.run()
                                    }
                                }
                            } catch (_: InterruptedException) {
                                break
                            } catch (t: Throwable) {
                                XposedBridge.log("ConfigWorker error: " + t.javaClass.simpleName + ": " + t.message)
                            }
                        }
                    }.apply {
                        isDaemon = true
                        name = "LocationSpoofer_MotionWorker"
                    }
                    configWorker = worker
                    worker.start()

                }
            }
        }
    }

    internal var cachedGpsSatellitesList: Iterable<Any>? = null
    internal var lastGpsSatellitesUpdate = 0L
}
