package com.vincenthzr.locationspoofer.xposed.hooks

import android.os.IBinder
import android.os.IInterface
import com.vincenthzr.locationspoofer.utils.ConfigKeys
import com.vincenthzr.locationspoofer.xposed.utils.SpoofedMotion
import com.vincenthzr.locationspoofer.utils.GnssRealism
import com.vincenthzr.locationspoofer.utils.NmeaFormat
import com.vincenthzr.locationspoofer.xposed.LocationHooker
import com.vincenthzr.locationspoofer.xposed.utils.HookLog
import com.vincenthzr.locationspoofer.xposed.utils.XposedHelpers
import org.json.JSONObject

/**
 * GNSS 会话开始事件。真实 GNSS 每次会话只发一次 onGnssStarted/onFirstFix，
 * 不能跟随 1 Hz 卫星心跳重复发送，否则目标 App 会把每次心跳都当成新会话。
 */
internal fun LocationHooker.notifyGnssSessionStarted(listener: Any) {
    val clazz = listener.javaClass
    try {
        clazz.methods.firstOrNull { it.name == "onGnssStarted" && it.parameterCount == 0 }
            ?.invoke(listener)
    } catch (t: Throwable) { HookLog.swallowed("SystemLocationServiceHooker.kt:417", t) }
    try {
        clazz.methods.firstOrNull { it.name == "onFirstFix" && it.parameterCount == 1 }
            ?.invoke(listener, 1000)
    } catch (t: Throwable) { HookLog.swallowed("SystemLocationServiceHooker.kt:420", t) }
}

/**
 * Android 7~11 的 IGnssStatusListener 数组签名。
 *
 * AOSP 的 svidWithFlags 编码随版本变化：
 * - Android 8.1~10：SVID 从 bit 8 开始，星座类型从 bit 4 开始，flags 在 bit 0~3；
 * - Android 11：SVID 从 bit 12 开始，星座类型从 bit 8 开始，flags 在 bit 0~4。
 *
 * 旧实现固定使用 `(svid shl 4) or 0x07`，会把 SVID 和星座类型都解成错误值。
 */
internal data class LegacyGnssArrays(
    val svCount: Int,
    val svidWithFlags: IntArray,
    val cn0DbHz: FloatArray,
    val elevations: FloatArray,
    val azimuths: FloatArray,
    val carrierFrequencies: FloatArray,
    val basebandCn0DbHz: FloatArray?
)

internal fun buildLegacyGnssArrays(
    config: JSONObject,
    nowMs: Long,
    includeBaseband: Boolean
): LegacyGnssArrays {
    val satCount = config.optInt(ConfigKeys.SATELLITE_COUNT, 20).coerceIn(4, 32)
    val jitter = config.optBoolean(ConfigKeys.ENABLE_JITTER, true)
    val sats = GnssFastMockEngine.mockSatellites(satCount, nowMs, jitter)
    val svidShift = if (includeBaseband) 12 else 8
    val constellationShift = if (includeBaseband) 8 else 4

    val svidWithFlags = IntArray(sats.size)
    val cn0 = FloatArray(sats.size)
    val elevations = FloatArray(sats.size)
    val azimuths = FloatArray(sats.size)
    val carrierFrequencies = FloatArray(sats.size)
    val baseband = if (includeBaseband) FloatArray(sats.size) else null

    for ((i, sat) in sats.withIndex()) {
        var flags = 0x1 or 0x2 // hasEphemeris | hasAlmanac
        if (sat.usedInFix) flags = flags or 0x4
        if (includeBaseband) flags = flags or 0x10 // hasBasebandCn0
        svidWithFlags[i] = (sat.svid shl svidShift) or
            ((sat.constellationType and 0xF) shl constellationShift) or flags
        cn0[i] = sat.cn0DbHz
        elevations[i] = sat.elevation
        azimuths[i] = sat.azimuth
        carrierFrequencies[i] = sat.carrierFrequencyHz
        baseband?.set(i, sat.basebandCn0DbHz)
    }

    return LegacyGnssArrays(
        svCount = sats.size,
        svidWithFlags = svidWithFlags,
        cn0DbHz = cn0,
        elevations = elevations,
        azimuths = azimuths,
        carrierFrequencies = carrierFrequencies,
        basebandCn0DbHz = baseband
    )
}

/**
 * 向 IGnssStatusListener 代理对象主动反射调用 onSvStatusChanged。
 *
 * 支持 Android 12+ 的 1 参数 GnssStatus、Android 7~10 的 6 参数数组，
 * 以及 Android 11 的 7 参数数组（带 basebandCn0s）。
 */
internal fun LocationHooker.dispatchGnssStatus(
    listener: Any,
    gnssStatus: Any?,
    config: JSONObject?,
    classLoader: ClassLoader
) {
    val clazz = listener.javaClass
    val svMethod = clazz.methods.firstOrNull { it.name == "onSvStatusChanged" } ?: return
    val cfg = config ?: readConfig() ?: return

    try {
        when (svMethod.parameterCount) {
            1 -> {
                val statusObj = gnssStatus ?: GnssFastMockEngine.getOrCreateSpoofedGnssStatus(
                    classLoader,
                    cfg.optInt(ConfigKeys.SATELLITE_COUNT, 20),
                    cfg.optBoolean(ConfigKeys.ENABLE_JITTER, true),
                    null
                )
                if (statusObj != null) svMethod.invoke(listener, statusObj)
            }

            6 -> {
                val a = buildLegacyGnssArrays(cfg, System.currentTimeMillis(), includeBaseband = false)
                svMethod.invoke(
                    listener, a.svCount, a.svidWithFlags, a.cn0DbHz,
                    a.elevations, a.azimuths, a.carrierFrequencies
                )
            }

            7 -> {
                val a = buildLegacyGnssArrays(cfg, System.currentTimeMillis(), includeBaseband = true)
                svMethod.invoke(
                    listener, a.svCount, a.svidWithFlags, a.cn0DbHz,
                    a.elevations, a.azimuths, a.carrierFrequencies,
                    a.basebandCn0DbHz ?: FloatArray(a.svCount)
                )
            }

            else -> logLoc(
                "[SysLoc] unsupported onSvStatusChanged signature: ${svMethod.parameterCount} args"
            )
        }
    } catch (e: Throwable) {
        logLoc("[SysLoc] dispatch onSvStatusChanged error: $e")
    }
}

/** 向 IGnssNmeaListener 反射分发 NMEA 语句 */
internal fun dispatchNmea(listener: Any, timestamp: Long, sentence: String) {
    val clazz = listener.javaClass
    val method = clazz.methods.firstOrNull { it.name == "onNmeaReceived" }
        ?: clazz.methods.firstOrNull { it.name == "onNmeaMessage" }
    if (method != null) {
        try {
            if (method.parameterTypes.size == 2) {
                if (method.parameterTypes[0] == Long::class.javaPrimitiveType || method.parameterTypes[0] == Long::class.java) {
                    method.invoke(listener, timestamp, sentence)
                } else {
                    method.invoke(listener, sentence, timestamp)
                }
            } else if (method.parameterTypes.size == 1 && method.parameterTypes[0] == String::class.java) {
                method.invoke(listener, sentence)
            }
        } catch (t: Throwable) { HookLog.swallowed("SystemLocationServiceHooker.kt:478", t) }
    }
}

/** 向 IGnssMeasurementsListener 反射分发合成 GnssMeasurementsEvent */
internal fun dispatchGnssMeasurements(listener: Any, event: Any) {
    val method = listener.javaClass.methods.firstOrNull {
        it.name == "onGnssMeasurementsReceived" && it.parameterTypes.size == 1
    } ?: return
    try {
        syntheticMeasurementsDelivery.withValue(true) {
            method.invoke(listener, event)
        }
    } catch (t: Throwable) { HookLog.swallowed("SystemLocationServiceHooker.kt:491", t) }
}

/**
 * 模拟激活时只让模块合成的 raw measurements 到达目标 App，丢弃真实芯片测量。
 * 真实事件数量、卫星集合与模拟数据不一致时会形成明显旁路。
 */
internal fun LocationHooker.ensureMeasurementCallbackHooked(callback: Any) {
    val clazz = callback.javaClass
    if (hookedMeasurementCallbackClasses.putIfAbsent(clazz, true) != null) return
    try {
        XposedHelpers.hookAllMethods(clazz, "onGnssMeasurementsReceived") { chain, _ ->
            val binder = (chain.thisObject as? IInterface)?.asBinder()
                ?: (chain.thisObject as? IBinder)
            val config = readConfig()
            val isTracked = binder != null && activeGnssMeasurementBinders.containsKey(binder)
            if (syntheticMeasurementsDelivery.current != true &&
                isTracked &&
                config != null &&
                config.optBoolean(ConfigKeys.ACTIVE, false)
            ) {
                return@hookAllMethods null
            }
            return@hookAllMethods chain.proceed(chain.args.toTypedArray())
        }
    } catch (t: Throwable) { HookLog.swallowed("SystemLocationServiceHooker.kt:516", t) }
}

/**
 * 拦截目标 App 的 NMEA 回调：模块自己派发模拟 NMEA 时放行，
 * 其它来自真实 GNSS 芯片的 NMEA 在模拟激活期间丢弃。
 *
 * 否则目标 App 会同时看到“21 颗星、quality=1、坐标等于模拟位置”的合成报文
 * 和“0 颗星、quality=0”的真实报文，形成明显的双流矛盾。
 */
internal fun LocationHooker.ensureNmeaCallbackHooked(callback: Any) {
    val clazz = callback.javaClass
    if (hookedNmeaCallbackClasses.putIfAbsent(clazz, true) != null) return
    for (mName in arrayOf("onNmeaReceived", "onNmeaMessage")) {
        try {
            XposedHelpers.hookAllMethods(clazz, mName) { chain, _ ->
                val binder = (chain.thisObject as? IInterface)?.asBinder()
                    ?: (chain.thisObject as? IBinder)
                val config = readConfig()
                val isTracked = binder != null && activeGnssNmeaBinders.containsKey(binder)
                if (syntheticNmeaDelivery.current != true &&
                    isTracked &&
                    config != null &&
                    config.optBoolean(ConfigKeys.ACTIVE, false)
                ) {
                    // 模拟激活时只允许模块合成的 NMEA 到达目标 App。
                    return@hookAllMethods null
                }
                return@hookAllMethods chain.proceed(chain.args.toTypedArray())
            }
        } catch (t: Throwable) { HookLog.swallowed("SystemLocationServiceHooker.kt:546", t) }
    }
}

/** 动态构造符合当前运动轨迹与坐标的标准 NMEA-0183 报文序列 */
internal fun LocationHooker.buildMockNmeaSentences(
    motion: SpoofedMotion,
    altitude: Double,
    accuracy: Float,
    config: JSONObject
): List<String> {
    val sentences = mutableListOf<String>()
    val now = System.currentTimeMillis()
    val calendar = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"))
    calendar.timeInMillis = now
    val timeUtc = String.format(
        java.util.Locale.US,
        "%02d%02d%02d.%02d",
        calendar.get(java.util.Calendar.HOUR_OF_DAY),
        calendar.get(java.util.Calendar.MINUTE),
        calendar.get(java.util.Calendar.SECOND),
        ((now % 1000L) / 10L).toInt()
    )
    val dateUtc = String.format(
        java.util.Locale.US,
        "%02d%02d%02d",
        calendar.get(java.util.Calendar.DAY_OF_MONTH),
        calendar.get(java.util.Calendar.MONTH) + 1,
        calendar.get(java.util.Calendar.YEAR) % 100
    )

    val lat = motion.lat
    val lng = motion.lng
    val absLat = kotlin.math.abs(lat)
    val latDeg = absLat.toInt()
    val latMin = (absLat - latDeg) * 60.0
    val latStr = String.format(java.util.Locale.US, "%02d%07.4f", latDeg, latMin)
    val latHem = if (lat >= 0) "N" else "S"

    val absLng = kotlin.math.abs(lng)
    val lngDeg = absLng.toInt()
    val lngMin = (absLng - lngDeg) * 60.0
    val lngStr = String.format(java.util.Locale.US, "%03d%07.4f", lngDeg, lngMin)
    val lngHem = if (lng >= 0) "E" else "W"

    val speedKnots = (motion.speed * 1.943844).coerceAtLeast(0.0)
    val speedStr = String.format(java.util.Locale.US, "%.2f", speedKnots)
    val bearingStr = String.format(java.util.Locale.US, "%.1f", motion.bearing)
    val altStr = String.format(java.util.Locale.US, "%.1f", altitude)

    // 与 GnssStatus 共用同一份卫星模型，避免 GGA 的卫星数、GSV 的可见卫星
    // 与状态栏/系统 GnssStatus 对不上。
    val sats = GnssFastMockEngine.mockSatellites(
        config.optInt(ConfigKeys.SATELLITE_COUNT, 20),
        now,
        config.optBoolean(ConfigKeys.ENABLE_JITTER, true)
    )
    val used = sats.filter { it.usedInFix }
    val startTs = config.optLong(ConfigKeys.START_TIMESTAMP, 0L)
    val realism = config.optInt(ConfigKeys.REALISM_LEVEL, 0)
    val configuredCount = config.optInt(ConfigKeys.SATELLITE_COUNT, 20)
    val hdop = GnssRealism.hdop(
        startTs, realism, configuredCount, used.size, now
    )
    val vdop = GnssRealism.vdop(
        startTs, realism, configuredCount, used.size, now
    )
    val pdop = GnssRealism.pdop(
        startTs, realism, configuredCount, used.size, now
    )
    val hdopStr = String.format(java.util.Locale.US, "%.1f", hdop)
    val vdopStr = String.format(java.util.Locale.US, "%.1f", vdop)
    val pdopStr = String.format(java.util.Locale.US, "%.1f", pdop)
    val talkers = mapOf(
        1 to "GP",
        3 to "GL",
        5 to "BD",
        6 to "GA"
    )
    fun appendGsv(talker: String, visible: List<GnssFastMockEngine.MockSatellite>) {
        if (visible.isEmpty()) return
        val total = (visible.size + 3) / 4
        visible.chunked(4).forEachIndexed { index, chunk ->
            val body = buildString {
                append(talker)
                append("GSV,").append(total).append(',').append(index + 1)
                append(',').append(String.format(java.util.Locale.US, "%02d", visible.size))
                for (sat in chunk) {
                    append(',').append(String.format(java.util.Locale.US, "%02d", sat.svid))
                    append(',').append(sat.elevation.toInt().coerceIn(0, 90))
                    append(',').append(String.format(java.util.Locale.US, "%03d", sat.azimuth.toInt().coerceIn(0, 359)))
                    append(',').append(sat.cn0DbHz.toInt().coerceIn(0, 99))
                }
            }
            sentences.add("$$body*${NmeaFormat.checksum(body)}")
        }
    }
    fun appendGsa(talker: String, usedSats: List<GnssFastMockEngine.MockSatellite>) {
        if (usedSats.isEmpty()) return
        val ids = usedSats.take(12).map { String.format(java.util.Locale.US, "%02d", it.svid) }.toMutableList()
        while (ids.size < 12) ids.add("")
        val body = "$talker" + "GSA,A,3," + ids.joinToString(",") +
            ",$pdopStr,$hdopStr,$vdopStr"
        sentences.add("$$body*${NmeaFormat.checksum(body)}")
    }

    // $GPRMC
    val rmc = "GPRMC,$timeUtc,A,$latStr,$latHem,$lngStr,$lngHem,$speedStr,$bearingStr,$dateUtc,,,A"
    sentences.add("$$rmc*${NmeaFormat.checksum(rmc)}")

    // $GPGGA：field 7 是参与定位解算的卫星数，HDOP 与 Location.accuracy
    // 共用 GnssRealism 的质量曲线，不再固定 0.8。
    val gga = "GPGGA,$timeUtc,$latStr,$latHem,$lngStr,$lngHem,1," +
        "${String.format(java.util.Locale.US, "%02d", used.size.coerceIn(0, 99))}," +
        "$hdopStr,$altStr,M,0.0,M,,"
    sentences.add("$$gga*${NmeaFormat.checksum(gga)}")

    // 每个星座分别生成 GSA 与 GSV，保持与 GnssStatus 的星座/卫星数一致
    for ((type, talker) in talkers) {
        val visible = sats.filter { it.constellationType == type }
        val usedForType = used.filter { it.constellationType == type }
        appendGsa(talker, usedForType)
        appendGsv(talker, visible)
    }

    return sentences
}

/** 向 ILocationListener 代理对象主动反射调用 onLocationChanged */
internal fun dispatchFakeLocationToListener(listener: Any, fakeLoc: Any) {
    val clazz = listener.javaClass
    val methods = clazz.methods

    // 优先尝试 onLocationChanged(Location)
    val singleLocMethod = methods.firstOrNull {
        it.name == "onLocationChanged" && it.parameterTypes.size == 1 &&
                LocationHooker.hasTypeByName(it.parameterTypes[0], "android.location.Location")
    }
    if (singleLocMethod != null) {
        singleLocMethod.invoke(listener, fakeLoc)
        return
    }

    // Android 12+ 批量位置接口: onLocationChanged(List<Location>, IRemoteCallback)
    val batchMethod = methods.firstOrNull {
        it.name == "onLocationChanged" && it.parameterTypes.isNotEmpty() &&
                List::class.java.isAssignableFrom(it.parameterTypes[0])
    }
    if (batchMethod != null) {
        val args = arrayOfNulls<Any>(batchMethod.parameterTypes.size)
        args[0] = listOf(fakeLoc)
        if (args.size > 1) {
            args[1] = createDummyRemoteCallback()
        }
        try {
            batchMethod.invoke(listener, *args)
        } catch (_: Throwable) {
            if (args.size > 1) {
                args[1] = null
                try { batchMethod.invoke(listener, *args) } catch (t: Throwable) { HookLog.swallowed("SystemLocationServiceHooker.kt:705", t) }
            }
        }
    }
}

