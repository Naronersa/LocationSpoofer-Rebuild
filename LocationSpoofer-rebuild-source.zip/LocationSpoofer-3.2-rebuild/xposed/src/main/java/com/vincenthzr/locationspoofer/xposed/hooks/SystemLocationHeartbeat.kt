package com.vincenthzr.locationspoofer.xposed.hooks

import com.vincenthzr.locationspoofer.utils.ConfigKeys
import com.vincenthzr.locationspoofer.xposed.utils.RouteEngine
import com.vincenthzr.locationspoofer.xposed.LocationHooker
import com.vincenthzr.locationspoofer.xposed.utils.HookLog
import com.vincenthzr.locationspoofer.xposed.utils.getJitteredAccuracy
import java.util.Timer
import java.util.TimerTask

/**
 * 启动 system_server 内部的主动心跳推送定时器
 * 当目标应用处于活动状态时，此定时器主动向客户端 Binder 投递平滑的伪造坐标、
 * 20+ 真实多星座卫星（GnssStatus）以及标准 NMEA-0183 报文，彻底消除 GPS 状态测试工具卫星数为 0 的问题。
 */
internal fun LocationHooker.startSystemLocationHeartbeat(classLoader: ClassLoader) {
    if (isHeartbeatTimerStarted) return
    synchronized(activeListenerBinders) {
        if (isHeartbeatTimerStarted) return
        isHeartbeatTimerStarted = true
    }

    val timer = ownReloadTimer(Timer("LocationSpoofer-SysHeartbeat", true))
    timer.scheduleAtFixedRate(object : TimerTask() {
        override fun run() {
            try {
                try {
                    tryHookPendingSystemServices(classLoader)
                } catch (t: Throwable) { HookLog.swallowed("SystemLocationServiceHooker.kt:289", t) }

                if (activeListenerBinders.isEmpty() &&
                    activeCallbackBinders.isEmpty() &&
                    activeGnssStatusBinders.isEmpty() &&
                    activeGnssNmeaBinders.isEmpty() &&
                    activeGnssMeasurementBinders.isEmpty()
                ) return
                val config = readConfig() ?: return
                if (!config.optBoolean(ConfigKeys.ACTIVE, false)) {
                    // 下一次模拟开始时，每个监听器重新收到一次 onGnssStarted/onFirstFix。
                    activeGnssStatusBinders.values.forEach { it.sessionStarted = false }
                    return
                }

                val motion = getCurrentSpoofedMotion("WGS-84") ?: return
                val altitude = RouteEngine.realisticAltitude(config)
                val accuracy = getJitteredAccuracy()

                // 1. 推送定位坐标给目标应用 ILocationListener
                if (activeListenerBinders.isNotEmpty()) {
                    for ((binder, info) in activeListenerBinders) {
                        if (!binder.isBinderAlive) {
                            activeListenerBinders.remove(binder)
                            continue
                        }
                        val fakeLoc = SystemHookUtils.buildFakeLocation(
                            classLoader,
                            info.provider,
                            motion,
                            altitude,
                            accuracy
                        )
                        if (fakeLoc != null) {
                            val listener = info.listener
                            try {
                                dispatchFakeLocationToListener(listener, fakeLoc)
                            } catch (e: Throwable) {
                                if (!binder.isBinderAlive) {
                                    activeListenerBinders.remove(binder)
                                }
                            }
                        }
                    }
                }

                // 1b. 目标 App 在模拟开启前注册的 getCurrentLocation 回调：
                // 只补发一次 fake fix 后移除（getCurrentLocation 本身是一次性 API）。
                if (activeCallbackBinders.isNotEmpty()) {
                    for ((binder, info) in activeCallbackBinders) {
                        if (!binder.isBinderAlive) {
                            activeCallbackBinders.remove(binder)
                            continue
                        }
                        val fakeLoc = SystemHookUtils.buildFakeLocation(
                            classLoader,
                            info.provider,
                            motion,
                            altitude,
                            accuracy
                        )
                        if (fakeLoc != null) {
                            val onLocation = info.callback.javaClass.methods.firstOrNull {
                                it.name == "onLocation" && it.parameterTypes.size == 1
                            }
                            try {
                                onLocation?.invoke(info.callback, fakeLoc)
                            } catch (t: Throwable) {
                                HookLog.swallowed("SystemLocationHeartbeat.kt:callback", t)
                            }
                        }
                        activeCallbackBinders.remove(binder)
                    }
                }

                // 2. 推送 20+ 真实卫星星座给目标应用 IGnssStatusListener (GnssStatus / GpsStatus)
                if (activeGnssStatusBinders.isNotEmpty()) {
                    val satCount = config.optInt(ConfigKeys.SATELLITE_COUNT, 20)
                    val enableJitter = config.optBoolean(ConfigKeys.ENABLE_JITTER, true)
                    val gnssStatus = GnssFastMockEngine.getOrCreateSpoofedGnssStatus(
                        classLoader,
                        satCount,
                        enableJitter,
                        null
                    )
                    for ((binder, info) in activeGnssStatusBinders) {
                        if (!binder.isBinderAlive) {
                            activeGnssStatusBinders.remove(binder)
                            continue
                        }
                        val callback = info.listener
                        try {
                            if (!info.sessionStarted) {
                                notifyGnssSessionStarted(callback)
                                info.sessionStarted = true
                            }
                            dispatchGnssStatus(callback, gnssStatus, config, classLoader)
                        } catch (e: Throwable) {
                            if (!binder.isBinderAlive) {
                                activeGnssStatusBinders.remove(binder)
                            }
                        }
                    }
                }

                // 3. 推送标准 NMEA-0183 报文流给目标应用 IGnssNmeaListener
                if (activeGnssNmeaBinders.isNotEmpty()) {
                    val nmeas = buildMockNmeaSentences(motion, altitude, accuracy, config)
                    // Android 的 onNmeaReceived/onNmeaMessage 时间戳约定是
                    // 自开机起的毫秒数（elapsedRealtime），不是墙钟 epoch。
                    val nowMs = android.os.SystemClock.elapsedRealtime()
                    for ((binder, info) in activeGnssNmeaBinders) {
                        if (!binder.isBinderAlive) {
                            activeGnssNmeaBinders.remove(binder)
                            continue
                        }
                        val callback = info.listener
                        try {
                            syntheticNmeaDelivery.withValue(true) {
                                for (line in nmeas) {
                                    dispatchNmea(callback, nowMs, line)
                                }
                            }
                        } catch (e: Throwable) {
                            if (!binder.isBinderAlive) {
                                activeGnssNmeaBinders.remove(binder)
                            }
                        }
                    }
                }

                // 4. 推送 raw GNSS measurements，保持与 status/NMEA 同一卫星模型
                if (activeGnssMeasurementBinders.isNotEmpty()) {
                    val event = GnssMeasurementsFactory.build(
                        classLoader,
                        config.optInt(ConfigKeys.SATELLITE_COUNT, 20),
                        config.optBoolean(ConfigKeys.ENABLE_JITTER, true),
                        config.optLong(ConfigKeys.START_TIMESTAMP, 0L),
                        motion.speed.toDouble()
                    )
                    if (event != null) {
                        for ((binder, info) in activeGnssMeasurementBinders) {
                            if (!binder.isBinderAlive) {
                                activeGnssMeasurementBinders.remove(binder)
                                continue
                            }
                            try {
                                dispatchGnssMeasurements(info.listener, event)
                            } catch (_: Throwable) {
                                if (!binder.isBinderAlive) {
                                    activeGnssMeasurementBinders.remove(binder)
                                }
                            }
                        }
                    }
                }
            } catch (t: Throwable) { HookLog.swallowed("SystemLocationServiceHooker.kt:405", t) }
        }
    }, 1000L, 1000L)
}

