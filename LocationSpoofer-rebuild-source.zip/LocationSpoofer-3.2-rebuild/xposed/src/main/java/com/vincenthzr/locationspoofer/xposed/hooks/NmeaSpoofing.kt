@file:Suppress(
    "UNUSED_PARAMETER",
    "UNUSED_VARIABLE",
    "UNNECESSARY_NOT_NULL_ASSERTION",
    "DEPRECATION",
    "NAME_SHADOWING",
    "FunctionName",
    "PrivatePropertyName",
    "SpellCheckingInspection",
    "RedundantUnitReturnType",
    "RemoveRedundantQualifierName",
    "OPT_IN_USAGE",
    "unused",
    "UnusedImport"
)

package com.vincenthzr.locationspoofer.xposed.hooks

import com.vincenthzr.locationspoofer.utils.ConfigKeys

import com.vincenthzr.locationspoofer.utils.GnssRealism
import com.vincenthzr.locationspoofer.utils.NmeaFormat
import com.vincenthzr.locationspoofer.xposed.LocationHooker
import com.vincenthzr.locationspoofer.xposed.utils.*
import com.vincenthzr.locationspoofer.xposed.hooks.*
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import java.lang.reflect.*
import kotlin.math.*
import io.github.libxposed.api.*

/**
 * NMEA $GPGGA/$GPRMC/$GPGSA/$GPGSV 语句动态拼装与劫持
 */
internal fun LocationHooker.createOnNmeaMessageListenerProxy(
    original: Any,
    classLoader: ClassLoader
): Any {
    val interfaceClass = classLoader.loadClass("android.location.OnNmeaMessageListener")
    val proxy = Proxy.newProxyInstance(
        classLoader,
        arrayOf(interfaceClass),
        object : InvocationHandler {
            override fun invoke(
                proxy: Any,
                method: Method,
                args: Array<out Any>?
            ): Any? {
                if (method.name == "onNmeaMessage" && args != null && args.size >= 1) {
                    val originalMsg = args[0] as? String
                    if (originalMsg != null) {
                        val spoofedMsg = spoofNmeaMessage(originalMsg)
                        if (spoofedMsg == null) return null // 允许丢弃消息
                        val newArgs = arrayOfNulls<Any>(args.size)
                        for (i in args.indices) {
                            newArgs[i] = if (i == 0) spoofedMsg else args[i]
                        }
                        return method.invoke(original, *newArgs)
                    }
                }
                val methodArgs =
                    if (args == null) emptyArray<Any>() else Array(args.size) { i -> args[i] }
                return method.invoke(original, *methodArgs)
            }
        }
    )
    // startNmeaGsvInjector(original, "onNmeaMessage", classLoader)
    return proxy
}

internal fun LocationHooker.createGpsStatusNmeaListenerProxy(
    original: Any,
    classLoader: ClassLoader
): Any {
    val interfaceClass = classLoader.loadClass("android.location.GpsStatus\$NmeaListener")
    val proxy = Proxy.newProxyInstance(
        classLoader,
        arrayOf(interfaceClass),
        object : InvocationHandler {
            override fun invoke(
                proxy: Any,
                method: Method,
                args: Array<out Any>?
            ): Any? {
                if (method.name == "onNmeaReceived" && args != null && args.size >= 2) {
                    val originalMsg = args[1] as? String
                    if (originalMsg != null) {
                        val spoofedMsg = spoofNmeaMessage(originalMsg)
                        if (spoofedMsg == null) return null // 允许丢弃消息
                        val newArgs = arrayOfNulls<Any>(args.size)
                        for (i in args.indices) {
                            newArgs[i] = if (i == 1) spoofedMsg else args[i]
                        }
                        return method.invoke(original, *newArgs)
                    }
                }
                val methodArgs =
                    if (args == null) emptyArray<Any>() else Array(args.size) { i -> args[i] }
                return method.invoke(original, *methodArgs)
            }
        }
    )
    // startNmeaGsvInjector(original, "onNmeaReceived", classLoader)
    return proxy
}

internal fun LocationHooker.spoofNmeaMessage(sentence: String): String? {
    try {
        val config = readConfig() ?: return sentence
        if (!config.optBoolean(ConfigKeys.ACTIVE, false)) return sentence

        val nowMs = System.currentTimeMillis()
        val motion = RouteEngine.calculateCurrentPosition(config, nowMs)
        val targetCoords = getAppTargetCoordinate(motion.lat, motion.lng, config, "WGS-84")
        val targetLat = targetCoords.first
        val targetLng = targetCoords.second

        val used = GnssRealism.usedSatellites(
            config.optLong(ConfigKeys.START_TIMESTAMP, 0L),
            config.optInt(ConfigKeys.REALISM_LEVEL, 0),
            config.optInt(ConfigKeys.SATELLITE_COUNT, 20),
            nowMs
        )
        val hdop = GnssRealism.hdop(
            config.optLong(ConfigKeys.START_TIMESTAMP, 0L),
            config.optInt(ConfigKeys.REALISM_LEVEL, 0),
            config.optInt(ConfigKeys.SATELLITE_COUNT, 20),
            used,
            nowMs
        )
        return NmeaFormat.rewriteSentence(
            sentence,
            targetLat,
            targetLng,
            motion.speed,
            motion.bearing,
            RouteEngine.realisticAltitude(config),
            used,
            hdop,
        ) ?: sentence
    } catch (e: Exception) {
        XposedBridge.log(e)
        return sentence
    }
}
