package com.vincenthzr.locationspoofer.xposed.hooks

import android.os.IBinder
import com.vincenthzr.locationspoofer.xposed.LocationHooker
import com.vincenthzr.locationspoofer.xposed.utils.CallScope
import com.vincenthzr.locationspoofer.xposed.utils.ModuleBinderDeaths
import java.util.Collections
import java.util.WeakHashMap
import java.util.concurrent.ConcurrentHashMap

// 存储被标记为目标应用的 ILocationListener / ILocationCallback 实例
internal val spoofedListenerInstances: MutableSet<Any> =
    Collections.synchronizedSet(Collections.newSetFromMap(WeakHashMap()))

// 存储当前处于活跃状态的目标应用 ILocationListener 代理对象及其 Binder 映射（强引用避免 GC 导致失联）
internal data class ListenerRegistrationInfo(
    val listener: Any,
    val packageName: String,
    val provider: String = android.location.LocationManager.GPS_PROVIDER,
    val registeredTime: Long = System.currentTimeMillis()
)

internal val activeListenerBinders = ConcurrentHashMap<IBinder, ListenerRegistrationInfo>()

// 存储当前活跃的目标应用 IGnssStatusListener 映射
internal data class GnssStatusRegistrationInfo(
    val listener: Any,
    val packageName: String,
    val registeredTime: Long = System.currentTimeMillis(),
    /** onGnssStarted/onFirstFix 每次模拟会话只应向该监听器发一次。 */
    @Volatile var sessionStarted: Boolean = false
)
internal val activeGnssStatusBinders = ConcurrentHashMap<IBinder, GnssStatusRegistrationInfo>()

// 存储当前活跃的目标应用 IGnssNmeaListener 映射
internal data class GnssNmeaRegistrationInfo(
    val listener: Any,
    val packageName: String,
    val registeredTime: Long = System.currentTimeMillis()
)
internal val activeGnssNmeaBinders = ConcurrentHashMap<IBinder, GnssNmeaRegistrationInfo>()

// 存储当前活跃的目标应用 IGnssMeasurementsCallback 映射
internal data class GnssMeasurementRegistrationInfo(
    val listener: Any,
    val packageName: String,
    val registeredTime: Long = System.currentTimeMillis()
)
internal val activeGnssMeasurementBinders = ConcurrentHashMap<IBinder, GnssMeasurementRegistrationInfo>()

/** 标记当前线程正在派发模块合成的 NMEA，用于放行模拟报文、拦截真实 NMEA。 */
internal val syntheticNmeaDelivery = CallScope<Boolean>()
internal val hookedNmeaCallbackClasses = ConcurrentHashMap<Class<*>, Boolean>()

/** 标记当前线程正在派发模块合成的 raw measurements，用于拦截真实测量事件。 */
internal val syntheticMeasurementsDelivery = CallScope<Boolean>()
internal val hookedMeasurementCallbackClasses = ConcurrentHashMap<Class<*>, Boolean>()

// 存储当前活跃的目标应用 ILocationCallback (单次定位) 映射
internal data class CallbackRegistrationInfo(
    val callback: Any,
    val packageName: String,
    val registeredTime: Long = System.currentTimeMillis(),
    /** getCurrentLocation 的 provider；模拟开启后补发一次性 fake fix 时使用。 */
    val provider: String = "gps"
)
internal val activeCallbackBinders = ConcurrentHashMap<IBinder, CallbackRegistrationInfo>()

// 存储当前活跃的目标应用 PendingIntent 映射。
// PendingIntent 可能被目标应用在注销前丢弃；用弱键避免它在 system_server
// 中被模块永久强引用（对象泄漏）。遍历时仍需在 map 锁内复制。
internal val activePendingIntents: MutableMap<android.app.PendingIntent, String> =
    Collections.synchronizedMap(WeakHashMap())

@Volatile
internal var isHeartbeatTimerStarted = false

/** Flatten module-defined registrations into bootstrap arrays before handing them to new code. */
internal fun saveSystemLocationReloadState(): Array<Any> {
    val pendingIntents = synchronized(activePendingIntents) {
        activePendingIntents.mapTo(java.util.ArrayList()) { (pendingIntent, packageName) ->
            arrayOf<Any>(pendingIntent, packageName)
        }
    }
    return arrayOf(
        activeListenerBinders.mapTo(java.util.ArrayList()) { (binder, info) ->
            arrayOf<Any>(binder, info.listener, info.packageName, info.provider, info.registeredTime)
        },
        activeGnssStatusBinders.mapTo(java.util.ArrayList()) { (binder, info) ->
            arrayOf<Any>(binder, info.listener, info.packageName, info.registeredTime)
        },
        activeGnssNmeaBinders.mapTo(java.util.ArrayList()) { (binder, info) ->
            arrayOf<Any>(binder, info.listener, info.packageName, info.registeredTime)
        },
        activeGnssMeasurementBinders.mapTo(java.util.ArrayList()) { (binder, info) ->
            arrayOf<Any>(binder, info.listener, info.packageName, info.registeredTime)
        },
        activeCallbackBinders.mapTo(java.util.ArrayList()) { (binder, info) ->
            arrayOf<Any>(binder, info.callback, info.packageName, info.registeredTime)
        },
        pendingIntents
    )
}

internal fun clearSystemLocationReloadState() {
    isHeartbeatTimerStarted = false
    activeListenerBinders.clear()
    activeGnssStatusBinders.clear()
    activeGnssNmeaBinders.clear()
    activeGnssMeasurementBinders.clear()
    activeCallbackBinders.clear()
    activePendingIntents.clear()
    spoofedListenerInstances.clear()
}

internal fun LocationHooker.restoreSystemLocationReloadState(value: Any?) {
    val state = value as? Array<*> ?: return
    fun rows(index: Int): List<Array<*>> = (state.getOrNull(index) as? List<*>)?.filterIsInstance<Array<*>>() ?: emptyList()
    rows(0).forEach { row ->
        val binder = row[0] as IBinder
        if (!binder.isBinderAlive) return@forEach
        val listener = row[1]!!
        activeListenerBinders[binder] = ListenerRegistrationInfo(listener, row[2] as String, row[3] as String, row[4] as Long)
        spoofedListenerInstances.add(listener)
        ensureCallbackHooked(listener, "onLocationChanged")
        runCatching { ModuleBinderDeaths.watch(binder) { activeListenerBinders.remove(binder) } }
    }
    rows(1).forEach { row ->
        val binder = row[0] as IBinder
        if (!binder.isBinderAlive) return@forEach
        activeGnssStatusBinders[binder] = GnssStatusRegistrationInfo(row[1]!!, row[2] as String, row[3] as Long)
        runCatching { ModuleBinderDeaths.watch(binder) { activeGnssStatusBinders.remove(binder) } }
    }
    rows(2).forEach { row ->
        val binder = row[0] as IBinder
        if (!binder.isBinderAlive) return@forEach
        activeGnssNmeaBinders[binder] = GnssNmeaRegistrationInfo(row[1]!!, row[2] as String, row[3] as Long)
        ensureNmeaCallbackHooked(row[1]!!)
        runCatching { ModuleBinderDeaths.watch(binder) { activeGnssNmeaBinders.remove(binder) } }
    }
    rows(3).forEach { row ->
        val binder = row[0] as IBinder
        if (!binder.isBinderAlive) return@forEach
        activeGnssMeasurementBinders[binder] = GnssMeasurementRegistrationInfo(row[1]!!, row[2] as String, row[3] as Long)
        ensureMeasurementCallbackHooked(row[1]!!)
        runCatching { ModuleBinderDeaths.watch(binder) { activeGnssMeasurementBinders.remove(binder) } }
    }
    rows(4).forEach { row ->
        val binder = row[0] as IBinder
        if (!binder.isBinderAlive) return@forEach
        val callback = row[1]!!
        activeCallbackBinders[binder] = CallbackRegistrationInfo(callback, row[2] as String, row[3] as Long)
        spoofedListenerInstances.add(callback)
        ensureCallbackHooked(callback, "onLocation")
        runCatching { ModuleBinderDeaths.watch(binder) { activeCallbackBinders.remove(binder) } }
    }
    rows(5).forEach { row -> activePendingIntents[row[0] as android.app.PendingIntent] = row[1] as String }
}

