@file:Suppress(
    "UNUSED_PARAMETER",
    "UNUSED_VARIABLE",
    "UNNECESSARY_NOT_NULL_ASSERTION",
    "DEPRECATION",
    "NAME_SHADOWING",
    "FunctionName",
    "PrivatePropertyName",
    "SpellCheckingInspection",
    "RedundantUnitReturnType",
    "RemoveRedundantQualifierName",
    "OPT_IN_USAGE",
    "unused",
    "UnusedImport"
)

package com.vincenthzr.locationspoofer.xposed.hooks.network

import com.vincenthzr.locationspoofer.xposed.utils.HookLog

import com.vincenthzr.locationspoofer.utils.ConfigKeys

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import com.vincenthzr.locationspoofer.xposed.LocationHooker
import com.vincenthzr.locationspoofer.xposed.utils.*
import org.json.JSONObject
import kotlin.random.Random
import io.github.libxposed.api.*

// 辅助函数：安全反射调用 onScanResult
internal fun LocationHooker.dispatchScanResultToCallback(callback: Any, scanResultObj: Any) {
        var dispatched = false
        var c: Class<*>? = callback.javaClass
        while (c != null && c != Any::class.java) {
            for (m in c.declaredMethods) {
                if (m.name == "onScanResult") {
                    if (m.parameterCount == 2) {
                        try {
                            m.isAccessible = true
                            m.invoke(callback, 1 /* CALLBACK_TYPE_ALL_MATCHES */, scanResultObj)
                            dispatched = true
                            break
                        } catch (e: Throwable) {
                            XposedBridge.log("[LocationSpoofer] dispatch onScanResult (2-args) direct error: ${e.cause ?: e}")
                        }
                    } else if (m.parameterCount == 1) {
                        try {
                            m.isAccessible = true
                            m.invoke(callback, scanResultObj)
                            dispatched = true
                            break
                        } catch (e: Throwable) {
                            XposedBridge.log("[LocationSpoofer] dispatch onScanResult (1-arg) direct error: ${e.cause ?: e}")
                        }
                    }
                }
            }
            if (dispatched) break
            c = c.superclass
        }
        if (!dispatched) {
            try {
                XposedHelpers.callMethod(callback, "onScanResult", 1, scanResultObj)
                dispatched = true
            } catch (_: Throwable) {
                try {
                    XposedHelpers.callMethod(callback, "onScanResult", scanResultObj)
                    dispatched = true
                } catch (t: Throwable) { HookLog.swallowed("BluetoothScanDispatcher.kt:630", t) }
            }
        }
        if (!dispatched) {
            try {
                val inner = XposedHelpers.getObjectField(callback, "mScanCallback") ?:
                            XposedHelpers.getObjectField(callback, "mCallback")
                if (inner != null) {
                    dispatchScanResultToCallback(inner, scanResultObj)
                }
            } catch (t: Throwable) { HookLog.swallowed("BluetoothScanDispatcher.kt:640", t) }
        }
    }

// 辅助函数：安全反射调用 onBatchScanResults
internal fun LocationHooker.dispatchBatchResultsToCallback(callback: Any, results: List<Any>) {
        var dispatched = false
        var c: Class<*>? = callback.javaClass
        while (c != null && c != Any::class.java) {
            for (m in c.declaredMethods) {
                if (m.name == "onBatchScanResults" && m.parameterCount == 1) {
                    try {
                        m.isAccessible = true
                        m.invoke(callback, results)
                        dispatched = true
                        break
                    } catch (t: Throwable) { HookLog.swallowed("BluetoothScanDispatcher.kt:656", t) }
                }
            }
            if (dispatched) break
            c = c.superclass
        }
        if (!dispatched) {
            try {
                XposedHelpers.callMethod(callback, "onBatchScanResults", results)
            } catch (t: Throwable) { HookLog.swallowed("BluetoothScanDispatcher.kt:665", t) }
        }
    }

// BLE 扫描结果伪造的核心分发逻辑
internal val syntheticBleDelivery = com.vincenthzr.locationspoofer.xposed.utils.CallScope<Boolean>()

internal fun LocationHooker.buildBleScanResults(config: JSONObject, cl: ClassLoader): List<Any> {
        if (!config.optBoolean(ConfigKeys.MOCK_BLUETOOTH, true)) return emptyList()
        val bluetoothArray = config.optJSONArray(ConfigKeys.BLUETOOTH_JSON_2) ?: return emptyList()
        if (bluetoothArray.length() == 0) return emptyList()

        val results = java.util.ArrayList<Any>()
        val targetScanRecordClass = XposedHelpers.findClassIfExists("android.bluetooth.le.ScanRecord", cl)
        val timestampNanos = SystemClock.elapsedRealtimeNanos()

        for (i in 0 until bluetoothArray.length()) {
            try {
                val obj = bluetoothArray.getJSONObject(i)
                val address = obj.optString(ConfigKeys.ADDRESS, "00:11:22:33:44:55")
                val name = obj.optString(ConfigKeys.NAME, "")
                val baseRssi = obj.optInt(ConfigKeys.RSSI, -60)
                val rssi = baseRssi + (if (config.optBoolean(ConfigKeys.ENABLE_JITTER, true)) Random.nextInt(-2, 3) else 0)
                val hexRecord = obj.optString(ConfigKeys.SCAN_RECORD_HEX, "")
                val rawBytes = buildScanRecordBytes(name, hexRecord, address)

                val device = createBluetoothDevice(cl, address)
                if (device == null) {
                    XposedBridge.log("[LocationSpoofer] 创建虚拟蓝牙设备失败 address=$address")
                    continue
                }

                var scanRecord: Any? = null
                if (targetScanRecordClass != null && rawBytes.isNotEmpty()) {
                    try {
                        scanRecord = XposedHelpers.callStaticMethod(targetScanRecordClass, "parseFromBytes", rawBytes)
                    } catch (e: Throwable) {
                        XposedBridge.log("[LocationSpoofer] ScanRecord.parseFromBytes 异常: $e")
                    }
                }

                val scanResultObj = createScanResult(cl, device, scanRecord, rssi, timestampNanos)
                if (scanResultObj != null) results.add(scanResultObj)
            } catch (e: Throwable) {
                XposedBridge.log("[LocationSpoofer] 构造虚拟BLE失败: $e")
            }
        }
        return results
    }

internal fun LocationHooker.deliverBleScanResults(config: JSONObject, callback: Any, cl: ClassLoader) {
        val results = buildBleScanResults(config, cl)
        if (results.isEmpty()) return
        val mainHandler = Handler(Looper.getMainLooper())
        for (result in results) {
            mainHandler.post {
                try {
                    syntheticBleDelivery.withValue(true) { dispatchScanResultToCallback(callback, result) }
                } catch (e: Throwable) {
                    XposedBridge.log("[LocationSpoofer] 派发 onScanResult 异常: $e")
                }
            }
        }
        mainHandler.post {
            try {
                syntheticBleDelivery.withValue(true) { dispatchBatchResultsToCallback(callback, results) }
            } catch (t: Throwable) { HookLog.swallowed("BluetoothScanDispatcher.kt:730", t) }
        }
    }

// 启动周期性定时广播模拟真实信标心跳 (约每 200ms 发送一次)
internal fun LocationHooker.startBleTimer(callback: Any, cl: ClassLoader) {
        bleScanTimers.remove(callback)?.cancel()
        val timer = java.util.Timer("LocationSpoofer-BleTimer", true)
        bleScanTimers[callback] = timer

        // 立即执行第一次
        val config = readConfig()
        if (config != null && config.optBoolean(ConfigKeys.ACTIVE, false) && config.optBoolean(ConfigKeys.MOCK_BLUETOOTH, true)) {
            deliverBleScanResults(config, callback, cl)
        }

        timer.schedule(object : java.util.TimerTask() {
            override fun run() {
                val cfg = readConfig()
                if (cfg == null || !cfg.optBoolean(ConfigKeys.ACTIVE, false) || !cfg.optBoolean(ConfigKeys.MOCK_BLUETOOTH, true)) {
                    cancel()
                    bleScanTimers.remove(callback)
                    return
                }
                deliverBleScanResults(cfg, callback, cl)
            }
        }, 200L, 200L)
    }

internal fun LocationHooker.deliverOldLeScanResults(config: JSONObject, callback: Any, cl: ClassLoader) {
        val mainHandler = Handler(Looper.getMainLooper())
        if (!config.optBoolean(ConfigKeys.MOCK_BLUETOOTH, true)) return
        val bluetoothArray = config.optJSONArray(ConfigKeys.BLUETOOTH_JSON_2) ?: return
        if (bluetoothArray.length() == 0) return

        for (i in 0 until bluetoothArray.length()) {
            try {
                val obj = bluetoothArray.getJSONObject(i)
                val address = obj.optString(ConfigKeys.ADDRESS, "00:11:22:33:44:55")
                val name = obj.optString(ConfigKeys.NAME, "")
                val baseRssi = obj.optInt(ConfigKeys.RSSI, -60)
                val rssi = baseRssi + (if (config.optBoolean(ConfigKeys.ENABLE_JITTER, true)) Random.nextInt(-2, 3) else 0)
                val hexRecord = obj.optString(ConfigKeys.SCAN_RECORD_HEX, "")
                val rawBytes = buildScanRecordBytes(name, hexRecord, address)

                val device = createBluetoothDevice(cl, address) ?: continue
                mainHandler.post {
                    try {
                        XposedHelpers.callMethod(callback, "onLeScan", device, rssi, rawBytes)
                    } catch (t: Throwable) { HookLog.swallowed("BluetoothScanDispatcher.kt:784", t) }
                }
            } catch (e: Throwable) {
                XposedBridge.log("[LocationSpoofer] 构造旧版LeScan失败: $e")
            }
        }
    }

internal fun LocationHooker.startOldLeScanTimer(callback: Any, cl: ClassLoader) {
        bleScanTimers.remove(callback)?.cancel()
        val timer = java.util.Timer("LocationSpoofer-OldBleTimer", true)
        bleScanTimers[callback] = timer

        val config = readConfig()
        if (config != null && config.optBoolean(ConfigKeys.ACTIVE, false) && config.optBoolean(ConfigKeys.MOCK_BLUETOOTH, true)) {
            deliverOldLeScanResults(config, callback, cl)
        }

        timer.schedule(object : java.util.TimerTask() {
            override fun run() {
                val cfg = readConfig()
                if (cfg == null || !cfg.optBoolean(ConfigKeys.ACTIVE, false) || !cfg.optBoolean(ConfigKeys.MOCK_BLUETOOTH, true)) {
                    cancel()
                    bleScanTimers.remove(callback)
                    return
                }
                deliverOldLeScanResults(cfg, callback, cl)
            }
        }, 200L, 200L)
    }
