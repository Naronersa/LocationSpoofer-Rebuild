package com.vincenthzr.locationspoofer.sensor

/**
 * global 系统级传感器 native 桥。
 *
 * 只在 system_server 中由 [GlobalSensorIntegration] 调用；native 侧通过
 * ShadowHook 优先拦截 libc `__sendto` 的 `svc` 指令，`sendto` 不可用时
 * 退回 `sendmsg`，按目标 UID 改写 STEP_COUNTER / STEP_DETECTOR /
 * ACCELEROMETER 等事件。
 */
internal object SystemAccelNative {

    external fun nativeSetProfile(
        svcOffset: Int,
        ctorOffset: Int,
        pltOffset: Int,
        bitTubeOffset: Int,
        bitTubeFdOffset: Int,
        uidOffset: Int,
        force: Boolean
    ): Boolean

    external fun nativeSetEventLayout(stride: Int): Boolean

    external fun nativeInit(targetUids: IntArray, allApps: Boolean): Boolean

    external fun nativeConfigure(
        targetUids: IntArray,
        allApps: Boolean,
        speedMps: Double,
        cadenceSpm: Int,
        stepDetectorHandle: Int,
        stepCounterHandle: Int,
        accelerometerHandle: Int,
        realismLevel: Int,
        fluctuationPct: Int,
        active: Boolean,
        stepSimulation: Boolean,
        accelerometerSimulation: Boolean,
        gaitTemplate: String
    ): Boolean

    external fun nativeSetClockStart(startTimestampMs: Long): Boolean

    external fun nativeSetCompassHeading(
        trueHeadingDeg: Double,
        declinationDeg: Double,
        accuracyDeg: Double,
        horizontalUt: Double,
        verticalUt: Double,
        enabled: Boolean
    ): Boolean

    external fun nativeConfigurePressure(
        altitudeM: Double,
        altitudeVariationM: Double,
        latitude: Double,
        longitude: Double,
        driftM: Double,
        seaLevelHpa: Double,
        enabled: Boolean
    ): Boolean

    /**
     * 仅供 native/Kotlin 一致性自检：返回 [MotionRealism.SmoothNoise] 的 value/integral。
     * 不参与传感器改写逻辑。
     */
    external fun nativeNoiseProbe(
        seed: Long,
        minPeriodSec: Double,
        maxPeriodSec: Double,
        tSec: Double
    ): DoubleArray

    /**
     * 仅供 native/Kotlin 一致性自检：返回 6 个姿态分量和 3 轴角速度。
     * 不参与传感器改写逻辑。
     */
    external fun nativeMotionProbe(
        stepsFloat: Double,
        speedMps: Double,
        cadenceSpm: Int,
        trueHeadingDeg: Double,
        declinationDeg: Double,
        yawRateRad: Double,
        realismLevel: Int,
        seed: Long,
        timeSec: Double
    ): DoubleArray

    /** 仅供 native/Kotlin 一致性自检：返回标准大气压公式结果。 */
    external fun nativePressureProbe(
        altitudeM: Double,
        seaLevelHpa: Double,
        timeSec: Double
    ): Double

    /** 仅供 native/Kotlin 一致性自检：返回地形 + 漂移后的模拟海拔。 */
    external fun nativeAltitudeProbe(
        baseM: Double,
        variationM: Double,
        driftM: Double,
        lat: Double,
        lng: Double,
        epochMs: Long
    ): Double

    /** 仅供 native/Kotlin 一致性自检：返回 speed/distance/cadence/steps。 */
    external fun nativeMotionSessionProbe(
        seed: Long,
        levelId: Int,
        fluctuationPct: Int,
        baseSpeedMps: Double,
        baseCadenceSpm: Double,
        elapsedSec: Double
    ): DoubleArray

    /** 仅供 native/Kotlin 一致性自检：返回不含噪声的程序化步态 x/y/z。 */
    external fun nativeProceduralGaitProbe(
        stepsFloat: Double,
        speedMps: Double,
        strength: Double
    ): DoubleArray

    /** 仅供 native/Kotlin 一致性自检：返回录制步态模板在指定相位/力度下的 x/y/z。 */
    external fun nativeGaitTemplateProbe(
        encoded: String,
        stridePhase: Double,
        strength: Double
    ): DoubleArray

    /** 仅供 native/Kotlin 一致性自检：返回 GyroMotion 三轴角速度。 */
    external fun nativeGyroProbe(
        stepsFloat: Double,
        cadenceSpm: Int,
        speedMps: Double,
        realismLevel: Int,
        fluctuationPct: Int,
        startTimestampMs: Long,
        yawRateRad: Double,
        elapsedSec: Double
    ): DoubleArray

    /**
     * 仅供 native 快照自检：返回指南针 7 类事件被改写后的值。
     * 顺序：heading(2)、orientation(3)、magnetic(3)、uncalibrated(6)、
     * rotation(5)、game(5)、geomagnetic(5)。
     */
    external fun nativeCompassProbe(
        stepsFloat: Double,
        speedMps: Double,
        cadenceSpm: Int,
        trueHeadingDeg: Double,
        declinationDeg: Double,
        yawRateRad: Double,
        realismLevel: Int,
        seed: Long,
        timeSec: Double,
        accuracyDeg: Double,
        fieldValid: Boolean,
        horizontalUt: Double,
        verticalUt: Double
    ): DoubleArray

    external fun nativeStatus(): String
}
