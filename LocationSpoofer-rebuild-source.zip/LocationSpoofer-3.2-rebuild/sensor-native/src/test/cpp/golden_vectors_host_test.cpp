// Host-side golden-vector regression test for the pure math in location_accel.cpp.
//
// Build/run (Linux/macOS/MinGW):
//   g++ -std=c++17 -O2 -I ../../main/cpp \
//       golden_vectors_host_test.cpp -o golden_vectors_host_test
//   ./golden_vectors_host_test
// Or: ./run_host_golden_vectors.sh
//
// This file intentionally includes the production .cpp rather than copying math
// code, so a formula change is tested against the same implementation shipped
// in liblocation_accel.so. Keep the expected values in sync with
// core-geo MotionGoldenVectors / CompassGoldenVectors.

#define LOCATION_ACCEL_HOST_TEST
#include "location_accel.cpp"

#include <cstdio>
#include <cstdlib>
#include <limits>

namespace {

int g_failures = 0;
int g_checks = 0;

void check(const char* name, double actual, double expected, double tolerance) {
  ++g_checks;
  if (std::fabs(actual - expected) > tolerance * (1.0 + std::fabs(expected))) {
    ++g_failures;
    std::printf("FAIL %s: expected %.17g actual %.17g\n", name, expected, actual);
  }
}

void checkArray(const char* name, const double* actual, const double* expected,
                int count, double tolerance) {
  for (int i = 0; i < count; ++i) {
    char label[128];
    std::snprintf(label, sizeof(label), "%s[%d]", name, i);
    check(label, actual[i], expected[i], tolerance);
  }
}

}  // namespace

int main() {
  constexpr double kTol = 1e-9;

  const Attitude attitude = computeAttitude(
      12.5, 3.0, 160, 90.0, -5.0, 0.1, 3, 123456789ULL, 42.0);
  const double expectedAttitude[6] = {
      1.668275986987822, 0.003695750168121, 0.034322105111358,
      -0.935500169441147, -0.214777230445939, 0.104959909394808,
  };
  const double actualAttitude[6] = {
      attitude.yawMagneticRad, attitude.pitchRad, attitude.rollRad,
      attitude.pitchRateRad, attitude.rollRateRad, attitude.yawRateRad,
  };
  checkArray("attitude", actualAttitude, expectedAttitude, 6, kTol);

  const Quat qNow = quatFromYawPitchRoll(
      -attitude.yawMagneticRad, attitude.pitchRad, attitude.rollRad);
  constexpr double kProbeGyroDtSec = 0.01;
  const Quat qPrev = quatFromYawPitchRoll(
      -(attitude.yawMagneticRad - attitude.yawRateRad * kProbeGyroDtSec),
      attitude.pitchRad - attitude.pitchRateRad * kProbeGyroDtSec,
      attitude.rollRad - attitude.rollRateRad * kProbeGyroDtSec);
  float bodyGyro[3] = {0.0f, 0.0f, 0.0f};
  bodyAngularVelocity(qNow, qPrev, kProbeGyroDtSec, bodyGyro);
  const double expectedQuaternion[4] = {
      0.011469600014435, 0.012897043011643, -0.740628646998153, 0.671692877588225,
  };
  const double actualQuaternion[4] = {qNow.x, qNow.y, qNow.z, qNow.w};
  checkArray("quaternion", actualQuaternion, expectedQuaternion, 4, kTol);
  const double expectedBodyGyro[3] = {
      0.938624913701506, -0.21389596518505, -0.07178456687313,
  };
  const double actualBodyGyro[3] = {bodyGyro[0], bodyGyro[1], bodyGyro[2]};
  checkArray("body-gyro", actualBodyGyro, expectedBodyGyro, 3, 1e-4);

  const SmoothNoise speedNoise = makeNoise(123456789ULL ^ 0x5EED5EEDULL, 20.0, 600.0);
  const SmoothNoise cadenceNoise = makeNoise(123456789ULL ^ 0x0CADE0CEULL, 3.0, 60.0);
  const double session[4] = {
      sessionSpeedValue(1.4, 0.10, speedNoise, 42.0),
      sessionDistanceValue(1.4, 0.10, speedNoise, 42.0),
      sessionCadenceValue(165.0, 0.10, kLevels[2], speedNoise, cadenceNoise, 42.0),
      sessionStepsDelta(165.0, 0.10, kLevels[2], 42.0,
                        noiseIntegral(speedNoise, 42.0),
                        noiseIntegral(cadenceNoise, 42.0)),
  };
  const double expectedSession[4] = {
      1.458289305460823, 59.83574874844371, 168.85230013247025,
      116.50615967189279,
  };
  checkArray("motion-session", session, expectedSession, 4, kTol);

  const double gaitInputs[3][3] = {{12.5, 1.4, 1.0}, {12.5, 3.0, 1.18}, {12.75, 0.8, 0.9}};
  const double expectedGait[3][3] = {
      {0.408, 0.26516593, 10.72166},
      {1.4868, -0.15749393, 3.4805167},
      {0.2138292, -0.11666048, 8.349104},
  };
  for (int c = 0; c < 3; ++c) {
    const double step = std::floor(gaitInputs[c][0]);
    float gait[3] = {0.0f, 0.0f, 0.0f};
    proceduralGait(gaitInputs[c][0] - step, gaitInputs[c][0],
                   static_cast<int64_t>(step), gaitInputs[c][1], gaitInputs[c][2], gait);
    const double actual[3] = {gait[0], gait[1], gait[2]};
    char name[32];
    std::snprintf(name, sizeof(name), "gait[%d]", c);
    checkArray(name, actual, expectedGait[c], 3, 1e-5);
  }

  struct GyroCase {
    double stepsFloat;
    int cadence;
    double speed;
    int realism;
    int fluctuation;
    uint64_t startMs;
    double yawRate;
    double elapsed;
    double expected[3];
  };
  const GyroCase gyroCases[3] = {
      {12.5, 165, 1.4, 3, 10, 1794273414385ULL, 0.0, 42.0,
       {0.09114537, -0.06441797, 0.011112517}},
      {40.25, 180, 3.0, 2, 20, 1700000000000ULL, 0.2, 12.3,
       {-0.059593584, -0.091861874, -0.05338922}},
      {0.25, 160, 0.0, 3, 10, 1234567890ULL, 0.0, 1.0, {0.0, 0.0, 0.0}},
  };
  for (int c = 0; c < 3; ++c) {
    float gyro[3] = {0.0f, 0.0f, 0.0f};
    gyroSample(gyroCases[c].stepsFloat, gyroCases[c].cadence, gyroCases[c].speed,
               gyroCases[c].realism, gyroCases[c].fluctuation, gyroCases[c].startMs,
               gyroCases[c].yawRate, gyroCases[c].elapsed, gyro);
    const double actual[3] = {gyro[0], gyro[1], gyro[2]};
    char name[32];
    std::snprintf(name, sizeof(name), "gyro[%d]", c);
    checkArray(name, actual, gyroCases[c].expected, 3, 1e-5);
  }

  const SmoothNoise goldenNoise = makeNoise(0x5EED5EEDULL, 20.0, 600.0);
  const double expectedNoise[2] = {-0.5523465818745603, -7.111830048027774};
  const double actualNoise[2] = {noiseValue(goldenNoise, 42.0),
                                 noiseIntegral(goldenNoise, 42.0)};
  checkArray("noise", actualNoise, expectedNoise, 2, kTol);

  check("pressure", pressureAt(25.0, 1013.25, 42.0), 1010.5256744380252, kTol);

  // AltitudeModel 纯移植：与 Kotlin AltitudeGoldenVectors.CASES 相同输入/输出。
  {
    Terrain terrain;
    bool terrainReady = false;
    double terrainAmp = 0.0;
    const SmoothNoise driftNoise = makeNoise(kDriftSeed, 30.0, 400.0);
    const double expectedAlt[4] = {
        44.291905274343215, 49.20748889152187,
        59.02513536122058, 46.16960776373187};
    const double actualAlt[4] = {
        altitudeValue(50.0, 20.0, 3.0, 23.1066, 113.3245,
                      1789398037217LL, terrain, terrainReady, terrainAmp,
                      driftNoise),
        altitudeValue(50.0, 20.0, 3.0, 30.0012, 120.0012,
                      1789398037217LL, terrain, terrainReady, terrainAmp,
                      driftNoise),
        altitudeValue(50.0, 100.0, 5.0, 30.0012, 120.0012,
                      1789398037217LL, terrain, terrainReady, terrainAmp,
                      driftNoise),
        altitudeValue(50.0, 10.0, 0.0, 30.0, 120.0,
                      0LL, terrain, terrainReady, terrainAmp, driftNoise)};
    checkArray("altitude", actualAlt, expectedAlt, 4, 1e-9);
  }

  // 录制步态模板：用与 Kotlin goldenGaitTemplate() 相同的 64 点数组，
  // 按 GaitTemplate.encode() 的三位小数格式编码后，验证 native parse+sample。
  std::string encodedGait = "v1;165;4";
  for (int axis = 0; axis < 3; ++axis) {
    encodedGait += ';';
    for (int i = 0; i < 64; ++i) {
      const float value = axis == 0
          ? static_cast<float>(((i * 7) % 17 - 8) / 10.0)
          : axis == 1
              ? static_cast<float>(((i * 11) % 19 - 9) / 10.0)
              : 9.8f + static_cast<float>(((i * 13) % 23 - 11) / 20.0);
      char cell[32];
      std::snprintf(cell, sizeof(cell), i == 0 ? "%.3f" : ",%.3f",
                    static_cast<double>(value));
      encodedGait += cell;
    }
  }
  const auto parsedTemplate = parseGait(encodedGait);
  if (parsedTemplate == nullptr) {
    std::printf("FAIL gait-template: parseGait returned null\n");
    ++g_failures;
  } else {
    float sampled[3] = {0.0f, 0.0f, 0.0f};
    sampleGait(*parsedTemplate, 0.37, 1.1, sampled);
    const double expectedTemplate[3] = {0.5235999822616577, 0.49326878786087036,
                                        9.68143367767334};
    const double actualTemplate[3] = {sampled[0], sampled[1], sampled[2]};
    checkArray("gait-template", actualTemplate, expectedTemplate, 3, 1e-5);
  }

  const double expectedCompassValid[29] = {
      90.58517456054688, 4.6482954025268555,
      95.58517456054688, 0.21175087988376617, 1.9665117263793945,
      -21.506006240844727, -2.145908832550049, -35.85377883911133,
      -21.506006240844727, -2.145908832550049, -35.85377883911133,
      -0.3168407380580902, -0.08234403282403946, -0.1638474017381668,
      0.011469599790871143, 0.01289704255759716, -0.7406286597251892,
      0.6716928482055664, 0.08112805336713791,
      0.011469599790871143, 0.01289704255759716, -0.7406286597251892,
      0.6716928482055664,
      0.0,
      0.011469599790871143, 0.01289704255759716, -0.7406286597251892,
      0.6716928482055664,
      0.0,
  };
  const double expectedCompassFallback[29] = {
      90.58517456054688, 4.6482954025268555,
      95.58517456054688, 0.21175087988376617, 1.9665117263793945,
      -23.598949432373047, -2.3729147911071777, 28.99286651611328,
      -23.598949432373047, -2.3729147911071777, 28.99286651611328,
      -0.3168407380580902, -0.08234403282403946, -0.1638474017381668,
      0.011469599790871143, 0.01289704255759716, -0.7406286597251892,
      0.6716928482055664, 0.08112805336713791,
      0.011469599790871143, 0.01289704255759716, -0.7406286597251892,
      0.6716928482055664,
      0.0,
      0.011469599790871143, 0.01289704255759716, -0.7406286597251892,
      0.6716928482055664,
      0.0,
  };
  const auto compass = [&](bool fieldValid, double out[29]) {
    int offset = 0;
    const auto run = [&](int32_t type, int count) {
      SensorsEvent event{};
      event.type = type;
      event.u.data[0] = 10.0f;
      event.u.data[1] = 20.0f;
      event.u.data[2] = 30.0f;
      rewriteCompassEvent(event, 90.0, -5.0, 5.0, fieldValid, 22.5, 35.0,
                          attitude, 123456789ULL, 42.0);
      for (int i = 0; i < count; ++i) out[offset++] = event.u.data[i];
    };
    run(kTypeHeading, 2);
    run(kTypeOrientation, 3);
    run(kTypeMagneticField, 3);
    run(kTypeMagneticFieldUncalibrated, 6);
    run(kTypeRotationVector, 5);
    run(kTypeGameRotationVector, 5);
    run(kTypeGeomagneticRotationVector, 5);
  };
  double compassValid[29];
  double compassFallback[29];
  compass(true, compassValid);
  compass(false, compassFallback);
  checkArray("compass-valid", compassValid, expectedCompassValid, 29, 1e-5);
  checkArray("compass-fallback", compassFallback, expectedCompassFallback, 29, 1e-5);

  // Edge cases: stationary/driving attitude collapses to heading only.
  for (double edgeSpeed : {0.0, 7.1}) {
    const Attitude edge = computeAttitude(
        12.5, edgeSpeed, 160, 90.0, -5.0, 0.1, 3, 123456789ULL, 42.0);
    const double expectedYaw = 95.0 * kPi / 180.0;
    check("edge-attitude-yaw", edge.yawMagneticRad, expectedYaw, kTol);
    check("edge-attitude-pitch", edge.pitchRad, 0.0, kTol);
    check("edge-attitude-roll", edge.rollRad, 0.0, kTol);
    check("edge-attitude-pitch-rate", edge.pitchRateRad, 0.0, kTol);
    check("edge-attitude-roll-rate", edge.rollRateRad, 0.0, kTol);
    check("edge-attitude-yaw-rate", edge.yawRateRad, 0.0, kTol);
  }

  // Cadence clamping: 1 vs 60 and 999 vs 240 must be identical.
  {
    const Attitude lowA = computeAttitude(
        12.5, 1.4, 1, 90.0, -5.0, 0.1, 3, 123456789ULL, 42.0);
    const Attitude lowB = computeAttitude(
        12.5, 1.4, 60, 90.0, -5.0, 0.1, 3, 123456789ULL, 42.0);
    const double a[6] = {lowA.yawMagneticRad, lowA.pitchRad, lowA.rollRad,
                         lowA.pitchRateRad, lowA.rollRateRad, lowA.yawRateRad};
    const double b[6] = {lowB.yawMagneticRad, lowB.pitchRad, lowB.rollRad,
                         lowB.pitchRateRad, lowB.rollRateRad, lowB.yawRateRad};
    checkArray("cadence-low-clamp", a, b, 6, kTol);
    const Attitude highA = computeAttitude(
        12.5, 1.4, 999, 90.0, -5.0, 0.1, 3, 123456789ULL, 42.0);
    const Attitude highB = computeAttitude(
        12.5, 1.4, 240, 90.0, -5.0, 0.1, 3, 123456789ULL, 42.0);
    const double c[6] = {highA.yawMagneticRad, highA.pitchRad, highA.rollRad,
                         highA.pitchRateRad, highA.rollRateRad, highA.yawRateRad};
    const double d[6] = {highB.yawMagneticRad, highB.pitchRad, highB.rollRad,
                         highB.pitchRateRad, highB.rollRateRad, highB.yawRateRad};
    checkArray("cadence-high-clamp", c, d, 6, kTol);
  }

  // Invalid/zero horizontal field falls back to the raw 10/20/30 µT path.
  {
    SensorsEvent heading{};
    heading.type = kTypeHeading;
    rewriteCompassEvent(heading, 90.0, -5.0, 0.0, true, 0.0, 35.0,
                        attitude, 123456789ULL, 42.0);
    check("zero-accuracy-heading", heading.u.data[1], 0.0, 1e-6);
    SensorsEvent rotation{};
    rotation.type = kTypeRotationVector;
    rewriteCompassEvent(rotation, 90.0, -5.0, 0.0, true, 0.0, 35.0,
                        attitude, 123456789ULL, 42.0);
    check("zero-accuracy-rotation", rotation.u.data[4], 0.0, 1e-6);
    double zeroField[29];
    int offset = 0;
    const auto runZeroField = [&](int32_t type, int count) {
      SensorsEvent event{};
      event.type = type;
      event.u.data[0] = 10.0f;
      event.u.data[1] = 20.0f;
      event.u.data[2] = 30.0f;
      rewriteCompassEvent(event, 90.0, -5.0, 5.0, true, 0.0, 35.0,
                          attitude, 123456789ULL, 42.0);
      for (int i = 0; i < count; ++i) zeroField[offset++] = event.u.data[i];
    };
    runZeroField(kTypeHeading, 2);
    runZeroField(kTypeOrientation, 3);
    runZeroField(kTypeMagneticField, 3);
    runZeroField(kTypeMagneticFieldUncalibrated, 6);
    runZeroField(kTypeRotationVector, 5);
    runZeroField(kTypeGameRotationVector, 5);
    runZeroField(kTypeGeomagneticRotationVector, 5);
    checkArray("zero-field-fallback", zeroField, expectedCompassFallback, 29, 1e-5);
  }

  // Gyro invalid speed must fail closed to zeros.
  {
    float edgeGyro[3] = {1.0f, 1.0f, 1.0f};
    gyroSample(1.0, 165, std::numeric_limits<double>::quiet_NaN(),
               3, 10, 1ULL, 0.0, 1.0, edgeGyro);
    check("gyro-nan-speed", edgeGyro[0], 0.0, 0.0);
    check("gyro-nan-speed-y", edgeGyro[1], 0.0, 0.0);
    check("gyro-nan-speed-z", edgeGyro[2], 0.0, 0.0);
  }

  // OFF level with zero fluctuation is exact constant motion.
  {
    const SmoothNoise offNoise = makeNoise(123ULL, 20.0, 600.0);
    const LevelParams off = kLevels[0];
    check("off-speed", sessionSpeedValue(1.4, 0.0, offNoise, 12.0), 1.4, kTol);
    check("off-distance", sessionDistanceValue(1.4, 0.0, offNoise, 12.0), 16.8, kTol);
    check("off-cadence",
          sessionCadenceValue(165.0, 0.0, off, offNoise, offNoise, 12.0), 165.0, kTol);
    check("off-steps",
          sessionStepsDelta(165.0, 0.0, off, 12.0, 0.0, 0.0), 33.0, kTol);
  }

  // Event-batch integration: exercise the same rewriteEventBatch used by
  // __sendto, with a deterministic session clock. This is a structural test
  // (step counter advances, accel/compass/gyro are rewritten) rather than a
  // byte-for-byte snapshot because gyro noise uses the production RNG.
  {
    const int64_t now = nowNanos();
    g_config = Config{};
    g_config.targetUids = {12345};
    g_config.allApps = false;
    g_config.active = true;
    g_config.speedMps = 1.4;
    g_config.cadenceSpm = 0;
    g_config.realismLevel = 2;
    g_config.fluctuationPct = 10;
    g_config.stepSimulation = true;
    g_config.accelerometerSimulation = true;
    g_config.compassSimulation = true;
    g_config.compassHeadingValid = true;
    g_config.compassHeadingAtNs = now;
    g_config.compassTrueHeadingDeg = 90.0;
    g_config.compassDeclinationDeg = -5.0;
    g_config.compassAccuracyDeg = 5.0;
    g_config.compassFieldValid = true;
    g_config.compassHorizontalUt = 22.5;
    g_config.compassVerticalUt = 35.0;
    g_event_stride.store(sizeof(SensorsEvent));
    g_clock_origin_ns = now - 10'000'000'000LL;
    g_clock_base_steps = 1000.0;
    g_counter_base_captured = true;
    g_session_start_ns = g_clock_origin_ns;
    g_session_start_configured = true;
    g_noise_seed = 123456789ULL;
    g_noise_ready = false;
    g_gait.reset();
    g_rng.seed(0x5EED);

    SensorsEvent events[4]{};
    for (auto& event : events) {
      event.version = static_cast<int32_t>(sizeof(SensorsEvent));
      event.timestamp = now;
    }
    events[0].type = kTypeStepCounter;
    events[0].u.step_counter = 1000;
    events[1].type = kTypeAccelerometer;
    events[2].type = kTypeHeading;
    events[3].type = kTypeGyroscope;
    const bool changed = rewriteEventBatch(
        events, sizeof(events), 10, 12345, 123456);
    if (!changed) {
      std::printf("FAIL event-batch: no event changed\n");
      ++g_failures;
    }
    ++g_checks;
    if (events[0].u.step_counter <= 1000) {
      std::printf("FAIL event-batch: step counter did not advance (%llu)\n",
                  static_cast<unsigned long long>(events[0].u.step_counter));
      ++g_failures;
    }
    ++g_checks;
    if (!(std::isfinite(events[1].u.data[0]) &&
          std::isfinite(events[1].u.data[1]) &&
          std::isfinite(events[1].u.data[2]))) {
      std::printf("FAIL event-batch: accelerometer non-finite\n");
      ++g_failures;
    }
    ++g_checks;
    if (!(events[2].u.data[0] >= 0.0f && events[2].u.data[0] < 360.0f &&
          events[2].u.data[1] > 0.0f)) {
      std::printf("FAIL event-batch: heading not rewritten (%.3f, %.3f)\n",
                  events[2].u.data[0], events[2].u.data[1]);
      ++g_failures;
    }
    ++g_checks;
    if (events[3].u.data[0] == 0.0f && events[3].u.data[1] == 0.0f &&
        events[3].u.data[2] == 0.0f) {
      std::printf("FAIL event-batch: gyro not rewritten\n");
      ++g_failures;
    }
    ++g_checks;
    g_config.active = false;
  }

  if (g_failures == 0) {
    std::printf("golden vectors: ok (%d checks)\n", g_checks);
    return 0;
  }
  std::printf("golden vectors: %d/%d checks failed\n", g_failures, g_checks);
  return 1;
}
