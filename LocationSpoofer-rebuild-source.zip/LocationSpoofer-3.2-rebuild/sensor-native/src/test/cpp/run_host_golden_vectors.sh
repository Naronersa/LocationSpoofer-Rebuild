#!/usr/bin/env bash
# Host-side golden-vector test (Linux/macOS/MinGW). No Android SDK/emulator needed.
set -euo pipefail

cd "$(dirname "$0")"
tmp_dir="$(mktemp -d)"
trap 'rm -rf "$tmp_dir"' EXIT

cxx="${CXX:-g++}"
"$cxx" -std=c++17 -O2 -I ../../main/cpp \
    golden_vectors_host_test.cpp -o "$tmp_dir/golden_vectors_host_test"
"$tmp_dir/golden_vectors_host_test"
