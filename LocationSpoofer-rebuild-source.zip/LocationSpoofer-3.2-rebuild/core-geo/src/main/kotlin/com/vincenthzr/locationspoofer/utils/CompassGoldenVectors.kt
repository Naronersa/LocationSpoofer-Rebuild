package com.vincenthzr.locationspoofer.utils

/**
 * 指南针/磁场的固定输入与期望输出。
 *
 * [NATIVE_*] 是 global native 侧 7 类事件的完整改写快照；[FLAT_*] 是
 * scoped/Kotlin `CompassMath` 水平设备模型的基准。
 */
object CompassGoldenVectors {
    const val TRUE_HEADING_DEG = 90.0
    const val DECLINATION_DEG = -5.0
    const val ACCURACY_DEG = 5.0
    const val HORIZONTAL_UT = 22.5
    const val VERTICAL_UT = 35.0

    // 与 MotionGoldenVectors 相同的姿态输入，保证 compass 与 attitude 同源。
    const val STEPS_FLOAT = MotionGoldenVectors.STEPS_FLOAT
    const val SPEED_MPS = MotionGoldenVectors.SPEED_MPS
    const val CADENCE_SPM = MotionGoldenVectors.CADENCE_SPM
    const val YAW_RATE_RAD = MotionGoldenVectors.YAW_RATE_RAD
    const val REALISM_LEVEL = MotionGoldenVectors.REALISM_LEVEL
    const val SEED = MotionGoldenVectors.SEED
    const val TIME_SEC = MotionGoldenVectors.TIME_SEC

    /**
     * heading(2), orientation(3), magnetic(3), uncalibrated(6),
     * rotation(5), game(5), geomagnetic(5)。
     */
    val NATIVE_VALID_FIELD = doubleArrayOf(
        90.58517456054688, 4.6482954025268555,
        95.58517456054688, 0.21175087988376617, 1.9665117263793945,
        -21.506006240844727, -2.145908832550049, -35.85377883911133,
        -21.506006240844727, -2.145908832550049, -35.85377883911133,
        -0.3168407380580902, -0.08234403282403946, -0.1638474017381668,
        0.011469599790871143, 0.01289704255759716,
        -0.7406286597251892, 0.6716928482055664, 0.08112805336713791,
        0.011469599790871143, 0.01289704255759716,
        -0.7406286597251892, 0.6716928482055664,
        0.0,
        0.011469599790871143, 0.01289704255759716,
        -0.7406286597251892, 0.6716928482055664,
        0.0,
    )

    /** fieldValid=false 时用真实事件的 10/20/30 µT 原始值做安全限幅。 */
    val NATIVE_FALLBACK_FIELD = doubleArrayOf(
        90.58517456054688, 4.6482954025268555,
        95.58517456054688, 0.21175087988376617, 1.9665117263793945,
        -23.598949432373047, -2.3729147911071777, 28.99286651611328,
        -23.598949432373047, -2.3729147911071777, 28.99286651611328,
        -0.3168407380580902, -0.08234403282403946, -0.1638474017381668,
        0.011469599790871143, 0.01289704255759716,
        -0.7406286597251892, 0.6716928482055664, 0.08112805336713791,
        0.011469599790871143, 0.01289704255759716,
        -0.7406286597251892, 0.6716928482055664,
        0.0,
        0.011469599790871143, 0.01289704255759716,
        -0.7406286597251892, 0.6716928482055664,
        0.0,
    )

    val FLAT_MAGNETIC_UT = floatArrayOf(-22.414381f, -1.9610043f, 35.0f)
    val FLAT_ROTATION_VECTOR = floatArrayOf(0.0f, 0.0f, -0.7372773f, 0.6755902f)
    const val FLAT_ACCURACY_RAD = 0.08726646f
    const val SHORTEST_DELTA_DEG = 20.0
}
