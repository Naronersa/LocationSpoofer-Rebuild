package com.vincenthzr.locationspoofer.utils

/**
 * 运动/姿态/步态/气压的固定输入与期望输出。
 *
 * 同一组常量用于 Kotlin 单测和 native 运行时自检；修改真实度公式时必须同步
 * 更新这里的期望值，避免 Kotlin 与 native 的真实度模型悄然漂移。
 */
object MotionGoldenVectors {
    const val STEPS_FLOAT = 12.5
    const val SPEED_MPS = 3.0
    const val CADENCE_SPM = 160
    const val TRUE_HEADING_DEG = 90.0
    const val DECLINATION_DEG = -5.0
    const val YAW_RATE_RAD = 0.1
    const val REALISM_LEVEL = 3
    const val SEED = 123456789L
    const val TIME_SEC = 42.0

    /** yaw, pitch, roll, pitchRate, rollRate, yawRate（弧度或 rad/s）。 */
    val ATTITUDE = doubleArrayOf(
        1.668275986987822,
        0.003695750168121,
        0.034322105111358,
        -0.935500169441147,
        -0.214777230445939,
        0.104959909394808,
    )

    /** x, y, z, w。 */
    val QUATERNION = doubleArrayOf(
        0.011469600014435,
        0.012897043011643,
        -0.740628646998153,
        0.671692877588225,
    )

    /** body x, y, z（rad/s）。 */
    val GYRO = doubleArrayOf(
        0.938624913701506,
        -0.21389596518505,
        -0.07178456687313,
    )

    const val PRESSURE_ALTITUDE_M = 25.0
    const val PRESSURE_SEA_LEVEL_HPA = 1013.25
    const val PRESSURE_TIME_SEC = 42.0
    const val PRESSURE_HPA = 1010.5256744380252

    // ------------------------------------------------------------ 速度/步频/步数

    const val SESSION_SEED = 123456789L
    const val SESSION_LEVEL_ID = 2
    const val SESSION_FLUCTUATION_PCT = 10
    const val SESSION_BASE_SPEED_MPS = 1.4
    const val SESSION_BASE_CADENCE_SPM = 165.0
    const val SESSION_ELAPSED_SEC = 42.0

    /** speed, distance, cadence, steps. */
    val SESSION_EXPECTED = doubleArrayOf(
        1.458289305460823,
        59.83574874844371,
        168.85230013247025,
        116.50615967189279,
    )

    // ------------------------------------------------------------ 程序化步态

    data class GaitCase(
        val stepsFloat: Double,
        val speedMps: Double,
        val strength: Double,
        val expected: FloatArray,
    )

    val GAIT_CASES = listOf(
        GaitCase(12.5, 1.4, 1.0, floatArrayOf(0.408f, 0.26516593f, 10.72166f)),
        GaitCase(12.5, 3.0, 1.18, floatArrayOf(1.4868f, -0.15749393f, 3.4805167f)),
        GaitCase(12.75, 0.8, 0.9, floatArrayOf(0.2138292f, -0.11666048f, 8.349104f)),
    )

    // ------------------------------------------------------------ 录制步态模板

    const val GAIT_TEMPLATE_PHASE = 0.37
    const val GAIT_TEMPLATE_STRENGTH = 1.1

    /**
     * 64 点合成模板。运行时先用 [GaitTemplate.encode] 再 decode，确保 native
     * 解析的是与 Kotlin 完全相同的三位小数文本。
     */
    fun goldenGaitTemplate(): GaitTemplate = GaitTemplate(
        FloatArray(64) { i -> ((i * 7) % 17 - 8) / 10.0f },
        FloatArray(64) { i -> ((i * 11) % 19 - 9) / 10.0f },
        FloatArray(64) { i -> 9.8f + ((i * 13) % 23 - 11) / 20.0f },
        165,
        4,
    )

    val GAIT_TEMPLATE_SAMPLE = floatArrayOf(
        0.5235999822616577f,
        0.49326878786087036f,
        9.68143367767334f,
    )

    // ------------------------------------------------------------ 陀螺仪

    data class GyroCase(
        val stepsFloat: Double,
        val cadenceSpm: Int,
        val speedMps: Double,
        val realismLevel: Int,
        val fluctuationPct: Int,
        val startTimestampMs: Long,
        val yawRateRad: Double,
        val elapsedSec: Double,
        val expected: FloatArray,
    )

    val GYRO_CASES = listOf(
        GyroCase(
            12.5, 165, 1.4, 3, 10, 1_794_273_414_385L, 0.0, 42.0,
            floatArrayOf(0.09114537f, -0.06441797f, 0.011112517f),
        ),
        GyroCase(
            40.25, 180, 3.0, 2, 20, 1_700_000_000_000L, 0.2, 12.3,
            floatArrayOf(-0.059593584f, -0.091861874f, -0.05338922f),
        ),
        GyroCase(
            0.25, 160, 0.0, 3, 10, 1_234_567_890L, 0.0, 1.0,
            floatArrayOf(0f, 0f, 0f),
        ),
    )
}
