package com.vincenthzr.locationspoofer.utils

/** GNSS 质量模型的固定输入与期望输出（Kotlin 纯函数）。 */
object GnssGoldenVectors {
    const val START_TIMESTAMP_MS = 123456789L
    const val REALISM_LEVEL = 2
    const val CONFIGURED_SATELLITES = 20
    const val NOW_MS = START_TIMESTAMP_MS + 42_000L
    const val SVID = 7
    const val SPEED_MPS = 1.4

    /** accuracy, used, hdop, vdop, pdop, degradation, pseudorangeRate, multipath. */
    val EXPECTED = doubleArrayOf(
        2.320281644313968,
        15.0,
        1.054641173765304,
        1.4215605163336127,
        1.4237655845831607,
        0.0,
        64.532319528115,
        2.0,
    )
}
