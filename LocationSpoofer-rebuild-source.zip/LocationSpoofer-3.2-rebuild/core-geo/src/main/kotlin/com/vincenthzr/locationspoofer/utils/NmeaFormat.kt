package com.vincenthzr.locationspoofer.utils

import java.util.Locale
import kotlin.math.abs

/** NMEA 经纬度格式与校验和的纯函数，供 hook 与 JVM golden 测试共用。 */
object NmeaFormat {

    fun latitude(lat: Double): Pair<String, String> {
        val absLat = abs(lat)
        val degrees = absLat.toInt()
        val minutes = (absLat - degrees) * 60.0
        val value = String.format(Locale.US, "%02d%08.5f", degrees, minutes)
        return value to if (lat >= 0) "N" else "S"
    }

    fun longitude(lng: Double): Pair<String, String> {
        val absLng = abs(lng)
        val degrees = absLng.toInt()
        val minutes = (absLng - degrees) * 60.0
        val value = String.format(Locale.US, "%03d%08.5f", degrees, minutes)
        return value to if (lng >= 0) "E" else "W"
    }

    /** XOR between '$' (exclusive) and '*' (exclusive), uppercase two hex digits. */
    fun checksum(sentence: String): String {
        var checksum = 0
        val startIndex = if (sentence.startsWith("$")) 1 else 0
        val endIndex = sentence.indexOf('*')
        val limit = if (endIndex != -1) endIndex else sentence.length
        for (i in startIndex until limit) {
            checksum = checksum xor sentence[i].code
        }
        return String.format(Locale.US, "%02X", checksum)
    }

    /**
     * 把 RMC/GGA/GLL 中的位置、速度、航向、海拔与卫星数替换为模拟值。
     * 返回 null 表示句型不支持或字段不足，调用方应原样返回输入。
     */
    fun rewriteSentence(
        sentence: String,
        lat: Double,
        lng: Double,
        speedMps: Float,
        bearingDeg: Float,
        altitudeM: Double,
        usedSatellites: Int,
        hdop: Double,
    ): String? {
        val parts = sentence.split("*")
        val fields = parts[0].split(",").toMutableList()
        if (fields.isEmpty()) return null

        val type = fields[0]
        var modified = false

        if (type.endsWith("RMC") && fields.size >= 7) {
            val (latStr, latDir) = latitude(lat)
            val (lngStr, lngDir) = longitude(lng)
            fields[2] = "A" // Status Active / Valid
            fields[3] = latStr
            fields[4] = latDir
            fields[5] = lngStr
            fields[6] = lngDir
            if (fields.size > 7) {
                val knots = speedMps * 1.943844f
                fields[7] = String.format(Locale.US, "%.2f", knots)
            }
            if (fields.size > 8) {
                fields[8] = String.format(Locale.US, "%.1f", bearingDeg)
            }
            modified = true
        } else if (type.endsWith("GGA") && fields.size >= 6) {
            val (latStr, latDir) = latitude(lat)
            val (lngStr, lngDir) = longitude(lng)
            fields[2] = latStr
            fields[3] = latDir
            fields[4] = lngStr
            fields[5] = lngDir
            if (fields.size > 6) fields[6] = "1" // GPS Fix (Quality indicator)
            if (fields.size > 7) fields[7] = usedSatellites.toString()
            if (fields.size > 8) {
                fields[8] = String.format(Locale.US, "%.1f", hdop)
            }
            if (fields.size > 9) {
                fields[9] = String.format(Locale.US, "%.1f", altitudeM)
            }
            modified = true
        } else if (type.endsWith("GLL") && fields.size >= 5) {
            val (latStr, latDir) = latitude(lat)
            val (lngStr, lngDir) = longitude(lng)
            fields[1] = latStr
            fields[2] = latDir
            fields[3] = lngStr
            fields[4] = lngDir
            if (fields.size > 6) fields[6] = "A"
            modified = true
        }

        if (!modified) return null

        val newMainPart = fields.joinToString(",")
        val newChecksum = checksum(newMainPart)
        val tail = if (parts.size > 1) {
            val rawTail = parts[1]
            val lineEnding = rawTail.substring(minOf(2, rawTail.length))
            "*$newChecksum$lineEnding"
        } else {
            "*$newChecksum"
        }
        return newMainPart + tail
    }
}
