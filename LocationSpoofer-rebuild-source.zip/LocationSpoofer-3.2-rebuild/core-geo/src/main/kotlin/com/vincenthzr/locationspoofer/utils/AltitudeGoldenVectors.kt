package com.vincenthzr.locationspoofer.utils

/** 固定输入/输出，用于锁定 AltitudeModel 与 native 海拔实现的一致性。 */
object AltitudeGoldenVectors {

    const val BASE_M = 50.0

    data class Case(
        val variationM: Double,
        val driftM: Double,
        val lat: Double,
        val lng: Double,
        val epochMs: Long,
        val expected: Double,
    )

    val CASES = listOf(
        Case(20.0, 3.0, 23.1066, 113.3245, 1_789_398_037_217L, 44.291905274343215),
        Case(20.0, 3.0, 30.0012, 120.0012, 1_789_398_037_217L, 49.20748889152187),
        Case(100.0, 5.0, 30.0012, 120.0012, 1_789_398_037_217L, 59.02513536122058),
        Case(10.0, 0.0, 30.0, 120.0, 0L, 46.16960776373187),
    )
}
