package com.vincenthzr.locationspoofer.utils

import org.junit.Assert.assertEquals
import org.junit.Test

class CompassGoldenVectorsTest {

    @Test
    fun `flat magnetic field matches golden vector`() {
        val actual = CompassMath.flatMagneticFieldUt(
            CompassGoldenVectors.TRUE_HEADING_DEG - CompassGoldenVectors.DECLINATION_DEG,
            CompassGoldenVectors.HORIZONTAL_UT.toFloat(),
            CompassGoldenVectors.VERTICAL_UT.toFloat(),
        )
        CompassGoldenVectors.FLAT_MAGNETIC_UT.indices.forEach { i ->
            assertEquals("mag[$i]", CompassGoldenVectors.FLAT_MAGNETIC_UT[i], actual[i], 1e-6f)
        }
    }

    @Test
    fun `flat rotation vector matches golden vector`() {
        val actual = CompassMath.flatRotationVector(
            CompassGoldenVectors.TRUE_HEADING_DEG - CompassGoldenVectors.DECLINATION_DEG
        )
        CompassGoldenVectors.FLAT_ROTATION_VECTOR.indices.forEach { i ->
            assertEquals("rot[$i]", CompassGoldenVectors.FLAT_ROTATION_VECTOR[i], actual[i], 1e-6f)
        }
    }

    @Test
    fun `invalid magnetic field falls back to 25 uT`() {
        val actual = CompassMath.flatMagneticFieldUt(0.0, 0.0f, Float.NaN)
        assertEquals(-0.0f, actual[0], 1e-6f)
        assertEquals(25.0f, actual[1], 1e-6f)
        assertEquals(0.0f, actual[2], 1e-6f)
    }

    @Test
    fun `angles wrap and shortest delta handles boundaries`() {
        assertEquals(350.0, CompassMath.wrap360(-10.0), 0.0)
        assertEquals(0.0, CompassMath.wrap360(360.0), 0.0)
        assertEquals(-180.0, CompassMath.shortestDeltaDegrees(0.0, 180.0), 0.0)
        assertEquals(0.0, CompassMath.shortestDeltaDegrees(42.0, 42.0), 0.0)
        assertEquals(0.0f, CompassMath.accuracyDegreesToRadians(Double.NaN), 0.0f)
    }

    @Test
    fun `accuracy and shortest delta match golden vectors`() {
        assertEquals(
            CompassGoldenVectors.FLAT_ACCURACY_RAD,
            CompassMath.accuracyDegreesToRadians(CompassGoldenVectors.ACCURACY_DEG),
            1e-7f,
        )
        assertEquals(
            CompassGoldenVectors.SHORTEST_DELTA_DEG,
            CompassMath.shortestDeltaDegrees(350.0, 10.0),
            0.0,
        )
    }
}
