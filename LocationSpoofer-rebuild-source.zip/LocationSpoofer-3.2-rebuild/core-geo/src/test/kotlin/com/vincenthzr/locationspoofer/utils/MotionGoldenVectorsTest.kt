package com.vincenthzr.locationspoofer.utils

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MotionGoldenVectorsTest {

    @Test
    fun `smooth noise matches golden vector`() {
        val seed = 0x5EED5EEDL
        val noise = MotionRealism.SmoothNoise(seed, 20.0, 600.0)
        val expected = doubleArrayOf(-0.5523465818745603, -7.111830048027774)
        val actual = doubleArrayOf(noise.value(42.0), noise.integral(42.0))
        expected.indices.forEach { i ->
            assertEquals("noise[$i]", expected[i], actual[i], 1e-12)
        }
    }

    @Test
    fun `motion session matches golden vector`() {
        val session = MotionRealism.Session(
            MotionGoldenVectors.SESSION_SEED,
            MotionRealism.Level.fromId(MotionGoldenVectors.SESSION_LEVEL_ID),
            MotionGoldenVectors.SESSION_FLUCTUATION_PCT,
        )
        val actual = doubleArrayOf(
            session.speed(
                MotionGoldenVectors.SESSION_BASE_SPEED_MPS,
                MotionGoldenVectors.SESSION_ELAPSED_SEC,
            ),
            session.distance(
                MotionGoldenVectors.SESSION_BASE_SPEED_MPS,
                MotionGoldenVectors.SESSION_ELAPSED_SEC,
            ),
            session.cadence(
                MotionGoldenVectors.SESSION_BASE_CADENCE_SPM,
                MotionGoldenVectors.SESSION_ELAPSED_SEC,
            ),
            session.steps(
                MotionGoldenVectors.SESSION_BASE_CADENCE_SPM,
                MotionGoldenVectors.SESSION_ELAPSED_SEC,
            ),
        )
        MotionGoldenVectors.SESSION_EXPECTED.indices.forEach { i ->
            assertEquals("session[$i]", MotionGoldenVectors.SESSION_EXPECTED[i], actual[i], 1e-12)
        }
    }

    @Test
    fun `procedural gait matches golden vectors`() {
        MotionGoldenVectors.GAIT_CASES.forEach { case ->
            val actual = MotionRealism.proceduralGaitSample(
                case.stepsFloat,
                case.speedMps,
                case.strength,
            )
            case.expected.indices.forEach { i ->
                assertEquals("gait ${case.stepsFloat}/${case.speedMps}[$i]",
                    case.expected[i], actual[i], 1e-6f)
            }
        }
    }

    @Test
    fun `gait template round trip matches golden vector`() {
        val encoded = MotionGoldenVectors.goldenGaitTemplate().encode()
        val decoded = GaitTemplate.decode(encoded)!!
        val actual = decoded.sample(
            MotionGoldenVectors.GAIT_TEMPLATE_PHASE,
            MotionGoldenVectors.GAIT_TEMPLATE_STRENGTH,
        )
        MotionGoldenVectors.GAIT_TEMPLATE_SAMPLE.indices.forEach { i ->
            assertEquals("template[$i]", MotionGoldenVectors.GAIT_TEMPLATE_SAMPLE[i], actual[i], 1e-6f)
        }
    }

    @Test
    fun `gyro matches golden vectors`() {
        MotionGoldenVectors.GYRO_CASES.forEach { case ->
            val actual = GyroMotion.sample(
                case.stepsFloat,
                case.cadenceSpm,
                case.speedMps,
                case.realismLevel,
                case.fluctuationPct,
                case.startTimestampMs,
                case.yawRateRad,
                case.elapsedSec,
            )
            case.expected.indices.forEach { i ->
                assertEquals("gyro ${case.stepsFloat}[$i]", case.expected[i], actual[i], 1e-6f)
            }
        }
    }

    @Test
    fun `off level without fluctuation is exact constant motion`() {
        val session = MotionRealism.Session(123L, MotionRealism.Level.OFF, 0)
        val t = 12.0
        assertEquals(1.4, session.speed(1.4, t), 1e-12)
        assertEquals(1.4 * t, session.distance(1.4, t), 1e-12)
        assertEquals(165.0, session.cadence(165.0, t), 1e-12)
        assertEquals(165.0 / 60.0 * t, session.steps(165.0, t), 1e-12)
    }

    @Test
    fun `gait and gyro handle invalid or extreme inputs`() {
        assertTrue(MotionRealism.proceduralGaitSample(0.25, 0.0, 1.0).all { it.isFinite() })
        assertTrue(MotionRealism.proceduralGaitSample(3.75, 30.0, 1.0).all { it.isFinite() })
        val invalid = GyroMotion.sample(
            Double.NaN, 165, 1.4, 3, 10, 1L, 0.0, 1.0,
        )
        assertTrue(invalid.all { it == 0f })
        val zeroSpeed = GyroMotion.sample(1.0, 165, 0.0, 3, 10, 1L, 0.0, 1.0)
        assertTrue(zeroSpeed.all { it == 0f })
    }

    @Test
    fun `pressure and quaternion snapshots stay sane`() {
        assertEquals(
            MotionGoldenVectors.PRESSURE_HPA,
            PressureMath.pressureHpa(
                MotionGoldenVectors.PRESSURE_ALTITUDE_M,
                MotionGoldenVectors.PRESSURE_SEA_LEVEL_HPA,
                MotionGoldenVectors.PRESSURE_TIME_SEC,
            ),
            1e-9,
        )
        val q = MotionGoldenVectors.QUATERNION
        assertEquals(1.0, q.sumOf { it * it }, 1e-12)
        assertTrue(MotionGoldenVectors.ATTITUDE.all { it.isFinite() })
        assertTrue(MotionGoldenVectors.GYRO.all { it.isFinite() })
    }
}
