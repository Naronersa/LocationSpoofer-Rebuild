package com.vincenthzr.locationspoofer.utils

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GnssGoldenVectorsTest {

    @Test
    fun `GNSS values stay in range at extreme inputs`() {
        val start = 0L
        val now = 1_000L
        val used = GnssRealism.usedSatellites(start, 99, 99, now)
        assertTrue(used in 4..32)
        assertTrue(GnssRealism.accuracyMeters(start, 99, 99, now) in 1.1..18.0)
        assertTrue(GnssRealism.hdop(start, 99, 99, used, now) in 0.7..6.5)
        assertTrue(GnssRealism.vdop(start, 99, 99, used, now) in 0.8..8.0)
        assertTrue(GnssRealism.pdop(start, 99, 99, used, now) in 1.0..9.0)
        assertTrue(GnssRealism.multipathIndicator(start, now) in 1..2)
    }

    @Test
    fun `GNSS quality matches golden vector`() {
        val start = GnssGoldenVectors.START_TIMESTAMP_MS
        val now = GnssGoldenVectors.NOW_MS
        val level = GnssGoldenVectors.REALISM_LEVEL
        val configured = GnssGoldenVectors.CONFIGURED_SATELLITES
        val used = GnssRealism.usedSatellites(start, level, configured, now)
        val actual = doubleArrayOf(
            GnssRealism.accuracyMeters(start, level, configured, now),
            used.toDouble(),
            GnssRealism.hdop(start, level, configured, used, now),
            GnssRealism.vdop(start, level, configured, used, now),
            GnssRealism.pdop(start, level, configured, used, now),
            GnssRealism.degradation(start, now),
            GnssRealism.pseudorangeRateMps(
                start,
                GnssGoldenVectors.SVID,
                GnssGoldenVectors.SPEED_MPS,
                now,
            ),
            GnssRealism.multipathIndicator(start, now).toDouble(),
        )
        GnssGoldenVectors.EXPECTED.indices.forEach { i ->
            assertEquals("gnss[$i]", GnssGoldenVectors.EXPECTED[i], actual[i], 1e-12)
        }
    }
}
