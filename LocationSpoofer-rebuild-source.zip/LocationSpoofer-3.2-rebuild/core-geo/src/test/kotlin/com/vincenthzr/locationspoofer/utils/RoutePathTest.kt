package com.vincenthzr.locationspoofer.utils

import com.vincenthzr.locationspoofer.utils.CoordinateUtils.LatLng
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RoutePathTest {

    private val a = LatLng(30.0, 120.0)
    private val b = GeoMath.destination(a, 90.0, 1000.0) // 正东 1000 米

    @Test
    fun `destination and distance are consistent`() {
        assertEquals(1000.0, GeoMath.distance(a, b), 0.01)
        assertEquals(90.0, GeoMath.bearing(a, b).toDouble(), 0.01)
    }

    @Test
    fun `open route goes back and forth`() {
        val path = RoutePath(listOf(a, b))
        assertFalse(path.isClosedLoop)
        val out = path.positionAt(400.0, stopAtDestination = false)
        assertEquals(400.0, GeoMath.distance(a, LatLng(out.lat, out.lng)), 0.5)
        assertEquals(90.0, out.bearing.toDouble(), 0.5)
        val back = path.positionAt(1600.0, stopAtDestination = false) // 折返途中，距起点 400 米
        assertEquals(400.0, GeoMath.distance(a, LatLng(back.lat, back.lng)), 0.5)
        assertEquals(270.0, back.bearing.toDouble(), 0.5)
    }

    @Test
    fun `closed loop keeps going forward`() {
        val c = GeoMath.destination(b, 0.0, 1000.0)
        val path = RoutePath(listOf(a, b, c, a))
        assertTrue(path.isClosedLoop)
        val lap = path.positionAt(path.totalDistance + 300.0, stopAtDestination = false)
        assertEquals(300.0, GeoMath.distance(a, LatLng(lap.lat, lap.lng)), 0.5)
    }

    @Test
    fun `route geometry matches golden vectors`() {
        val p0 = LatLng(30.0, 120.0)
        val p1 = LatLng(30.0012, 120.0012)
        val open = RoutePath(listOf(p0, p1))
        assertEquals(176.7137553298078, open.totalDistance, 1e-9)
        assertFalse(open.isClosedLoop)

        listOf(
            0.0 to doubleArrayOf(30.0, 120.0, 40.892923214455266),
            100.0 to doubleArrayOf(30.000679064285496, 120.00067906428549, 40.892923214455266),
            176.7137553298078 to doubleArrayOf(30.0012, 120.0012, 40.892923214455266),
            276.7137553298078 to doubleArrayOf(30.000520935714505, 120.0005209357145, 220.8935232253012),
            403.4275106596156 to doubleArrayOf(30.000339532142746, 120.00033953214275, 40.892923214455266),
        ).forEach { (distance, expected) ->
            val pos = open.positionAt(distance, stopAtDestination = false)
            assertEquals("lat@$distance", expected[0], pos.lat, 1e-9)
            assertEquals("lng@$distance", expected[1], pos.lng, 1e-9)
            assertEquals("bearing@$distance", expected[2], pos.bearing.toDouble(), 1e-4)
        }

        val p2 = LatLng(30.0012, 120.0024)
        val p3 = LatLng(30.0, 120.0024)
        val loop = RoutePath(listOf(p0, p1, p2, p3, p0))
        assertEquals(657.3555704368655, loop.totalDistance, 1e-9)
        assertTrue(loop.isClosedLoop)
        listOf(0.0 to doubleArrayOf(30.0, 120.0, 40.892923214455266),
            50.0 to doubleArrayOf(30.000339532142746, 120.00033953214275, 40.892923214455266),
            707.3555704368655 to doubleArrayOf(30.000339532142746, 120.00033953214275, 40.892923214455266),
        ).forEach { (distance, expected) ->
            val pos = loop.positionAt(distance, stopAtDestination = false)
            assertEquals("loop lat@$distance", expected[0], pos.lat, 1e-9)
            assertEquals("loop lng@$distance", expected[1], pos.lng, 1e-9)
            assertEquals("loop bearing@$distance", expected[2], pos.bearing.toDouble(), 1e-4)
        }

        val stop = open.positionAt(5000.0, stopAtDestination = true)
        assertTrue(stop.arrived)
        assertEquals(p1.lat, stop.lat, 0.0)
        assertEquals(p1.lng, stop.lng, 0.0)
    }

    @Test
    fun `stops at the destination when requested`() {
        val path = RoutePath(listOf(a, b))
        val end = path.positionAt(5000.0, stopAtDestination = true)
        assertTrue(end.arrived)
        assertEquals(b.lat, end.lat, 1e-9)
        assertEquals(b.lng, end.lng, 1e-9)
    }
}
