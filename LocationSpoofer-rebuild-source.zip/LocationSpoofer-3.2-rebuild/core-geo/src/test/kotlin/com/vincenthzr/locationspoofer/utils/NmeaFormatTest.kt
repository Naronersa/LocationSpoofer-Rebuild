package com.vincenthzr.locationspoofer.utils

import org.junit.Assert.assertEquals
import org.junit.Test

class NmeaFormatTest {

    @Test
    fun `latitude matches golden vectors`() {
        assertEquals("2602.23167" to "N", NmeaFormat.latitude(26.03719450620751))
        assertEquals("3352.12800" to "S", NmeaFormat.latitude(-33.8688))
        assertEquals("0000.00000" to "N", NmeaFormat.latitude(0.0))
        assertEquals("9000.00000" to "N", NmeaFormat.latitude(90.0))
        assertEquals("9000.00000" to "S", NmeaFormat.latitude(-90.0))
    }

    @Test
    fun `longitude matches golden vectors`() {
        assertEquals("11911.55642" to "E", NmeaFormat.longitude(119.19260700285616))
        assertEquals("00007.66800" to "W", NmeaFormat.longitude(-0.1278))
        assertEquals("00000.00000" to "E", NmeaFormat.longitude(0.0))
        assertEquals("18000.00000" to "E", NmeaFormat.longitude(180.0))
        assertEquals("18000.00000" to "W", NmeaFormat.longitude(-180.0))
    }

    @Test
    fun `checksums match golden vectors`() {
        assertEquals(
            "47",
            NmeaFormat.checksum("\$GPGGA,123519,4807.038,N,01131.000,E,1,08,0.9,545.4,M,46.9,M,,*47"),
        )
        assertEquals(
            "6A",
            NmeaFormat.checksum(
                "\$GPRMC,123519,A,4807.038,N,01131.000,E,022.4,084.4,230394,003.1,W*6A"
            ),
        )
        assertEquals("31", NmeaFormat.checksum("GPGLL,4916.45,N,12311.12,W,225444,A"))
        assertEquals("31", NmeaFormat.checksum("\$GPGLL,4916.45,N,12311.12,W,225444,A*00"))
    }

    @Test
    fun `RMC sentence rewrite matches golden vector`() {
        val rewritten = NmeaFormat.rewriteSentence(
            "\$GPRMC,123519,A,4807.038,N,01131.000,E,022.4,084.4,230394,003.1,W*6A\r\n",
            lat = 26.03719450620751,
            lng = 119.19260700285616,
            speedMps = 1.4f,
            bearingDeg = 90f,
            altitudeM = 25.0,
            usedSatellites = 15,
            hdop = 1.1,
        )
        assertEquals(
            "\$GPRMC,123519,A,2602.23167,N,11911.55642,E,2.72,90.0,230394,003.1,W*64\r\n",
            rewritten,
        )
    }

    @Test
    fun `GGA sentence rewrite matches golden vector`() {
        val rewritten = NmeaFormat.rewriteSentence(
            "\$GPGGA,123519,4807.038,N,01131.000,E,1,08,0.9,545.4,M,46.9,M,,*47\r\n",
            lat = 26.03719450620751,
            lng = 119.19260700285616,
            speedMps = 1.4f,
            bearingDeg = 90f,
            altitudeM = 25.0,
            usedSatellites = 15,
            hdop = 1.1,
        )
        assertEquals(
            "\$GPGGA,123519,2602.23167,N,11911.55642,E,1,15,1.1,25.0,M,46.9,M,,*79\r\n",
            rewritten,
        )
    }

    @Test
    fun `GLL sentence rewrite matches golden vector`() {
        val rewritten = NmeaFormat.rewriteSentence(
            "\$GPGLL,4916.45,N,12311.12,W,225444,A*31",
            lat = 26.03719450620751,
            lng = 119.19260700285616,
            speedMps = 1.4f,
            bearingDeg = 90f,
            altitudeM = 25.0,
            usedSatellites = 15,
            hdop = 1.1,
        )
        assertEquals("\$GPGLL,2602.23167,N,11911.55642,E,225444,A*25", rewritten)
    }

    @Test
    fun `unsupported or short sentences are left untouched`() {
        assertEquals(
            null,
            NmeaFormat.rewriteSentence(
                "\$GPVTG,54.7,T,,M,0.0,N,0.0,K,A*34",
                26.0, 119.0, 1.4f, 90f, 25.0, 15, 1.1,
            ),
        )
        assertEquals(
            null,
            NmeaFormat.rewriteSentence(
                "\$GPRMC,123519,A,4807.038,N,01131.000*00",
                26.0, 119.0, 1.4f, 90f, 25.0, 15, 1.1,
            ),
        )
        assertEquals(
            "\$GPRMC,123519,A,2602.23167,N,11911.55642,E*32",
            NmeaFormat.rewriteSentence(
                "\$GPRMC,123519,A,4807.038,N,01131.000,E",
                26.03719450620751, 119.19260700285616, 1.4f, 90f, 25.0, 15, 1.1,
            ),
        )
    }

    @Test
    fun `spoofed sentence checksum covers rewritten body`() {
        val (latStr, latDir) = NmeaFormat.latitude(26.03719450620751)
        val (lngStr, lngDir) = NmeaFormat.longitude(119.19260700285616)
        val body = "GPGGA,123519,$latStr,$latDir,$lngStr,$lngDir,1,08,0.9,545.4,M,46.9,M,,"
        assertEquals("GPGGA,123519,2602.23167,N,11911.55642,E,1,08,0.9,545.4,M,46.9,M,,", body)
        // Recomputed with the pure helper; keeps the sentence self-consistent after rewrite.
        assertEquals("4B", NmeaFormat.checksum(body))
        assertEquals("4B", NmeaFormat.checksum("$body*00"))
    }
}
