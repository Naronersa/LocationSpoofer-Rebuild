package com.vincenthzr.locationspoofer.data.db

import com.vincenthzr.locationspoofer.utils.ConfigKeys

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import java.io.File

@Database(
    entities = [
        LocationRecord::class,
        LocationConnectedWifi::class,
        WifiDevice::class, LocationWifi::class,
        BluetoothDevice::class, LocationBluetooth::class,
        CellDevice::class, LocationCell::class,
        SavedRouteEntity::class, CollectionRouteRecord::class
    ],
    version = 13,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun environmentDao(): EnvironmentDao
    abstract fun savedRouteDao(): SavedRouteDao

    companion object {
        private const val DB_NAME = "environment_database"
        // 与上方 @Database(version = 13) 保持一致；升级数据库时两处一起修改。
        private const val DB_VERSION = 13

        @Volatile
        private var INSTANCE: AppDatabase? = null

        private val MIGRATION_3_4 = object : androidx.room.migration.Migration(3, 4) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE location_records ADD COLUMN placeName TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE location_records ADD COLUMN remark TEXT NOT NULL DEFAULT ''")
            }
        }

        /**
         * v4/v5 是早期发布过的数据库版本，历史 schema 没有随源码保存。
         * 这两步没有已知的 DDL 变化；显式补上 no-op 迁移，至少保证 Room 能
         * 从 4/5 继续走到 6→7…，而不是直接抛 "migration not found"。
         * 若某个 v4/v5 库确实带有额外列，Room 会在迁移后的校验阶段报错；
         * getDatabase() 已在迁移前把原库备份为 environment_database.vN.bak。
         */
        private val MIGRATION_4_5 = object : androidx.room.migration.Migration(4, 5) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) = Unit
        }

        private val MIGRATION_5_6 = object : androidx.room.migration.Migration(5, 6) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) = Unit
        }

        private val MIGRATION_6_7 = object : androidx.room.migration.Migration(6, 7) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE location_records ADD COLUMN selectedWifiBssid TEXT")
                db.execSQL("ALTER TABLE location_records ADD COLUMN selectedBluetoothAddress TEXT")
                db.execSQL("ALTER TABLE location_records ADD COLUMN selectedCellKey TEXT")
            }
        }

        private val MIGRATION_7_8 = object : androidx.room.migration.Migration(7, 8) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("CREATE INDEX IF NOT EXISTS index_location_records_lat_lng ON location_records(lat, lng)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_location_records_timestamp ON location_records(timestamp)")
            }
        }

        private val MIGRATION_8_9 = object : androidx.room.migration.Migration(8, 9) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS collection_routes (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, name TEXT NOT NULL, remark TEXT NOT NULL, pointsJson TEXT NOT NULL, halfWidthM REAL NOT NULL, timestamp INTEGER NOT NULL)")
                db.execSQL("ALTER TABLE location_records ADD COLUMN collectionRouteId INTEGER REFERENCES collection_routes(id) ON DELETE CASCADE")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_location_records_collectionRouteId ON location_records(collectionRouteId)")
            }
        }

        /** 上游 3.0.12+：位置、采集路线、保存路线增加跨设备同步唯一标识。 */
        private val MIGRATION_9_10 = object : androidx.room.migration.Migration(9, 10) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                for (table in listOf("location_records", "collection_routes", "saved_routes")) {
                    db.execSQL("ALTER TABLE $table ADD COLUMN syncId TEXT NOT NULL DEFAULT ''")
                    val ids = ArrayList<Long>()
                    db.query("SELECT id FROM $table").use { cursor ->
                        while (cursor.moveToNext()) ids.add(cursor.getLong(0))
                    }
                    for (id in ids) {
                        db.execSQL(
                            "UPDATE $table SET syncId=? WHERE id=?",
                            arrayOf<Any>(java.util.UUID.randomUUID().toString(), id)
                        )
                    }
                }
            }
        }

        /** 上游 3.0.17：保存路线增加"录制来源"标记。 */
        private val MIGRATION_10_11 = object : androidx.room.migration.Migration(10, 11) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE saved_routes ADD COLUMN recorded INTEGER NOT NULL DEFAULT 0")
            }
        }

        /**
         * 上游 3.0.18：三类记录增加坐标参考系，并把原始坐标备份到 coordinate_backup_v11。
         * 迁移只补列与备份，不修改已保存的坐标值（与上游"不自动修改原始坐标"一致）。
         */
        private val MIGRATION_11_12 = object : androidx.room.migration.Migration(11, 12) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS coordinate_backup_v11(" +
                        "kind TEXT NOT NULL,record_id INTEGER NOT NULL,payload TEXT NOT NULL," +
                        "PRIMARY KEY(kind,record_id))"
                )
                // location_records 存的是单点
                db.execSQL("ALTER TABLE location_records ADD COLUMN coordinateSystem TEXT NOT NULL DEFAULT 'WGS84'")
                db.query("SELECT id,lat,lng FROM location_records").use { cursor ->
                    while (cursor.moveToNext()) {
                        val payload = org.json.JSONObject()
                            .put(ConfigKeys.LAT, cursor.getDouble(1))
                            .put(ConfigKeys.LNG, cursor.getDouble(2))
                            .toString()
                        db.execSQL(
                            "INSERT OR IGNORE INTO coordinate_backup_v11 VALUES(?,?,?)",
                            arrayOf<Any>("location_records", cursor.getLong(0), payload)
                        )
                    }
                }
                // 两类路线存的是 pointsJson
                for (table in listOf("saved_routes", "collection_routes")) {
                    db.execSQL("ALTER TABLE $table ADD COLUMN coordinateSystem TEXT NOT NULL DEFAULT 'WGS84'")
                    val rows = ArrayList<Pair<Long, String>>()
                    db.query("SELECT id,pointsJson FROM $table").use { cursor ->
                        while (cursor.moveToNext()) rows.add(cursor.getLong(0) to cursor.getString(1))
                    }
                    for ((id, pointsJson) in rows) {
                        val payload = org.json.JSONObject().put(ConfigKeys.POINTS_JSON, pointsJson).toString()
                        db.execSQL(
                            "INSERT OR IGNORE INTO coordinate_backup_v11 VALUES(?,?,?)",
                            arrayOf<Any>(table, id, payload)
                        )
                    }
                }
            }
        }

        /**
         * 修正 v12 迁移给旧规划路线/收藏点统一写死的 WGS84 元数据：
         * - 地图收藏点与 collection_routes 实际是 GCJ-02；
         * - saved_routes 里只有录制路线（recorded=1）是 WGS-84。
         * 不修改坐标值，只修 coordinateSystem。
         */
        private val MIGRATION_12_13 = object : androidx.room.migration.Migration(12, 13) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL(
                    "UPDATE location_records SET coordinateSystem='GCJ02' " +
                        "WHERE coordinateSystem='WGS84'"
                )
                db.execSQL(
                    "UPDATE collection_routes SET coordinateSystem='GCJ02' " +
                        "WHERE coordinateSystem='WGS84'"
                )
                db.execSQL(
                    "UPDATE saved_routes SET coordinateSystem='GCJ02' " +
                        "WHERE recorded=0 AND coordinateSystem='WGS84'"
                )
            }
        }

        /**
         * 在 Room 打开数据库前，把旧版本数据库复制一份。
         *
         * 迁移失败时 Room 会抛异常，不再静默清库；这份副本让用户/开发者仍有机会恢复。
         * 只复制一次，避免每次启动都写一份。
         */
        private fun backupBeforeMigration(context: Context) {
            val dbFile = context.getDatabasePath(DB_NAME)
            if (!dbFile.exists() || dbFile.length() == 0L) return
            val version = runCatching {
                SQLiteDatabase.openDatabase(
                    dbFile.path, null, SQLiteDatabase.OPEN_READONLY
                ).use { it.version }
            }.getOrDefault(-1)
            if (version <= 0 || version == DB_VERSION) return

            val parent = dbFile.parentFile ?: return
            val backup = File(parent, "$DB_NAME.v$version.bak")
            if (backup.exists()) return
            runCatching {
                dbFile.copyTo(backup, overwrite = false)
                // WAL/SHM 与主库一起复制，避免备份只包含旧页。
                for (suffix in listOf("-wal", "-shm")) {
                    val sidecar = File(dbFile.path + suffix)
                    if (sidecar.exists()) {
                        sidecar.copyTo(File(backup.path + suffix), overwrite = false)
                    }
                }
                android.util.Log.w(
                    "AppDatabase",
                    "legacy database v$version backed up to ${backup.absolutePath}"
                )
            }
        }

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                backupBeforeMigration(context)
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    DB_NAME
                )
                    .addMigrations(
                        MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6,
                        MIGRATION_6_7, MIGRATION_7_8, MIGRATION_8_9,
                        MIGRATION_9_10, MIGRATION_10_11, MIGRATION_11_12,
                        MIGRATION_12_13
                    )
                    // 不使用全局 fallbackToDestructiveMigration()：缺少迁移时让 Room 抛异常，
                    // 避免静默清空用户的收藏点、路线和环境数据；旧库已在上方备份。
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
