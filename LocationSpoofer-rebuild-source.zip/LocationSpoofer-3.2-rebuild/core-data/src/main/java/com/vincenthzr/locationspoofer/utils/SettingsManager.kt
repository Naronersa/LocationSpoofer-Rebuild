package com.vincenthzr.locationspoofer.utils

import android.content.Context
import android.content.SharedPreferences
import com.vincenthzr.locationspoofer.data.model.RoutePoint
import com.vincenthzr.locationspoofer.data.model.SavedLocation
import com.vincenthzr.locationspoofer.data.model.SavedRoute
import org.json.JSONArray
import org.json.JSONObject

class SettingsManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("app_settings", Context.MODE_PRIVATE)

    init {
        // 自动升级迁移：
        // 修复之前版本将 mockWifi / mockCell / mockBluetooth 错误绑定导致旧配置中被意外写入 false 的历史遗留问题。
        // 在系统级 Hook 架构下，Wi-Fi、基站与蓝牙均由系统服务自动实时合成高拟真环境数据，
        // 必须默认保持开启以彻底杜绝高德/阿里/抖音等通过物理 Wi-Fi BSSID 与基站反查真实位置。
        // 同时确保系统级全局模拟模式（is_system_hook_global_mode）默认开启。
        // 仅全局方案执行：非全局方案不改动用户已有的开关设置。
        if (!prefs.getBoolean(ConfigKeys.MOCK_SWITCHES_MIGRATED_V3, false)) {
            // 不要覆盖用户已明确设置过的开关。旧版本可能因为迁移把自己写成
            // false，但直接强制改成 true 同样会覆盖用户的白名单/关闭选择。
            // 只在 key 不存在（真正的新安装/从未写过）时补默认值。
            val editor = prefs.edit()
            if (!prefs.contains("mock_wifi")) editor.putBoolean("mock_wifi", true)
            if (!prefs.contains("mock_cell")) editor.putBoolean("mock_cell", true)
            if (!prefs.contains("mock_bluetooth")) editor.putBoolean("mock_bluetooth", true)
            if (!prefs.contains("is_system_hook_global_mode")) {
                editor.putBoolean("is_system_hook_global_mode", true)
            }
            editor.putBoolean("mock_switches_migrated_v3", true)
            editor.apply()
        }
    }

    var isDarkMode: Boolean
        get() = prefs.getBoolean(ConfigKeys.IS_DARK_MODE, true)
        set(value) = prefs.edit().putBoolean("is_dark_mode", value).apply()

    var language: String
        get() = prefs.getString(ConfigKeys.LANGUAGE, "") ?: ""
        set(value) = prefs.edit().putString("language", value).apply()

    var isLanguageSet: Boolean
        get() = prefs.getBoolean(ConfigKeys.IS_LANGUAGE_SET, false)
        set(value) = prefs.edit().putBoolean("is_language_set", value).apply()

    /**
     * 上游 3.0.15：已有本地设置的老用户不再重复进入首次语言选择。
     * 不能只看 is_language_set —— 旧版本从未写过该标志。
     */
    fun shouldShowLanguageSelection(): Boolean {
        if (isLanguageSet) return false
        val initialized = prefs.contains("map_type") ||
            prefs.contains("map_engine") ||
            prefs.contains("is_spoofing_active") ||
            prefs.contains("last_spoofed_lat") ||
            prefs.getBoolean(ConfigKeys.MOCK_SWITCHES_MIGRATED_V3, false)
        if (initialized) {
            isLanguageSet = true
            return false
        }
        return true
    }

    var amapApiKey: String
        get() = prefs.getString(ConfigKeys.AMAP_API_KEY, "") ?: ""
        set(value) = prefs.edit().putString("amap_api_key", value).apply()

    var baiduApiKey: String
        get() = prefs.getString(ConfigKeys.BAIDU_API_KEY, "") ?: ""
        set(value) = prefs.edit().putString("baidu_api_key", value).apply()

    var googleApiKey: String
        get() = prefs.getString(ConfigKeys.GOOGLE_API_KEY, "") ?: ""
        set(value) = prefs.edit().putString("google_api_key", value).apply()

    var wigleApiToken: String
        get() = prefs.getString(ConfigKeys.WIGLE_API_TOKEN, "") ?: ""
        set(value) = prefs.edit().putString("wigle_api_token", value).apply()

    var opencellidApiToken: String
        get() = prefs.getString(ConfigKeys.OPENCELLID_API_TOKEN, "") ?: ""
        set(value) = prefs.edit().putString("opencellid_api_token", value).apply()

    var mapType: String
        get() = prefs.getString(ConfigKeys.MAP_TYPE, "NORMAL") ?: "NORMAL"
        set(value) = prefs.edit().putString("map_type", value).apply()

    var mapEngine: String
        get() = prefs.getString(ConfigKeys.MAP_ENGINE, "AUTO") ?: "AUTO"
        set(value) = prefs.edit().putString("map_engine", value).apply()

    var rootSolution: String
        get() = prefs.getString(ConfigKeys.ROOT_SOLUTION, "AUTO") ?: "AUTO"
        set(value) = prefs.edit().putString("root_solution", value).apply()

    /** 用户在"厂商适配方案"设置页手动选中的 [com.vincenthzr.locationspoofer.vendor.VendorScheme.id]；"auto" 表示走自动识别。 */
    var vendorOverride: String
        get() = prefs.getString(ConfigKeys.VENDOR_OVERRIDE, "auto") ?: "auto"
        set(value) = prefs.edit().putString("vendor_override", value).apply()

    /** 适配新系统用：开机时把各系统服务候选类的方法 / 字段列表写进 Xposed 日志（全局方案，需重启生效） */
    var debugDumpSystemServices: Boolean
        get() = prefs.getBoolean(ConfigKeys.DEBUG_DUMP_SYSTEM_SERVICES, false)
        set(value) = prefs.edit().putBoolean("debug_dump_system_services", value).apply()

    var isSpoofingActive: Boolean
        get() = prefs.getBoolean(ConfigKeys.IS_SPOOFING_ACTIVE, false)
        set(value) = prefs.edit().putBoolean("is_spoofing_active", value).apply()

    var lastSpoofedLat: String
        get() = prefs.getString(ConfigKeys.LAST_SPOOFED_LAT, "0") ?: "0"
        set(value) = prefs.edit().putString("last_spoofed_lat", value).apply()

    var lastSpoofedLng: String
        get() = prefs.getString(ConfigKeys.LAST_SPOOFED_LNG, "0") ?: "0"
        set(value) = prefs.edit().putString("last_spoofed_lng", value).apply()

    var mockWifi: Boolean
        get() = prefs.getBoolean(ConfigKeys.MOCK_WIFI, true)
        set(value) = prefs.edit().putBoolean("mock_wifi", value).apply()

    var mockCell: Boolean
        get() = prefs.getBoolean(ConfigKeys.MOCK_CELL, true)
        set(value) = prefs.edit().putBoolean("mock_cell", value).apply()

    var mockBluetooth: Boolean
        get() = prefs.getBoolean(ConfigKeys.MOCK_BLUETOOTH, true)
        set(value) = prefs.edit().putBoolean("mock_bluetooth", value).apply()

    var enableJitter: Boolean
        get() = prefs.getBoolean(ConfigKeys.ENABLE_JITTER, true)
        set(value) = prefs.edit().putBoolean("enable_jitter", value).apply()

    /** 开始模拟时是否强制重启已勾选作用域的目标 App，让它们加载当前模块并订阅框架配置 */
    var restartAppsOnSpoof: Boolean
        get() = prefs.getBoolean(ConfigKeys.RESTART_APPS_ON_SPOOF, true)
        set(value) = prefs.edit().putBoolean("restart_apps_on_spoof", value).apply()

    var altitude: String
        get() = prefs.getString(ConfigKeys.ALTITUDE, "25.0") ?: "25.0"
        set(value) = prefs.edit().putString("altitude", value).apply()

    /** 海拔相对基准值的最大起伏（±米），0 表示固定海拔 */
    var altitudeVariationM: Int
        get() = prefs.getInt(ConfigKeys.ALTITUDE_VARIATION_M, AltitudeModel.DEFAULT_VARIATION_M)
        set(value) = prefs.edit().putInt("altitude_variation_m", value).apply()

    /** 运动真实度随机强度，取值见 MotionRealism.Level.id */
    var realismLevel: Int
        get() = prefs.getInt(ConfigKeys.REALISM_LEVEL, MotionRealism.DEFAULT_LEVEL_ID)
        set(value) = prefs.edit().putInt("realism_level", value).apply()

    /** 路线模拟速度浮动范围（±百分比） */
    var speedFluctuationPct: Int
        get() = prefs.getInt(ConfigKeys.SPEED_FLUCTUATION_PCT, MotionRealism.DEFAULT_SPEED_FLUCTUATION_PCT)
        set(value) = prefs.edit().putInt("speed_fluctuation_pct", value).apply()

    /** 上游 3.0.12：按模拟海拔生成气压并缓慢浮动（需要设备具备气压计） */
    var barometerFluctuation: Boolean
        get() = prefs.getBoolean(ConfigKeys.BAROMETER_FLUCTUATION, false)
        set(value) = prefs.edit().putBoolean("barometer_fluctuation", value).apply()

    /**
     * 气压换算用的当地海平面气压（hPa）。
     * 不同天气/第三方指南针会用自己的 QNH 校准；调整该值可让它们的海拔显示
     * 与模拟 altitude 一致。默认采用标准大气压 1013.25。
     */
    var barometerSeaLevelHpa: Float
        get() = prefs.getFloat("barometer_sea_level_hpa", 1013.25f)
        set(value) = prefs.edit().putFloat("barometer_sea_level_hpa", value).apply()

    /** 路线/运动模拟时生成指南针、磁场与旋转矢量数据 */
    var compassSimulationEnabled: Boolean
        get() = prefs.getBoolean(ConfigKeys.COMPASS_SIMULATION_ENABLED, true)
        set(value) = prefs.edit().putBoolean("compass_simulation_enabled", value).apply()

    /** 上游 3.0.13：定点模拟开启悬浮摇杆时锁定地图选点，减少误触 */
    var fixedJoystickEnabled: Boolean
        get() = prefs.getBoolean(ConfigKeys.FIXED_JOYSTICK_ENABLED, false)
        set(value) = prefs.edit().putBoolean("fixed_joystick_enabled", value).apply()

    /** 上游 3.0.13：路线模拟的平滑左右偏移 */
    var routeLateralDeviation: Boolean
        get() = prefs.getBoolean(ConfigKeys.ROUTE_LATERAL_DEVIATION, false)
        set(value) = prefs.edit().putBoolean("route_lateral_deviation", value).apply()

    /** 路线已进入第一阶段（起点静止），等待用户第二次点击开始移动 */
    var routeWaitingToStart: Boolean
        get() = prefs.getBoolean(ConfigKeys.ROUTE_WAITING_TO_START, false)
        set(value) = prefs.edit().putBoolean("route_waiting_to_start", value).apply()

    /** 第一阶段等待中的路线点 JSON，进程重启后恢复 */
    var routeWaitingPoints: String
        get() = prefs.getString(ConfigKeys.ROUTE_WAITING_POINTS, "[]") ?: "[]"
        set(value) = prefs.edit().putString("route_waiting_points", value).apply()

    /** 第一阶段等待中的速度/运行模式，进程重启后恢复 */
    var routeWaitingSimMode: String
        get() = prefs.getString(ConfigKeys.ROUTE_WAITING_SIM_MODE, "WALKING") ?: "WALKING"
        set(value) = prefs.edit().putString("route_waiting_sim_mode", value).apply()

    var routeWaitingCustomSpeed: Float
        get() = prefs.getFloat("route_waiting_custom_speed", 3.0f)
        set(value) = prefs.edit().putFloat("route_waiting_custom_speed", value).apply()

    var routeWaitingRunMode: String
        get() = prefs.getString(ConfigKeys.ROUTE_WAITING_RUN_MODE, "LOOP") ?: "LOOP"
        set(value) = prefs.edit().putString("route_waiting_run_mode", value).apply()

    /** 录制的个人步态模板（GaitTemplate.encode() 的结果），空串表示未录制 */
    var gaitTemplate: String
        get() = prefs.getString(ConfigKeys.GAIT_TEMPLATE, "") ?: ""
        set(value) = prefs.edit().putString("gait_template", value).apply()

    var useGaitTemplate: Boolean
        get() = prefs.getBoolean(ConfigKeys.USE_GAIT_TEMPLATE, false)
        set(value) = prefs.edit().putBoolean("use_gait_template", value).apply()

    /** 打开 App 时地图停留在上次选定的位置，而不是自动跳到真实位置 */
    var keepLastMapPosition: Boolean
        get() = prefs.getBoolean(ConfigKeys.KEEP_LAST_MAP_POSITION, true)
        set(value) = prefs.edit().putBoolean("keep_last_map_position", value).apply()

    /**
     * 仅使用离线地图瓦片：禁止高德地图 SDK 发起在线地图请求。
     * 已下载城市仍可使用；未下载区域会空白。离线包下载时会临时联网。
     */
    var amapOfflineOnly: Boolean
        get() = prefs.getBoolean(ConfigKeys.AMAP_OFFLINE_ONLY, false)
        set(value) = prefs.edit().putBoolean("amap_offline_only", value).apply()

    var lastMapLat: String
        get() = prefs.getString(ConfigKeys.LAST_MAP_LAT, "") ?: ""
        set(value) = prefs.edit().putString("last_map_lat", value).apply()

    var lastMapLng: String
        get() = prefs.getString(ConfigKeys.LAST_MAP_LNG, "") ?: ""
        set(value) = prefs.edit().putString("last_map_lng", value).apply()

    var satelliteCount: String
        get() = prefs.getString(ConfigKeys.SATELLITE_COUNT, "20") ?: "20"
        set(value) = prefs.edit().putString("satellite_count", value).apply()

    fun getSavedLocations(): List<SavedLocation> {
        val jsonString = prefs.getString(ConfigKeys.SAVED_LOCATIONS, "[]") ?: "[]"
        val list = mutableListOf<SavedLocation>()
        try {
            val jsonArray = JSONArray(jsonString)
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                list.add(
                    SavedLocation(
                        name = obj.optString(ConfigKeys.NAME, ""),
                        lat = obj.optDouble(ConfigKeys.LAT, 0.0),
                        lng = obj.optDouble(ConfigKeys.LNG, 0.0),
                        wifiJson = obj.optString(ConfigKeys.WIFI_JSON, "[]"),
                        cellJson = obj.optString(ConfigKeys.CELL_JSON, "[]"),
                        bluetoothJson = obj.optString(ConfigKeys.BLUETOOTH_JSON, "[]"),
                        // 老版本写入的收藏没有这个 key，has() 为 false 时保持 null
                        sourceLocationId = if (obj.has(ConfigKeys.SOURCE_LOCATION_ID)) obj.optLong(ConfigKeys.SOURCE_LOCATION_ID) else null
                    )
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list
    }

    /**
     * 两条收藏是否视为"同一条"：都来自同一条采集记录（sourceLocationId 相同且非空）时按
     * 来源关联判断——这样编辑过采集点坐标也认得出来；否则退回按 name+lat+lng 精确匹配
     * （手动收藏、或老版本写入的没有来源 id 的收藏）。不能只按坐标匹配，那样会把同一坐标
     * 下其他名字/其他来源的收藏一并命中。
     */
    private fun isSameSavedLocation(a: SavedLocation, b: SavedLocation): Boolean {
        if (a.sourceLocationId != null && b.sourceLocationId != null) {
            return a.sourceLocationId == b.sourceLocationId
        }
        return a.name == b.name && a.lat == b.lat && a.lng == b.lng
    }

    fun addSavedLocation(location: SavedLocation) {
        val list = getSavedLocations().toMutableList()
        list.removeAll { isSameSavedLocation(it, location) }
        list.add(location)
        saveLocationList(list)
    }

    fun removeSavedLocation(location: SavedLocation) {
        val list = getSavedLocations().toMutableList()
        list.removeAll { isSameSavedLocation(it, location) }
        saveLocationList(list)
    }

    fun saveLocationList(list: List<SavedLocation>) {
        val jsonArray = JSONArray()
        list.forEach {
            val obj = JSONObject()
            obj.put(ConfigKeys.NAME, it.name)
            obj.put(ConfigKeys.LAT, it.lat)
            obj.put(ConfigKeys.LNG, it.lng)
            obj.put(ConfigKeys.WIFI_JSON, it.wifiJson)
            obj.put(ConfigKeys.CELL_JSON, it.cellJson)
            obj.put(ConfigKeys.BLUETOOTH_JSON, it.bluetoothJson)
            if (it.sourceLocationId != null) {
                obj.put(ConfigKeys.SOURCE_LOCATION_ID, it.sourceLocationId)
            }
            jsonArray.put(obj)
        }
        prefs.edit().putString("saved_locations", jsonArray.toString()).apply()
    }

    fun getSavedRoutes(): List<SavedRoute> {
        val jsonString = prefs.getString(ConfigKeys.SAVED_ROUTES, "[]") ?: "[]"
        val list = mutableListOf<SavedRoute>()
        try {
            val jsonArray = JSONArray(jsonString)
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                val pointsArray = obj.getJSONArray(ConfigKeys.POINTS)
                val points = (0 until pointsArray.length()).map { j ->
                    val p = pointsArray.getJSONObject(j)
                    RoutePoint(p.getDouble(ConfigKeys.LAT), p.getDouble(ConfigKeys.LNG))
                }
                list.add(SavedRoute(obj.getString(ConfigKeys.NAME), points))
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list
    }

    fun addSavedRoute(route: SavedRoute) {
        val list = getSavedRoutes().toMutableList()
        list.add(route)
        saveRouteList(list)
    }

    fun removeSavedRoute(route: SavedRoute) {
        val list = getSavedRoutes().toMutableList()
        list.removeAll { it.name == route.name }
        saveRouteList(list)
    }

    private fun saveRouteList(list: List<SavedRoute>) {
        val jsonArray = JSONArray()
        list.forEach { route ->
            val obj = JSONObject()
            obj.put(ConfigKeys.NAME, route.name)
            val pointsArray = JSONArray()
            route.points.forEach { p ->
                val pObj = JSONObject()
                pObj.put(ConfigKeys.LAT, p.lat)
                pObj.put(ConfigKeys.LNG, p.lng)
                pointsArray.put(pObj)
            }
            obj.put(ConfigKeys.POINTS, pointsArray)
            jsonArray.put(obj)
        }
        prefs.edit().putString("saved_routes", jsonArray.toString()).apply()
    }

    /** system_server 级定位 Hook（实验性）里被勾选生效的目标 App 包名集合 */
    fun getSystemHookPackages(): Set<String> {
        val jsonString = prefs.getString(ConfigKeys.SYSTEM_HOOK_PACKAGES, "[]") ?: "[]"
        val set = mutableSetOf<String>()
        try {
            val jsonArray = JSONArray(jsonString)
            for (i in 0 until jsonArray.length()) {
                set.add(jsonArray.getString(i))
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return set
    }

    fun setSystemHookPackages(packages: Set<String>) {
        val jsonArray = JSONArray()
        packages.forEach { jsonArray.put(it) }
        prefs.edit().putString("system_hook_packages", jsonArray.toString()).apply()
    }

    /** 是否开启全局模拟模式（除本应用与系统基础核心外对所有应用生效） */
    var isSystemHookGlobalMode: Boolean
        get() = prefs.getBoolean(ConfigKeys.IS_SYSTEM_HOOK_GLOBAL_MODE, true)
        set(value) = prefs.edit().putBoolean("is_system_hook_global_mode", value).apply()
    var forceLocationEnabled: Boolean
        get() = prefs.getBoolean(ConfigKeys.FORCE_LOCATION_ENABLED, false)
        set(value) = prefs.edit().putBoolean("force_location_enabled", value).apply()
}
