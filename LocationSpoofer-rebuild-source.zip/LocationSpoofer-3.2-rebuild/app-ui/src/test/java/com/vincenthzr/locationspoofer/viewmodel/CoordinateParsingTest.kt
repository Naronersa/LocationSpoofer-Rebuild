package com.vincenthzr.locationspoofer.viewmodel

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class CoordinateParsingTest {

    @Test
    fun asciiCoordinatesParse() {
        assertEquals(119.194996, "119.194996".toCoordinateOrNull()!!, 0.0)
        assertEquals(26.032962, "26.032962".toCoordinateOrNull()!!, 0.0)
    }

    @Test
    fun whitespaceIsTrimmed() {
        assertEquals(120.0, "  120.0  ".toCoordinateOrNull()!!, 0.0)
    }

    @Test
    fun arabicIndicDigitsAndDecimalSeparatorParse() {
        // ١١٩٫٥ = 119.5
        assertEquals(119.5, "١١٩٫٥".toCoordinateOrNull()!!, 0.0)
    }

    @Test
    fun persianDigitsParse() {
        // ۱۲۰ = 120
        assertEquals(120.0, "۱۲۰".toCoordinateOrNull()!!, 0.0)
    }

    @Test
    fun invalidAndBlankReturnNull() {
        assertNull("".toCoordinateOrNull())
        assertNull("   ".toCoordinateOrNull())
        assertNull("abc".toCoordinateOrNull())
        assertNull("12.3.4".toCoordinateOrNull())
    }
}
