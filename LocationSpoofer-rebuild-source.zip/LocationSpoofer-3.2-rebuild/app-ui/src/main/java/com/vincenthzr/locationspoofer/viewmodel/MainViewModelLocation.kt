package com.vincenthzr.locationspoofer.viewmodel

import com.vincenthzr.locationspoofer.utils.ConfigKeys

import android.content.Context
import java.util.Locale
import androidx.lifecycle.viewModelScope
import com.amap.api.location.AMapLocationClient
import com.amap.api.location.AMapLocationClientOption
import com.vincenthzr.locationspoofer.ui.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull

// MainViewModel 的当前位置获取、原生定位回退与模拟能力评估相关扩展函数

// 当前位置获取
internal fun MainViewModel.fetchCurrentLocation(ctx: Context, forceCallback: ((Double, Double) -> Unit)? = null) {
    viewModelScope.launch(Dispatchers.Main) {
        // 模拟中绝不能用真实定位覆盖模拟坐标。地图上的“我的位置”按钮在这里
        // 只把相机移回当前模拟点；输入框、lastSpoofed 和框架配置都保持不动。
        if (_uiState.value.isSpoofingActive) {
            val simLat = _uiState.value.latitudeInput.toCoordinateOrNull()
                ?: com.vincenthzr.locationspoofer.data.state.SpoofingState.latitude
            val simLng = _uiState.value.longitudeInput.toCoordinateOrNull()
                ?: com.vincenthzr.locationspoofer.data.state.SpoofingState.longitude
            if (simLat != 0.0 || simLng != 0.0) {
                forceCallback?.invoke(simLat, simLng)
            }
            return@launch
        }
        val client = try {
            AMapLocationClient(ctx.applicationContext)
        } catch (e: Exception) {
            fallbackToNativeLocation(ctx, forceCallback, true)
            return@launch
        }
        client.setLocationOption(AMapLocationClientOption().apply {
            locationMode = AMapLocationClientOption.AMapLocationMode.Hight_Accuracy
            isOnceLocation = true
            isNeedAddress = false // 禁用逆地理编码，防止因未开通Web服务导致 SERVICE_NOT_EXIST 鉴权错误
        })
        client.setLocationListener { loc ->
            if (loc != null && loc.errorCode == 0) {
                if (_uiState.value.longitudeInput.isEmpty() || _uiState.value.latitudeInput.isEmpty() || forceCallback != null) {
                    _uiState.update {
                        it.copy(
                            latitudeInput = String.format(Locale.US, "%.6f", loc.latitude),
                            longitudeInput = String.format(Locale.US, "%.6f", loc.longitude),
                            showCoordinateError = false
                        )
                    }
                    forceCallback?.invoke(loc.latitude, loc.longitude)
                }
            } else {
                // 如果鉴权失败(如 SERVICE_NOT_EXIST)或其他错误，回退到原生定位
                fallbackToNativeLocation(ctx, forceCallback, true)
            }
            client.stopLocation()
            client.onDestroy()
        }
        client.startLocation()
    }
}

@android.annotation.SuppressLint("MissingPermission")

private fun MainViewModel.fallbackToNativeLocation(
    ctx: Context,
    forceCallback: ((Double, Double) -> Unit)?,
    convertToGcj: Boolean
) {
    try {
        val locationManager =
            ctx.getSystemService(Context.LOCATION_SERVICE) as android.location.LocationManager
        // 上游 3.0.13：GPS 关闭再开启后优先用 GPS，且不把很久以前的缓存位置当成当前位置
        val provider = when {
            locationManager.isProviderEnabled(android.location.LocationManager.GPS_PROVIDER) ->
                android.location.LocationManager.GPS_PROVIDER

            locationManager.isProviderEnabled(android.location.LocationManager.NETWORK_PROVIDER) ->
                android.location.LocationManager.NETWORK_PROVIDER

            else -> null
        }
        if (provider == null) {
            if (forceCallback != null) {
                android.widget.Toast.makeText(
                    ctx,
                    ctx.getString(com.vincenthzr.locationspoofer.ui.R.string.waiting_gps_signal),
                    android.widget.Toast.LENGTH_LONG
                ).show()
            }
            return
        }

        val lastLoc = locationManager.getLastKnownLocation(provider)
        val fresh = lastLoc != null &&
            System.currentTimeMillis() - lastLoc.time <= 120_000L
        if (fresh) {
            applyNativeLocation(ctx, lastLoc, forceCallback, convertToGcj)
        } else if (forceCallback != null) {
            android.widget.Toast.makeText(
                ctx,
                ctx.getString(com.vincenthzr.locationspoofer.ui.R.string.waiting_gps_signal),
                android.widget.Toast.LENGTH_LONG
            ).show()
        }

        val listener = object : android.location.LocationListener {
            override fun onLocationChanged(location: android.location.Location) {
                if (forceCallback != null) {
                    android.widget.Toast.makeText(
                        ctx,
                        ctx.getString(com.vincenthzr.locationspoofer.ui.R.string.native_location_success),
                        android.widget.Toast.LENGTH_SHORT
                    ).show()
                }
                applyNativeLocation(ctx, location, forceCallback, convertToGcj)
                locationManager.removeUpdates(this)
            }

            override fun onStatusChanged(
                provider: String?,
                status: Int,
                extras: android.os.Bundle?
            ) {
            }

            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}
        }
        locationManager.requestSingleUpdate(
            provider,
            listener,
            android.os.Looper.getMainLooper()
        )
    } catch (e: SecurityException) {
        if (forceCallback != null) {
            android.widget.Toast.makeText(
                ctx,
                ctx.getString(com.vincenthzr.locationspoofer.ui.R.string.location_permission_denied),
                android.widget.Toast.LENGTH_SHORT
            ).show()
        }
    } catch (e: Exception) {
        e.printStackTrace()
    }
}

private fun MainViewModel.applyNativeLocation(
    ctx: Context,
    location: android.location.Location,
    forceCallback: ((Double, Double) -> Unit)?,
    convertToGcj: Boolean
) {
    var finalLat = location.latitude
    var finalLng = location.longitude

    if (convertToGcj) {
        val converter = com.amap.api.maps.CoordinateConverter(ctx).apply {
            from(com.amap.api.maps.CoordinateConverter.CoordType.GPS)
            coord(com.amap.api.maps.model.LatLng(location.latitude, location.longitude))
        }
        val gcj = converter.convert()
        finalLat = gcj.latitude
        finalLng = gcj.longitude
    }

    if (_uiState.value.longitudeInput.isEmpty() || _uiState.value.latitudeInput.isEmpty() || forceCallback != null) {
        _uiState.update {
            it.copy(
                latitudeInput = String.format(Locale.US, "%.6f", finalLat),
                longitudeInput = String.format(Locale.US, "%.6f", finalLng),
                showCoordinateError = false
            )
        }
        forceCallback?.invoke(finalLat, finalLng)
    }
}

internal suspend fun MainViewModel.fetchRealLocationSilent(ctx: Context): Pair<Double, Double>? {
    val amapResult = withTimeoutOrNull(15_000) {
        suspendCancellableCoroutine<Pair<Double, Double>?> { cont ->
            val client = try {
                AMapLocationClient(ctx.applicationContext)
            } catch (error: Exception) {
                cont.resume(null)
                return@suspendCancellableCoroutine
            }
            fun closeClient() {
                runCatching { client.stopLocation(); client.onDestroy() }
            }
            cont.invokeOnCancellation { closeClient() }
            client.setLocationOption(AMapLocationClientOption().apply {
                locationMode = AMapLocationClientOption.AMapLocationMode.Hight_Accuracy
                isOnceLocation = true
                isNeedAddress = false
            })
            client.setLocationListener { location ->
                closeClient()
                if (cont.isActive) {
                    cont.resume(if (location != null && location.errorCode == 0) {
                        location.latitude to location.longitude
                    } else null)
                }
            }
            if (cont.isActive) client.startLocation() else closeClient()
        }
    }
    return amapResult ?: fallbackToNativeLocationSilent(ctx, true)
}

@android.annotation.SuppressLint("MissingPermission")
private suspend fun MainViewModel.fallbackToNativeLocationSilent(
    ctx: Context,
    convertToGcj: Boolean
): Pair<Double, Double>? = withTimeoutOrNull(5_000) {
    suspendCancellableCoroutine { cont ->
        val locationManager = ctx.getSystemService(Context.LOCATION_SERVICE) as android.location.LocationManager
        var listener: android.location.LocationListener? = null
        cont.invokeOnCancellation { listener?.let { runCatching { locationManager.removeUpdates(it) } } }
        try {
            val provider = when {
                locationManager.isProviderEnabled(android.location.LocationManager.NETWORK_PROVIDER) -> android.location.LocationManager.NETWORK_PROVIDER
                locationManager.isProviderEnabled(android.location.LocationManager.GPS_PROVIDER) -> android.location.LocationManager.GPS_PROVIDER
                else -> {
                    cont.resume(null)
                    return@suspendCancellableCoroutine
                }
            }
            val lastLocation = locationManager.getLastKnownLocation(provider)
            if (lastLocation != null) {
                cont.resume(getNativeConverted(ctx, lastLocation, convertToGcj))
                return@suspendCancellableCoroutine
            }
            val callback = object : android.location.LocationListener {
                override fun onLocationChanged(location: android.location.Location) {
                    locationManager.removeUpdates(this)
                    if (cont.isActive) cont.resume(getNativeConverted(ctx, location, convertToGcj))
                }
                override fun onStatusChanged(provider: String?, status: Int, extras: android.os.Bundle?) {}
                override fun onProviderEnabled(provider: String) {}
                override fun onProviderDisabled(provider: String) {}
            }
            listener = callback
            locationManager.requestSingleUpdate(provider, callback, android.os.Looper.getMainLooper())
            if (!cont.isActive) locationManager.removeUpdates(callback)
        } catch (error: Exception) {
            listener?.let { runCatching { locationManager.removeUpdates(it) } }
            if (cont.isActive) cont.resume(null)
        }
    }
}

private fun MainViewModel.getNativeConverted(
    ctx: Context,
    location: android.location.Location,
    convertToGcj: Boolean
): Pair<Double, Double> {
    var finalLat = location.latitude
    var finalLng = location.longitude
    if (convertToGcj) {
        val converter = com.amap.api.maps.CoordinateConverter(ctx).apply {
            from(com.amap.api.maps.CoordinateConverter.CoordType.GPS)
            coord(com.amap.api.maps.model.LatLng(location.latitude, location.longitude))
        }
        val gcj = converter.convert()
        finalLat = gcj.latitude
        finalLng = gcj.longitude
    }
    return Pair(finalLat, finalLng)
}

// 坐标输入
internal fun MainViewModel.updateLongitude(value: String) {
    if (isValidCoord(value)) {
        _uiState.update { it.copy(longitudeInput = value, showCoordinateError = false) }
        evaluateMockCapabilities()
    }
}

internal fun MainViewModel.updateLatitude(value: String) {
    if (isValidCoord(value)) {
        _uiState.update { it.copy(latitudeInput = value, showCoordinateError = false) }
        evaluateMockCapabilities()
    }
}

private fun MainViewModel.isValidCoord(value: String): Boolean {
    if (value.isEmpty() || value == "-") return true
    return value.toDoubleOrNull() != null
}

internal fun MainViewModel.evaluateMockCapabilities() {
    mockCapabilitiesJob?.cancel()
    val state = _uiState.value
    val lat = state.latitudeInput.toCoordinateOrNull()
    val lng = state.longitudeInput.toCoordinateOrNull()

    if (lat == null || lng == null) {
        _uiState.update {
            it.copy(
                canMockWifi = false,
                canMockCell = false,
                canMockBluetooth = false,
                collectedWifiJson = "[]",
                collectedCellJson = "[]",
                collectedBluetoothJson = "[]",
                wifiApCount = 0,
                wifiLoadStatus = com.vincenthzr.locationspoofer.data.model.WifiLoadStatus.IDLE
            )
        }
        return
    }

    mockCapabilitiesJob = viewModelScope.launch {
        evaluateMockCapabilitiesSuspend(lat, lng)
    }
}

internal fun MainViewModel.selectCollectedLocation(locationId: Long) {
    viewModelScope.launch {
        val record = withContext(Dispatchers.IO) {
            environmentDao.getCompleteLocationById(locationId)
        }
        if (record != null) {
            pinnedLocationRecordId = locationId
            val name = when {
                record.location.remark.isNotBlank() -> record.location.remark
                record.location.placeName.isNotBlank() -> record.location.placeName
                else -> String.format(Locale.US, "(%.5f, %.5f)", record.location.lat, record.location.lng)
            }
            _uiState.update {
                it.copy(
                    latitudeInput = record.location.lat.toString(),
                    longitudeInput = record.location.lng.toString(),
                    selectedCollectionRouteId = null,
                    pinnedCollectedLocationId = locationId,
                    pinnedLocationName = name
                )
            }
            evaluateMockCapabilitiesSuspend(record.location.lat, record.location.lng)
        }
    }
}

internal fun MainViewModel.clearPinnedCollectedLocation() {
    pinnedLocationRecordId = null
    _uiState.update {
        it.copy(
            pinnedCollectedLocationId = null,
            pinnedLocationName = null
        )
    }
    evaluateMockCapabilities()
}

private fun MainViewModel.calculateDistanceMeters(lat1: Double, lng1: Double, lat2: Double, lng2: Double): Double {
    val dLat = Math.toRadians(lat2 - lat1)
    val dLng = Math.toRadians(lng2 - lng1)
    val a = kotlin.math.sin(dLat / 2).let { it * it } +
            kotlin.math.cos(Math.toRadians(lat1)) *
            kotlin.math.cos(Math.toRadians(lat2)) *
            kotlin.math.sin(dLng / 2).let { it * it }
    return 2 * 6378137.0 * kotlin.math.atan2(kotlin.math.sqrt(a), kotlin.math.sqrt(1 - a))
}

internal suspend fun MainViewModel.evaluateMockCapabilitiesSuspend(lat: Double, lng: Double) {
    val currentPinnedId = pinnedLocationRecordId
    var pinnedRecord: com.vincenthzr.locationspoofer.data.db.CompleteLocation? = null

    if (currentPinnedId != null) {
        val pinned = withContext(Dispatchers.IO) {
            environmentDao.getCompleteLocationById(currentPinnedId)
        }
        if (pinned != null) {
            val distToPinned = calculateDistanceMeters(lat, lng, pinned.location.lat, pinned.location.lng)
            if (distToPinned <= 50.0) {
                pinnedRecord = pinned
            } else {
                // 超出 50 米有效范围，自动解除锁定
                pinnedLocationRecordId = null
                withContext(Dispatchers.Main) {
                    _uiState.update {
                        it.copy(
                            pinnedCollectedLocationId = null,
                            pinnedLocationName = null
                        )
                    }
                }
            }
        } else {
            pinnedLocationRecordId = null
            withContext(Dispatchers.Main) {
                _uiState.update {
                    it.copy(
                        pinnedCollectedLocationId = null,
                        pinnedLocationName = null
                    )
                }
            }
        }
    }

    val validRecords = environmentRecordsAt(lat, lng).toMutableList()

    // 若用户当前明确锁定了某个 50m 内的采集点，则将其置于首位最高优先级
    if (pinnedRecord != null) {
        validRecords.removeAll { it.location.id == pinnedRecord.location.id }
        validRecords.add(0, pinnedRecord)
    }

    withContext(Dispatchers.Main) {
        val current = _uiState.value
        if (current.latitudeInput.toCoordinateOrNull() != lat || current.longitudeInput.toCoordinateOrNull() != lng) {
            return@withContext
        }
        if (validRecords.isEmpty()) {
            _uiState.update {
                it.copy(
                    canMockWifi = false,
                    canMockCell = false,
                    canMockBluetooth = false,
                    collectedWifiJson = "[]",
                    collectedCellJson = "[]",
                    collectedBluetoothJson = "[]",
                    wifiApCount = 0,
                    wifiLoadStatus = com.vincenthzr.locationspoofer.data.model.WifiLoadStatus.IDLE
                )
            }
        } else {
            val (wifiJson, cellJson, btJson) = locationToJson(validRecords, lat, lng)
            val hasW = try {
                val obj = org.json.JSONObject(wifiJson)
                val nearby = obj.optJSONArray(ConfigKeys.NEARBY_WIFI)
                val connected = obj.opt("connectedWifi")
                (nearby != null && nearby.length() > 0) || (connected != null && !obj.isNull(ConfigKeys.CONNECTED_WIFI))
            } catch (e: Exception) {
                false
            }
            val hasC = try {
                val arr = org.json.JSONArray(cellJson)
                arr.length() > 0
            } catch (e: Exception) {
                false
            }
            val hasB = try {
                val arr = org.json.JSONArray(btJson)
                arr.length() > 0
            } catch (e: Exception) {
                false
            }

            val wifiCount = parseWifiCount(wifiJson)

            _uiState.update {
                it.copy(
                    canMockWifi = hasW,
                    canMockCell = hasC,
                    canMockBluetooth = hasB,
                    collectedWifiJson = wifiJson,
                    collectedCellJson = cellJson,
                    collectedBluetoothJson = btJson,
                    wifiApCount = wifiCount,
                    wifiLoadStatus = if (hasW) com.vincenthzr.locationspoofer.data.model.WifiLoadStatus.DONE else com.vincenthzr.locationspoofer.data.model.WifiLoadStatus.IDLE
                )
            }
        }
    }
}

internal suspend fun MainViewModel.hasLocalWifiWithin50m(lat: Double, lng: Double): Boolean =
    environmentRecordsAt(lat, lng).any { it.wifis.isNotEmpty() || it.connectedWifi != null }

internal suspend fun MainViewModel.hasLocalCellsWithin50m(lat: Double, lng: Double): Boolean =
    environmentRecordsAt(lat, lng).any { it.cells.isNotEmpty() }

internal suspend fun MainViewModel.fetchWifiFromWigleSync(lat: Double, lng: Double) {
    val settingsToken = settingsRepository.getWigleApiToken()
    if (settingsToken.isBlank()) {
        withContext(Dispatchers.Main) {
            _uiState.update {
                it.copy(
                    wifiLoadStatus = com.vincenthzr.locationspoofer.data.model.WifiLoadStatus.IDLE,
                    wifiApCount = 0,
                    canMockWifi = false
                )
            }
        }
        return
    }

    withContext(Dispatchers.Main) {
        _uiState.update { it.copy(wifiLoadStatus = com.vincenthzr.locationspoofer.data.model.WifiLoadStatus.LOADING) }
    }
    // 将坐标转换对齐至 WGS-84 标准以用于 WiGLE API
    val wgs84 = com.vincenthzr.locationspoofer.utils.CoordinateUtils.gcj02ToWgs84(lat, lng)
    val wgsLat = wgs84.lat
    val wgsLng = wgs84.lng

    try {
        val rawJsonArrayString = wifiRepository.fetchWifiData(wgsLat, wgsLng, settingsToken)
        val nearbyArr = org.json.JSONArray(rawJsonArrayString)
        if (nearbyArr.length() > 0) {
            val wifiObj = org.json.JSONObject()
            wifiObj.put(ConfigKeys.IS_CONNECTED, true)

            val firstAp = nearbyArr.getJSONObject(0)
            val firstBssid = firstAp.optString(ConfigKeys.BSSID)
            val firstSsid = firstAp.optString(ConfigKeys.SSID)

            val connObj = org.json.JSONObject().apply {
                put(ConfigKeys.BSSID, firstBssid)
                put(ConfigKeys.SSID, firstSsid)
                put(ConfigKeys.VENDOR,
                    com.vincenthzr.locationspoofer.utils.MacVendorHelper.getVendor(firstBssid)
                )
                put(ConfigKeys.LEVEL, -45)
                put(ConfigKeys.FREQUENCY, 2412)
                put(ConfigKeys.CHANNEL, 1)
                put(ConfigKeys.CAPABILITIES, "[WPA2-PSK-CCMP][ESS]")
                put(ConfigKeys.MAC_ADDRESS, "02:00:00:00:00:00")
                put(ConfigKeys.LINK_SPEED, 150)
                put(ConfigKeys.NETWORK_ID, 1)
                put(ConfigKeys.WIFI_STANDARD, 4)
            }
            wifiObj.put(ConfigKeys.CONNECTED_WIFI, connObj)

            val formattedNearby = org.json.JSONArray()
            for (i in 0 until nearbyArr.length()) {
                val ap = nearbyArr.getJSONObject(i)
                val bssid = ap.optString(ConfigKeys.BSSID)
                val ssid = ap.optString(ConfigKeys.SSID)
                val level = -50 - (i * 2)
                val freq = if (i % 2 == 0) 2412 else 5180

                val itemObj = org.json.JSONObject().apply {
                    put(ConfigKeys.BSSID, bssid)
                    put(ConfigKeys.SSID, ssid)
                    put(ConfigKeys.VENDOR,
                        com.vincenthzr.locationspoofer.utils.MacVendorHelper.getVendor(bssid)
                    )
                    put(ConfigKeys.LEVEL, level)
                    put(ConfigKeys.CAPABILITIES, "[WPA2-PSK-CCMP][ESS]")
                    put(ConfigKeys.FREQUENCY, freq)
                    put(ConfigKeys.CHANNEL,
                        com.vincenthzr.locationspoofer.utils.MacVendorHelper.frequencyToChannel(
                            freq
                        )
                    )
                }
                formattedNearby.put(itemObj)
            }
            wifiObj.put(ConfigKeys.NEARBY_WIFI, formattedNearby)

            val formattedWifiJson = wifiObj.toString()

            withContext(Dispatchers.IO) {
                saveEnvironmentData(lat, lng, formattedWifiJson, "[]", "[]")
                // 更新 metadata 以指示 WiGLE 来源
                val newestLocation = environmentDao.getAllLocations()
                    .firstOrNull { it.lat == lat && it.lng == lng }
                if (newestLocation != null) {
                    val latLngPrefix = context.getString(R.string.lat_lng_format_prefix)
                    environmentDao.updateMetadata(
                        newestLocation.id,
                        lat,
                        lng,
                        context.getString(R.string.wigle_import),
                        "$latLngPrefix (${String.format(Locale.US, "%.6f", lat)}, ${
                            String.format(
                                "%.6f",
                                lng
                            )
                        })",
                        null, null, null
                    )
                }
            }

            withContext(Dispatchers.Main) {
                evaluateMockCapabilities()
                // 刷新记录统计总数
                viewModelScope.launch(Dispatchers.IO) {
                    val count = environmentDao.getRecordCount()
                    _uiState.update { it.copy(environmentRecordCount = count) }
                }
            }
        } else {
            withContext(Dispatchers.Main) {
                _uiState.update {
                    it.copy(
                        wifiLoadStatus = com.vincenthzr.locationspoofer.data.model.WifiLoadStatus.IDLE,
                        wifiApCount = 0,
                        canMockWifi = false
                    )
                }
            }
        }
    } catch (e: Exception) {
        e.printStackTrace()
        withContext(Dispatchers.Main) {
            _uiState.update {
                it.copy(
                    wifiLoadStatus = com.vincenthzr.locationspoofer.data.model.WifiLoadStatus.IDLE,
                    wifiApCount = 0,
                    canMockWifi = false
                )
            }
        }
    }
}

internal suspend fun MainViewModel.fetchCellFromOpenCellIdSync(lat: Double, lng: Double) {
    val tokenToUse = settingsRepository.getOpencellidApiToken()
    if (tokenToUse.isBlank()) {
        return
    }
    val wgs84 = com.vincenthzr.locationspoofer.utils.CoordinateUtils.gcj02ToWgs84(lat, lng)
    val wgsLat = wgs84.lat
    val wgsLng = wgs84.lng

    try {
        val rawJsonArrayString = opencellidClient.fetchCellData(wgsLat, wgsLng, tokenToUse)
        val cellsArray = org.json.JSONArray(rawJsonArrayString)
        if (cellsArray.length() > 0) {
            val formattedCells = normalizeCellArrayForStorage(cellsArray)
            if (formattedCells.length() == 0) {
                return
            }

            withContext(Dispatchers.IO) {
                saveEnvironmentData(lat, lng, "{}", formattedCells.toString(), "[]")
                val newestLocation = environmentDao.getAllLocations()
                    .firstOrNull { it.lat == lat && it.lng == lng }
                if (newestLocation != null) {
                    val latLngPrefix = context.getString(R.string.lat_lng_format_prefix)
                    environmentDao.updateMetadata(
                        newestLocation.id,
                        lat,
                        lng,
                        context.getString(R.string.opencellid_import),
                        "$latLngPrefix (${String.format(Locale.US, "%.6f", lat)}, ${
                            String.format(
                                "%.6f",
                                lng
                            )
                        })",
                        null, null, null
                    )
                }
            }

            withContext(Dispatchers.Main) {
                evaluateMockCapabilities()
                // 刷新记录统计总数
                viewModelScope.launch(Dispatchers.IO) {
                    val count = environmentDao.getRecordCount()
                    _uiState.update { it.copy(environmentRecordCount = count) }
                }
            }
        }
    } catch (e: Exception) {
        e.printStackTrace()
    }
}

/**
 * 坐标输入解析：阿拉伯语/波斯语 Locale 下系统键盘和 String.format 可能产生
 * 阿拉伯-印度数字（U+0660..U+0669）、波斯数字（U+06F0..U+06F9）以及阿拉伯
 * 小数点 U+066B。Double.parseDouble 只接受 ASCII，直接 toDoubleOrNull() 会
 * 返回 null，导致“自动定位/地图选点后无法开始模拟”。这里先归一化成 ASCII。
 */
internal fun String.toCoordinateOrNull(): Double? {
    if (isBlank()) return null
    // Important: the buildString lambda receiver is the empty StringBuilder.
    // Calling trim() inside the lambda trims that empty builder, so the
    // normalized string stays empty. Trim the source string outside first.
    val trimmed = trim()
    val normalized = buildString(trimmed.length) {
        for (ch in trimmed) {
            when (ch) {
                in '\u0660'..'\u0669' -> append('0' + (ch - '\u0660'))
                in '\u06F0'..'\u06F9' -> append('0' + (ch - '\u06F0'))
                '\u066B' -> append('.')
                '\u066C' -> Unit
                else -> append(ch)
            }
        }
    }
    return normalized.toDoubleOrNull()
}
