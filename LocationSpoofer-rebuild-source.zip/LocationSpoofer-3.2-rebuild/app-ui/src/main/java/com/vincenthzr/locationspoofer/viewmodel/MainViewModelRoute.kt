package com.vincenthzr.locationspoofer.viewmodel

import com.vincenthzr.locationspoofer.utils.ConfigKeys

import com.vincenthzr.locationspoofer.data.motion.MotionController
import java.util.Locale
import androidx.lifecycle.viewModelScope
import com.vincenthzr.locationspoofer.ui.R
import com.vincenthzr.locationspoofer.data.model.AppState
import com.vincenthzr.locationspoofer.data.model.RoutePoint
import com.vincenthzr.locationspoofer.data.model.RoutePlanStage
import com.vincenthzr.locationspoofer.data.model.RouteRunMode
import com.vincenthzr.locationspoofer.data.model.SavedLocation
import com.vincenthzr.locationspoofer.data.model.SimMode
import com.vincenthzr.locationspoofer.data.state.SpoofingState
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

// MainViewModel 的路线规划、收藏位置/路线与自动巡航相关扩展函数

/** 地图中心确认添加路点 */

internal fun MainViewModel.addRoutePoint(lat: Double, lng: Double) {
    _uiState.update { it.copy(routePoints = it.routePoints + RoutePoint(lat, lng)) }
}

/** 撤销最后一个路点 */

internal fun MainViewModel.undoLastRoutePoint() {
    _uiState.update { state ->
        if (state.routePoints.isEmpty()) state
        else state.copy(routePoints = state.routePoints.dropLast(1))
    }
}

/** 结束选点 → READY */

internal fun MainViewModel.finishSelectingPoints() {
    if (_uiState.value.routePoints.size < 2) return
    _uiState.update { it.copy(routePlanStage = RoutePlanStage.READY) }
}

/** 重新选点：清空路点，回到 SELECTING */

internal fun MainViewModel.restartSelectingPoints() {
    _uiState.update {
        it.copy(
            routePoints = emptyList(),
            routePlanStage = RoutePlanStage.SELECTING,
            selectedCollectionRouteId = null
        )
    }
}

/** 设置路线运行模式 */

internal fun MainViewModel.setRouteRunMode(mode: RouteRunMode) {
    _uiState.update { it.copy(routeRunMode = mode) }
}

internal fun MainViewModel.saveRoute(name: String, points: List<RoutePoint>) {
    viewModelScope.launch(Dispatchers.IO) {
        locationRepository.insertSavedRoute(name, points)
    }
}

internal fun MainViewModel.deleteSavedRoute(route: com.vincenthzr.locationspoofer.data.model.SavedRoute) {
    viewModelScope.launch(Dispatchers.IO) {
        // 上游 3.0.17：优先按唯一标识删除，避免同名路线误删；旧数据没有 syncId 时回退按名称。
        if (route.syncId.isNotEmpty()) {
            locationRepository.deleteSavedRouteBySyncId(route.syncId)
        } else {
            val routes = locationRepository.getSavedRoutes().first()
            routes.find { it.name == route.name }?.let { locationRepository.deleteSavedRoute(it) }
        }
    }
}

/** 设置循环模式速度 */

internal fun MainViewModel.setRouteSimMode(mode: SimMode) {
    _uiState.update { it.copy(routeSimMode = mode) }
}

/** 设置自定义速度 (m/s) */

internal fun MainViewModel.setCustomSpeedMs(speed: Double) {
    _uiState.update { it.copy(customSpeedMs = speed.coerceIn(0.1, 30.0)) }
}

/** 获取实际生效的速度 (m/s) */

private fun MainViewModel.getEffectiveSpeedMs(): Double {
    val state = _uiState.value
    return if (state.routeSimMode == SimMode.CUSTOM) state.customSpeedMs
    else state.routeSimMode.speedMs
}

/** 摇杆推满时的速度；自定义速度未填或为 0 时回退到步行速度，避免摇杆推不动 */
internal fun MainViewModel.joystickMaxSpeedMs(): Float =
    getEffectiveSpeedMs().takeIf { it > 0.0 }?.toFloat() ?: SimMode.WALKING.speedMs.toFloat()

/** 首页地图确认选点 */

internal fun MainViewModel.confirmMapPoint(lat: Double, lng: Double, isDragging: Boolean = false) {
    // 路线/手动路线运行期间，地图拖动和程序化相机移动都不能把路线改成
    // STILL 定点。否则目标 App 会停在拖动点，而路线页仍显示 RUNNING。
    // 需要改点时应先停止路线模拟。
    if (_uiState.value.routePlanStage == RoutePlanStage.RUNNING) return
    _uiState.update {
        it.copy(
            latitudeInput = String.format(Locale.US, "%.6f", lat),
            longitudeInput = String.format(Locale.US, "%.6f", lng),
            mapConfirmedPoint = Pair(lat, lng),
            showCoordinateError = false
        )
    }
    evaluateMockCapabilities()
    val state = _uiState.value
    if (state.isSpoofingActive) {
        settingsRepository.lastSpoofedLat = lat.toString()
        settingsRepository.lastSpoofedLng = lng.toString()
        mapConfirmJob?.cancel()
        mapConfirmJob = viewModelScope.launch {
            if (state.mockWifi && !hasLocalWifiWithin50m(lat, lng) && !isDragging) {
                fetchWifiFromWigleSync(lat, lng)
            }
            if (state.mockCell && !hasLocalCellsWithin50m(lat, lng) && !isDragging) {
                fetchCellFromOpenCellIdSync(lat, lng)
            }
            evaluateMockCapabilitiesSuspend(lat, lng)
            // 网络请求可能持续数秒；期间用户可能已经 Stop。
            // updateConfig 会硬编码 active=true，必须先复查。
            if (!_uiState.value.isSpoofingActive ||
                _uiState.value.routePlanStage == RoutePlanStage.RUNNING
            ) return@launch
            val updatedState = _uiState.value
            locationRepository.updateConfig(
                lat = lat,
                lng = lng,
                simMode = "STILL",
                simBearing = 0f,
                startTime = SpoofingState.startTimestamp,
                routePoints = emptyList(),
                isRouteMode = false,
                wifiJson = updatedState.collectedWifiJson,
                cellJson = updatedState.collectedCellJson,
                bluetoothJson = updatedState.collectedBluetoothJson,
                mockWifi = updatedState.mockWifi && updatedState.canMockWifi,
                mockCell = updatedState.mockCell,
                mockBluetooth = updatedState.mockBluetooth && updatedState.canMockBluetooth,
                enableJitter = updatedState.enableJitter
            )
            motionController.onStaticStarted(lat, lng)
        }
    }
}

/** 清除地图选点状态 */

internal fun MainViewModel.setUseRealRoute(use: Boolean) {
    _uiState.update { it.copy(useRealRoute = use) }
}

internal fun MainViewModel.setStopAtDestination(stop: Boolean) {
    _uiState.update { it.copy(stopAtDestination = stop) }
}

internal fun MainViewModel.setEnableStepSimulation(enable: Boolean) {
    _uiState.update { it.copy(enableStepSimulation = enable) }
}

internal fun MainViewModel.setStepCadenceSpm(spm: Int) {
    _uiState.update { it.copy(stepCadenceSpm = spm) }
}

internal fun MainViewModel.setIsAutoCadence(auto: Boolean) {
    _uiState.update { it.copy(isAutoCadence = auto) }
}

/**
 * 开始路线模拟。
 * - 手动模式：路线以暂停状态开始并自动打开悬浮摇杆，摇杆自由移动，点"开始"后沿路线前进。
 * - 循环模式：启动 spoofing，自动沿路线点按速度移动，到终点后反向循环。
 */

internal fun MainViewModel.startRoutePlanning() {
    val state = _uiState.value
    if (state.isContinuousScanning || state.isStoppingCollection) {
        android.widget.Toast.makeText(
            context,
            context.getString(com.vincenthzr.locationspoofer.ui.R.string.disable_continuous_scan_route_first),
            android.widget.Toast.LENGTH_SHORT
        ).show()
        return
    }
    if (state.routePoints.size < 2) return
    // 手动模式完全靠悬浮摇杆操作，没有悬浮窗权限就不启动，免得路线停在起点无法控制
    if (state.routeRunMode == RouteRunMode.MANUAL && !ensureOverlayPermission()) return

    if (state.useRealRoute) {
        _uiState.update { it.copy(isFetchingRoute = true) }
        fetchRealRouteAndStart(state.routePoints, state)
    } else {
        startRouteAtStartPoint(state.routePoints)
    }
}

private fun MainViewModel.fetchRealRouteAndStart(points: List<RoutePoint>, state: AppState) {
    viewModelScope.launch(Dispatchers.IO) {
        try {
            com.amap.api.services.core.ServiceSettings.updatePrivacyShow(context, true, true)
            com.amap.api.services.core.ServiceSettings.updatePrivacyAgree(context, true)

            val routeSearch = com.amap.api.services.route.RouteSearch(context)
            val allRealPoints = mutableListOf<RoutePoint>()
            var hasError = false

            for (i in 0 until points.size - 1) {
                // 从起点到终点，中间点作为途经点
                val start = com.amap.api.services.core.LatLonPoint(points[i].lat, points[i].lng)
                val end =
                    com.amap.api.services.core.LatLonPoint(points[i + 1].lat, points[i + 1].lng)
                val fromAndTo = com.amap.api.services.route.RouteSearch.FromAndTo(start, end)

                // 创建驾车路线查询 (0: 速度优先，不考虑路况)
                val query = com.amap.api.services.route.RouteSearch.DriveRouteQuery(
                    fromAndTo,
                    com.amap.api.services.route.RouteSearch.DrivingDefault,
                    null,
                    null,
                    ""
                )

                val result = routeSearch.calculateDriveRoute(query)
                if (result != null && result.paths.isNotEmpty()) {
                    val path = result.paths[0]
                    val segmentPoints = mutableListOf<RoutePoint>()
                    val stepEndIndices = mutableListOf<Int>()
                    for (step in path.steps) {
                        for (polyline in step.polyline) {
                            segmentPoints.add(
                                RoutePoint(
                                    polyline.latitude,
                                    polyline.longitude,
                                    0.0
                                )
                            )
                        }
                        if (segmentPoints.isNotEmpty()) {
                            stepEndIndices.add(segmentPoints.size - 1)
                        }
                    }
                    val trafficLights = path.totalTrafficlights
                    if (trafficLights > 0 && stepEndIndices.isNotEmpty()) {
                        stepEndIndices.shuffled().take(trafficLights).forEach { idx ->
                            segmentPoints[idx] = segmentPoints[idx].copy(waitSec = 15.0)
                        }
                    }
                    allRealPoints.addAll(segmentPoints)
                } else {
                    hasError = true
                    break
                }
            }

            if (!hasError && allRealPoints.isNotEmpty()) {
                withContext(Dispatchers.Main) {
                    _uiState.update { it.copy(isFetchingRoute = false) }
                    startRouteAtStartPoint(allRealPoints)
                }
            } else {
                withContext(Dispatchers.Main) {
                    _uiState.update { it.copy(isFetchingRoute = false) }
                    android.widget.Toast.makeText(
                        context,
                        context.getString(R.string.route_plan_failed_fallback_straight),
                        android.widget.Toast.LENGTH_SHORT
                    ).show()
                    startRouteAtStartPoint(points)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            withContext(Dispatchers.Main) {
                _uiState.update { it.copy(isFetchingRoute = false) }
                var msg = context.getString(R.string.route_request_exception, e.message ?: "")
                if (e is com.amap.api.services.core.AMapException) {
                    val errCode = e.errorCode
                    val errMsg = e.errorMessage ?: ""
                    msg = context.getString(R.string.amap_api_exception_format, errCode, errMsg)
                    if (errCode == 10003 || errCode == 10012 || errCode == 10013 || errCode == 1800 || errCode == 18000 ||
                        errMsg.contains("额度") || errMsg.contains("limit", ignoreCase = true)
                    ) {
                        msg = context.getString(R.string.amap_quota_exhausted_fallback_format, errMsg)
                    }
                }
                android.widget.Toast.makeText(context, msg, android.widget.Toast.LENGTH_LONG)
                    .show()
                startRouteAtStartPoint(points)
            }
        }
    }
}

private fun MainViewModel.startRouteAtStartPoint(pointsToRun: List<RoutePoint>) {
    // 上游 3.0.17：实际路线录制与定位模拟互斥
    if (physicalRouteRecorder.state.value.recording) {
        android.widget.Toast.makeText(
            context,
            context.getString(R.string.physical_route_stop_before_simulation),
            android.widget.Toast.LENGTH_SHORT
        ).show()
        return
    }
    val startPoint = pointsToRun.first()

    _uiState.update {
        it.copy(
            latitudeInput = String.format(Locale.US, "%.6f", startPoint.lat),
            longitudeInput = String.format(Locale.US, "%.6f", startPoint.lng),
            routePlanStage = RoutePlanStage.RUNNING,
            routePoints = pointsToRun,
            routeWaitingToStart = true
        )
    }

    settingsRepository.setRouteWaitingState(
        pointsToRun,
        _uiState.value.routeSimMode.name,
        _uiState.value.customSpeedMs,
        _uiState.value.routeRunMode.name
    )
    val now = System.currentTimeMillis()
    settingsRepository.isSpoofingActive = true
    settingsRepository.lastSpoofedLat = startPoint.lat.toString()
    settingsRepository.lastSpoofedLng = startPoint.lng.toString()
    SpoofingState.startTimestamp = now
    SpoofingState.latitude = startPoint.lat
    SpoofingState.longitude = startPoint.lng
    SpoofingState.simBearing = 0f
    SpoofingState.routeDistanceOffset = 0.0

    // 本地点位/路线采集先同步就绪，起点静态模拟立即有环境数据。
    routeEnvironmentReplay.prepareLocal(pointsToRun, environmentLocations.value)

    routePreviewJob?.cancel()
    routePreviewJob = viewModelScope.launch {
        try {
        // 配置必须来自路线起点，避免将此前地图位置的环境数据带入起点。
        val records = environmentRecordsAt(startPoint.lat, startPoint.lng)
        val fallback = locationToJson(records, startPoint.lat, startPoint.lng)
        val replayWifi = routeEnvironmentReplay.buildWifiJson(startPoint.lat, startPoint.lng)
        val replayCell = routeEnvironmentReplay.buildCellJson(startPoint.lat, startPoint.lng)
        val wifi = replayWifi.takeIf { it != "{}" } ?: fallback.first
        val cell = replayCell.takeIf { it != "[]" } ?: fallback.second
        val bluetooth = fallback.third
        android.util.Log.i(
            "EnvReplay",
            "route start environment: ${routeEnvironmentReplay.summary()} " +
                "wifiSelected=${runCatching { org.json.JSONObject(wifi).optJSONArray(ConfigKeys.NEARBY_WIFI)?.length() ?: 0 }.getOrDefault(0)} " +
                "cellSelected=${runCatching { org.json.JSONArray(cell).length() }.getOrDefault(0)}"
        )
        _uiState.update { it.copy(collectedWifiJson = wifi, collectedCellJson = cell, collectedBluetoothJson = bluetooth) }

        // 第一阶段刻意使用点位模拟配置：active=true、STILL、无路线、速度 0。
        // 这样 Xposed 端看到的就是起点静止，而不是已经沿路线走了一段。
        val started = locationRepository.startSpoofing(
            context,
            startPoint.lat,
            startPoint.lng,
            "STILL",
            0f,
            now,
            emptyList(),
            false,
            wifi,
            cell,
            bluetooth,
            _uiState.value.mockWifi,
            _uiState.value.mockCell,
            _uiState.value.mockBluetooth,
            _uiState.value.enableJitter
        )
        // 挂起调用期间用户可能已经停止；不要让迟到的静态配置覆盖停止。
        if (!started || _uiState.value.routePlanStage != RoutePlanStage.RUNNING) {
            runCatching { locationRepository.stopSpoofing(context) }
            settingsRepository.isSpoofingActive = false
            _uiState.update {
                it.copy(
                    routePlanStage = RoutePlanStage.READY,
                    routeWaitingToStart = false,
                    isSpoofingActive = false
                )
            }
            if (!started) {
                android.widget.Toast.makeText(
                    context, context.getString(R.string.spoofing_start_failed),
                    android.widget.Toast.LENGTH_LONG
                ).show()
            }
            return@launch
        }
        motionController.onStaticStarted(startPoint.lat, startPoint.lng)
        _uiState.update { it.copy(isSpoofingActive = true) }

        // WiGLE/OpenCellID 在后台补充；第二阶段开始时直接复用。
        routeEnvironmentPrefetchJob?.cancel()
        routeEnvironmentPrefetchJob = viewModelScope.launch {
            routeEnvironmentReplay.prefetch(
                points = pointsToRun,
                localRecords = environmentLocations.value,
                wifiRepository = wifiRepository,
                openCellIdClient = opencellidClient,
                wigleToken = settingsRepository.getWigleApiToken(),
                openCellIdToken = settingsRepository.getOpencellidApiToken()
            )
        }
        } catch (c: CancellationException) {
            throw c
        } catch (t: Throwable) {
            settingsRepository.clearRouteWaitingState()
            _uiState.update {
                it.copy(
                    routePlanStage = RoutePlanStage.READY,
                    routeWaitingToStart = false,
                    isSpoofingActive = false
                )
            }
            runCatching { locationRepository.stopSpoofing(context) }
            android.util.Log.e("LocationSpoofer", "startRouteAtStartPoint failed", t)
        }
    }
}

/** 起点已就位后，第二次点击“开始模拟”才真正沿路线移动。 */
internal fun MainViewModel.startRouteMotion() {
    val state = _uiState.value
    if (!state.routeWaitingToStart || state.routePoints.size < 2) return
    // 先清掉等待标记，避免连续点击重复启动；持久化状态也同步清除。
    settingsRepository.clearRouteWaitingState()
    _uiState.update { it.copy(routeWaitingToStart = false) }
    val preview = routePreviewJob
    routeMotionJob = viewModelScope.launch {
        try {
            preview?.join()
            val current = _uiState.value
            if (current.routePlanStage != RoutePlanStage.RUNNING ||
                current.routePoints.size < 2
            ) return@launch
            startRouteMotionInternal(current)
        } catch (c: CancellationException) {
            throw c
        } catch (t: Throwable) {
            // 启动失败时回到可重试的路线就绪态，并清掉可能残留的静态配置。
            _uiState.update {
                it.copy(
                    routePlanStage = RoutePlanStage.READY,
                    routeWaitingToStart = false,
                    isSpoofingActive = false
                )
            }
            runCatching { locationRepository.stopSpoofing(context) }
            android.util.Log.e("LocationSpoofer", "startRouteMotion failed", t)
        }
    }
}

private suspend fun MainViewModel.startRouteMotionInternal(state: AppState) {
    if (state.routePlanStage != RoutePlanStage.RUNNING) return
    val pointsToRun = state.routePoints
    val startPoint = pointsToRun.first()
    val isLoop = state.routeRunMode == RouteRunMode.LOOP
    val now = System.currentTimeMillis()
    val speed = getEffectiveSpeedMs()

    SpoofingState.startTimestamp = now
    SpoofingState.latitude = startPoint.lat
    SpoofingState.longitude = startPoint.lng
    SpoofingState.simBearing = 0f
    SpoofingState.routeDistanceOffset = 0.0

    val started = locationRepository.startSpoofing(
        context,
        startPoint.lat,
        startPoint.lng,
        if (isLoop) state.routeSimMode.name else "STILL",
        0f,
        now,
        pointsToRun,
        isLoop,
        state.collectedWifiJson,
        state.collectedCellJson,
        state.collectedBluetoothJson,
        state.mockWifi,
        state.mockCell,
        state.mockBluetooth,
        state.enableJitter,
        // 手动路线起步时位置是 STILL（等待用户推摇杆/点播放），
        // native 传感器不能按 speed>0 提前开始走路。
        speedMs = if (isLoop) speed else 0.0,
        stopAtDestination = state.stopAtDestination,
        enableStepSimulation = state.enableStepSimulation,
        stepCadenceSpm = state.stepCadenceSpm,
        isAutoCadence = state.isAutoCadence
    )
    // startSpoofing 是挂起调用；若用户在它返回前已经停止/离开，
    // 不要再让运动控制器把配置写回 active。
    if (!started || _uiState.value.routePlanStage != RoutePlanStage.RUNNING) {
        runCatching { locationRepository.stopSpoofing(context) }
        settingsRepository.isSpoofingActive = false
        _uiState.update {
            it.copy(
                routePlanStage = RoutePlanStage.READY,
                routeWaitingToStart = false,
                isSpoofingActive = false
            )
        }
        if (!started) {
            android.widget.Toast.makeText(
                context, context.getString(R.string.spoofing_start_failed),
                android.widget.Toast.LENGTH_LONG
            ).show()
        }
        return
    }
    val preset = MotionController.SpeedPreset(state.routeSimMode.name, joystickMaxSpeedMs().toDouble())
    // 手动模式同样加载路线，只是以暂停状态开始、由悬浮摇杆控制。
    motionController.onRouteStarted(
        pointsToRun,
        preset,
        state.stopAtDestination,
        now,
        startPaused = !isLoop
    )
    if (!isLoop) locationRepository.setFloatingJoystickVisible(context, true)
    _uiState.update {
        it.copy(isSpoofingActive = true, routeWaitingToStart = false)
    }
}

internal fun MainViewModel.stopRoutePlanning() {
    settingsRepository.isSpoofingActive = false
    mapConfirmJob?.cancel()
    mapConfirmJob = null
    mapMoveJob?.cancel()
    mapMoveJob = null
    settingsRepository.clearRouteWaitingState()
    locationSyncJob?.cancel()
    locationSyncJob = null
    routePreviewJob?.cancel()
    routePreviewJob = null
    routeMotionJob?.cancel()
    routeMotionJob = null
    motionController.onStopped()
    environmentUpdateJob?.cancel()
    routeEnvironmentPrefetchJob?.cancel()
    routeEnvironmentPrefetchJob = null
    _uiState.update { it.copy(routeWaitingToStart = false) }
    viewModelScope.launch {
        locationRepository.stopSpoofing(context)
        _uiState.update {
            it.copy(
                isSpoofingActive = false,
                routePlanStage = RoutePlanStage.IDLE,
                routePoints = emptyList(),
                routeRunMode = RouteRunMode.LOOP,
                routeWaitingToStart = false
            )
        }
    }
}

// 保存位置
internal fun MainViewModel.saveCurrentLocation(name: String) {
    val lng = _uiState.value.longitudeInput.toCoordinateOrNull() ?: return
    val lat = _uiState.value.latitudeInput.toCoordinateOrNull() ?: return
    val state = _uiState.value
    settingsRepository.addSavedLocation(
        SavedLocation(
            name,
            lat,
            lng,
            state.collectedWifiJson,
            state.collectedCellJson,
            // 此前漏了这一段，导致从定位页保存的收藏点丢失蓝牙指纹
            state.collectedBluetoothJson
        )
    )
    _uiState.update { it.copy(savedLocations = settingsRepository.getSavedLocations()) }
}

/** 与卡片标题（LocalDataItem.primaryTitle）保持一致的取名优先级：地名优先，其次备注——
 *  否则收藏成功的 Toast 报的名字会和用户在列表上看到的标题对不上。 */

private fun MainViewModel.resolveFavoriteName(record: com.vincenthzr.locationspoofer.data.db.CompleteLocation): String {
    val lat = record.location.lat
    val lng = record.location.lng
    return when {
        record.location.placeName.isNotBlank() -> record.location.placeName
        record.location.remark.isNotBlank() -> record.location.remark
        else -> String.format(Locale.US, "(%.5f, %.5f)", lat, lng)
    }
}

/** 串行化收藏切换：避免短时间内两次点击的"判断是否已收藏"互相在对方写入落盘前读取，
 *  导致本该互相抵消的两次操作都走进同一个分支。 */

/**
 * 收藏/取消收藏一条采集记录。"本地采集数据源"弹窗和"管理采集数据"页共用同一个入口，
 * 避免两处各自维护一份几乎相同的逻辑而互相漂移。
 */
internal fun MainViewModel.toggleCollectedLocationFavorite(
    locationId: Long,
    onResult: (FavoriteToggleResult) -> Unit
) {
    viewModelScope.launch {
        favoriteToggleMutex.withLock {
            val record = withContext(Dispatchers.IO) {
                environmentDao.getCompleteLocationById(locationId)
            }
            if (record == null) {
                onResult(FavoriteToggleResult.Failed)
                return@withLock
            }

            val lat = record.location.lat
            val lng = record.location.lng
            // 优先按来源 id 关联：这样即便之后编辑了这条采集点的坐标，依然认得出
            // "这是同一条"，不会静默失联。只有老版本写入、没有 sourceLocationId 的
            // 收藏才退回按坐标匹配。删除时会精确匹配 sourceLocationId 或
            // name+lat+lng（见 SettingsManager.isSameSavedLocation），不会波及
            // 同坐标下其他名字/其他来源的收藏。
            val existing = settingsRepository.getSavedLocations().firstOrNull {
                it.sourceLocationId == locationId ||
                    (it.sourceLocationId == null && it.lat == lat && it.lng == lng)
            }

            if (existing != null) {
                settingsRepository.removeSavedLocation(existing)
                _uiState.update { it.copy(savedLocations = settingsRepository.getSavedLocations()) }
                onResult(FavoriteToggleResult.Removed(existing.name))
            } else {
                val name = resolveFavoriteName(record)
                val (wifiJson, cellJson, btJson) = locationToJson(listOf(record), lat, lng)
                settingsRepository.addSavedLocation(
                    SavedLocation(name, lat, lng, wifiJson, cellJson, btJson, sourceLocationId = locationId)
                )
                _uiState.update { it.copy(savedLocations = settingsRepository.getSavedLocations()) }
                onResult(FavoriteToggleResult.Added(name))
            }
        }
    }
}

/**
 * 编辑采集点坐标后，同步更新它对应的收藏记录坐标（按 sourceLocationId 关联），
 * 避免收藏因为坐标变了而找不到关联、变成孤儿数据。老版本收藏（没有 sourceLocationId）
 * 本来就是按坐标关联的独立快照，不受这次编辑影响，这里也不会去动它们。
 */

internal fun MainViewModel.syncFavoriteCoordinateIfExists(locationId: Long, newLat: Double, newLng: Double) {
    val existing = settingsRepository.getSavedLocations()
        .firstOrNull { it.sourceLocationId == locationId } ?: return
    if (existing.lat == newLat && existing.lng == newLng) return
    settingsRepository.removeSavedLocation(existing)
    settingsRepository.addSavedLocation(existing.copy(lat = newLat, lng = newLng))
    _uiState.update { it.copy(savedLocations = settingsRepository.getSavedLocations()) }
}

internal fun MainViewModel.parseWifiCount(wifiJson: String?): Int {
    if (wifiJson.isNullOrBlank()) return 0
    return try {
        val obj = org.json.JSONObject(wifiJson)
        val nearbyCount = obj.optJSONArray(ConfigKeys.NEARBY_WIFI)?.length() ?: 0
        val connectedCount = if (obj.optBoolean(ConfigKeys.IS_CONNECTED, false) && !obj.isNull(ConfigKeys.CONNECTED_WIFI)) 1 else 0
        nearbyCount + connectedCount
    } catch (e: Exception) {
        try {
            org.json.JSONArray(wifiJson).length()
        } catch (e2: Exception) {
            0
        }
    }
}

internal fun MainViewModel.loadSavedLocation(loc: SavedLocation) {
    val wifiCount = parseWifiCount(loc.wifiJson)
    _uiState.update {
        it.copy(
            latitudeInput = String.format(java.util.Locale.US, "%.6f", loc.lat),
            longitudeInput = String.format(java.util.Locale.US, "%.6f", loc.lng),
            collectedWifiJson = loc.wifiJson,
            collectedCellJson = loc.cellJson,
            wifiApCount = wifiCount,
            wifiLoadStatus = if (wifiCount > 0) com.vincenthzr.locationspoofer.data.model.WifiLoadStatus.DONE else com.vincenthzr.locationspoofer.data.model.WifiLoadStatus.IDLE
        )
    }
}

internal fun MainViewModel.removeSavedLocation(location: SavedLocation) {
    settingsRepository.removeSavedLocation(location)
    _uiState.update { it.copy(savedLocations = settingsRepository.getSavedLocations()) }
}

internal fun MainViewModel.addSavedRoute(name: String) {
    val points = _uiState.value.routePoints
    // 统一走 Room 的 saveRoute；旧 SharedPreferences 列表没有 syncId，
    // 会和 Room Flow 双写同一份 uiState，删除时也可能误删同名路线。
    if (points.size >= 2) saveRoute(name, points)
}

internal fun MainViewModel.removeSavedRoute(route: com.vincenthzr.locationspoofer.data.model.SavedRoute) {
    deleteSavedRoute(route)
}

internal fun MainViewModel.loadSavedRoute(route: com.vincenthzr.locationspoofer.data.model.SavedRoute) {
    // 路线正在推进时只换 UI 点集会让 MotionController/框架继续跑旧路线。
    // 必须让用户先停止，避免“界面显示新路线、实际旧路线还在走”。
    if (_uiState.value.routePlanStage == RoutePlanStage.RUNNING ||
        motionController.state.value.mode == MotionController.Mode.ROUTE
    ) {
        android.widget.Toast.makeText(
            context,
            context.getString(R.string.route_stop_before_load),
            android.widget.Toast.LENGTH_SHORT
        ).show()
        return
    }
    _uiState.update {
        it.copy(
            routePoints = route.points,
            routePlanStage = com.vincenthzr.locationspoofer.data.model.RoutePlanStage.READY
        )
    }
}

// 搜索


// 内部工具

/**
 * 路线播放、摇杆（包括悬浮窗摇杆）移动时由进程级 MotionController 推进位置，
 * 这里把位置同步到界面，并按移动距离刷新周边环境数据；悬浮窗切换的速度档位也同步回界面。
 */
internal fun MainViewModel.observeMotionController() {
    viewModelScope.launch {
        motionController.state.collect { st ->
            if (!st.active) return@collect
            if (st.mode == MotionController.Mode.ROUTE || st.mode == MotionController.Mode.MANUAL) {
                updatePosition(st.lat, st.lng, st.bearing)
                // 只有路线/摇杆运动态才同步预设；第一阶段的 STATIC 起点模拟
                // 使用的是 MotionController 默认预设，不能把用户刚选的
                // 3.0/5.5/15 m/s 覆盖回 WALKING。
                val simMode = SimMode.entries.firstOrNull { it.name == st.preset.name }
                if (simMode != null && simMode != _uiState.value.routeSimMode) {
                    _uiState.update { it.copy(routeSimMode = simMode) }
                }
            }
        }
    }

    // 到达终点（stopAtDestination=true）：MotionController 已经把框架配置
    // 通过 writeStatic 切成终点 STILL，这里只同步界面状态并提示。
    viewModelScope.launch {
        motionController.arrivals.collect {
            if (!settingsRepository.isSpoofingActive) return@collect
            _uiState.update {
                it.copy(
                    routePlanStage = RoutePlanStage.IDLE,
                    routePoints = emptyList(),
                    routeWaitingToStart = false,
                    isSpoofingActive = true
                )
            }
            android.widget.Toast.makeText(
                context,
                context.getString(R.string.stop_at_destination_desc_on),
                android.widget.Toast.LENGTH_LONG
            ).show()
        }
    }
}

/** 更新当前模拟位置到 UI 和 SpoofingState */
private fun MainViewModel.updatePosition(lat: Double, lng: Double, bearing: Float) {
    _uiState.update {
        it.copy(
            latitudeInput = String.format(Locale.US, "%.6f", lat),
            longitudeInput = String.format(Locale.US, "%.6f", lng),
            simBearing = bearing,
            showCoordinateError = false
        )
    }
    SpoofingState.latitude = lat
    SpoofingState.longitude = lng
    SpoofingState.simBearing = bearing

    // 检查是否需要查询数据库（例如：自上次查询以来移动了超过 20 米）
    val dLat = Math.toRadians(lat - lastDbQueryLat)
    val dLng = Math.toRadians(lng - lastDbQueryLng)
    val a = kotlin.math.sin(dLat / 2).let { it * it } + kotlin.math.cos(
        Math.toRadians(lastDbQueryLat)
    ) * kotlin.math.cos(Math.toRadians(lat)) * kotlin.math.sin(dLng / 2).let { it * it }
    val distance =
        2 * 6378137.0 * kotlin.math.atan2(kotlin.math.sqrt(a), kotlin.math.sqrt(1 - a))

    val coveredRouteId = com.vincenthzr.locationspoofer.data.model.CollectionRouteMatcher.routeAt(
        collectionRoutes.value,
        com.vincenthzr.locationspoofer.utils.CoordinateUtils.LatLng(lat, lng),
        _uiState.value.selectedCollectionRouteId
    )?.route?.id
    // 跨越路线边界立即切换环境；沿途按 5 米刷新，让 Wi-Fi/基站随位置变化。
    if (distance > 5.0 || coveredRouteId != lastEnvironmentRouteId) {
        lastEnvironmentRouteId = coveredRouteId
        lastDbQueryLat = lat
        lastDbQueryLng = lng

        environmentUpdateJob?.cancel()
        environmentUpdateJob = viewModelScope.launch {
            val records = environmentRecordsAt(lat, lng)
            val fallback = locationToJson(records, lat, lng)
            val replayWifi = routeEnvironmentReplay.buildWifiJson(lat, lng)
            val replayCell = routeEnvironmentReplay.buildCellJson(lat, lng)
            val wifi = replayWifi.takeIf { it != "{}" } ?: fallback.first
            val cell = replayCell.takeIf { it != "[]" } ?: fallback.second
            android.util.Log.i(
                "EnvReplay",
                "route update: ${routeEnvironmentReplay.summary()} " +
                    "wifi=${runCatching { org.json.JSONObject(wifi).optJSONArray(ConfigKeys.NEARBY_WIFI)?.length() ?: 0 }.getOrDefault(0)} " +
                    "cell=${runCatching { org.json.JSONArray(cell).length() }.getOrDefault(0)}"
            )
            locationRepository.updateEnvironment(wifi, cell, fallback.third)
        }
    }
}

